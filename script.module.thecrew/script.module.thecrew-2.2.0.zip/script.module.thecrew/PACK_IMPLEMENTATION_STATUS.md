This document has been moved to `docs/PACK_IMPLEMENTATION_STATUS.md`.

Please see `docs/PACK_IMPLEMENTATION_STATUS.md` for details.

### 1. Pack Filter Utilities (source_utils.py)
**Status:** ✅ COMPLETE

Added the following functions to `lib/resources/lib/modules/source_utils.py`:

- `aliases_to_array(aliases, filter=None)` - Convert aliases to array format
- `release_title_format(release_title)` - Format release title for filtering
- `filter_season_pack(show_title, aliases, year, season, release_title)` - Validate season packs
  - Returns: `(valid, episode_start, episode_end)`
  - Detects full season packs and partial episode range packs
  - Filters out single episodes and wrong seasons

- `filter_show_pack(show_title, aliases, imdb, year, season, release_title, total_seasons)` - Validate show packs
  - Returns: `(valid, last_season)`
  - Detects complete series packs
  - Handles season ranges (1-5, 1 to 9, etc.)
  - Filters out single seasons

**Constants Added:**
- `SEASON_LIST` - Spelled out season numbers (one, two, three...)
- `SEASON_ORDINAL_LIST` - Ordinal season numbers (first, second, third...)
- `SEASON_ORDINAL2_LIST` - Short ordinal numbers (1st, 2nd, 3rd...)

### 2. Pack Scraper Template
**Status:** ✅ COMPLETE

Created comprehensive documentation in `PACK_SCRAPER_TEMPLATE.md`:
- Detailed explanation of pack types (season, partial, show)
- Complete `sources_packs()` method implementation guide
- Pack validation examples
- Search query patterns
- Metadata structure requirements
- PirateBay example implementation
- Testing and troubleshooting guide

## 🔄 Needs Implementation

### 3. Sources.py Infrastructure

**Current State:**
The Crew uses a thread-based source calling system:
- Each scraper runs in a separate thread
- `get_movie_source()` handles movie scraping (line ~820)
- Episode scraping happens inline (line ~1050-1150)
- CocoScrapers adapter already exists (lines 1115-1128, 875-889)

**What Needs to be Added:**

#### Option A: Add Pack Calling to Existing Thread Worker (Recommended)

After line 1138 in sources.py (after standard sources() call), add:

```python
# After standard single episode scraping, check for pack support
try:
    # Check if scraper supports packs
    if hasattr(call, 'pack_capable') and getattr(call, 'pack_capable', False):
        if hasattr(call, 'sources_packs'):
            # Build pack data
            pack_data = {
                'tvshowtitle': tvshowtitle,
                'season': season,
                'episode': episode,
                'year': year,
                'imdb': imdb,
                'tmdb': tmdb,
                'aliases': aliases
            }

            # Get total seasons for show pack support
            total_seasons = meta.get('total_seasons', 0) if meta else 0

            # Call season pack scraper
            pack_sources = call.sources_packs(pack_data, self.hostDict, search_series=False)
            if pack_sources:
                for i in pack_sources:
                    i.update({'provider': source})
                self.sources.extend(pack_sources)

            # Optionally call show pack scraper (less common)
            # if total_seasons > 0:
            #     show_pack_sources = call.sources_packs(pack_data, self.hostDict,
            #                                            search_series=True, total_seasons=total_seasons)
            #     if show_pack_sources:
            #         for i in show_pack_sources:
            #             i.update({'provider': source})
            #         self.sources.extend(show_pack_sources)
except:
    pass
```

#### Option B: Create Separate Pack Thread Workers

Create a second set of threads specifically for pack scraping that runs in parallel. This would require:
1. Filter sourceDict for pack_capable sources
2. Create parallel pack threads
3. Merge results

**Recommendation:** Option A is simpler and sufficient. Packs can run in the same thread as single episode scraping.

### 4. Pack Resolution (player.py/sources.py)

**Location:** `sourcesResolve()` method (need to find and update)

**What to Add:**
```python
def sourcesResolve(self, item, info=False):
    # ... existing code ...

    # Check if this is a pack source
    if item.get('package'):
        # Pack resolution logic
        package_type = item.get('package')  # 'season' or 'show'

        if package_type == 'season':
            # For season packs, debrid service will list files
            # User selects the correct episode file
            # Or auto-select based on episode number
            season_num = item.get('season')
            episode_num = item.get('episode')

        elif package_type == 'show':
            # For show packs, need season and episode
            season_num = item.get('season')
            episode_num = item.get('episode')
            last_season = item.get('last_season')

        # Debrid services (RD, PM, AD) all support file selection from torrents
        # The existing debrid.resolver() should handle this, just needs pack context
```

**Note:** The existing debrid resolver may already handle this automatically. Real-Debrid, Premiumize, and AllDebrid all present file selection dialogs for multi-file torrents. The pack metadata just helps with filtering and auto-selection.

### 5. Update Existing Scrapers

**Scrapers to Update:**
- `lib/resources/lib/sources/en_tor/piratebay.py`
- `lib/resources/lib/sources/en_tor/1337x.py`
- `lib/resources/lib/sources/en_tor/limetorrents.py`
- `lib/resources/lib/sources/en_tor/bitlord.py`
- `lib/resources/lib/sources/en_tor/torrentgalaxy.py`
- Any other torrent scrapers

**For Each Scraper:**
1. Add `pack_capable = True` class variable
2. Implement `sources_packs()` method following the template
3. Test with known pack releases

## 📋 Implementation Priority

1. **CRITICAL** - Add pack calling to sources.py thread worker
   - Without this, pack scrapers won't be called
   - Estimated time: 30 minutes

2. **HIGH** - Update 1-2 existing scrapers as proof of concept
   - Start with piratebay.py (most reliable)
   - Then 1337x.py
   - Estimated time: 1-2 hours per scraper

3. **MEDIUM** - Test pack resolution with debrid services
   - May work automatically with existing code
   - If not, add file selection hints
   - Estimated time: 1 hour

4. **LOW** - Update remaining scrapers
   - Once pattern is proven, roll out to all
   - Estimated time: 30 minutes per scraper

## 🧪 Testing Checklist

- [ ] Season pack appears in source list
- [ ] Partial season pack detected with episode_start/episode_end
- [ ] Show pack detected with last_season
- [ ] Pack metadata passed to player
- [ ] Debrid service can resolve pack files
- [ ] Correct episode file selected from pack
- [ ] Pack source caching works
- [ ] Filter functions correctly reject false positives
- [ ] Multiple packs from same scraper handled
- [ ] Pack priority/sorting works with quality detection

## 📝 Notes

- CocoScrapers already has full pack support (16 pack-capable scrapers loaded)
- The Crew's native scrapers need pack support added manually
- Pack support is optional - scrapers work fine without it
- Packs improve user experience by reducing torrent count
- Quality: One 1080p season pack > 10 separate 1080p episodes
- Debrid cache rate is higher for popular packs than individual episodes

## ⚠️ Caveats

- Pack scraping adds ~100-500ms per scraper due to extra searches
- Need to handle partial packs (episodes 1-8 of 12)
- Show packs for ongoing series may be incomplete
- Some sites have poor pack naming (filter_season_pack helps)
- Pack size can be large (50GB+) - need debrid with good quota

## 🚀 Quick Start Guide

**To add pack support to a scraper:**

1. Open the scraper file (e.g., `piratebay.py`)
2. Add `pack_capable = True` after class definition
3. Copy the `sources_packs()` template from `PACK_SCRAPER_TEMPLATE.md`
4. Adapt the search queries to your scraper's API
5. Use `filter_season_pack()` to validate results
6. Return sources with `package`, `last_season`, or `episode_start`/`episode_end` metadata
7. Test with a popular TV show (Breaking Bad, Game of Thrones, etc.)

**Example commit message:**
```
Add pack support to piratebay scraper

- Set pack_capable = True
- Implement sources_packs() method
- Support season packs and show packs
- Use source_utils.filter_season_pack() for validation
- Return pack metadata (package, last_season, episode ranges)
```
