This document has been moved to `docs/PACK_SCRAPER_TEMPLATE.md`.

Please see `docs/PACK_SCRAPER_TEMPLATE.md` for details.

## What are Packs?

Packs are torrent releases that contain multiple episodes:
- **Season Packs**: All episodes of a single season (e.g., "Breaking.Bad.S01.1080p.BluRay")
- **Partial Season Packs**: Episode ranges (e.g., "Breaking.Bad.S01E01-E08.1080p")
- **Show Packs**: Complete series with all seasons (e.g., "Breaking.Bad.Complete.Series")

## Scraper Structure

```python
class source:
    priority = 3
    pack_capable = True  # Enable pack support
    hasMovies = True
    hasEpisodes = True

    def __init__(self):
        self.base_link = 'https://example.com'
        # ... other initialization

    def sources(self, data, hostDict):
        """Standard single episode scraping"""
        # Your existing episode scraping code
        pass

    def sources_packs(self, data, hostDict, search_series=False, total_seasons=None, bypass_filter=False):
        """
        Pack scraping - separate method for season/show packs.

        Args:
            data (dict): Metadata dict with keys:
                - tvshowtitle: Show title
                - season: Season number
                - episode: Episode number (for context, not used in search)
                - year: Show year
                - imdb: IMDB ID
                - tmdb: TMDB ID
                - aliases: List of alternative titles
            hostDict (dict): Host dictionary
            search_series (bool): If True, search for complete show packs
            total_seasons (int): Total number of seasons (required for show packs)
            bypass_filter (bool): If True, skip pack validation filters

        Returns:
            list: List of source dicts with pack metadata
        """
        sources = []
        try:
            # Extract metadata
            title = data['tvshowtitle'].replace('&', 'and')
            season = data['season']
            year = data['year']
            aliases = data.get('aliases', [])
            imdb = data['imdb']

            # Format season numbers
            season_x = str(season)  # "1"
            season_xx = season_x.zfill(2)  # "01"

            # Build search queries
            queries = []
            if search_series:
                # Complete series pack queries
                queries = [
                    f"{title} Season",
                    f"{title} Complete",
                    f"{title} Series"
                ]
            else:
                # Season pack queries
                queries = [
                    f"{title} S{season_xx}",
                    f"{title} Season {season_x}",
                    f"{title} Season {season_x} Complete"
                ]

            # Scrape results for each query
            for query in queries:
                results = self.search_torrents(query)  # Your scraper's search method

                for result in results:
                    name = result['name']
                    url = result['magnet'] or result['url']
                    seeders = result.get('seeders', 0)
                    size = result.get('size', 0)

                    # Validate pack using filter functions
                    episode_start, episode_end = 0, 0

                    if not search_series:
                        # Season pack validation
                        if not bypass_filter:
                            from resources.lib.modules import source_utils
                            valid, episode_start, episode_end = source_utils.filter_season_pack(
                                title, aliases, year, season_x, name)
                            if not valid:
                                continue
                        package = 'season'
                    else:
                        # Show pack validation
                        if not bypass_filter:
                            from resources.lib.modules import source_utils
                            valid, last_season = source_utils.filter_show_pack(
                                title, aliases, imdb, year, season_x, name, total_seasons)
                            if not valid:
                                continue
                        package = 'show'

                    # Get quality and info
                    quality, info = source_utils.get_release_quality(name, url)

                    # Build source dict
                    item = {
                        'provider': 'your_scraper_name',
                        'source': 'torrent',
                        'seeders': seeders,
                        'hash': self.extract_hash(url),  # Extract hash from magnet
                        'name': name,
                        'quality': quality,
                        'language': 'en',
                        'url': url,
                        'info': info,
                        'direct': False,
                        'debridonly': True,
                        'size': size,
                        'package': package  # 'season' or 'show'
                    }

                    # Add pack-specific metadata
                    if search_series:
                        item['last_season'] = last_season
                    elif episode_start:
                        # Partial season pack (e.g., episodes 1-8)
                        item['episode_start'] = episode_start
                        item['episode_end'] = episode_end

                    sources.append(item)

            return sources
        except:
            from resources.lib.modules import log_utils
            log_utils.error()
            return sources
```

## Key Points

### 1. Pack Validation

Always use the filter functions to validate packs:

```python
# For season packs
valid, ep_start, ep_end = source_utils.filter_season_pack(
    title, aliases, year, season, release_name)

# For show packs
valid, last_season = source_utils.filter_show_pack(
    title, aliases, imdb, year, season, release_name, total_seasons)
```

### 2. Pack Metadata

Pack sources must include:
- `package`: Either `'season'` or `'show'`
- `last_season`: For show packs, the last season included
- `episode_start`/`episode_end`: For partial season packs (optional)

### 3. Search Queries

Good pack search patterns:
```python
# Season packs
f"{title} S{season_xx}"           # "Breaking.Bad.S01"
f"{title} Season {season_x}"      # "Breaking.Bad.Season.1"
f"{title} S{season_xx} Complete"  # "Breaking.Bad.S01.Complete"

# Show packs
f"{title} Complete"               # "Breaking.Bad.Complete"
f"{title} Series"                 # "Breaking.Bad.Series"
f"{title} All Seasons"            # "Breaking.Bad.All.Seasons"
```

### 4. Quality Detection

Use the standard quality detection:
```python
quality, info = source_utils.get_release_quality(release_name, url)
```

## Example: PirateBay Pack Scraper

```python
def sources_packs(self, data, hostDict, search_series=False, total_seasons=None, bypass_filter=False):
    sources = []
    try:
        from resources.lib.modules import source_utils

        title = data['tvshowtitle'].replace('&', 'and')
        season = data['season']
        year = data['year']
        aliases = data.get('aliases', [])
        imdb = data['imdb']

        season_x = str(season)
        season_xx = season_x.zfill(2)

        if search_series:
            queries = [f"{title} Complete", f"{title} Series"]
        else:
            queries = [f"{title} S{season_xx}", f"{title} Season {season_x}"]

        for query in queries:
            url = f"{self.base_link}/search/{query}/1/99/200"  # Category 200 = TV
            html = client.request(url)

            rows = client.parseDOM(html, 'tr')
            for row in rows[1:]:  # Skip header
                try:
                    # Extract torrent info
                    title_link = client.parseDOM(row, 'a', ret='href', attrs={'class': 'detLink'})[0]
                    name = client.parseDOM(row, 'a', attrs={'class': 'detLink'})[0]
                    magnet = client.parseDOM(row, 'a', ret='href', attrs={'title': 'Download this torrent using magnet'})[0]

                    seeds = client.parseDOM(row, 'td', attrs={'align': 'right'})[0]

                    # Validate pack
                    episode_start, episode_end = 0, 0
                    if not search_series:
                        valid, episode_start, episode_end = source_utils.filter_season_pack(
                            title, aliases, year, season_x, name)
                        if not valid: continue
                        package = 'season'
                    else:
                        valid, last_season = source_utils.filter_show_pack(
                            title, aliases, imdb, year, season_x, name, total_seasons)
                        if not valid: continue
                        package = 'show'

                    quality, info = source_utils.get_release_quality(name, magnet)

                    item = {
                        'provider': 'piratebay',
                        'source': 'torrent',
                        'seeders': int(seeds),
                        'hash': re.search(r'btih:([a-zA-Z0-9]+)', magnet).group(1),
                        'name': name,
                        'quality': quality,
                        'language': 'en',
                        'url': magnet,
                        'info': info,
                        'direct': False,
                        'debridonly': True,
                        'package': package
                    }

                    if search_series:
                        item['last_season'] = last_season
                    elif episode_start:
                        item.update({'episode_start': episode_start, 'episode_end': episode_end})

                    sources.append(item)
                except:
                    pass

        return sources
    except:
        from resources.lib.modules import log_utils
        log_utils.error()
        return sources
```

## Testing Your Pack Scraper

1. **Enable pack capability:**
   ```python
   pack_capable = True
   ```

2. **Test with known pack releases:**
   - Search for popular shows with complete packs
   - Verify season packs are detected for recent seasons
   - Check show packs for completed series

3. **Check filter accuracy:**
   - Single episodes should be filtered out
   - Season packs should only match the correct season
   - Partial packs should have episode_start/episode_end set

4. **Verify metadata:**
   - `package` field is set correctly
   - `last_season` is accurate for show packs
   - Episode ranges are detected for partial packs

## Troubleshooting

**Pack not appearing:**
- Check if `pack_capable = True` is set
- Verify `sources_packs()` method exists
- Ensure sources.py is calling pack scrapers

**Wrong packs returned:**
- Review filter_season_pack() logic
- Check title/alias matching
- Verify season number formatting

**Partial packs not working:**
- Ensure episode range regex is matching
- Check episode_start/episode_end are set
- Verify pack player can handle partial packs
