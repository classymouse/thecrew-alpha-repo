This document has been moved to `docs/SCROBBLE_QUEUE_IMPLEMENTATION.md`.

Please see `docs/SCROBBLE_QUEUE_IMPLEMENTATION.md` for details.

## Key Changes

### 1. Database Schema (`trakt.py`)
Added new `scrobble_queue` table:
```sql
CREATE TABLE IF NOT EXISTS scrobble_queue (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    media_type TEXT,
    imdb TEXT,
    season TEXT,
    episode TEXT,
    progress REAL,
    action TEXT,
    timestamp TEXT,
    UNIQUE(media_type, imdb, season, episode)
)
```

The UNIQUE constraint ensures only the latest scrobble event for each piece of content is kept in the queue.

### 2. New Functions (`trakt.py`)

#### `queue_scrobble(media_type, imdb, watched_percent, action, season='', episode='')`
- Queues a scrobble event instead of making immediate API call
- Replaces existing queue entry for same content (keeps only latest progress)
- Returns immediately for better performance

#### `process_scrobble_queue(force=False)`
- Processes all queued scrobble events
- Makes actual API calls to Trakt
- Removes successfully processed items from queue
- Keeps failed items for retry on next run

#### Updated `scrobbleMovie()` and `scrobbleEpisode()`
- Added `use_queue=True` parameter (defaults to queuing)
- Set `use_queue=False` for immediate API call when needed
- Backward compatible with existing code

### 3. Background Service (`service.py`)

#### Updated `TraktMonitor` class:
- Processes scrobble queue every **5 minutes**
- Uses 1-minute intervals to check queue more frequently
- Full Trakt sync still runs every hour
- Processes remaining queue items before service exit

```python
FIVE_MINUTES = 60 * 5  # 300 seconds
```

### 4. Player Integration (`player.py`)

#### `update_time()` function enhanced:
- Queues scrobble events during playback
- On `stop` action: immediately processes queue to ensure progress is saved
- This ensures resume position is available immediately when returning to content

## Benefits

### 1. Reduced API Calls
- **Before**: 3+ API calls per movie (start, pause, resume, stop)
- **After**: 1 API call per 5 minutes maximum, typically 1-2 total

### 2. Better Resume Time Handling
- Queue is processed immediately when user stops playback
- Ensures resume position is saved to Trakt quickly
- Local bookmarks still save immediately (no delay)

### 3. Improved Performance
- No waiting for API calls during playback
- Reduces network overhead
- Batched processing is more efficient

### 4. Resilience
- Failed API calls are retried automatically
- Queue persists across Kodi restarts
- No data loss if network is temporarily unavailable

## Configuration

### Queue Processing Interval
Default: 5 minutes (configurable in `service.py`)
```python
FIVE_MINUTES = 60 * 5
```

### Immediate Processing
Queue is processed immediately on:
- Playback stop (ensures resume time is saved)
- Service shutdown (clears remaining items)
- Manual call to `process_scrobble_queue(force=True)`

## Database Location
Queue is stored in the Trakt sync database:
```python
control.traktsyncFile  # Same as other Trakt data
```

## Backward Compatibility
- Existing code continues to work
- Can force immediate API calls by passing `use_queue=False`:
  ```python
  trakt.scrobbleMovie(imdb, percent, 'pause', use_queue=False)
  ```

## Testing
1. Play a movie/episode
2. Pause several times - no immediate API calls
3. Check logs: scrobbles are queued
4. **Indicators show watched status immediately** (before 5-minute sync)
5. Wait 5 minutes or stop playback
6. Check logs: queue is processed and sent to Trakt
7. Resume same content - position is restored correctly

## Real-Time Indicators

### Problem Solved
Previously, indicators (watched/unwatched icons) only updated after the queue was processed every 5 minutes. This caused confusion where users would finish watching something but it wouldn't show as watched for up to 5 minutes.

### Solution
Added real-time indicator functions that merge queue data with Trakt data:

#### `get_queued_indicators_movies()`
- Returns list of movie IMDB IDs queued as watched (progress >= 92%)
- Merged with Trakt watched list in `syncMovies()`
- Movies show as watched **immediately** after finishing

#### `get_queued_indicators_episodes()`
- Returns dict of episodes queued as watched (progress >= 92%)
- Merged with Trakt watched list in `syncTVShows()`
- Episodes show as watched **immediately** after finishing

#### `get_queued_progress(media_type, imdb, season, episode)`
- Returns current progress percentage from queue
- Used in `bookmarks.get()` to show real-time resume points
- Resume indicators update **immediately** on pause/stop

### How It Works
1. User finishes movie (progress >= 92%)
2. Scrobble queued with action='stop'
3. `syncMovies()` calls `get_queued_indicators_movies()`
4. Queued movies merged with Trakt data
5. Movie shows as watched **immediately** in UI
6. After 5 minutes, queue processes and syncs to Trakt
7. Next refresh pulls from Trakt (queue entry removed)

### Database Queries
All indicator queries check the queue first:
```python
# Movies marked as watched in queue
SELECT DISTINCT imdb FROM scrobble_queue
WHERE media_type='movie' AND progress >= 92 AND action='stop'

# Episodes marked as watched in queue
SELECT imdb, season, episode FROM scrobble_queue
WHERE media_type='episode' AND progress >= 92 AND action='stop'

# Progress for specific item
SELECT progress FROM scrobble_queue
WHERE media_type=? AND imdb=? [AND season=? AND episode=?]
```

## Logs
Look for these log entries:
- `[Trakt] Queued scrobble:` - When event is queued
- `[TraktMonitor] Processing scrobble queue` - Every 5 minutes
- `[Trakt] Processing X queued scrobble events` - When queue is processed
- `[Trakt] Processed scrobble:` - When API call succeeds
- `[Player] Processing scrobble queue immediately on stop` - When playback stops
- `[Trakt] Movie indicators: X from Trakt + Y queued = Z total` - Real-time indicator merge
- `[Bookmarks] Found queued progress X% for [media_type] [imdb]` - Real-time progress lookup

## Future Enhancements
- Add setting to configure queue processing interval
- Add manual "Sync Now" button to force immediate processing
- Add statistics showing API call reduction
- Consider batch API endpoints if Trakt adds support
