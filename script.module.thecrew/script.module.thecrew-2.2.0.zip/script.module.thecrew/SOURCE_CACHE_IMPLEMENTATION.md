This document has been moved to `docs/SOURCE_CACHE_IMPLEMENTATION.md`.

Please see `docs/SOURCE_CACHE_IMPLEMENTATION.md` for details.

## Features

### 1. **Automatic Caching**
- All scraped sources are automatically cached after a successful scrape
- Cache is transparent - no user intervention needed
- Works for both movies and TV episodes

### 2. **Configurable Settings**
Located in Add-on Settings → Providers:

- **Enable Source Cache**: Toggle caching on/off (default: enabled)
- **Cache Duration**: Set how long sources remain cached (5-60 minutes, default: 15)

### 3. **Smart Cache Management**
- Automatic expiration based on configured duration
- Periodic cleanup of expired entries (runs randomly to avoid performance impact)
- Separate cache keys for movies vs episodes (imdb_tmdb_movie vs imdb_tmdb_s01e05)

## Use Cases

### Scenario 1: Re-selecting Sources
**Problem**: User views sources for a movie, doesn't like the first choice, goes back and selects sources again.

**Before**: Full scrape takes 15-30 seconds again
**After**: Instant retrieval from cache

### Scenario 2: Episode Binge Watching
**Problem**: User watches multiple episodes of a show. If they accidentally close the player and need to restart, scraping takes 15-30 seconds.

**Before**: Must wait for full scrape every time
**After**: Cached sources available instantly within the cache window

### Scenario 3: Quality Comparison
**Problem**: User wants to compare different quality sources (4K vs 1080p) for the same content.

**Before**: Must wait for full scrape each time
**After**: Can quickly switch between different sources from cache

## Technical Details

### Database Schema
New table `source_cache` in `providers.13.db`:
```sql
CREATE TABLE source_cache (
    cache_key TEXT PRIMARY KEY,
    imdb_id TEXT,
    tmdb_id TEXT,
    season TEXT,
    episode TEXT,
    sources_json TEXT,  -- JSON serialized source list
    cached_at INTEGER,  -- Unix timestamp
    UNIQUE(cache_key)
);
```

### Cache Key Format
- **Movies**: `sources_{imdb}_{tmdb}_movie`
- **Episodes**: `sources_{imdb}_{tmdb}_s{season}e{episode}`

Example: `sources_tt0104431_772_movie` for Home Alone 2

### Performance Impact

**Cache Hit** (source lookup from cache):
- Time: < 0.1 seconds
- No network requests
- No debrid API calls

**Cache Miss** (normal scraping):
- Time: 15-30 seconds (unchanged)
- Full scraping process runs
- Results cached for next time

### Logging

All cache operations are logged with `[SourceCache]` prefix:
- `Cache HIT for sources_tt0104431_772_movie, age: 245s / 900s`
- `Cache MISS for sources_tt0104431_772_movie`
- `Cache EXPIRED for sources_tt0104431_772_movie, age: 1005s > 900s`
- `Cached 47 sources for sources_tt0104431_772_movie`

## Configuration Recommendations

### Conservative (Bandwidth Sensitive)
- Cache Duration: 30-60 minutes
- Best for: Users with limited bandwidth or slow connections

### Balanced (Recommended)
- Cache Duration: 15 minutes (default)
- Best for: Most users - good balance of freshness vs performance

### Aggressive (Always Fresh)
- Cache Duration: 5 minutes
- Best for: Users who want the freshest sources but still benefit from quick re-selections

### Disabled
- Turn off "Enable Source Cache"
- Best for: Users who always want fresh scrapes (not recommended)

## Benefits

1. **Faster UX**: Instant source retrieval for repeated lookups
2. **Reduced Load**: Less strain on scrapers and debrid services
3. **Better Experience**: Encourages users to explore different sources without penalty
4. **Episode Watching**: Seamless binge-watching experience if player is restarted

## Implementation Notes

- Cache is checked BEFORE any scraping begins
- Only successful scrapes with results are cached
- Empty results are NOT cached (always scrape fresh)
- Cache survives Kodi restarts (stored in database)
- Thread-safe database operations
- JSON serialization preserves all source attributes

## Future Enhancements

Potential additions (not currently implemented):
- Manual cache clearing action in settings
- Cache statistics (hits/misses)
- Per-scraper cache control
- Cache warming (pre-fetch for playlist)
