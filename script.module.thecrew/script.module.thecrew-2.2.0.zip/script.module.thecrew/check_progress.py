import sqlite3

conn = sqlite3.connect('C:/Users/fvanb/AppData/Roaming/Kodi/userdata/addon_data/plugin.video.thecrew/traktsync.db')
cursor = conn.cursor()

# Check progress table schema
cursor.execute("PRAGMA table_info(progress)")
cols = cursor.fetchall()
print('Progress table columns:')
for col in cols:
    print(f'  {col[1]} ({col[2]})')

print('\n' + '='*60 + '\n')

# Check GoT S1E01 with different ID fields
print('GoT S1E01 lookup attempts:')
print('\n1. By imdb (episode IMDB):')
cursor.execute("SELECT imdb, showimdb, season, episode, resume_point FROM progress WHERE imdb = 'tt1480055' AND season = 1 AND episode = 1")
row = cursor.fetchone()
if row:
    print(f'   Found: episode_imdb={row[0]}, show_imdb={row[1]}, S{row[2]}E{row[3]}, progress={row[4]}%')
else:
    print('   NOT FOUND')

print('\n2. By showimdb (show IMDB):')
cursor.execute("SELECT imdb, showimdb, season, episode, resume_point FROM progress WHERE showimdb = 'tt0944947' AND season = 1 AND episode = 1")
row = cursor.fetchone()
if row:
    print(f'   Found: episode_imdb={row[0]}, show_imdb={row[1]}, S{row[2]}E{row[3]}, progress={row[4]}%')
else:
    print('   NOT FOUND')

conn.close()
