"""
Top-level compatibility wrapper for `cfscrape` imports.

Some external scrapers import `cfscrape` as a top-level module. Prefer the
local `resources.lib.modules.cfscrape` implementation (The Crew), then
`gearsscrapers.modules.cfscrape` (external addon). If neither is available,
provide a minimal safe stub so tests and import-time code do not crash.
"""

import logging

log = logging.getLogger(__name__)


def _expose_from_module(mod):
    """Expose selected names from an existing cfscrape implementation into this module."""
    for name in ("create_scraper", "get_cookie_string", "CloudScraper"):
        if hasattr(mod, name):
            globals()[name] = getattr(mod, name)

    # Also import other public names from the implementation for completeness
    for key, val in vars(mod).items():
        if not key.startswith("_") and key not in globals():
            globals()[key] = val


# Try The Crew's own cfscrape implementation first
try:
    import resources.lib.modules.cfscrape as _src
    # alias the underlying implementation as top-level cfscrape for simplicity
    import sys as _sys
    _sys.modules['cfscrape'] = _src
    log.debug("cfscrape: using resources.lib.modules.cfscrape (aliased)")
except Exception as e1:
    log.debug(f"cfscrape: resources copy not available: {e1}")
    # Fall back to gearsscrapers copy if present
    try:
        import gearsscrapers.modules.cfscrape as _src
        import sys as _sys
        _sys.modules['cfscrape'] = _src
        log.debug("cfscrape: using gearsscrapers.modules.cfscrape (aliased)")
    except Exception as e2:
        log.debug(f"cfscrape: gearsscrapers copy not available: {e2}")
        # Minimal stub implementation sufficient for tests and to avoid ImportError
        class _DummyCloudScraper:
            @classmethod
            def create_scraper(cls, *a, **k):
                class _S:
                    def get(self, *a, **k):
                        # Return an object with a `.text` attr (common usage by providers)
                        class _R:
                            text = ""

                        return _R()

                return _S()

            @classmethod
            def get_cookie_string(cls, *a, **k):
                return ("", "")

        # expose minimal functions expected by providers
        create_scraper = _DummyCloudScraper.create_scraper
        get_cookie_string = _DummyCloudScraper.get_cookie_string
        import sys as _sys
        # assign this module object into sys.modules so `import cfscrape` resolves here
        _sys.modules['cfscrape'] = _sys.modules.get('cfscrape', _sys.modules.get(__name__))


# make sure imports like `from cfscrape import create_scraper` still work
__all__ = ["create_scraper", "get_cookie_string", "CloudScraper"]
