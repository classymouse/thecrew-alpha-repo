"""
ISO to GMT Time Converter Class

Provides utilities for converting between ISO 8601 formatted strings and GMT (UTC) datetime objects.
Handles timezone-aware conversions safely.

Usage:
    converter = ISOGMTConverter()
    gmt_dt = converter.iso_to_gmt("2023-10-05T14:30:00Z")
    iso_str = converter.gmt_to_iso(gmt_dt)
"""

from datetime import datetime, timezone
from typing import Optional


class ISOGMTConverter:
    """
    Class for converting between ISO 8601 strings and GMT (UTC) datetime objects.
    All operations assume GMT/UTC as the reference timezone.
    """

    def __init__(self):
        """Initialize the converter. No special setup required."""
        pass

    def iso_to_gmt(self, iso_str: str) -> Optional[datetime]:
        """
        Convert an ISO 8601 formatted string to a GMT (UTC) datetime object.

        Args:
            iso_str: ISO 8601 string, e.g., "2023-10-05T14:30:00Z" or "2023-10-05T14:30:00+00:00"

        Returns:
            datetime object in GMT/UTC, or None if parsing fails.
        """
        try:
            # Parse ISO string; fromisoformat handles most formats, but ensure UTC
            dt = datetime.fromisoformat(iso_str.replace('Z', '+00:00'))
            # Convert to UTC if not already
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            else:
                dt = dt.astimezone(timezone.utc)
            return dt
        except (ValueError, TypeError) as e:
            print(f"Error parsing ISO string '{iso_str}': {e}")
            return None

    def gmt_to_iso(self, gmt_dt: datetime, include_microseconds: bool = False) -> Optional[str]:
        """
        Convert a GMT (UTC) datetime object to an ISO 8601 formatted string.

        Args:
            gmt_dt: datetime object (assumed to be in GMT/UTC; will convert if not)
            include_microseconds: If True, include microseconds in the output

        Returns:
            ISO 8601 string, e.g., "2023-10-05T14:30:00Z", or None if conversion fails.
        """
        try:
            # Ensure the datetime is in UTC
            if gmt_dt.tzinfo is None:
                gmt_dt = gmt_dt.replace(tzinfo=timezone.utc)
            else:
                gmt_dt = gmt_dt.astimezone(timezone.utc)
            # Format to ISO with 'Z' for UTC
            iso_str = gmt_dt.isoformat()
            if not include_microseconds and '.' in iso_str:
                iso_str = iso_str.split('.')[0]
            return iso_str + 'Z'
        except (AttributeError, TypeError) as e:
            print(f"Error converting datetime '{gmt_dt}' to ISO: {e}")
            return None

    def iso_to_timestamp(self, iso_str: str) -> Optional[float]:
        """
        Convert an ISO 8601 string to a Unix timestamp (seconds since epoch, GMT).

        Args:
            iso_str: ISO 8601 string

        Returns:
            Unix timestamp as float, or None if conversion fails.
        """
        gmt_dt = self.iso_to_gmt(iso_str)
        if gmt_dt:
            return gmt_dt.timestamp()
        return None

    def timestamp_to_iso(self, timestamp: float) -> Optional[str]:
        """
        Convert a Unix timestamp to an ISO 8601 string in GMT.

        Args:
            timestamp: Unix timestamp (seconds since epoch)

        Returns:
            ISO 8601 string, or None if conversion fails.
        """
        try:
            gmt_dt = datetime.fromtimestamp(timestamp, tz=timezone.utc)
            return self.gmt_to_iso(gmt_dt)
        except (ValueError, TypeError, OSError) as e:
            print(f"Error converting timestamp '{timestamp}' to ISO: {e}")
            return None