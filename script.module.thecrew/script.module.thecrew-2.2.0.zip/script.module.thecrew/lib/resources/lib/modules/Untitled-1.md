Testing checklist:

Disable cocoscrapers → verify crew scrapers work
Enable cocoscrapers → verify both scraper sets load
Test playback → confirm no Python 3 runtime errors
The migration is functionally complete. CocoScrapers remains unchanged as requested, and crew will dynamically load its scrapers when available.