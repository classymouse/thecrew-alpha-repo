# -*- coding: utf-8 -*-

'''
 ***********************************************************
 * The Crew Add-on
 *
 *
 * @file crewruntime.py
 * @package script.module.thecrew
 *
 * @copyright (c) 2023, The Crew
 * @license GNU General Public License, version 3 (GPL-3.0)
 *
 ********************************************************cm*
'''


import os
import sys
import re
import platform
import json
import base64
import datetime
import importlib
import traceback

from io import open
from inspect import getframeinfo, stack

import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui
import xbmcplugin

from . import keys



imageSizes = (
    {'poster': 'w185', 'fanart': 'w300', 'still': 'w300', 'profile': 'w185'},
    {'poster': 'w342', 'fanart': 'w780', 'still': 'w500', 'profile': 'w342'},
    {'poster': 'w780', 'fanart': 'w1280', 'still': 'w780', 'profile': 'h632'},
    {'poster': 'original', 'fanart': 'original', 'still': 'original', 'profile': 'original'}
)


class CrewRuntime:
    '''
    Global new superclass starting to run alongside the old code

    '''

    # ============================cm=
    # class variable shared by all instances
    # globals here

    transpath = xbmcvfs.translatePath
    lang = xbmcaddon.Addon().getLocalizedString
    listItem = xbmcgui.ListItem
    addonInfo = xbmcaddon.Addon().getAddonInfo

    # ============================cm=

    def __init__(self):

        '''
        # cm - can later be used on a child class as temp obj to super crewRuntime
        # super().__init__(self)
        '''

        self.name = None
        self.platform = None
        self.kodiversion = None
        self.int_kodiversion = None

        self.moduleversion = None
        self.pluginversion = None
        self.addon = None
        self.toggle = None
        self.has_silent_boot = None

        self.artPoster = None
        self.artThumb = None
        self.artIcon = None
        self.artFanart = None
        self.artClearlogo = None
        self.artClearart = None
        self.artDiscart = None

        self.tmdb_postersize = ''
        self.tmdb_fanartsize = ''
        self.tmdb_stillsize = ''
        self.tmdb_profilesize = ''
        self.devmode = False

        self._theme = ''
        self.art = ''

        self.cores = 0
        self.max_threads = 0

        self.initialize_all()

    def __del__(self):
        '''
        On destruction of the class
        '''
        self.deinit()

    def deinit(self):
        '''
        cleanup
        '''
        self.toggle = None
        self.addon = None

    def initialize_all(self):
        '''
        initialize all vars
        '''
        # Cache a single Addon instance to ensure settings persist across calls
        try:
            self.addon = xbmcaddon.Addon()
            self.plugin_id = self.addon.getAddonInfo("id")
            self.pluginversion = self.addon.getAddonInfo("version")
            self.name = self.addon.getAddonInfo('name')
        except Exception:
            # Fallback (prior behavior) - keep the class reference if instance creation fails
            self.addon = xbmcaddon.Addon
            self.plugin_id = self.addon().getAddonInfo("id")
            self.pluginversion = self.addon().getAddonInfo("version")
            self.name = self.addon().getAddonInfo('name')

        self.name = self.strip_tags(text=self.name).title()
        self.platform = self._get_current_platform()

        # Local settings cache to ensure programmatic changes (e.g., in tests) are visible
        self._local_settings = {}

        self.module_addon = xbmcaddon.Addon("script.module.thecrew")
        self.module_id = self.module_addon.getAddonInfo(id="id")
        self.moduleversion = self.module_addon.getAddonInfo(id="version")

        self.kodiversion = self._get_kodi_version(as_string=True, as_full=True)
        self.int_kodiversion = self._get_kodi_version(as_string=False, as_full=False)
        self.pyversion = self._get_python_version(as_string=True)
        self.int_pyversion = self._get_python_version(as_string=False)
        self.has_silent_boot = self._has_silent_boot()
        self.artwork_path = self.get_artwork_path()
        self.cores = os.cpu_count() or 1

        self.devmode = self.get_setting('dev_pw') == self.ensure_text(base64.b64decode(b'dGhlY3Jldw=='))
        self.is_orion_disabled = self.orion_disabled()


        self._theme = self.appearance()
        self.art = self.get_art_path()

        self.toggle = 1 # cm - internal debugging

        self.set_imagesizes()
        self.check_orion()

    def get_max_threads(self,total_items: int, default_cap: int = 50) -> int:
        """Determine an appropriate number of threads for concurrent tasks."""
        try:
            user_defined = int(self.get_setting('max.threads') or 0)
        except (ValueError, TypeError):
            user_defined = 0

        cpu_cores = os.cpu_count() or 1
        thread_count = user_defined if user_defined > 0 else cpu_cores * 2
        thread_count = min(thread_count, default_cap, total_items)
        return max(5, thread_count)

    def orion_disabled(self) -> bool:
        '''Check if Orion is disabled'''

        if(self.get_setting('disable.orion') == 'true'):
            self.log('[CM Debug @ 158 in crewRuntime] navigator.navigator (disable.orion)')
            return True
        return False
    @staticmethod
    def addon_exists(script_name) -> bool:
        """
        Check if an add-on with the given script name is installed and enabled.

        Args:
            script_name (str): The name of the script or add-on to check.

        Returns:
            bool: True if the add-on is installed and enabled, False otherwise.
        """

        if not script_name:
            return False
        return xbmc.getCondVisibility(f'System.HasAddon({script_name})') == 1

    def _has_silent_boot(self) -> bool:
        return self.get_setting('silent.boot') == 'true'

    def log_boot_option(self) -> None:
        if self.has_silent_boot:
            self.log('User enabled silent boot option')
        else:
            self.log('User disabled silent boot option')

    @staticmethod
    def get_artwork_path() -> str:
        """Returns the path to the script.thecrew.artwork addon's resources directory"""
        return xbmcaddon.Addon('script.thecrew.artwork').getAddonInfo('path')



    def _get_current_platform(self):

        platform_name = platform.uname()
        _system = platform_name[0]
        _sysname = platform_name[1]
        _sysrelease = platform_name[2]
        _sysversion = platform_name[3]
        _sysmachine = platform_name[4]
        _sysprocessor = platform_name[5]
        is_64bits = sys.maxsize > 2**32
        pf = platform.python_version() # pylint disable=snake-case

        #self.log(f"[CM Debug @ 190 in crewruntime.py] _system = {_system} | _sysversion = {_sysversion} | _sysmachine = {_sysmachine} | _sysrelease = {_sysrelease} with type = {type(_sysrelease)} | sysrelease 11?: {_system == 'Windows' and int(_sysversion.split('.')[-1]) > 22000} | pf = {pf}")

        if _system == 'Windows' and int(_sysversion.split('.')[-1]) > 22000:
            _sysrelease = '11'

        #self.log(f"[CM Debug @ 195 in crewruntime.py]] _system = {_system} | _sysversion = {int(_sysversion.split('.')[-1])} | _sysrelease = {_sysrelease} ", )

        _64bits = '64bits' if is_64bits else '32bits'

        return f"{_system} {_sysrelease} v.{_sysversion} ({_64bits})"

    def _get_kodi_version(self, as_string=False, as_full=False):
        version_raw = xbmc.getInfoLabel("System.BuildVersion").split(" ")

        v_temp = version_raw[0]

        if as_full is False:
            version = v_temp.split(".")[0]
            fversion = ''
        else:
            v_major = v_temp.split(".")[0]
            v_minor = v_temp.split(".")[1]
            fversion = f"{v_major}.{v_minor}"
            version = ''

        if as_string is True:
            return version if as_full is False else fversion

        return int(version)

    def _get_python_version(self, as_string=False, as_full=False):
        """
        Get the python version

        :param as_string: bool Return the python version as a string
        :param as_full: bool Return the full python version string
        :return: str or int
        """
        version = platform.python_version_tuple()

        if as_string and as_full:
            return sys.version

        return '.'.join(version[:3]) if as_string else float('.'.join(version[:2]))

    def log(self, msg, trace=0):
        '''
        General new log messages

        Args:
            msg (str): The message to log
            trace (int): If 1, includes caller information from stack
        '''
        # Early exit if logging disabled - avoid string processing
        debug_enabled = self.get_setting('addon_debug')
        if not debug_enabled:
            return

        debug_prefix = f' DEBUG [{self.name} {self.pluginversion} | {self.moduleversion} | {self.pyversion} | {self.kodiversion} | {self.platform}]'
        info_prefix = f' INFO [{self.name} {self.pluginversion}/{self.moduleversion} | {self.pyversion}]'

        log_path = xbmcvfs.translatePath('special://logpath')
        filename = 'the_crew.log'
        log_file = os.path.join(log_path, filename)
        debug_log = self.get_setting('debug.location')

        try:
            if not isinstance(msg, str):
                raise TypeError('c.log() msg not of type str!')

            if trace == 1:
                caller = getframeinfo(stack()[1][0])

                head = debug_prefix
                _msg = f'\n     {msg}:\n    \n--> called from file {caller.filename} @ {caller.lineno}'
            else:
                head = info_prefix
                _msg = f'\n    {msg}'

            if debug_log== '1':
                #xbmc.log(f"\n\n--> addon name @ 147 = {self.name} | {self.pluginversion} | {self.moduleversion}  \n\n")

                if not os.path.exists(log_file):
                    _file = open(log_file, 'a', encoding="utf8")
                    s = [
                        "====================================================================\n",
                        f"Log File The Crew | plugin: v.{self.pluginversion} | module: v.{self.moduleversion} | Kodi: v.{self.kodiversion}\n",
                        "Created: "
                        + datetime.datetime.now().strftime("%d-%m-%Y %H:%M:%S")
                        + "\n",
                        "=================================================================cm=\n\n\n",
                    ]

                    with open(log_file, "w", encoding="utf8") as f:
                        f.writelines(s)

                with open(log_file, 'a', encoding="utf8") as _file:
                    now = datetime.datetime.now()
                    _dt = now.strftime("%Y-%m-%d %H:%M:%S")

                    #line = f'[{_date} {_time}] {head}: {msg}'
                    line = f'{_dt} {head}: {msg}'
                    #_file.write(line.rstrip('\r\n') + '\n\n')
                    _file.write(line.rstrip('\r\n') + '\n')

        except (TypeError, OSError, UnicodeError) as exc:
            xbmc.log(f'[ {self.name} ] Logging Failure: {exc}', 1)

    def scraper_error(self, msg, scraper=None, trace=0, exc_info=None):
        """
        Logs an error message associated with a specific scraper.

        Improvements:
        - Auto-detects scraper name from filename if not provided
        - Accepts Exception objects and automatically captures full traceback
        - Better formatting for readability

        Args:
            msg (str or Exception): The error message or exception object to log
            scraper (str, optional): The name of the scraper. Auto-detected if None
            trace (int, optional): If set to 1, includes caller info. Defaults to 0
            exc_info (Exception, optional): Exception object for full traceback capture

        Examples:
            c.scraper_error("Custom error message", "my_scraper")
            c.scraper_error(exception_object)  # Auto-detects scraper name
            c.scraper_error("Error context", exc_info=e)  # Combines message + traceback
        """
        # Early exit if logging disabled
        if not self.get_setting('addon_debug'):
            return

        # Handle exception objects passed as msg
        if isinstance(msg, Exception):
            exc_info = msg
            msg = str(msg)

        # Auto-detect scraper name from call stack if not provided
        if scraper is None:
            try:
                caller_frame = stack()[1]
                caller_file = caller_frame[0].f_code.co_filename
                # Extract scraper name from filename (e.g., "/path/to/filmxy.py" -> "filmxy")
                scraper = os.path.splitext(os.path.basename(caller_file))[0]
            except:
                scraper = "unknown"

        # Build error message with traceback if exception available
        error_lines = [
            '\n' + '='*70,
            f'SCRAPER ERROR: {scraper}',
            '='*70
        ]

        if exc_info:
            # Capture full traceback
            import sys
            tb_lines = traceback.format_exception(type(exc_info), exc_info, exc_info.__traceback__)
            error_lines.append(f'Exception Type: {type(exc_info).__name__}')
            error_lines.append(f'Exception Message: {msg}')
            error_lines.append('\nFull Traceback:')
            error_lines.extend(['  ' + line.rstrip() for line in tb_lines])
        else:
            error_lines.append(f'Error: {msg}')

        error_lines.append('='*70)

        formatted_msg = '\n'.join(error_lines)
        self.log(formatted_msg, trace)

    def in_addon(self) -> bool:
        '''
        returns bool if we are inside addon
        '''
        # self.log('[CM Debug @ 158 in crewRuntime] navigator.navigator (in_addon), self.container.pluginname = ' + xbmc.getInfoLabel('Container.PluginName'))
        return xbmc.getInfoLabel('Container.PluginName') == "plugin.video.thecrew"

    def get_setting(self, setting) -> str:
        '''
        return a setting value
        '''
        try:
            # Prefer using a cached Addon instance created during initialization.
            # Support both callable (old behavior) and instance stored in self.addon.
            addon_inst = None
            try:
                raw_addon = getattr(self, 'addon', None)
                if callable(raw_addon):
                    addon_inst = raw_addon()
                else:
                    addon_inst = raw_addon
            except Exception:
                addon_inst = None

            # Respect any programmatic settings set via set_setting() by checking local cache first
            try:
                if hasattr(self, '_local_settings') and setting in self._local_settings:
                    return self._local_settings.get(setting)
            except Exception:
                pass

            if addon_inst and hasattr(addon_inst, 'getSetting'):
                try:
                    # DEBUG: trace addon setting reads during tests
                    try:
                        val = addon_inst.getSetting(id=setting)
                    except Exception:
                        val = addon_inst.getSetting(setting) if hasattr(addon_inst, 'getSetting') else ''
                    return val
                except Exception:
                    pass

            # Fallback to creating a fresh Addon instance (best-effort)
            try:
                return xbmcaddon.Addon().getSetting(id=setting)
            except Exception:
                return ''
        except Exception:
            return ''

    def set_setting(self, setting, val) -> None:
        '''
        set a setting value
        .getSettingString
        .getSettingBool
        .getSettingNumber
        .setSettingInt
        .setSettingBool
        '''
        try:
            # Prefer using a cached Addon instance when available (support callable and instance)
            addon_inst = None
            try:
                raw_addon = getattr(self, 'addon', None)
                if callable(raw_addon):
                    addon_inst = raw_addon()
                else:
                    addon_inst = raw_addon
            except Exception:
                addon_inst = None

            if addon_inst and hasattr(addon_inst, 'setSetting'):
                try:
                    # Also update the local cache so subsequent get_setting reads (during tests)
                    try:
                        if hasattr(self, '_local_settings'):
                            self._local_settings[setting] = val
                    except Exception:
                        pass
                    return addon_inst.setSetting(id=setting, value=val)
                except Exception:
                    pass

            try:
                return xbmcaddon.Addon().setSetting(id=setting, value=val)
            except Exception:
                return None
        except Exception:
            return None

    def strip_tags(self, text) -> str:
        '''
        Strip the tags, added to the name in the addon.xml file
        '''

        clean = re.compile(r'\[.*?\]')
        return re.sub(clean, '', text)




    def check_orion(self):
        #check if Orion is installed
        if self.is_orion_installed():
            try:
                OrionClass = getattr(self, 'Orion', None)
                if OrionClass is None:
                    import importlib
                    module = importlib.import_module('orion')
                    OrionClass = getattr(module, 'Orion', None)
                    self.Orion = OrionClass
                if OrionClass is None:
                    raise ImportError('Orion class not found in orion module')

                result = OrionClass(keys.orion_key).user()
                self.set_setting('orion.installed', '[COLOR lawngreen]Installed[/COLOR]')
                self.set_setting('orion.boolinstalled', 'true')

                if result.get('username') is not None:
                    temp = result.get("username")
                else:
                    temp = self.obscure_email(result.get('email'))
                self.set_setting('orion.username', temp)
                package = result.get('subscription').get('package').get('name')
                self.set_setting('orion.package', package)
                expiration = result.get('subscription').get('time').get('expiration')
                exp = datetime.datetime.fromtimestamp(expiration).strftime('%A %d %b, %Y')
                self.set_setting('orion.expiration', str(exp))

            except Exception as e:
                self.log(f'Error checking Orion installation: {e}', 1)
                self.set_setting('orion.installed', '[COLOR red]Not Installed![/COLOR]')
                self.set_setting('orion.boolinstalled', 'false')


    def is_orion_installed(self):# -> Any:
        """
        Safely check if Orion add-on is installed and import its Orion class if available.
        This avoids a bare module import at parse time and handles missing or broken modules.
        """
        if not xbmc.getCondVisibility('System.HasAddon(script.module.orion)'):
            return False

        try:

            module = importlib.import_module('orion')
            OrionClass = getattr(module, 'Orion', None)
            if OrionClass is None:
                self.log('Orion module found but Orion class missing', 1)
                return False
            # attach the class to the instance so other methods can access it
            self.Orion = OrionClass
            return True
        except Exception as e:
            self.log(f'Failed to import Orion module: {e}', 1)
            self.set_setting('orion.installed', '[COLOR red]Not Installed![/COLOR]')
            self.set_setting('orion.boolinstalled', 'false')
            return False


    def obscure_email(self, email):
        return email[:2] + '*' * (len(email) - 4) + email[-2:]


    #######
    # cm - replacing the six standard functions with own code


    @staticmethod
    def encode(s, encoding='utf-8') -> bytes:
        """
        Encodes a string to bytes using the specified encoding.

        Parameters:
            s (str): The string to be encoded. It can be a str (Python 3) or unicode (Python 2).
            encoding (str): The encoding type. Default is 'utf-8'.

        Returns:
            bytes: The encoded byte string.
        """

        # Check if the input is a string
        if isinstance(s, str):
            # In Python 3, 'str' is already Unicode, so we encode it.
            return s.encode(encoding)

        if isinstance(s, bytes):
            # If it's already bytes, just return it as is (Python 3)
            return s

        # If it's neither a string nor bytes, raise an error
        raise TypeError(f"Input must be a string or bytes, not '{type(s).__name__}'")




    @staticmethod
    def six_encode(txt, char='utf-8', errors='replace'):
        """
        Encode text to bytes if it's a str, otherwise return as-is.
        Backwards compatible replacement for six-based encoding in Python 3.8+.
        """
        return txt.encode(char, errors) if isinstance(txt, str) else txt

    @staticmethod
    def six_decode(txt, char='utf-8', errors='replace'):
        """
        Decode bytes to text if it's bytes, otherwise return as-is.
        Backwards compatible replacement for six-based decoding in Python 3.8+.
        """
        return txt.decode(char, errors) if isinstance(txt, bytes) else txt

    @staticmethod
    def ensure_str(s, encoding='utf-8', errors='strict') -> str:
        """
        Ensures the input is a str (string), decoding bytes if necessary.
        Backwards compatible replacement for six.ensure_str in Python 3.8+.

        Args:
            s: Input string or bytes.
            encoding: Encoding to use for decoding bytes (default 'utf-8').
            errors: Error handling mode ('strict', 'ignore', 'replace', etc.).

        Returns:
            str: The input as a string.

        Raises:
            TypeError: If s is not str or bytes.
            UnicodeDecodeError: If decoding fails and errors='strict'.
        """
        if isinstance(s, str):
            return s
        elif isinstance(s, bytes):
            return s.decode(encoding, errors)
        else:
            raise TypeError(f"ensure_str expects str or bytes, got {type(s)}")

    @staticmethod
    def ensure_text(s, encoding='utf-8', errors='strict') -> str:
        """
        Ensures the input is a text (str) string, decoding bytes if necessary.
        Backwards compatible replacement for six.ensure_text in Python 3.8+.

        Args:
            s: Input string or bytes.
            encoding: Encoding to use for decoding bytes (default 'utf-8').
            errors: Error handling mode ('strict', 'ignore', 'replace', etc.).

        Returns:
            str: The input as a text string.

        Raises:
            TypeError: If s is not str or bytes.
            UnicodeDecodeError: If decoding fails and errors='strict'.
        """
        if isinstance(s, str):
            return s
        elif isinstance(s, bytes):
            return s.decode(encoding, errors)
        else:
            raise TypeError(f"ensure_text expects str or bytes, got {type(s)}")

    @staticmethod
    def decode_text(s, encoding='utf-8', errors='strict') -> str:
        """
        Decodes bytes to a text (str) string.
        Backwards compatible replacement for six.decode_text in Python 3.8+.

        Args:
            s: Input bytes or str.
            encoding: Encoding to use for decoding (default 'utf-8').
            errors: Error handling mode ('strict', 'ignore', 'replace', etc.).

        Returns:
            str: The decoded text string.

        Raises:
            TypeError: If s is not str or bytes.
            UnicodeDecodeError: If decoding fails and errors='strict'.
        """
        if isinstance(s, bytes):
            return s.decode(encoding, errors)
        elif isinstance(s, str):
            return s  # Already text
        else:
            raise TypeError(f"decode_text expects str or bytes, got {type(s)}")

    @staticmethod
    def encode_text(s, encoding='utf-8', errors='strict') -> bytes:
        """
        Encodes a text (str) string to bytes.
        Backwards compatible replacement for six.encode_text in Python 3.8+.

        Args:
            s: Input str or bytes.
            encoding: Encoding to use for encoding (default 'utf-8').
            errors: Error handling mode ('strict', 'ignore', 'replace', etc.).

        Returns:
            bytes: The encoded bytes.

        Raises:
            TypeError: If s is not str or bytes.
            UnicodeEncodeError: If encoding fails and errors='strict'.
        """
        if isinstance(s, str):
            return s.encode(encoding, errors)
        elif isinstance(s, bytes):
            return s  # Already bytes
        else:
            raise TypeError(f"encode_text expects str or bytes, got {type(s)}")

    def to_unicode(self, data, encoding: str = 'utf-8', errors: str = 'replace') -> str:
        """
        Safely return a unicode (str) from bytes/str/other.
        - If already str -> return unchanged.
        - If bytes -> decode using encoding/errors.
        - Otherwise -> convert via str() (safe fallback).
        Logs and re-raises decoding errors.
        """
        try:
            if isinstance(data, str):
                return data
            return data.decode(encoding, errors) if isinstance(data, bytes) else str(data)
        except Exception as e:
            failure = traceback.format_exc()
            self.log(f'[CM Debug @ crewruntime.to_unicode]Traceback:: {failure}')
            self.log(f'[CM Debug @ crewruntime.to_unicode]Exception raised. Error = {e}')


            # UnicodeDecodeError requires (encoding, object, start, end, reason)
            # use a safe empty bytes object with start=end=0 and include the original error message
            raise UnicodeDecodeError(encoding, b'', 0, 0, f"Decoding failed: {e}") from e

    def decode(self, data, encoding: str = 'utf-8', errors: str = 'replace') -> str:
        """
        Safely return a text (str) from bytes/str/other.
        - If already str -> return unchanged.
        - If bytes -> decode using encoding/errors.
        - Otherwise -> convert via str() (safe fallback).
        Logs and re-raises decoding errors.
        """
        try:
            if isinstance(data, str):
                return data
            return data.decode(encoding, errors) if isinstance(data, bytes) else str(data)
        except Exception as e:
            failure = traceback.format_exc()
            self.log(f'[CM Debug @ crewruntime.decode]Traceback:: {failure}')
            self.log(f'[CM Debug @ crewruntime.decode]Exception raised. Error = {e}')


            # UnicodeDecodeError requires (encoding, object, start, end, reason)
            # use a safe empty bytes object with start=end=0 and include the original error message
            raise UnicodeDecodeError(encoding, b'', 0, 0, f"Decoding failed: {e}") from e




    def set_imagesizes(self) -> None:
        '''
        Return the correct image sizes according to settings
        '''
        # Be tolerant of missing or invalid settings during test collection/imports
        try:
            q = self.get_setting('fanart.quality')
            idx = int(q) if q not in (None, '') else 2
        except Exception:
            idx = 2

        # imageSizes is a tuple of dicts; index it safely with bounds checking
        if isinstance(idx, int) and 0 <= idx < len(imageSizes):
            resolutions = imageSizes[idx]
        else:
            resolutions = imageSizes[2]
        self.tmdb_postersize = resolutions.get('poster')
        self.tmdb_fanartsize = resolutions.get('fanart')
        self.tmdb_stillsize = resolutions.get('still')
        self.tmdb_profilesize = resolutions.get('profile')
        old_imagesetting = self.get_setting('fanart.quality.old')
        cur_imagesetting = self.get_setting('fanart.quality')
        if old_imagesetting != cur_imagesetting:
            self.clear_imagecaches()


    def clear_imagecaches(self) -> None:
        '''
        Clear the image cache
        '''
        self.set_setting('fanart.quality.old', self.get_setting('fanart.quality'))


    def now(self):
        '''
        Return the current time
        '''
        return datetime.now()



    def is_widget_listing(self) -> bool:
        """Check if the current window is a widget listing.

        Returns
        -------
        bool
            True if the current window is a widget listing, else False.
        """
        plugin_name = xbmc.getInfoLabel('Container.PluginName')
        b = 'plugin' not in plugin_name
        # self.log(f'[CM Debug @ 158 in crewRuntime] (is_widget_listing), plugin_name =  {plugin_name}, result = {b}')
        return 'plugin' not in plugin_name


    #---Add Directory Method---#
    def addDirectoryItem(self, name, url, mode, icon, fanart, thumb, description='', page='', dir_name='', cm=None, labels=None, cast=None, the_id = '', season = '', episode = '', isAction = True, isFolder = True):
        sys_url = sys.argv[0]
        sys_handle = int(sys.argv[1])

        if isinstance(name, int):
            name = xbmcaddon.Addon().getLocalizedString(name)

        if description == '':
            description = name
        if cast is None:
            cast = []
        if labels is None:
            labels = {'title': name, 'plot': description, 'mediatype': 'video'}

        if mode == 'navigator':

            if sys_url not in url:
                url = f'{sys_url}?action={url}'

            #url = '%s?action=%s' % (sys_url, url) if isAction is True else query
            thumb = os.path.join(self.art, thumb) if self.art is not None else icon

            fanart = self.addon_fanart()

            li = self.listItem(name)
            vtag = li.getVideoInfoTag()
            vtag.setMediaType(labels.get("mediatype", "video"))
            vtag.setTitle(labels.get("title", self.lang(32566)))
            if cm is not None:
                li.addContextMenuItems(cm)
            li.setArt({'icon': icon, 'thumb': thumb, 'fanart': fanart, 'poster': thumb})

            if fanart is not None:
                li.setProperty('fanart', fanart)
        if mode == 'tvshow':
            self.log(f'[CM DEBUG in crewruntime.py @ 293] inside crewruntime addDirectory:: Mode = tvshow\nurl = {url}')

        xbmcplugin.addDirectoryItem(handle=sys_handle, url=url, listitem=li, isFolder=isFolder)


    def setContent(self, content: str) -> any:
        return xbmcplugin.setContent(int(sys.argv[1]), content)


    def endDirectory(self) -> None:
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

    ######
    #
    # moving this over from control with better code
    def addon_icon(self) -> str:
        if self.art is not None and self._theme not in ['-', '']:
            return os.path.join(self.art, 'icon.png')
        return xbmcaddon.Addon().getAddonInfo('icon')

    def addon_thumb(self) -> str:
        if self.art is not None and self._theme not in ['-', '']:
            return os.path.join(self.art, 'thumb.jpg')
        return ''

    def addon_poster(self) -> str:
        if self.art is not None and self._theme not in ['-', '']:
            return os.path.join(self.art, 'poster.png')
        return 'DefaultVideo.png'

    def addon_banner(self) -> str:
        if self.art is not None and self._theme not in ['-', '']:
            return os.path.join(self.art, 'banner.png')
        return 'DefaultVideo.png'

    def addon_fanart(self) -> str:
        if self.art is not None and self._theme not in ['-', '']:
            fanart = os.path.join(self.art, 'fanart.jpg')
            if isinstance(fanart, tuple):
                return fanart[0]
            return fanart
        return xbmcaddon.Addon().getAddonInfo('fanart')

    def addon_clearart(self) -> str:
        if self.art is not None and self._theme not in ['-', '']:
            return os.path.join(self.art, 'clearart.png')
        return ''

    def addon_discart(self) -> str:
        if self.art is not None and self._theme not in ['-', '']:
            return os.path.join(self.art, 'discart.png')
        return ''

    def addon_clearlogo(self) -> str:
        if self.art is not None and self._theme not in ['-', '']:
            return os.path.join(self.art, 'clearlogo.png')
        return ''

    def addon_next(self) -> str:
        if self.art is not None and self._theme not in ['-', '']:
            return os.path.join(self.art, 'next.png')
        return 'DefaultVideo.png'

    def get_art_path(self) -> str:

        if self._theme in ['-', '']:
            return ''
        elif xbmc.getCondVisibility('System.HasAddon(script.thecrew.artwork)'):
            return os.path.join(
                xbmcaddon.Addon('script.thecrew.artwork').getAddonInfo('path'),
                'resources',
                'media',
                str(self._theme)
            )

    def appearance(self):
        return (
            self.get_setting('appearance.1').lower()
            if xbmc.getCondVisibility('System.HasAddon(script.thecrew.artwork)')
            else self.get_setting('appearance.alt').lower()
        )

    def artwork(self) -> None:
        xbmc.executebuiltin('RunPlugin(plugin://script.thecrew.artwork)')

    def capitalize_word(self, string) -> str:

        return string.title()

    def string_split_to_list(self, string) -> list:

        if string in ['0', None]:
            return []
        if(isinstance(string, list)):
            return string
        elif(isinstance(string, tuple)):
            return list(string)
        elif(isinstance(string, str)):
            string = string.strip()
        lst = string.split('/')
        lst = [s.strip() for s in lst]
        lst = [self.capitalize_word(s) for s in lst]

        return lst

    def search_tmdb_index_in_indicators(self, tmdb_id, indicator_list):
        try:

            if not indicator_list:
                return -1

            tmdb_id = str(tmdb_id)
            indices = [index for index, value in enumerate(indicator_list) if value[0] == tmdb_id]
            #self.log(f'[CM Debug @ 587 in crewruntime.py]indices = {indices}')

            return indices[0] if indices else -1
        except Exception as e:
            import traceback
            failure = traceback.format_exc()
            self.log(f'[CM Debug @ 595 in crewruntime.py]Traceback:: {failure}')
            self.log(f'[CM Debug @ 596 in crewruntime.py]Exception raised. Error = {e}')

    def search_tmdb_index_in_indicators2(self, tmdb, indicators):

        if not indicators:
            return -1

        if not isinstance(tmdb, str):
            tmdb = str(tmdb)

        lst = [i for i, v in enumerate(indicators) if v[0] == tmdb]

        if len(lst) == 0:
            return -1
        else:
            return lst[0]


    def count_wachted_items_in_indicators(self, index, indicators):

        try:
            if not indicators[index]:
                return -1
            else:
                return len(indicators[index][2])

        except Exception as e:
            import traceback
            failure = traceback.format_exc()
            self.log(f'[CM Debug @ 469 in crewruntime.py]Traceback:: {failure}')
            self.log(f'[CM Debug @ 469 in crewruntime.py]Exception raised. Error = {e}')


    def count_total_items_in_indicators(self, index, indicators):
        if not indicators[index]:
            return -1
        return indicators[index][1]

    def string_to_tuple(self, string):
        return tuple(map(str, string.split(',')))




    def unicode_art(self, _str) -> str:
        _str = re.sub('\\\\\\\\u([\\da-f]{4})', lambda x: chr(int(x.group(1), 16)), _str)
        return json.dumps(_str)

    @staticmethod
    def okDialog(message, heading='Info'):
        """
        Display a simple OK dialog with the given message and optional heading.
        """
        xbmcgui.Dialog().ok(heading, message)

    def infoDialog(self, message, heading=addonInfo('name'), icon='', time=3000, sound=False) -> None:
        if icon == '':
            icon = self.addon_icon()
        elif icon == 'INFO':
            icon = xbmcgui.NOTIFICATION_INFO
        elif icon == 'WARNING':
            icon = xbmcgui.NOTIFICATION_WARNING
        elif icon == 'ERROR':
            icon = xbmcgui.NOTIFICATION_ERROR
        elif icon.endswith('.png'):
            icon = os.path.join(self.art, icon)
        xbmcgui.Dialog().notification(heading, message, icon, time, sound=sound)


c = CrewRuntime()
