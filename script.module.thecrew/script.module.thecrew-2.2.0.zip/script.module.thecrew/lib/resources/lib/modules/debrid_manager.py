# -*- coding: utf-8 -*-

'''
    The Crew Add-on
    Debrid Account Manager

    Displays user account information for Real-Debrid, AllDebrid, and Premiumize
    Shows account status, expiration, points, and cloud storage access
'''

import xbmcgui
from resources.lib.modules import control
from resources.lib.modules.crewruntime import c

try:
    import resolveurl
    RESOLVEURL_AVAILABLE = True
except:
    RESOLVEURL_AVAILABLE = False


class DebridAccountManager:
    def __init__(self):
        self.services = {
            'Real-Debrid': self.get_realdebrid_info,
            'AllDebrid': self.get_alldebrid_info,
            'Premiumize': self.get_premiumize_info
        }

    def show_account_info(self):
        """Main entry point - shows account info for all configured debrid services"""
        if not RESOLVEURL_AVAILABLE:
            xbmcgui.Dialog().ok(
                '[B]Debrid Account Manager[/B]',
                'ResolveURL is not installed or configured.\nPlease install ResolveURL to use debrid services.'
            )
            return

        # Get info for all services
        service_info = {}
        for service_name, get_info_func in self.services.items():
            try:
                info = get_info_func()
                if info:
                    service_info[service_name] = info
            except Exception as e:
                c.log(f'[Debrid Manager] Error getting {service_name} info: {e}', 1)

        if not service_info:
            xbmcgui.Dialog().ok(
                '[B]Debrid Account Manager[/B]',
                'No debrid accounts configured.\nConfigure your debrid services in ResolveURL settings.'
            )
            return

        # Show menu with available services
        self.show_service_menu(service_info)

    def show_service_menu(self, service_info):
        """Shows menu to select which debrid service to view details for"""
        service_names = list(service_info.keys())
        service_labels = []
        
        for name in service_names:
            info = service_info[name]
            status = '[COLOR green]●[/COLOR] Active' if info.get('active') else '[COLOR red]●[/COLOR] Inactive'
            service_labels.append(f'[B]{name}[/B]  {status}')

        service_labels.append('[B][COLOR skyblue]Browse Cloud Storage[/COLOR][/B]')
        service_labels.append('[B]Configure Debrid Services[/B]')

        choice = xbmcgui.Dialog().select(
            '[B]Debrid Account Manager[/B]',
            service_labels
        )

        if choice < 0:
            return
        elif choice < len(service_names):
            # Show detailed info for selected service
            self.show_service_details(service_names[choice], service_info[service_names[choice]])
        elif choice == len(service_names):
            # Browse cloud storage
            self.browse_cloud_menu(service_info)
        else:
            # Open ResolveURL settings
            control.execute('RunPlugin(plugin://plugin.video.thecrew/?action=ResolveUrlSettings)')

    def show_service_details(self, service_name, info):
        """Shows detailed account information for a specific service"""
        lines = [f'[B]{service_name} Account Information[/B]', '']
        
        if info.get('username'):
            lines.append(f'[B]Username:[/B] {info["username"]}')
        if info.get('email'):
            lines.append(f'[B]Email:[/B] {info["email"]}')
        if info.get('expiration'):
            lines.append(f'[B]Expires:[/B] {info["expiration"]}')
        if info.get('type'):
            lines.append(f'[B]Account Type:[/B] {info["type"]}')
        if info.get('points'):
            lines.append(f'[B]Points/Credits:[/B] {info["points"]}')
        if info.get('storage'):
            lines.append(f'[B]Storage Used:[/B] {info["storage"]}')
        if info.get('limits'):
            lines.append(f'[B]Limits:[/B] {info["limits"]}')

        if not info.get('active'):
            lines.append('')
            lines.append('[COLOR red][B]Account is not active or expired[/B][/COLOR]')

        xbmcgui.Dialog().textviewer(
            f'{service_name} Account',
            '\n'.join(lines)
        )

    def browse_cloud_menu(self, service_info):
        """Shows menu to select cloud storage to browse"""
        service_names = [name for name in service_info.keys()]
        service_labels = [f'[B]{name}[/B] Cloud Storage' for name in service_names]

        choice = xbmcgui.Dialog().select(
            '[B]Browse Cloud Storage[/B]',
            service_labels
        )

        if choice >= 0:
            service_name = service_names[choice]
            self.browse_cloud_storage(service_name)

    def browse_cloud_storage(self, service_name):
        """Opens cloud storage browser for the selected service"""
        # This would integrate with the cloud browse functionality
        # For now, show info message
        xbmcgui.Dialog().ok(
            f'{service_name} Cloud Storage',
            f'Cloud storage browsing for {service_name} will be integrated with the file manager in a future update.\n\nFor now, access your cloud via the service website.'
        )

    def get_realdebrid_info(self):
        """Get Real-Debrid account information"""
        try:
            # Find Real-Debrid resolver
            resolver = self._get_resolver('Real-Debrid')
            if not resolver or not self._is_resolver_logged_in(resolver):
                return None

            # Get user info from Real-Debrid API
            import requests
            auth_token = self._get_resolver_auth(resolver)
            if not auth_token:
                return None

            headers = {'Authorization': f'Bearer {auth_token}'}
            response = requests.get('https://api.real-debrid.com/rest/1.0/user', headers=headers, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                return {
                    'active': True,
                    'username': data.get('username', 'N/A'),
                    'email': data.get('email', 'N/A'),
                    'expiration': data.get('expiration', 'N/A'),
                    'type': data.get('type', 'N/A'),
                    'points': str(data.get('points', 0)),
                    'limits': f"{data.get('limit', 'N/A')}"
                }
        except Exception as e:
            c.log(f'[Debrid Manager] Real-Debrid error: {e}', 1)
        return None

    def get_alldebrid_info(self):
        """Get AllDebrid account information"""
        try:
            resolver = self._get_resolver('AllDebrid')
            if not resolver or not self._is_resolver_logged_in(resolver):
                return None

            import requests
            api_key = self._get_resolver_auth(resolver)
            if not api_key:
                return None

            response = requests.get(f'https://api.alldebrid.com/v4/user?agent=theCrew&apikey={api_key}', timeout=10)
            
            if response.status_code == 200:
                data = response.json().get('data', {}).get('user', {})
                return {
                    'active': True,
                    'username': data.get('username', 'N/A'),
                    'email': data.get('email', 'N/A'),
                    'expiration': data.get('premiumUntil', 'N/A'),
                    'type': 'Premium' if data.get('isPremium') else 'Free',
                    'points': str(data.get('fidelityPoints', 0))
                }
        except Exception as e:
            c.log(f'[Debrid Manager] AllDebrid error: {e}', 1)
        return None

    def get_premiumize_info(self):
        """Get Premiumize account information"""
        try:
            resolver = self._get_resolver('Premiumize.me')
            if not resolver or not self._is_resolver_logged_in(resolver):
                return None

            import requests
            api_key = self._get_resolver_auth(resolver)
            if not api_key:
                return None

            headers = {'Authorization': f'Bearer {api_key}'}
            response = requests.get('https://www.premiumize.me/api/account/info', headers=headers, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                storage_used = data.get('space_used', 0)
                storage_total = data.get('limit_used', 0)
                storage_str = f'{storage_used / (1024**3):.2f} GB / {storage_total / (1024**3):.2f} GB'
                
                return {
                    'active': True,
                    'email': data.get('customer_id', 'N/A'),
                    'expiration': data.get('premium_until', 'N/A'),
                    'type': 'Premium' if data.get('premium_until') else 'Free',
                    'storage': storage_str,
                    'points': str(data.get('fairuse_left', 'N/A'))
                }
        except Exception as e:
            c.log(f'[Debrid Manager] Premiumize error: {e}', 1)
        return None

    def _get_resolver(self, service_name):
        """Get resolver instance for a service"""
        try:
            if not RESOLVEURL_AVAILABLE:
                return None
            
            resolvers = [r for r in resolveurl.relevant_resolvers(order_matters=True) if r.name == service_name]
            return resolvers[0] if resolvers else None
        except:
            return None

    def _is_resolver_logged_in(self, resolver):
        """Check if resolver is logged in"""
        try:
            return hasattr(resolver, 'login') and resolver.valid_url('test')
        except:
            return False

    def _get_resolver_auth(self, resolver):
        """Get auth token/key from resolver"""
        try:
            # Try to get stored auth data
            if hasattr(resolver, 'get_setting'):
                # Real-Debrid uses 'token'
                token = resolver.get_setting('token')
                if token:
                    return token
                # AllDebrid/Premiumize might use 'api_key'
                api_key = resolver.get_setting('api_key')
                if api_key:
                    return api_key
                # Try 'apikey' variant
                api_key = resolver.get_setting('apikey')
                if api_key:
                    return api_key
        except Exception as e:
            c.log(f'[Debrid Manager] Auth retrieval error: {e}', 1)
        return None


def show_debrid_accounts():
    """Entry point for the debrid account manager"""
    manager = DebridAccountManager()
    manager.show_account_info()
