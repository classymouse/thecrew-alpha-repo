# -*- coding: utf-8 -*-

'''
    The Crew Add-on
    Debrid Account Manager

    Displays user account information for Real-Debrid, AllDebrid, and Premiumize
    Shows account status, expiration, points, and cloud storage access
'''

import xbmcgui
from resources.lib.modules import control
from resources.lib.modules.crewruntime import c

try:
    import resolveurl
    RESOLVEURL_AVAILABLE = True
except:
    RESOLVEURL_AVAILABLE = False


class DebridAccountManager:
    def __init__(self):
        self.services = {
            'Real-Debrid': self.get_realdebrid_info,
            'AllDebrid': self.get_alldebrid_info,
            'Premiumize': self.get_premiumize_info
        }

    def show_account_info(self):
        """Main entry point - shows account info for all configured debrid services"""
        if not RESOLVEURL_AVAILABLE:
            xbmcgui.Dialog().ok(
                '[B]Debrid Account Manager[/B]',
                'ResolveURL is not installed or configured.\nPlease install ResolveURL to use debrid services.'
            )
            return

        # Get info for all services
        c.log('[Debrid Manager] Starting account info check...', 1)
        service_info = {}
        for service_name, get_info_func in self.services.items():
            try:
                c.log(f'[Debrid Manager] Checking {service_name}...', 1)
                info = get_info_func()
                if info:
                    c.log(f'[Debrid Manager] Got info for {service_name}', 1)
                    service_info[service_name] = info
                else:
                    c.log(f'[Debrid Manager] No info returned for {service_name}', 1)
            except Exception as e:
                c.log(f'[Debrid Manager] Error getting {service_name} info: {e}', 1)
                import traceback
                c.log(f'[Debrid Manager] Traceback: {traceback.format_exc()}', 1)

        c.log(f'[Debrid Manager] Found {len(service_info)} configured services', 1)
        if not service_info:
            xbmcgui.Dialog().ok(
                '[B]Debrid Account Manager[/B]',
                'No debrid accounts configured.\nConfigure your debrid services in ResolveURL settings.'
            )
            return

        # Show menu with available services
        self.show_service_menu(service_info)

    def show_service_menu(self, service_info):
        """Shows menu to select which debrid service to view details for"""
        service_names = list(service_info.keys())
        service_labels = []
        
        for name in service_names:
            info = service_info[name]
            status = '[COLOR green]●[/COLOR] Active' if info.get('active') else '[COLOR red]●[/COLOR] Inactive'
            service_labels.append(f'[B]{name}[/B]  {status}')

        service_labels.append('[B][COLOR skyblue]Browse Cloud Storage[/COLOR][/B]')
        service_labels.append('[B]Configure Debrid Services[/B]')

        choice = xbmcgui.Dialog().select(
            '[B]Debrid Account Manager[/B]',
            service_labels
        )

        if choice < 0:
            return
        elif choice < len(service_names):
            # Show detailed info for selected service
            self.show_service_details(service_names[choice], service_info[service_names[choice]])
        elif choice == len(service_names):
            # Browse cloud storage
            self.browse_cloud_menu(service_info)
        else:
            # Open ResolveURL settings
            control.execute('RunPlugin(plugin://plugin.video.thecrew/?action=ResolveUrlSettings)')

    def show_service_details(self, service_name, info):
        """Shows detailed account information for a specific service"""
        lines = [f'[B]{service_name} Account Information[/B]', '']
        
        if info.get('username'):
            lines.append(f'[B]Username:[/B] {info["username"]}')
        if info.get('email'):
            lines.append(f'[B]Email:[/B] {info["email"]}')
        if info.get('expiration'):
            lines.append(f'[B]Expires:[/B] {info["expiration"]}')
        if info.get('type'):
            lines.append(f'[B]Account Type:[/B] {info["type"]}')
        if info.get('points'):
            lines.append(f'[B]Points/Credits:[/B] {info["points"]}')
        if info.get('storage'):
            lines.append(f'[B]Storage Used:[/B] {info["storage"]}')
        if info.get('limits'):
            lines.append(f'[B]Limits:[/B] {info["limits"]}')

        if not info.get('active'):
            lines.append('')
            lines.append('[COLOR red][B]Account is not active or expired[/B][/COLOR]')

        xbmcgui.Dialog().textviewer(
            f'{service_name} Account',
            '\n'.join(lines)
        )

    def browse_cloud_menu(self, service_info):
        """Shows menu to select cloud storage to browse"""
        service_names = [name for name in service_info.keys()]
        service_labels = [f'[B]{name}[/B] Cloud Storage' for name in service_names]

        choice = xbmcgui.Dialog().select(
            '[B]Browse Cloud Storage[/B]',
            service_labels
        )

        if choice >= 0:
            service_name = service_names[choice]
            self.browse_cloud_storage(service_name)

    def browse_cloud_storage(self, service_name):
        """Opens cloud storage browser for the selected service"""
        # This would integrate with the cloud browse functionality
        # For now, show info message
        xbmcgui.Dialog().ok(
            f'{service_name} Cloud Storage',
            f'Cloud storage browsing for {service_name} will be integrated with the file manager in a future update.\n\nFor now, access your cloud via the service website.'
        )

    def get_realdebrid_info(self):
        """Get Real-Debrid account information"""
        try:
            # Find Real-Debrid resolver
            c.log('[Debrid Manager] Getting Real-Debrid resolver...', 1)
            resolver = self._get_resolver('Real-Debrid')
            if not resolver:
                c.log('[Debrid Manager] Real-Debrid resolver not found', 1)
                return None
            
            c.log(f'[Debrid Manager] Real-Debrid resolver: {resolver}', 1)
            if not self._is_resolver_logged_in(resolver):
                c.log('[Debrid Manager] Real-Debrid not logged in', 1)
                return None

            # Get user info from Real-Debrid API
            import requests
            auth_token = self._get_resolver_auth(resolver)
            if not auth_token:
                c.log('[Debrid Manager] Real-Debrid no auth token', 1)
                return None

            c.log('[Debrid Manager] Making Real-Debrid API call...', 1)
            headers = {'Authorization': f'Bearer {auth_token}'}
            response = requests.get('https://api.real-debrid.com/rest/1.0/user', headers=headers, timeout=10)
            
            c.log(f'[Debrid Manager] Real-Debrid API response: {response.status_code}', 1)
            if response.status_code == 200:
                data = response.json()
                c.log(f'[Debrid Manager] Real-Debrid data received: {data.get("username", "N/A")}', 1)
                return {
                    'active': True,
                    'username': data.get('username', 'N/A'),
                    'email': data.get('email', 'N/A'),
                    'expiration': data.get('expiration', 'N/A'),
                    'type': data.get('type', 'N/A'),
                    'points': str(data.get('points', 0)),
                    'limits': f"{data.get('limit', 'N/A')}"
                }
        except Exception as e:
            c.log(f'[Debrid Manager] Real-Debrid error: {e}', 1)
            import traceback
            c.log(f'[Debrid Manager] Real-Debrid traceback: {traceback.format_exc()}', 1)
        return None

    def get_alldebrid_info(self):
        """Get AllDebrid account information"""
        try:
            resolver = self._get_resolver('AllDebrid')
            if not resolver or not self._is_resolver_logged_in(resolver):
                return None

            import requests
            api_key = self._get_resolver_auth(resolver)
            if not api_key:
                return None

            response = requests.get(f'https://api.alldebrid.com/v4/user?agent=theCrew&apikey={api_key}', timeout=10)
            
            if response.status_code == 200:
                data = response.json().get('data', {}).get('user', {})
                return {
                    'active': True,
                    'username': data.get('username', 'N/A'),
                    'email': data.get('email', 'N/A'),
                    'expiration': data.get('premiumUntil', 'N/A'),
                    'type': 'Premium' if data.get('isPremium') else 'Free',
                    'points': str(data.get('fidelityPoints', 0))
                }
        except Exception as e:
            c.log(f'[Debrid Manager] AllDebrid error: {e}', 1)
        return None

    def get_premiumize_info(self):
        """Get Premiumize account information"""
        try:
            resolver = self._get_resolver('Premiumize.me')
            if not resolver or not self._is_resolver_logged_in(resolver):
                return None

            import requests
            api_key = self._get_resolver_auth(resolver)
            if not api_key:
                return None

            headers = {'Authorization': f'Bearer {api_key}'}
            response = requests.get('https://www.premiumize.me/api/account/info', headers=headers, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                storage_used = data.get('space_used', 0)
                storage_total = data.get('limit_used', 0)
                storage_str = f'{storage_used / (1024**3):.2f} GB / {storage_total / (1024**3):.2f} GB'
                
                return {
                    'active': True,
                    'email': data.get('customer_id', 'N/A'),
                    'expiration': data.get('premium_until', 'N/A'),
                    'type': 'Premium' if data.get('premium_until') else 'Free',
                    'storage': storage_str,
                    'points': str(data.get('fairuse_left', 'N/A'))
                }
        except Exception as e:
            c.log(f'[Debrid Manager] Premiumize error: {e}', 1)
        return None

    def _get_resolver(self, service_name):
        """Get resolver instance for a service"""
        try:
            if not RESOLVEURL_AVAILABLE:
                return None
            
            # Get resolver class and instantiate it
            resolver_classes = [r for r in resolveurl.relevant_resolvers(order_matters=True) if r.name == service_name]
            if resolver_classes:
                return resolver_classes[0]()  # Instantiate the resolver class
            return None
        except Exception as e:
            c.log(f'[Debrid Manager] Error getting {service_name} resolver: {e}', 1)
            return None

    def _is_resolver_logged_in(self, resolver):
        """Check if resolver is logged in"""
        try:
            # Check if resolver has get_setting method and a valid auth token/key
            if not hasattr(resolver, 'get_setting'):
                return False
            
            # Check for different auth setting names used by different services
            for setting_name in ['token', 'api_key', 'apikey', 'auth']:
                try:
                    value = resolver.get_setting(setting_name)
                    if value:
                        c.log(f'[Debrid Manager] Found {setting_name} for {resolver.name}', 1)
                        return True
                except:
                    continue
            
            c.log(f'[Debrid Manager] No auth found for {resolver.name}', 1)
            return False
        except Exception as e:
            c.log(f'[Debrid Manager] Login check error for {resolver.name}: {e}', 1)
            return False

    def _get_resolver_auth(self, resolver):
        """Get auth token/key from resolver"""
        try:
            # Try to get stored auth data
            if hasattr(resolver, 'get_setting'):
                # Try different setting names used by different services
                for setting_name in ['token', 'api_key', 'apikey', 'auth', 'client_id']:
                    try:
                        value = resolver.get_setting(setting_name)
                        if value:
                            c.log(f'[Debrid Manager] Retrieved {setting_name} for {resolver.name}', 1)
                            return value
                    except:
                        continue
            
            c.log(f'[Debrid Manager] No auth token found for {resolver.name}', 1)
        except Exception as e:
            c.log(f'[Debrid Manager] Auth retrieval error for {resolver.name}: {e}', 1)
        return None


def show_debrid_accounts():
    """Entry point for the debrid account manager"""
    manager = DebridAccountManager()
    manager.show_account_info()
