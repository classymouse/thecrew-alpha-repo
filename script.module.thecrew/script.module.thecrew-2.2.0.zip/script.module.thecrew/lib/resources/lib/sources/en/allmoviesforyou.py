# -*- coding: utf-8 -*-
# Add tvshows later(only a few on site)
"""
    **Created by Tempest** Converted 19 crew
    **If you see this in a addon other than Tempest and says it was
    created by someone other than Tempest they stole it from me**
"""

import re
from resources.lib.modules import client
from resources.lib.modules import source_utils, control

try: from urlparse import parse_qs, urljoin
except ImportError: from urllib.parse import parse_qs, urljoin
try: from urllib import urlencode, quote_plus
except ImportError: from urllib.parse import urlencode, quote_plus


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['allmoviesforyou.co']
        self.base_link = 'https://allmovies.gg'
        self.search_link = '/?s=%s'
        self.search_link2 = '/embed/tmdb/tv?id=%s&s=%s&e=%s'
        self.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:88.0) Gecko/20100101 Firefox/88.0', 'Referer': self.base_link}

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urlencode(url)
            return url
        except:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urlencode(url)
            return url
        except:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return

            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urlencode(url)
            return url
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            items = []

            if url is None:
                return sources

            hostDict = hostprDict + hostDict

            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            urls = self.search_link % quote_plus(data['title'])

            try:
                url = urljoin(self.base_link, urls)
                r = client.request(url, headers=self.headers)
                # Defensive checks: empty / 404 / Cloudflare responses
                if not r or '404 Not Found' in r or 'Just a moment' in r or 'Enable JavaScript and cookies' in r:
                    c.log(f"[AllMovies] No valid search page for {url}")
                    return sources
                r = client.parseDom(r, 'article', attrs={'class': 'TPost B'})
                parsed = []
                for i in r:
                    try:
                        found = re.findall('<a href="(.+?)">.+?<span class="Qlty">(.+?)</span>.+?<span class="Qlty Yr">(.+?)</span>.+?<h2 class="Title">(.+?)</h2>', i, re.DOTALL)
                        if found:
                            parsed.append(found[0])
                    except re.error as rex:
                        c.log(f"[AllMovies] Regex error parsing search results: {rex}")
                        continue
                items += parsed
            except Exception as e:
                c.log(f"[AllMovies] Exception during search: {e}")
                return sources

            for item in items:
                try:
                    if data['title'] in item[3] and data['year'] in item[2]:
                        try:
                            page = client.request(item[0], headers=self.headers)
                            if not page or '404 Not Found' in page or 'Just a moment' in page:
                                c.log(f"[AllMovies] Invalid item page {item[0]}")
                                continue
                            frames = re.findall('<iframe src="(.+?)"', page)
                            if not frames:
                                c.log(f"[AllMovies] No iframe found on {item[0]}")
                                continue
                            iframe = frames[0].replace('#038;', '')
                            iframe_page = client.request(iframe, headers={'User-Agent': self.headers.get('User-Agent'), 'Referer': item[0]})
                            if not iframe_page:
                                continue
                            urls_found = re.findall('src="(.+?)"', iframe_page)
                            for u in urls_found:
                                valid, host = source_utils.is_host_valid(u, hostDict)
                                sources.append({'source': host, 'quality': item[1], 'language': 'en', 'url': u, 'direct': False, 'debridonly': False})
                        except Exception as e:
                            c.log(f"[AllMovies] Error processing item {item[0]}: {e}")
                            continue
                except:
                    pass

            return sources
        except Exception:
            return sources

    def resolve(self, url):
        return url
