# -*- coding: utf-8 -*-

import re

from resources.lib.modules import client
from resources.lib.modules import source_utils
from resources.lib.modules.crewruntime import c




class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['databasegdriveplayer.co', 'database.gdriveplayer.us', 'series.databasegdriveplayer.co']
        self.base_link = 'https://databasegdriveplayer.co'

    def sources(self, data, hostDict):
        sources = []
        try:
            if not data:
                return sources

            imdb = data.get('imdb')
            if imdb == '0':
                return sources

            # Build URL based on content type
            if data.get('tvshowtitle'):
                # TV show episode
                season = data.get('season')
                episode = data.get('episode')
                url = self.base_link + f'/player.php?type=series&imdb={imdb}&season={season}&episode={episode}'
            else:
                # Movie
                url = self.base_link + f'/player.php?imdb={imdb}'

            html = client.request(url)

            # Check for None or empty response
            if not html or html is None:
                c.log("[databasegdriveplayer] Empty or None response from request")
                return sources

            # Check for Cloudflare protection
            if 'Just a moment' in html or 'Enable JavaScript and cookies' in html:
                c.log("[databasegdriveplayer] Cloudflare protection detected")
                return sources

            # Parse servers with error handling for malformed HTML
            try:
                servers = client.parseDom(html, 'ul', attrs={'class': 'list-server-items'})
            except Exception as parse_error:
                c.log(f"[databasegdriveplayer] Failed to parse HTML - malformed content: {str(parse_error)}")
                # Fallback: try simple href extraction from full HTML
                try:
                    raw_links = re.findall(r'href=["\'](.*?)["\']', html)
                    if not raw_links:
                        c.log("[databasegdriveplayer] No servers found after fallback parse")
                        return sources
                    links = raw_links
                except re.error as rex:
                    c.log(f"[databasegdriveplayer] Regex failure in fallback parse: {rex}")
                    return sources
            else:
                if not servers:
                    c.log("[databasegdriveplayer] No servers found in HTML")
                    return sources
                servers = servers[0]
                try:
                    links = client.parseDom(servers, 'a', ret='href')
                except Exception as parse_error:
                    c.log(f"[databasegdriveplayer] Failed to parse links: {str(parse_error)}")
                    # Fallback to scanning the servers block for hrefs
                    try:
                        links = re.findall(r'href=["\'](.*?)["\']', servers)
                        if not links:
                            c.log("[databasegdriveplayer] No links found in servers fallback")
                            return sources
                    except re.error as rex:
                        c.log(f"[databasegdriveplayer] Regex failure in servers fallback: {rex}")
                        return sources
            for link in links:
                if link.startswith('/player.php'):
                    continue
                link = 'https:' + link if not link.startswith('http') else link
                link = link.replace('vidcloud.icu', 'vidembed.io').replace(
                                    'vidcloud9.com', 'vidembed.io').replace(
                                    'vidembed.cc', 'vidembed.io').replace(
                                    'vidnext.net', 'vidembed.me')
                if 'vidembed' in link:
                    for source in self.get_vidembed(link, hostDict):
                        sources.append(source)
                valid, host = source_utils.is_host_valid(link, hostDict)
                if valid:
                    link = link.split('&title=')[0]
                    sources.append({'source': host, 'quality': '720p', 'language': 'en', 'url': link, 'direct': False, 'debridonly': False})
            return sources
        except Exception as e:
            c.scraper_error('Exception in sources method', exc_info=e)
            return sources


    def resolve(self, url):
        return url


    def get_vidembed(self, link, hostDict):
        sources = []
        try:
            html = client.request(link)
            if not html:
                return sources

            try:
                urls = client.parseDom(html, 'li', ret='data-video')
            except Exception as parse_error:
                c.log(f"[databasegdriveplayer] Failed to parse vidembed HTML: {str(parse_error)}")
                return sources

            if urls:
                for url in urls:
                    url = url.replace('vidcloud.icu', 'vidembed.io').replace(
                                      'vidcloud9.com', 'vidembed.io').replace(
                                      'vidembed.cc', 'vidembed.io').replace(
                                      'vidnext.net', 'vidembed.me')
                    valid, host = source_utils.is_host_valid(url, hostDict)
                    if valid:
                        url = url.split('&title=')[0]
                        sources.append({'source': host, 'quality': '720p', 'language': 'en', 'url': url, 'direct': False, 'debridonly': False})
            return sources
        except Exception:
            #log_utils.log('vidembed', 1)
            return sources
