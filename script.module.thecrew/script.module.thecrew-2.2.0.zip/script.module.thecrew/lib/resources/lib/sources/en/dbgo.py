# -*- coding: utf-8 -*-
"""
    **Created by Tempest**
    **If you see this in a addon other than Tempest and says it was
    created by someone other than Tempest they stole it from me**
"""

import re, base64
import traceback

from resources.lib.modules import client
from resources.lib.modules.crewruntime import c
try: from urlparse import urljoin
except ImportError: from urllib.parse import urljoin
try: from urllib import quote_plus
except ImportError: from urllib.parse import quote_plus

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['dbgo.fun']
        self.base_link = 'https://dbgo.fun' # cm - connection timed out (cloudflare connection was working)
        self.search_link = '/video.php?id=%s'
        self.headers = {'Referer': 'https://cdn.dbgo.fun'}

    def sources(self, data, hostDict):
        try:
            sources = []

            if not data:
                return sources

            imdb = data.get('imdb')

            url = self.search_link % quote_plus(imdb)
            url = urljoin(self.base_link, url)
            try:
                url = client.request(url, headers=self.headers)
                url = re.findall('file:"#2(.*?)"', url)[0].replace('//eS95L3kv', '').replace('//ei96L3ov', '').replace('//eC94L3gv', '')
                url = base64.b64decode(url).decode('utf-8') + '|Referer=https://cdn.dbgo.fun/'
                sources.append({'source': 'CDN', 'quality': '720p', 'language': 'en', 'url': url, 'direct': False, 'debridonly': False})
            except:
                pass

            return sources
        except Exception as e:
            c.scraper_error('Exception in sources method', exc_info=e)
            return sources

    def resolve(self, url):
        return url
