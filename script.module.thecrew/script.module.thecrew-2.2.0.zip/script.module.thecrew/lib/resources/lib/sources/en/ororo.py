# -*- coding: utf-8 -*-

'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import re
import base64
import json

from urllib.parse import parse_qs, urljoin, urlencode, quote_plus, quote

from ...modules import cache
from ...modules import control
from ...modules import client
from ...modules.crewruntime import c



class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['ororo.tv']
        self.base_link = 'https://ororo.tv'
        self.moviesearch_link = '/api/v2/movies'
        self.tvsearch_link = '/api/v2/shows'
        self.movie_link = '/api/v2/movies/%s'
        self.show_link = '/api/v2/shows/%s'

        self.episode_link = '/api/v2/episodes/%s'

        self.user = control.setting('ororo.user')
        self.password = control.setting('ororo.pass')
        self.user = f'{self.user}:{self.password}'
        self.encoded = base64.b64encode(self.user.encode('utf-8')).decode('utf-8')
        self.headers = {
        'Authorization': 'Basic %s' % self.encoded,
        'User-Agent': 'Kodi'
        }


    def movie(self, imdb, title, localtitle, aliases, year):
        # Return None quickly when credentials are not set
        if (not self.user or not self.password):
            c.log('[Ororo] No credentials configured - skipping movie()')
            return

        try:
            #url = cache.get(self.ororo_moviecache, 60, self.user)
            url = self.ororo_moviecache(self.user)
            if not url:
                c.log(f'[Ororo] movie cache empty for user {self.user}')
                return

            try:
                url_id = [i[0] for i in url if imdb == i[1]][0]
            except Exception:
                c.log(f'[Ororo] Movie with imdb {imdb} not found in cache')
                return

            url = self.movie_link % url_id
            return url
        except Exception as e:
            c.log(f'[Ororo] Unexpected error in movie(): {e}')
            return


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        if (not self.user or not self.password):
            c.log('[Ororo] No credentials configured - skipping tvshow()')
            return

        try:
            url = cache.get(self.ororo_tvcache, 120, self.user)
            if not url:
                c.log(f'[Ororo] tv cache empty for user {self.user}')
                return

            try:
                url_id = [i[0] for i in url if imdb == i[1]][0]
            except Exception:
                c.log(f'[Ororo] TV show with imdb {imdb} not found in cache')
                return

            url = self.show_link % url_id
            return url
        except Exception as e:
            c.log(f'[Ororo] Unexpected error in tvshow(): {e}')
            return


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        if (not self.user or not self.password):
            c.log('[Ororo] No credentials configured - skipping episode()')
            return

        if url is None:
            return

        try:
            url_full = urljoin(self.base_link, url)
            r = client.request(url_full, headers=self.headers)
        except Exception as e:
            c.log(f'[Ororo] Network error fetching episode list: {e}')
            return

        try:
            data = json.loads(r)
            episodes = data.get('episodes', [])
            episodes = [(str(i.get('id')), str(i.get('season')), str(i.get('number')), str(i.get('airdate'))) for i in episodes]
        except Exception as e:
            c.log(f'[Ororo] Failed to parse episode list JSON: {e}')
            return

        matches = [i for i in episodes if season == '%01d' % int(i[1]) and episode == '%01d' % int(i[2])]
        matches += [i for i in episodes if premiered == i[3]]

        if not matches:
            c.log('[Ororo] No matching episode found')
            return

        try:
            url = self.episode_link % matches[0][0]
            return url
        except Exception as e:
            c.log(f'[Ororo] Failed to build episode URL: {e}')
            return


    def ororo_moviecache(self, user):
        try:
            url = urljoin(self.base_link, self.moviesearch_link)
            c.log(f"[Ororo] fetching movie cache from {url}")

            r = client.request(url, headers=self.headers)
            try:
                data = json.loads(r)
            except Exception as e:
                c.log(f"[Ororo] Failed to decode movie cache JSON: {e}")
                return

            movies = data.get('movies', [])
            result = []
            for i in movies:
                try:
                    result.append((str(i.get('id')), str(i.get('imdb_id'))))
                except Exception:
                    continue

            result = [(i[0], 'tt' + re.sub('[^0-9]', '', i[1])) for i in result if i[1]]
            return result
        except Exception as e:
            c.log(f"[Ororo] Error building movie cache: {e}")
            return


    def ororo_tvcache(self, user):
        try:
            url = urljoin(self.base_link, self.tvsearch_link)
            c.log(f"[Ororo] fetching TV cache from {url}")

            r = client.request(url, headers=self.headers)
            try:
                data = json.loads(r)
            except Exception as e:
                c.log(f"[Ororo] Failed to decode TV cache JSON: {e}")
                return

            shows = data.get('shows', [])
            result = []
            for i in shows:
                try:
                    result.append((str(i.get('id')), str(i.get('imdb_id'))))
                except Exception:
                    continue

            result = [(i[0], 'tt' + re.sub(r'[^0-9]', '', i[1])) for i in result if i[1]]
            return result
        except Exception as e:
            c.log(f"[Ororo] Error building TV cache: {e}")
            return


    def sources(self, url, hostDict, hostprDict):
        sources = []

        if url is None:
            return sources

        if (not self.user or not self.password):
            c.log('[Ororo] No credentials configured - skipping sources()')
            return sources

        try:
            url_full = urljoin(self.base_link, url)
            r = client.request(url_full, headers=self.headers)
        except Exception as e:
            c.log(f'[Ororo] Network error fetching media URL: {e}')
            return sources

        try:
            data = json.loads(r)
            media_url = data.get('url')
            if not media_url:
                c.log(f'[Ororo] No media URL found in response for {url_full}')
                return sources

            sources.append({
                'source': 'ororo', 'quality': 'HD', 'language': 'en', 'url': media_url,
                'direct': True, 'debridonly': False
            })

            return sources
        except Exception as e:
            c.log(f'[Ororo] Failed to parse sources JSON: {e}')
            return sources


    def resolve(self, url):
        return url
