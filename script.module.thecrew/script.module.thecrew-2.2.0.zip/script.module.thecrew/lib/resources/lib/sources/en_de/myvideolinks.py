# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file myvideolinks.py
* @package script.module.thecrew
*
* @copyright (c) 2025, The Crew
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*
'''

import re


from resources.lib.modules import cleantitle
from resources.lib.modules import debrid
from resources.lib.modules import client
from resources.lib.modules import source_utils


from resources.lib.modules.crewruntime import c


from urllib.parse import parse_qs, urljoin, urlencode

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['myvideolinks.org','iwantmyshow.tk', 'iwantmyshow.tk', 'go.myvideolinks.net', 'to.myvideolinks.net/', 'see.home.kg', 'to.myvideolinks.net']
        self.base_link = 'https://myvideolinks.org/'
        self.search_link = '/?s=%s'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urlencode(url)
            return url
        except:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urlencode(url)
            return url
        except:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None:
                return

            # Accept either a query-string or a dict; normalize to a simple dict of scalars
            if isinstance(url, dict):
                _data = {k: (v[0] if isinstance(v, (list, tuple)) else v) for k, v in url.items()}
            else:
                _data = parse_qs(url)
                _data = {k: (_data[k][0] if _data[k] else '') for k in _data}

            _data['title'], _data['premiered'], _data['season'], _data['episode'] = title, premiered, season, episode
            url = urlencode(_data)
            return url
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []

            if url is None:
                return sources

            if debrid.status() is False:
                raise Exception()

            # Accept either a query-string or a dict; normalize to a simple dict of scalars
            if isinstance(url, dict):
                data = {k: (v[0] if isinstance(v, (list, tuple)) else v) for k, v in url.items()}
            else:
                data = parse_qs(url)
                data = {k: (data[k][0] if data[k] else '') for k in data}

            title = data.get('tvshowtitle', data['title'])

            hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else data['year']

            hostDict = hostprDict + hostDict

            items, urls, posts, links = [], [], [], []

            url = urljoin(self.base_link, self.search_link % data['imdb'])
            r = client.request(url)

            # Defensive checks for empty/blocked responses
            if not r or 'Just a moment' in r or 'Enable JavaScript and cookies' in r or '404 Not Found' in r:
                c.log(f"[MyVideoLinks] Empty or blocked response for {url}")
                return sources

            if 'CLcBGAs/s1600/1.jpg' in r:
                try:
                    url = client.parseDom(r, 'a', ret='href')[0]
                    self.base_link = url = urljoin(url, self.search_link % data['imdb'])
                    r = client.request(url)
                except Exception as e:
                    c.log(f"[MyVideoLinks] Error following fallback link: {e}")

            posts = client.parseDom(r, 'article') or []
            if not posts and 'tvshowtitle' in data:
                try:
                    url = urljoin(self.base_link, self.search_link % (cleantitle.geturl(title).replace('-','+') + '+' + hdlr))
                    r = client.request(url, headers={'User-Agent': client.agent()})
                    posts += client.parseDom(r, 'article') or []
                    url = urljoin(self.base_link, self.search_link % cleantitle.geturl(title).replace('-','+'))
                    r = client.request(url, headers={'User-Agent': client.agent()})
                    posts += client.parseDom(r, 'article') or []
                except Exception as e:
                    c.log(f"[MyVideoLinks] Error during TV fallback search: {e}")

            if not posts:
                c.log("[MyVideoLinks] No posts found")
                return sources

            for post in posts:
                try:
                    t = client.parseDom(post, 'img', ret='title')[0]
                    u = client.parseDom(post, 'a', ret='href')[0]
                    s_match = re.search(r'((?:\d+\.\d+|\d+,\d+|\d+)\s*(?:GiB|MiB|GB|MB))', post)
                    s = s_match.groups()[0] if s_match else '0'
                    items += [(t, u, s, post)]
                except Exception as e:
                    c.log(f"[MyVideoLinks] Error parsing post: {e}")
                    continue
            items = set(items)
            items = [i for i in items if cleantitle.get(title) in cleantitle.get(i[0])]

            for item in items:
                name = item[0]
                u = client.request(item[1])
                if 'tvshowtitle' in data:
                    if hdlr.lower() not in name.lower():
                        pattern = '''<p>\s*%s\s*<\/p>(.+?)<\/ul>''' % hdlr.lower()
                        r = re.search(pattern, u, flags = re.I|re.S)
                        if not r: continue
                        links = client.parseDom(r.groups()[0], 'a', ret='href')
                    else:
                        links = client.parseDom(u, 'a', ret='href')
                else: links = client.parseDom(u, 'a', ret='href')
                for url in links:
                    valid, host = source_utils.is_host_valid(url, hostDict)
                    if not valid: continue
                    host = client.replaceHTMLCodes(host)
                    if isinstance(host, bytes):
                        try:
                            host = host.decode('utf-8')
                        except Exception:
                            host = str(host)

                    info = []
                    quality, info = source_utils.get_release_quality(name, url)

                    try:
                        size = re.findall('((?:\d+\.\d+|\d+\,\d+|\d+) (?:GB|GiB|MB|MiB))', item[2])[0]
                        div = 1 if size.endswith(('GB', 'GiB')) else 1024
                        size = float(re.sub('[^0-9|/.|/,]', '', size)) / div
                        size = '%.2f GB' % size
                        info.append(size)
                    except:
                        pass

                    info = ' | '.join(info)
                    sources.append({'source': host, 'quality': quality, 'language': 'en', 'url': url, 'info': info, 'direct': False, 'debridonly': False})

            return sources
        except:
            return sources

    def resolve(self, url):
        return url