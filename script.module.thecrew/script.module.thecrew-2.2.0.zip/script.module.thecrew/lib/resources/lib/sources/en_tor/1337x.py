# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file 1337x.py
* @package script.module.thecrew
*
* @copyright (c) 2026, The Crew
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*
'''


import contextlib
import re


from urllib.parse import urlencode, quote_plus, quote, parse_qs, urljoin

from ...modules import cache
from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import debrid

from resources.lib.modules import source_utils
from resources.lib.modules import workers
from ...modules import dom_parser as dom
from ...modules.crewruntime import c


class source:
    pack_capable = True

    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['1337x.to', '1337x.is', '1337x.st', '1337x.se', '1337x.eu', '1337x.ws', '1337x.gd']
        # self.base_link = "https://1337x.to"
        self.tvsearch = '/sort-category-search/%s/TV/size/desc/1/'
        self.moviesearch = '/sort-category-search/%s/Movies/size/desc/1/'

        self._base_link = None

    def _parse_size(self, size_str):
        """
        Parse a size string like '1.23 GiB' or '700 MiB' and return tuple (dsize_gb, display_size).
        dsize_gb is a float in GB (e.g. 1.23), display_size is a formatted string like '1.23 GB' or '700.00 MB'.
        """
        try:
            if not size_str:
                return 0.0, ''
            s = size_str.upper().replace('GIB', 'GB').replace('MIB', 'MB')
            # Remove thousand separators
            s = s.replace(',', '')
            m = re.match(r'([0-9]+(?:\.[0-9]+)?)\s*(GB|MB)', s)
            if not m:
                return 0.0, ''
            val = float(m[1])
            unit = m[2]
            dsize = val if unit == 'GB' else val / 1024.0
            # Keep original unit for display
            isize = f'{val:.2f} {unit}'
            return dsize, isize
        except Exception:
            return 0.0, ''

    @property
    def base_link(self):
        if not self._base_link:
            self._base_link = cache.get(self.__get_base_url, 120, 'https://%s' % self.domains[0])
        return self._base_link

    def _safe_request(self, url, timeout=10, retries=2):
        """Make a request with simple retry and safe return semantics.

        Returns the response text or None on repeated failure.
        """
        for _ in range(retries):
            try:
                r = client.request(url, timeout=timeout)
                if r:
                    return r
            except Exception:
                # swallow and retry
                continue
        return None

    def sources(self, data, hostDict):
        try:
            self._sources = []
            self.items = []
            if not data:
                return self._sources

            if debrid.status() is False:
                return self._sources

            # prebuild search URLs using selected base link
            self.tvsearch = '%s/sort-category-search/%s/TV/seeders/desc/1/' % (self.base_link, '%s')
            self.moviesearch = '%s/sort-category-search/%s/Movies/size/desc/1/' % (self.base_link, '%s')

            self.title = data.get('tvshowtitle', data.get('title'))
            self.title = cleantitle.get_query(self.title)
            self.hdlr = 'S%02dE%02d' % (int(data.get('season')), int(data.get('episode'))
                                        ) if data.get('tvshowtitle') else data.get('year')

            query = '%s S%02dE%02d' % (
                self.title,
                int(data.get('season')),
                int(data.get('episode'))) if data.get('tvshowtitle') else '%s %s' % (
                self.title,
                data.get('year'))
            query = re.sub(r'(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', ' ', query)
            urls = []
            if data.get('tvshowtitle'):
                urls.extend(
                    (
                        self.tvsearch % (quote(query)),
                        self.tvsearch.format(quote(query), '2'),
                        self.tvsearch.format(quote(query), '3'),
                    )
                )
            else:
                urls.extend(
                    (
                        self.moviesearch % (quote(query)),
                        self.moviesearch.format(quote(query), '2'),
                        self.moviesearch.format(quote(query), '3'),
                    )
                )

            # fetch items concurrently with retry-safe requests
            threads = []
            threads.extend(workers.Thread(self._get_items, url) for url in urls)
            [i.start() for i in threads]
            [i.join() for i in threads]

            # get detail sources concurrently
            self.hostDict = hostDict
            threads2 = []
            threads2.extend(workers.Thread(self._get_sources, i) for i in self.items)
            [i.start() for i in threads2]
            [i.join() for i in threads2]

            return self._sources
        except Exception as e:
            c.log(f'1337x_exc2: {e}', 1)
            return self._sources

    def _get_items(self, url):
        try:

            r = self._safe_request(url, timeout=10, retries=2)

            # Validate response before ensure_text
            if r is None or not r:
                c.log(f"[1337x] Empty or None response from request: {url}")
                return

            r = c.ensure_text(r, errors='replace')

            posts = client.parseDom(r, 'tbody')
            if not posts:
                c.log(f"[1337x] No tbody found in response (len={len(r)} chars) for {url}")
                return
            posts = client.parseDom(posts[0], 'tr')
            for post in posts:
                a_tags = client.parseDom(post, 'a')
                a_hrefs = client.parseDom(post, 'a', ret='href')
                if len(a_tags) < 2 or len(a_hrefs) < 2:
                    continue
                link = urljoin(self.base_link, a_hrefs[1])
                name = a_tags[1]
                t = name.split(self.hdlr)[0]

                if cleantitle.get(re.sub('(|)', '', t)) != cleantitle.get(self.title):
                    continue

                try:
                    y = re.findall(r'[\.|\(|\[|\s|\_|\-](S\d+E\d+|S\d+)[\.|\)|\]|\s|\_|\-]', name, re.I)[-1].upper()
                except Exception:
                    y = re.findall(r'[\.|\(|\[|\s\_|\-](\d{4})[\.|\)|\]|\s\_|\-]', name, re.I)[-1].upper()
                if y != self.hdlr:
                    continue

                try:
                    size = re.findall(r'((?:\d+\,\d+\.\d+|\d+\.\d+|\d+\,\d+|\d+)\s*(?:GiB|MiB|GB|MB))', post)[0]
                    dsize, isize = source_utils._size(size)
                except BaseException:
                    dsize, isize = 0.0, ''

                self.items.append((name, link, isize, dsize))
            return self.items
        except Exception as e:
            c.log(f'1337x_exc0: {e}', 1)
            return self.items

    def _get_sources(self, item):
        try:
            name = item[0]
            quality, info = source_utils.get_release_quality(name, item[1])
            info.insert(0, item[2])
            data = self._safe_request(item[1], timeout=10, retries=2)
            if not data:
                c.log(f"[1337x] Empty detail page for {item[1]}")
                return
            data = c.ensure_text(data, errors='replace')
            data = client.parseDom(data, 'a', ret='href')
            mags = [i for i in data if 'magnet:' in i]
            if not mags:
                c.log(f"[1337x] No magnet link found on detail page {item[1]}")
                return
            url = mags[0]
            url = url.split('&tr')[0]
            info = ' | '.join(info)

            self._sources.append(
                {
                    'source': 'Torrent', 'quality': quality, 'language': 'en', 'url': url,
                    'info': info, 'direct': False, 'debridonly': True, 'size': item[3],
                    'name': name
                })
        except Exception as e:
            c.log(f'1337x_exc1: {e}', 1)
            pass

    def sources_packs(self, data, hostDict, search_series=False, total_seasons=0, bypass_filter=0):
        """
        Searches for torrents matching the given TV show.

        :param data: TV show data from the metadata module
        :param hostDict: Dictionary of hosters and their corresponding functions
        :param search_series: Whether to search for the entire series or just the current season
        :param total_seasons: The total number of seasons in the TV show
        :param bypass_filter: Whether to bypass the filter or not
        :return: A list of dictionaries containing the torrent information
        """
        sources = []
        # reference or remove unused params to satisfy linters/static analysis
        try:
            # mark unused parameters to avoid "unused argument" warnings
            del hostDict, bypass_filter
            if debrid.status() is False:
                return sources

            tvshowtitle = data.get('tvshowtitle')
            year = data.get('year')
            season = int(data.get('season', 0))
            imdb = data.get('imdb')
            aliases = data.get('aliases', [])

            if not tvshowtitle:
                return sources

            title_query = cleantitle.get_query(tvshowtitle)

            queries = []
            if search_series:
                queries.extend(
                    (
                        f'{title_query} Complete Series',
                        f'{title_query} All Seasons',
                    )
                )
            else:
                queries.extend(
                    (
                        f'{title_query} S{season:02d}',
                        f'{title_query} Season {season}',
                    )
                )
            for query in queries:
                try:
                    search_url = self.tvsearch % quote(query)
                    r = client.request(search_url)
                    r = c.ensure_text(r, errors='replace')

                    posts = client.parseDom(r, 'tbody')[0]
                    posts = client.parseDom(posts, 'tr')

                    for post in posts:
                        try:
                            a_hrefs = client.parseDom(post, 'a', ret='href')
                            a_tags = client.parseDom(post, 'a')
                            if len(a_hrefs) < 2 or len(a_tags) < 2:
                                continue
                            link = urljoin(self.base_link, a_hrefs[1])
                            name = a_tags[1]

                            # Filter using pack validation
                            if search_series:
                                valid, last_season = source_utils.filter_show_pack(
                                    tvshowtitle, aliases, imdb, year, season,
                                    source_utils.release_title_format(name), total_seasons
                                )
                                if not valid:
                                    continue
                                package_meta = {'package': 'show', 'last_season': last_season}
                            else:
                                valid, episode_start, episode_end = source_utils.filter_season_pack(
                                    tvshowtitle, aliases, year, season,
                                    source_utils.release_title_format(name)
                                )
                                if not valid:
                                    continue
                                package_meta = {
                                    'package': 'season',
                                    'episode_start': episode_start,
                                    'episode_end': episode_end
                                }

                            try:
                                size = re.findall(r'((?:\d+\,\d+\.\d+|\d+\.\d+|\d+\,\d+|\d+)\s*(?:GiB|MiB|GB|MB))', post)[0]
                                dsize, isize = source_utils._size(size)
                            except BaseException:
                                dsize, isize = 0.0, ''

                            # Get magnet link
                            try:
                                detail_page = client.request(link)
                                detail_page = c.ensure_text(detail_page, errors='replace')
                                detail_data = client.parseDom(detail_page, 'a', ret='href')
                                url = [i for i in detail_data if 'magnet:' in i][0]
                                url = url.split('&tr')[0]
                            except Exception:
                                continue

                            quality, info = source_utils.get_release_quality(name, link)
                            info.insert(0, isize)
                            info = ' | '.join(info)

                            source_dict = {
                                'source': 'Torrent',
                                'quality': quality,
                                'language': 'en',
                                'url': url,
                                'info': info,
                                'direct': False,
                                'debridonly': True,
                                'size': dsize,
                                'name': name
                            }
                            source_dict.update(package_meta)
                            sources.append(source_dict)

                        except Exception as e:
                            c.log(f'1337x Pack - Error processing item: {e}', 1)
                            continue

                except Exception as e:
                    c.log(f'1337x Pack - Error searching: {e}', 1)
                    continue

            return sources
        except Exception as e:
            c.log(f'1337x Pack - Exception: {e}', 1)
            return sources

    def __get_base_url(self, fallback):
        # Try known domains and return the first that responds with an expected title
        for domain in self.domains:
            try:
                url = f'https://{domain}'
                result = self._safe_request(url, timeout=7, retries=1)
                if not result:
                    continue
                result = c.ensure_text(result, errors='ignore')
                m = re.findall('<title>(.+?)</title>', result, re.DOTALL)
                if m and '1337x' in m[0].lower():
                    return url
            except Exception:
                continue
        # fallback to the default supplied
        return fallback

    def resolve(self, url):
        return url
