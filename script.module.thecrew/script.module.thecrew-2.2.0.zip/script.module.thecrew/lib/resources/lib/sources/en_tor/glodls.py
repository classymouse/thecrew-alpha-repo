# -*- coding: utf-8 -*-

'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

from resources.lib.modules import debrid
from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import source_utils

from urllib.parse import urlencode, quote_plus, quote, parse_qs, urljoin


class source:
    pack_capable = True

    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['glodls.to']
        self.base_link = 'https://glodls.to/'
        self.tvsearch = 'search_results.php?search={0}&cat=41&incldead=0&inclexternal=0&lang=1&sort=seeders&order=desc'
        self.moviesearch = 'search_results.php?search={0}&cat=1&incldead=0&inclexternal=0&lang=1&sort=size&order=desc'


    def sources(self, data, hostDict):
        sources = []
        try:
            if not data:
                return sources

            if debrid.status() is False:
                raise Exception()

            self.title = data.get('tvshowtitle') if data.get('tvshowtitle') else data.get('title')
            self.hdlr = 'S%02dE%02d' % (int(data.get('season')), int(data.get('episode'))) if data.get('tvshowtitle') else data.get('year')

            query = '%s S%02dE%02d' % (
            data.get('tvshowtitle'), int(data.get('season')), int(data.get('episode'))) if data.get('tvshowtitle') else '%s %s' % (
            data.get('title'), data.get('year'))
            query = re.sub('(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', ' ', query)
            if data.get('tvshowtitle'):
                url = self.tvsearch.format(urllib.quote_plus(query))
                url = urljoin(self.base_link, url)

            else:
                url = self.moviesearch.format(quote_plus(query))
                url = urljoin(self.base_link, url)

            items = self._get_items(url)

            for item in items:
                try:
                    name = item[0]
                    quality, info = source_utils.get_release_quality(name, name)
                    info.append(item[2])
                    info = ' | '.join(info)
                    url = item[1]
                    url = url.split('&tr')[0]

                    sources.append({'source': 'Torrent', 'quality': quality, 'language': 'en', 'url': url, 'info': info,
                                    'direct': False, 'debridonly': True})
                except BaseException:
                    pass

            return sources
        except BaseException:
            return sources

    def _get_items(self, url):
        items = []
        try:
            headers = {'User-Agent': client.agent()}
            r = client.request(url, headers=headers)
            posts = client.parseDom(r, 'tr', attrs={'class': 't-row'})
            posts = [i for i in posts if not 'racker:' in i]
            for post in posts:
                data = client.parseDom(post, 'a', ret='href')
                url = [i for i in data if 'magnet:' in i][0]
                name = client.parseDom(post, 'a', ret='title')[0]
                t = name.split(self.hdlr)[0]

                if not cleantitle.get(re.sub('(|)', '', t)) == cleantitle.get(self.title): continue

                try:
                    y = re.findall('[\.|\(|\[|\s|\_|\-](S\d+E\d+|S\d+)[\.|\)|\]|\s|\_|\-]', name, re.I)[-1].upper()
                except BaseException:
                    y = re.findall('[\.|\(|\[|\s\_|\-](\d{4})[\.|\)|\]|\s\_|\-]', name, re.I)[-1].upper()
                if not y == self.hdlr: continue

                try:
                    size = re.findall('((?:\d+\,\d+\.\d+|\d+\.\d+|\d+\,\d+|\d+)\s*(?:GiB|MiB|GB|MB))', post)[0]
                    div = 1 if size.endswith('GB') else 1024
                    size = float(re.sub('[^0-9|/.|/,]', '', size.replace(',', '.'))) / div
                    size = '%.2f GB' % size

                except BaseException:
                    size = '0'

                items.append((name, url, size))
            return items
        except BaseException:
            return items

    def sources_packs(self, data, hostDict, search_series=False, total_seasons=0, bypass_filter=0):
        sources = []
        try:
            if debrid.status() is False:
                return sources

            tvshowtitle = data.get('tvshowtitle')
            year = data.get('year')
            season = int(data.get('season', 0))
            imdb = data.get('imdb')
            aliases = data.get('aliases', [])

            if not tvshowtitle:
                return sources

            title_query = cleantitle.get_query(tvshowtitle)
            queries = []
            if search_series:
                queries.append(f'{title_query} Complete Series')
            else:
                queries.append(f'{title_query} S{season:02d}')

            for query in queries:
                try:
                    url = self.tvsearch.format(quote_plus(query))
                    url = urljoin(self.base_link, url)
                    r = client.request(url)

                    posts = client.parseDom(r, 'tr', attrs={'class': 't-row'})
                    for post in posts:
                        try:
                            name = client.parseDom(post, 'a', attrs={'class': 'pn'})[0]

                            if search_series:
                                valid, last_season = source_utils.filter_show_pack(
                                    tvshowtitle, aliases, imdb, year, season,
                                    source_utils.release_title_format(name), total_seasons
                                )
                                if not valid:
                                    continue
                                package_meta = {'package': 'show', 'last_season': last_season}
                            else:
                                valid, episode_start, episode_end = source_utils.filter_season_pack(
                                    tvshowtitle, aliases, year, season,
                                    source_utils.release_title_format(name)
                                )
                                if not valid:
                                    continue
                                package_meta = {'package': 'season', 'episode_start': episode_start, 'episode_end': episode_end}

                            url_magnet = client.parseDom(post, 'a', ret='href', attrs={'class': 'ttth'})[0]
                            if not url_magnet.startswith('magnet'):
                                url_magnet = urljoin(self.base_link, url_magnet)
                                r2 = client.request(url_magnet)
                                url_magnet = re.findall('href="(magnet:.+?)"', r2, re.DOTALL)[0]
                            url_magnet = url_magnet.split('&tr=')[0]

                            quality, info = source_utils.get_release_quality(name, name)
                            try:
                                size = re.findall(r'((?:\d+\.\d+|\d+\,\d+|\d+)\s*(?:GB|GiB|MB|MiB))', post)[0]
                                div = 1 if size.endswith(('GB', 'GiB')) else 1024
                                size = float(re.sub('[^0-9|/.|/,]', '', size.replace(',', '.'))) / div
                                size = '%.2f GB' % size
                            except BaseException:
                                size = '0'
                            info.append(size)
                            info = ' | '.join(info)

                            source_dict = {'source': 'Torrent', 'quality': quality, 'language': 'en',
                                         'url': url_magnet, 'info': info, 'direct': False, 'debridonly': True}
                            source_dict.update(package_meta)
                            sources.append(source_dict)
                        except BaseException:
                            continue
                except BaseException:
                    continue
            return sources
        except BaseException:
            return sources


    def resolve(self, url):
        return url