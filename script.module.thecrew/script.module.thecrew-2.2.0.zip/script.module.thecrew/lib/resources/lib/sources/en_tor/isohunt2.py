# -*- coding: utf-8 -*-
'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

from urllib.parse import parse_qs, urljoin, urlencode, quote_plus, unquote

from resources.lib.modules import debrid
from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import source_utils

from resources.lib.modules.crewruntime import c



class source:
    pack_capable = True

    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['isohunt2.net']
        self.base_link = 'https://isohunt.nz'
        self.search_link = '/torrent/?ihq=%s&fiht=2&age=0&Torrent_sort=seeders'

    def sources(self, data, hostDict):
        try:
            size = re.findall(r'((?:\d+\,\d+\.\d+|\d+\.\d+|\d+\,\d+|\d+)\s*(?:GiB|MiB|GB|MB))', getsize)[0]
            div = 1 if size.endswith('GB') else 1024
            size = float(re.sub(r'[^0-9|/.|/,]', '', size.replace(',', '.'))) / div
            return '%.2f GB' % size
        except BaseException:
            return '0'

    def process_link(self, link, data, getsize):

        url = unquote(link)
        url = url.split('url=')[1].split('&tr=')[0].replace('%28', '(').replace('%29',')')
        quality, info = source_utils.get_release_quality(data)
        info.append(self.extract_size(getsize))
        info = ' | '.join(info)
        return {'source': 'Torrent', 'quality': quality, 'language': 'en', 'url': url, 'info': info, 'direct': False, 'debridonly': True}

    def sources(self, data, hostDict):
        sources = []
        try:
            if not data:
                return sources
            if debrid.status() is False:
                raise Exception()

            title = data.get('tvshowtitle') if data.get('tvshowtitle') else data.get('title')

            hdlr = 'S%02dE%02d' % (int(data.get('season')), int(data.get('episode'))) if data.get('tvshowtitle') else data.get('year')

            query = '%s S%02dE%02d' % (
            data.get('tvshowtitle'), int(data.get('season')), int(data.get('episode'))) if data.get('tvshowtitle') else '%s %s' % (
            data.get('title'), data.get('year'))
            query = re.sub(r'(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', ' ', query)

            url = self.search_link % quote_plus(query)
            url = urljoin(self.base_link, url).replace('++', '+')

            r = client.request(url)
            posts = client.parseDOM(r, 'tbody')[0]
            posts = client.parseDOM(posts, 'tr')
            for post in posts:
                links = re.compile('<a href="(/torrent_details/.+?)">\n<span>(.+?)</span>').findall(post)
                for link, data in links:
                    if hdlr not in data:
                        continue
                    link = urljoin(self.base_link, link)
                    if any(x in link for x in ['FRENCH', 'Ita', 'ITA', 'italian', 'Tamil', 'TRUEFRENCH', '-lat-', 'Dublado', 'Dub', 'Rus', 'Hindi']):
                        continue
                    link = client.request(link)
                    getsize = re.findall('Size&nbsp;(.+?)&nbsp', link, re.DOTALL)[0]
                    sources.append(self.process_link(link, data, getsize))
        except Exception:
            return sources
        return sources

    def sources_packs(self, data, hostDict, search_series=False, total_seasons=0, bypass_filter=0):
        sources = []
        try:
            tvshowtitle = data.get('tvshowtitle')
            year = data.get('year')
            season = int(data.get('season', 0))
            imdb = data.get('imdb')
            aliases = data.get('aliases', [])

            if not tvshowtitle:
                return sources

            title_query = cleantitle.get_query(tvshowtitle)
            queries = []
            if search_series:
                queries.append(f'{title_query} Complete Series')
            else:
                queries.append(f'{title_query} S{season:02d}')

            for query in queries:
                try:
                    url = self.search_link % quote_plus(query)
                    url = urljoin(self.base_link, url)
                    r = client.request(url)

                    posts = client.parseDom(r, 'tr', attrs={'class': 't-row'})
                    for post in posts:
                        try:
                            data_elem = client.parseDom(post, 'td', attrs={'class': 'title-row'})[0]
                            link = client.parseDom(data_elem, 'a', ret='href')[0]
                            name = client.parseDom(data_elem, 'a')[0]

                            if search_series:
                                valid, last_season = source_utils.filter_show_pack(
                                    tvshowtitle, aliases, imdb, year, season,
                                    source_utils.release_title_format(name), total_seasons
                                )
                                if not valid:
                                    continue
                                package_meta = {'package': 'show', 'last_season': last_season}
                            else:
                                valid, episode_start, episode_end = source_utils.filter_season_pack(
                                    tvshowtitle, aliases, year, season,
                                    source_utils.release_title_format(name)
                                )
                                if not valid:
                                    continue
                                package_meta = {'package': 'season', 'episode_start': episode_start, 'episode_end': episode_end}

                            link = urljoin(self.base_link, link)
                            detail_page = client.request(link)
                            getsize = re.findall('Size&nbsp;(.+?)&nbsp', detail_page, re.DOTALL)[0]

                            url_magnet = unquote(detail_page.split('url=')[1].split('&tr=')[0])
                            quality, info = source_utils.get_release_quality(name)
                            info.append(self.extract_size(getsize))
                            info = ' | '.join(info)

                            source_dict = {'source': 'Torrent', 'quality': quality, 'language': 'en',
                                         'url': url_magnet, 'info': info, 'direct': False, 'debridonly': True}
                            source_dict.update(package_meta)
                            sources.append(source_dict)
                        except Exception:
                            continue
                except Exception:
                    continue
            return sources
        except Exception:
            return sources

    def resolve(self, url):
        return url
