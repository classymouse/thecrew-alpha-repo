# -*- coding: utf-8 -*-

'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

from resources.lib.modules import debrid
from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import workers
from resources.lib.modules import source_utils

from urllib.parse import parse_qs, urljoin, urlencode, quote


class source:
    pack_capable = True

    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['limetorrents.info']
        self.base_link = 'https://www.limetorrents.info' # cm - blocked
        self.tvsearch = 'https://www.limetorrents.info/search/tv/{0}/'
        self.moviesearch = 'https://www.limetorrents.info/search/movies/{0}/'

    def sources(self, data, hostDict):
        try:
            self._sources = []
            self.items = []
            if not data:
                return self._sources

            if debrid.status() is False:
                raise Exception()

            self.title = data.get('tvshowtitle') or data.get('title')
            self.hdlr = 'S%02dE%02d' % (int(data.get('season')), int(data.get('episode'))) if data.get('tvshowtitle') else data.get('year')

            query = '%s S%02dE%02d' % (
            data.get('tvshowtitle'), int(data.get('season')), int(data.get('episode'))) if data.get('tvshowtitle') else '%s %s' % (
            data.get('title'), data.get('year'))
            query = re.sub(r'(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', ' ', query)
            if data.get('tvshowtitle'):
                url = self.tvsearch.format(quote(query))
            else:
                url = self.moviesearch.format(quote(query))

            self._get_items(url)
            self.hostDict = hostDict

            return self._sources
        except BaseException:
            return self._sources

    def _get_items(self, url):
        try:
            headers = {'User-Agent': client.agent()}
            r = client.request(url, headers=headers)
            posts = client.parseDom(r, 'table', attrs={'class': 'table2'})[0]
            posts = client.parseDom(posts, 'tr')
            for post in posts:
                data = client.parseDom(post, 'a', ret='href')[1]
                link = urljoin(self.base_link, data)
                name = client.parseDom(post, 'a')[1]
                t = name.split(self.hdlr)[0]

                if cleantitle.get(re.sub(r'(\(|\))', '', t)) != cleantitle.get(self.title):
                    continue

                try:
                    y = re.findall(r'[\.|\(|\[|\s|\_|\-](S\d+E\d+|S\d+)[\.|\)|\]|\s|\_|\-]', name, re.I)[-1].upper()
                except BaseException:
                    y = re.findall(r'[\.|\(|\[|\s\_|\-](\d{4})[\.|\)|\]|\s\_|\-]', name, re.I)[-1].upper()
                if y != self.hdlr:
                    continue

                try:
                    size = re.findall(r'((?:\d+\,\d+\.\d+|\d+\.\d+|\d+\,\d+|\d+)\s*(?:GiB|MiB|GB|MB))', post)[0]
                    div = 1 if size.endswith('GB') else 1024
                    size = float(re.sub('[^0-9|/.|/,]', '', size.replace(',', '.'))) / div
                    size = '%.2f GB' % size
                except BaseException:
                    size = '0'

                self.items.append((name, link, size))
            return self.items
        except BaseException:
            return self.items

    def _get_sources(self, item):
        try:
            name = item[0]
            quality, info = source_utils.get_release_quality(name, name)
            info.append(item[2])
            info = ' | '.join(info)
            data = client.request(item[1])
            m = re.search(r"href=[\"'](magnet:\\?[^\"']+)", data)
            if not m:
                return
            url = m[1]

            self._sources.append(
                {
                    'source': 'torrent', 'quality': quality, 'language': 'en', 'url': url,
                    'info': info, 'direct': False, 'debridonly': True
                    })
        except BaseException:
            pass

    def sources_packs(self, data, _hostDict, search_series=False, total_seasons=0, _bypass_filter=0):
        """
        Searches for torrents matching the given TV show.

        :param data: TV show data from the metadata module
        :param _hostDict: Dictionary of hosters and their respective functions
        :param search_series: Whether to search for the entire series or just the current season
        :param total_seasons: The total number of seasons in the TV show
        :param _bypass_filter: Whether to bypass the filter or not
        :return: A list of dictionaries containing the torrent information
        """
        sources = []
        del _hostDict
        del _bypass_filter
        try:
            if not debrid.status():
                return sources

            tvshowtitle = data.get('tvshowtitle')
            year = data.get('year')
            season = int(data.get('season', 0))
            imdb = data.get('imdb')
            aliases = data.get('aliases', [])

            if not tvshowtitle:
                return sources

            title_query = cleantitle.get_query(tvshowtitle)

            queries = []
            if search_series:
                queries.append(f'{title_query} Complete Series')
                queries.append(f'{title_query} All Seasons')
            else:
                queries.append(f'{title_query} S{season:02d}')
                queries.append(f'{title_query} Season {season}')

            for query in queries:
                try:
                    search_url = self.tvsearch.format(quote(query))
                    headers = {'User-Agent': client.agent()}
                    r = client.request(search_url, headers=headers)

                    posts = client.parseDom(r, 'table', attrs={'class': 'table2'})[0]
                    posts = client.parseDom(posts, 'tr')

                    for post in posts:
                        try:
                            link = client.parseDom(post, 'a', ret='href')[1]
                            link = urljoin(self.base_link, link)
                            name = client.parseDom(post, 'a')[1]

                            # Filter using pack validation
                            if search_series:
                                valid, last_season = source_utils.filter_show_pack(
                                    tvshowtitle, aliases, imdb, year, season,
                                    source_utils.release_title_format(name), total_seasons
                                )
                                if not valid:
                                    continue
                                package_meta = {'package': 'show', 'last_season': last_season}
                            else:
                                valid, episode_start, episode_end = source_utils.filter_season_pack(
                                    tvshowtitle, aliases, year, season,
                                    source_utils.release_title_format(name)
                                )
                                if not valid:
                                    continue
                                package_meta = {
                                    'package': 'season',
                                    'episode_start': episode_start,
                                    'episode_end': episode_end
                                }

                            try:
                                size = re.findall(r'((?:\d+\,\d+\.\d+|\d+\.\d+|\d+\,\d+|\d+)\s*(?:GiB|MiB|GB|MB))', post)[0]
                                div = 1 if size.endswith('GB') else 1024
                                size_val = float(re.sub('[^0-9|/.|/,]', '', size.replace(',', '.'))) / div
                                size = '%.2f GB' % size_val
                            except BaseException:
                                size = '0'

                            # Get magnet link
                            try:
                                detail_data = client.request(link)
                                url = re.search(r'''href=["'](magnet:\?[^"']+)''', detail_data).groups()[0]
                            except Exception:
                                continue

                            quality, info = source_utils.get_release_quality(name, name)
                            info.append(size)
                            info = ' | '.join(info)

                            source_dict = {
                                'source': 'torrent',
                                'quality': quality,
                                'language': 'en',
                                'url': url,
                                'info': info,
                                'direct': False,
                                'debridonly': True
                            }
                            source_dict.update(package_meta)
                            sources.append(source_dict)

                        except BaseException as e:
                            continue

                except BaseException as e:
                    continue

            return sources
        except BaseException:
            return sources

    def resolve(self, url):
        return url
