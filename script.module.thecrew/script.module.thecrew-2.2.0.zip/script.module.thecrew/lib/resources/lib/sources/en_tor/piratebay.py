# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file piratebay.py
* @package script.module.thecrew
*
* @copyright (c) 2025, The Crew
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*
'''

import re
import traceback
import ast
from urllib.parse import parse_qs, urljoin, urlencode, quote_plus

from resources.lib.modules import cache, cleantitle, client, control, debrid, source_utils
from resources.lib.modules.crewruntime import c


class source:
    pack_capable = True

    def __init__(self):
        self.priority = 0
        self.language = ['en']
        self.domains = [
            'prbay.top','pirateproxy.live', 'thepiratebay.org', 'thepiratebay.fun',
            'thepiratebay.asia', 'tpb.party', 'thepiratebay3.org', 'thepiratebayz.org',
            'thehiddenbay.com', 'piratebay.live', 'thepiratebay.zone'
            ]
        #self._base_link = None
        #self.search_link = '/s/?q=%s&page=0&&video=on&orderby=99'
        self._base_link = "https://apibay.org"
        self.search_link = '/q.php?q=%s&cat=0'
        #self.search_link = '/search/%s/1/99/200' #-direct link can flip pages

        try:
            self.min_seeders = int(control.setting('torrent.min.seeders') or 0)
        except Exception:
            self.min_seeders = 0

    @property
    def base_url(self):
        """Return the base URL of the torrent site.

        The base URL is the URL of the torrent site without any query
        parameters. It is retrieved from cache and updated every 2
        minutes.
        """
        if self._base_link is None:
            default_url = f"https://{self.domains[0]}"
            self._base_link = cache.get(self.__get_base_url, 120, default_url)

        return self._base_link

    @base_url.setter
    def base_url(self, value):
        """Setter for the base_url property.

        This method sets the base URL of the torrent site. The base URL
        is the URL of the torrent site without any query parameters.
        """
        self._base_link = value

    def sources(self, data, hostDict):
        """
        {
            "id": "53458028",
            "name": "4400 S01E01 480p x264-mSD",
            "info_hash": "8EA36B7B4F7F381A4703CE5308BF9F751B8AACBE",
            "leechers": "0",
            "seeders": "1",
            "num_files": "0",
            "size": "170288742",
            "username": "jajaja",
            "added": "1635245412",
            "status": "vip",
            "category": "205",
            "imdb": ""
        }
        """
        try:
            sources = []

            if not data:
                return sources

            title = data.get('tvshowtitle') if data.get('tvshowtitle') else data.get('title')
            hdlr = 'S%02dE%02d' % (int(data.get('season')), int(data.get('episode'))) if data.get('tvshowtitle') else data.get('year')

            query = '%s S%02dE%02d' % (
                data.get('tvshowtitle'),
                int(data.get('season')),
                int(data.get('episode'))) if data.get('tvshowtitle') else '%s %s' % (
                data.get('title'),
                data.get('year'))
            query = re.sub(r'(\\\|/| -|:|;|\*|\?|"|<|>|\|)', ' ', query)
            url = self.search_link % quote_plus(query)

            url = urljoin(self.base_url, url)
            #c.log(f"[CM Debug @ 130 in piratebay.py] url = {url}")
            html = client.request(url)
            #c.log(f"[CM Debug @ 117 in piratebay.py] html: {html}")
            #c.log(f"[CM Debug @ 133 in piratebay.py] type html: {type(html)}")

            def process_entry(entry, title, hdlr):
                try:
                    name = entry['name']

                    if str(cleantitle.get(title)) not in str(cleantitle.get(name)):
                        return
                    y = re.findall(r'[\.|\(|\[|\s](\d{4}|S\d*E\d*|S\d*)[\.|\)|\]|\s]', name)
                    if y:
                        y = y[-1].upper()
                    if y != hdlr:
                        return

                    seeders = int(entry['seeders'])
                    if self.min_seeders > seeders:
                        return

                    link = f'magnet:?xt=urn:btih:{entry["info_hash"]}'
                    quality, info = source_utils.get_release_quality(name, name)

                    size = entry['size']
                    if size == 0:
                        size = '0.00 GB'
                    else:
                        size = float(size) / 1024 / 1024 / 1024
                        size = f'{size:.2f} GB'
                    info.insert(0, size)

                    info = ' | '.join(info)
                    sources.append({'source': 'Torrent', 'quality': quality, 'language': 'en', 'url': link, 'info': info, 'direct': False, 'debridonly': True})
                except Exception as e:
                    failure = traceback.format_exc()
                    c.log(f'[CM Debug @ 178 in piratebay.py]Traceback:: {failure}')
                    c.log(f'[CM Debug @ 178 in piratebay.py]Exception raised. Error = {e}')

            if html.startswith('['):
                try:
                    # html is a list in text so i need to convert it to a plain list
                    # ast.literal_eval creates a safe envir for py 3.x
                    html = ast.literal_eval(html)
                    if not html:
                        return sources
                    for entry in html:
                        process_entry(entry, title, hdlr)
                except Exception as e:
                    failure = traceback.format_exc()
                    c.log(f'[CM Debug @ 188 in piratebay.py]Traceback:: {failure}')
                    c.log(f'[CM Debug @ 189 in piratebay.py]Exception raised. Error = {e}')            #we have a listing returned

                try:
                    # c.log(f"[CM Debug @ 211 in piratebay.py] html is of type: {type(html)} and = {html}")
                    # Ensure html is a decoded string if bytes
                    if isinstance(html, bytes):
                        # c.log(f"[CM Debug @ 213 in piratebay.py] type(html): {type(html)} is bytes, decoding to str")
                        html = html.decode('utf-8')
                    # If html is a string representation of a list, parse it into a Python list
                    if isinstance(html, str):
                        try:
                            html = ast.literal_eval(html)
                        except Exception:
                            # leave as-is if cannot parse; further checks will guard against wrong types
                            pass
                    if not html:
                        return sources
                    # Only iterate if html is a list-like of dicts
                    if not isinstance(html, (list, tuple)):
                        return sources
                    for entry in html:
                        try:
                            # skip non-dict entries (protects against bytes iter yielding ints)
                            if not isinstance(entry, dict):
                                continue
                            name = entry.get('name', '')
                            if str(cleantitle.get(title)) not in str(cleantitle.get(name)):
                                continue
                            y = re.findall(r'[\.|\(|\[|\s](\d{4}|S\d*E\d*|S\d*)[\.|\)|\]|\s]', name)
                            if y:
                                y = y[-1].upper()
                            if y != hdlr:
                                continue

                            seeders = int(entry.get('seeders', 0))
                            if self.min_seeders > seeders:
                                continue

                            link = f'magnet:?xt=urn:btih:{entry.get("info_hash", "")}'
                            quality, info = source_utils.get_release_quality(name, name)

                            size = entry.get('size', 0)
                            #c.log(f"[CM Debug @ 146 in piratebay.py] size in bytes = {size} with type = {type(size)}")
                            try:
                                if int(size) == 0:
                                    size = '0.00 GB'
                                else:
                                    size = float(size) / 1024 / 1024 / 1024
                                    size = f'{size:.2f} GB'
                            except Exception:
                                size = '0.00 GB'
                            #c.log(f"[CM Debug @ 150 in piratebay.py] size = {size} with type = {type(size)}")
                            info.insert(0, size)

                            info = ' | '.join(info)
                            sources.append({'source': 'Torrent', 'quality': quality, 'language': 'en', 'url': link, 'info': info, 'direct': False, 'debridonly': True})
                        except Exception as e:
                            failure = traceback.format_exc()
                            c.log(f'[CM Debug @ 178 in piratebay.py]Traceback:: {failure}')
                            c.log(f'[CM Debug @ 178 in piratebay.py]Exception raised. Error = {e}')

                        #except Exception as e:
                        #    c.log(f'TPB2 - Failed to parse search results:{e}')
                        #    continue
                except Exception as e:
                    failure = traceback.format_exc()
                    c.log(f'[CM Debug @ 171 in piratebay.py]Traceback:: {failure}')
                    c.log(f'[CM Debug @ 171 in piratebay.py]Exception raised. Error = {e}')

            else:
                html = html.replace('&nbsp;', ' ')
                try:
                    #results = client.parseDom(html, 'table', attrs={'id': 'searchResult'})[0]
                    results = client.parseDom(html, 'table', attrs={'id': 'searchResult'})[0]
                except Exception as e:
                    c.log(f'TPB1 - Failed to parse search results:{e}')
                    return sources
                rows = re.findall('<tr(.+?)</tr>', results, re.DOTALL)
                if rows is None:
                    return sources

                for entry in rows:
                    try:
                        try:
                            name = re.findall('class="detLink" title=".+?">(.+?)</a>', entry, re.DOTALL)[0]
                            name = client.replaceHTMLCodes(name)
                            # t = re.sub('(\.|\(|\[|\s)(\d{4}|S\d*E\d*|S\d*|3D)(\.|\)|\]|\s|)(.+|)', '', name, flags=re.I)
                            t_title = cleantitle.get(title) or ''
                            t_name = cleantitle.get(name) or ''
                            if t_title not in t_name:
                                continue
                        except Exception:
                            continue
                        y = re.findall(r'[\.|\(|\[|\s](\d{4}|S\d*E\d*|S\d*)[\.|\)|\]|\s]', name)[-1].upper()
                        if y != hdlr:
                            continue

                        try:
                            seeders = int(re.findall('<td align="right">(.+?)</td>', entry, re.DOTALL)[0])
                        except Exception:
                            continue
                        if self.min_seeders > seeders:
                            continue

                        try:
                            link = 'magnet:%s' % (re.findall('a href="magnet:(.+?)"', entry, re.DOTALL)[0])
                            link = str(client.replaceHTMLCodes(link).split('&tr')[0])
                        except Exception:
                            continue

                        quality, info = source_utils.get_release_quality(name, name)

                        try:
                            size = re.findall(r'((?:\d+\.\d+|\d+\,\d+|\d+)\s*(?:GB|GiB|MB|MiB))', entry)[-1]
                            div = 1 if size.endswith(('GB', 'GiB')) else 1024
                            size = float(re.sub('[^0-9|/.|/,]', '', size)) / div
                            size = f'{size:.2f} GB'
                            info.append(size)
                        except Exception:
                            pass

                        info = ' | '.join(info)
                        sources.append({'source': 'Torrent', 'quality': quality, 'language': 'en', 'url': link, 'info': info, 'direct': False, 'debridonly': True})
                    except Exception as e:
                        c.scraper_error('Exception in pack processing', exc_info=e)
                        continue

            check = [i for i in sources if i['quality'] != 'CAM']
            if check:
                sources = check

            return sources
        except Exception:
            failure = traceback.format_exc()
            c.log('TPB - Exception: \n' + str(failure))
            return sources

    def sources_packs(self, data, hostDict, search_series=False, total_seasons=0, bypass_filter=0):
        """
        Search for pack releases (season packs or show packs).

        Args:
            data: Dict with keys: tvshowtitle, year, season, episode, imdb, aliases
            hostDict: Host dictionary for debrid validation
            search_series: If True, search for complete series packs
            total_seasons: Total number of seasons (for show pack validation)
            bypass_filter: If >0, skip pack validation filters

        Returns:
            List of source dicts with pack metadata
        """
        sources = []

        try:
            if debrid.status(True) is False:
                return sources

            tvshowtitle = data.get('tvshowtitle')
            year = data.get('year')
            season = int(data.get('season', 0))
            imdb = data.get('imdb')
            aliases = data.get('aliases', [])

            if not tvshowtitle:
                return sources

            # Format title for pack search
            title_query = cleantitle.get_query(tvshowtitle)

            # Build search queries
            queries = []

            if search_series:
                # Complete series pack searches
                queries.append(f'{title_query} Complete Series')
                queries.append(f'{title_query} All Seasons')
                queries.append(f'{title_query} Season 1-{total_seasons}' if total_seasons > 0 else None)
            else:
                # Season pack searches
                queries.append(f'{title_query} S{season:02d}')
                queries.append(f'{title_query} Season {season}')
                queries.append(f'{title_query} Season.{season}')

            # Remove None entries
            queries = [q for q in queries if q]

            for query in queries:
                try:
                    url = self.search_link % quote_plus(query)
                    url = urljoin(self.base_url, url)
                    html = client.request(url)

                    if not html:
                        continue

                    # Parse API response (JSON array)
                    if html.startswith('['):
                        try:
                            entries = ast.literal_eval(html)
                            if not isinstance(entries, list):
                                continue

                            for entry in entries:
                                if not isinstance(entry, dict):
                                    continue

                                try:
                                    name = entry.get('name', '')
                                    if not name:
                                        continue

                                    # Filter using pack validation
                                    if search_series:
                                        # Validate show pack
                                        valid, last_season = source_utils.filter_show_pack(
                                            tvshowtitle, aliases, imdb, year, season,
                                            source_utils.release_title_format(name), total_seasons
                                        )
                                        if not valid:
                                            continue

                                        package = 'show'
                                        package_meta = {'package': package, 'last_season': last_season}
                                    else:
                                        # Validate season pack
                                        valid, episode_start, episode_end = source_utils.filter_season_pack(
                                            tvshowtitle, aliases, year, season,
                                            source_utils.release_title_format(name)
                                        )
                                        if not valid:
                                            continue

                                        package = 'season'
                                        package_meta = {
                                            'package': package,
                                            'episode_start': episode_start,
                                            'episode_end': episode_end
                                        }

                                    # Check seeders
                                    seeders = int(entry.get('seeders', 0))
                                    if self.min_seeders > seeders:
                                        continue

                                    # Build magnet link
                                    link = f'magnet:?xt=urn:btih:{entry.get("info_hash", "")}'

                                    # Get quality and info
                                    quality, info = source_utils.get_release_quality(name, name)

                                    # Format size
                                    size = entry.get('size', 0)
                                    try:
                                        if int(size) == 0:
                                            size = '0.00 GB'
                                        else:
                                            size = float(size) / 1024 / 1024 / 1024
                                            size = f'{size:.2f} GB'
                                    except Exception:
                                        size = '0.00 GB'
                                    info.insert(0, size)

                                    info = ' | '.join(info)

                                    # Add pack source
                                    source_dict = {
                                        'source': 'Torrent',
                                        'quality': quality,
                                        'language': 'en',
                                        'url': link,
                                        'info': info,
                                        'direct': False,
                                        'debridonly': True
                                    }
                                    source_dict.update(package_meta)
                                    sources.append(source_dict)

                                except Exception as e:
                                    c.log(f'TPB Pack - Error processing entry: {e}')
                                    continue

                        except Exception as e:
                            c.log(f'TPB Pack - Error parsing JSON: {e}')
                            continue

                except Exception as e:
                    c.log(f'TPB Pack - Error searching query "{query}": {e}')
                    continue

            return sources

        except Exception:
            failure = traceback.format_exc()
            c.log('TPB Pack - Exception: \n' + str(failure))
            return sources


    def __get_base_url(self, fallback):
        try:
            for domain in self.domains:
                try:
                    url = f'https://{domain}'
                    # c.log(f"[CM Debug @ 204 in piratebay.py] url = {url}")
                    result = client.request(url, limit=1, timeout='10')
                    result = re.findall('<input type="submit" title="(.+?)"', result, re.DOTALL)[0]
                    if result and 'Pirate Search' in result:
                        return url
                except Exception as e:
                    c.log(f"[CM Debug @ 192 in piratebay.py] exception 1 in __get_base_url: {e}")

        except Exception as e:
            c.log(f"[CM Debug @ 195 in piratebay.py] exception 2 in __get_base_url: {e}")


        return fallback

    def resolve(self, url):
        return url
