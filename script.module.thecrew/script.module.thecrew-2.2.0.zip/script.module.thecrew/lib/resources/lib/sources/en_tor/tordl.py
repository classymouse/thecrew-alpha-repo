# -*- coding: utf-8 -*-

'''
    OathScrapers module

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import requests

from six import ensure_text

from urllib.parse import urlparse, parse_qs, urljoin, urlencode, quote_plus

from resources.lib.modules import debrid
from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import source_utils
from resources.lib.modules.crewruntime import c

class source:
    pack_capable = True

    def __init__(self):
        self.priority = 0
        self.language = ['en']
        self.domains = ['btdig.com']
        self.base_link = 'https://www.torrentdownload.info'
        self.search_link = '/search?q=%s'
        self.session = requests.Session()

    def sources(self, data, hostDict):
        sources = []
        try:
            if debrid.status() is False:
                return sources

            if not data:
                c.log(f"[CM Debug @ 85 in tordl.py] data = {data}")
                return sources

            query = '%s s%02de%02d' % (data.get('tvshowtitle'), int(data.get('season')), int(data.get('episode'))) if data.get('tvshowtitle') else '%s %s' % (data.get('title'), data.get('year'))
            query = re.sub(r'(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', ' ', query).lower()
            #orig_query = query
            #query =query.replace(' ', '+')

            url = urljoin(self.base_link, self.search_link % quote_plus(query))

            r = client.request(url)
            #r = scraper.get(url).content
            r = ensure_text(r, errors='replace').strip()

            posts = client.parseDom(r, 'table', attrs={'class': 'table2', 'cellspacing': '0'})
            posts = client.parseDom(posts, 'tr')[1:]

            for post in posts:
                if 'php' or '/feed' in post:
                    continue
                links = client.parseDom(post, 'a', ret='href')[0]
                c.log(f"[CM Debug @ 108 in tordl.py] links = {links} with type = {type(links)}")
                links = client.replaceHTMLCodes(links).lstrip('/')
                hash = links.split('/')[0]
                name = links.split('/')[1]
                if len(hash) != 40:
                    c.log(f"[CM Debug @ 112 in tordl.py] continueing in tordl sources with hash = {hash}")
                    continue

                url = f'magnet:?xt=urn:btih:{hash}'
                c.log(f"[CM Debug @ 115 in tordl.py] url = {url}")

                if query not in str(cleantitle.get_title(name)):
                    c.log(f"[CM Debug @ 110 in tordl.py] continueing in tordl sources with title = {name} and query = {query}")
                    continue

                quality, info = source_utils.get_release_quality(name)
                try:
                    #size = client.parseDom(post, 'td', attrs={'class': 'tdnormal'})[1]
                    size = client.parseDom(post, 'td', attrs={'class': 'tdnormal'})[1]
                    dsize, isize = source_utils._size(size)
                except Exception:
                    dsize, isize = 0.0, ''

                info.insert(0, isize)

                info = ' | '.join(info)

                sources.append({'source': 'Torrent', 'quality': quality, 'language': 'en', 'url': url, 'info': info,
                                'direct': False, 'debridonly': True, 'size': dsize, 'name': name})

            return sources
        except Exception as e:
            import traceback
            failure = traceback.format_exc()
            c.log(f'[CM Debug @ 130 in tordl.py]Traceback:: {failure}')
            c.log(f'[CM Debug @ 130 in tordl.py]Exception raised. Error = {e}')

        #except Exception as e:
            #c.log(f'tdl3 - Exception raised:: {e}', 1)
            return sources

    def sources_packs(self, data, hostDict, search_series=False, total_seasons=0, bypass_filter=0):
        sources = []
        try:
            if debrid.status() is False:
                return sources

            tvshowtitle = data.get('tvshowtitle')
            year = data.get('year')
            season = int(data.get('season', 0))
            imdb = data.get('imdb')
            aliases = data.get('aliases', [])

            if not tvshowtitle:
                return sources

            title_query = cleantitle.get_query(tvshowtitle)
            queries = []
            if search_series:
                queries.append(f'{title_query} Complete Series')
            else:
                queries.append(f'{title_query} S{season:02d}')

            for query in queries:
                try:
                    url = self.search_link % quote_plus(query)
                    url = urljoin(self.base_link, url)
                    r = self.session.get(url)
                    r = ensure_text(r.content, errors='replace')

                    posts = client.parseDom(r, 'div', attrs={'class': 'grey_bar3'})
                    for post in posts:
                        try:
                            data_elem = client.parseDom(post, 'p', attrs={'class': 'tt-name'})[0]
                            name = client.parseDom(data_elem, 'a')[0]

                            if search_series:
                                valid, last_season = source_utils.filter_show_pack(
                                    tvshowtitle, aliases, imdb, year, season,
                                    source_utils.release_title_format(name), total_seasons
                                )
                                if not valid:
                                    continue
                                package_meta = {'package': 'show', 'last_season': last_season}
                            else:
                                valid, episode_start, episode_end = source_utils.filter_season_pack(
                                    tvshowtitle, aliases, year, season,
                                    source_utils.release_title_format(name)
                                )
                                if not valid:
                                    continue
                                package_meta = {'package': 'season', 'episode_start': episode_start, 'episode_end': episode_end}

                            url_link = client.parseDom(data_elem, 'a', ret='href')[0]
                            url_link = urljoin(self.base_link, url_link)
                            r2 = self.session.get(url_link)
                            r2 = ensure_text(r2.content, errors='replace')
                            url_magnet = re.findall('href=["\']?(magnet:.+?)["\']?>', r2)[0]
                            url_magnet = url_magnet.split('&tr=')[0]

                            quality, info = source_utils.get_release_quality(name, name)
                            try:
                                size = re.findall(r'((?:\d+\.\d+|\d+\,\d+|\d+)\s*(?:GB|GiB|MB|MiB))', post)[0]
                                dsize, isize = source_utils._size(size)
                            except Exception:
                                dsize, isize = 0.0, ''
                            info.insert(0, isize)
                            info = ' | '.join(info)

                            source_dict = {'source': 'Torrent', 'quality': quality, 'language': 'en',
                                         'url': url_magnet, 'info': info, 'direct': False, 'debridonly': True, 'size': dsize, 'name': name}
                            source_dict.update(package_meta)
                            sources.append(source_dict)
                        except Exception:
                            continue
                except Exception:
                    continue
            return sources
        except Exception:
            return sources

    def resolve(self, url):
        return url
