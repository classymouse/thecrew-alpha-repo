# -*- coding: utf-8 -*-

'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

from resources.lib.modules import debrid
from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import workers
from resources.lib.modules import source_utils

from urllib.parse import urlencode, quote_plus, quote, urljoin, parse_qs


class source:
    pack_capable = True

    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['torrentdownloads.me']
        self.base_link = 'https://www.torrentdownloads.me'
        self.search = '/rss.xml?new=1&type=search&cid={0}&search={1}'

    def sources(self, data, hostDict):
        try:
            self._sources = []
            if not data:
                return self._sources

            if debrid.status() is False:
                raise Exception()

            self.title = data.get('tvshowtitle', data.get('title'))
            self.hdlr = 'S%02dE%02d' % (int(data.get('season')), int(data.get('episode'))) if data.get('tvshowtitle') else data.get('year')

            query = '%s S%02dE%02d' % (
            data.get('tvshowtitle'), int(data.get('season')), int(data.get('episode'))) if data.get('tvshowtitle') else '%s %s' % (
            data.get('title'), data.get('year'))
            query = re.sub(r'(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', ' ', query)
            if data.get('tvshowtitle'):
                url = self.search.format('8', quote(query))
            else:
                url = self.search.format('4', quote(query))

            url = urljoin(self.base_link, url)

            self.hostDict = hostDict
            headers = {'User-Agent': client.agent()}
            _html = client.request(url, headers=headers)

            if not _html:
                c.log(f"[TorrentDownloads] Empty or None RSS response for {url}")
                return self._sources

            threads = [
                workers.Thread(self._get_items, i)
                for i in re.findall(r'<item>(.+?)</item>', _html, re.DOTALL)
            ]
            [i.start() for i in threads]
            [i.join() for i in threads]

            return self._sources
        except BaseException:
            return self._sources

    def _get_items(self, r):
        try:
            size = re.search(r'<size>([\d]+)</size>', r).groups()[0]
            seeders = re.search(r'<seeders>([\d]+)</seeders>', r).groups()[0]
            _hash = re.search(r'<info_hash>([a-zA-Z0-9]+)</info_hash>', r).groups()[0]
            name = re.search(r'<title>(.+?)</title>', r).groups()[0]
            url = 'magnet:?xt=urn:btih:%s&dn=%s' % (_hash.upper(), quote_plus(name))
            t = name.split(self.hdlr)[0]

            try:
                y = re.findall(r'[\.|\(|\[|\s|\_|\-](S\d+E\d+|S\d+)[\.|\)|\]|\s|\_|\-]', name, re.I)[-1].upper()
            except BaseException:
                y = re.findall(r'[\.|\(|\[|\s\_|\-](\d{4})[\.|\)|\]|\s\_|\-]', name, re.I)[-1].upper()

            try:
                div = 1000 ** 3
                size = float(size) / div
                size = '%.2f GB' % size
            except BaseException:
                size = '0'

            quality, info = source_utils.get_release_quality(name, name)
            info.append(size)
            info = ' | '.join(info)

            if seeders != '0' and (cleantitle.get(re.sub('(|)', '', t)) == cleantitle.get(self.title) and y == self.hdlr):
                self._sources.append({
                    'source': 'torrent', 'quality': quality, 'language': 'en', 'url': url,
                    'info': info, 'direct': False, 'debridonly': True
                    })

        except BaseException:
            pass

    def sources_packs(self, data, hostDict, search_series=False, total_seasons=0, bypass_filter=0):
        sources = []
        try:
            if debrid.status() is False:
                return sources

            tvshowtitle = data.get('tvshowtitle')
            year = data.get('year')
            season = int(data.get('season', 0))
            imdb = data.get('imdb')
            aliases = data.get('aliases', [])

            if not tvshowtitle:
                return sources

            title_query = cleantitle.get_query(tvshowtitle)
            queries = []
            if search_series:
                queries.append(f'{title_query} Complete Series')
            else:
                queries.append(f'{title_query} S{season:02d}')

            for query in queries:
                try:
                    url = self.search.format('8', quote_plus(query))
                    url = urljoin(self.base_link, url)
                    r = client.request(url)

                    items = client.parseDom(r, 'item')
                    for item in items:
                        try:
                            name = client.parseDom(item, 'title')[0]

                            if search_series:
                                valid, last_season = source_utils.filter_show_pack(
                                    tvshowtitle, aliases, imdb, year, season,
                                    source_utils.release_title_format(name), total_seasons
                                )
                                if not valid:
                                    continue
                                package_meta = {'package': 'show', 'last_season': last_season}
                            else:
                                valid, episode_start, episode_end = source_utils.filter_season_pack(
                                    tvshowtitle, aliases, year, season,
                                    source_utils.release_title_format(name)
                                )
                                if not valid:
                                    continue
                                package_meta = {'package': 'season', 'episode_start': episode_start, 'episode_end': episode_end}

                            seeders = re.findall(r'<torrent:seeds>(\d+)</torrent:seeds>', item)
                            seeders = seeders[0] if seeders else '0'
                            if seeders == '0':
                                continue

                            url_magnet = re.findall('<link>(.+?)</link>', item)[0]
                            url_magnet = client.request(url_magnet, output='geturl')
                            if 'magnet:' not in url_magnet:
                                continue
                            url_magnet = url_magnet.split('&tr=')[0]

                            quality, info = source_utils.get_release_quality(name, name)
                            try:
                                size = re.findall(r'((?:\d+\.\d+|\d+\,\d+|\d+)\s*(?:GB|GiB|MB|MiB))', name)[0]
                                div = 1 if size.endswith(('GB', 'GiB')) else 1024
                                size = float(re.sub('[^0-9|/.|/,]', '', size.replace(',', '.'))) / div
                                size = '%.2f GB' % size
                            except BaseException:
                                size = '0'
                            info.append(size)
                            info = ' | '.join(info)

                            source_dict = {'source': 'torrent', 'quality': quality, 'language': 'en',
                                         'url': url_magnet, 'info': info, 'direct': False, 'debridonly': True}
                            source_dict.update(package_meta)
                            sources.append(source_dict)
                        except BaseException:
                            continue
                except BaseException:
                    continue
            return sources
        except BaseException:
            return sources

    def resolve(self, url):
        return url
