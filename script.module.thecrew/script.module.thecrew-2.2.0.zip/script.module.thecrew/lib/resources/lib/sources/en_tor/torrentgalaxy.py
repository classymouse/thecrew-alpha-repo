# -*- coding: utf-8 -*-

'''
 ***********************************************************
 * The Crew Add-on - Scraper Module
 *
 *
 * @file torrentgalaxy.py
 * @package script.module.thecrew
 *
 * @copyright (c) 2025, The Crew
 * @license GNU General Public License, version 3 (GPL-3.0)
 *
  ***********************************************************cm*
'''

import re
from urllib.parse import urlencode, quote_plus, parse_qs, urljoin

from resources.lib.modules import cleantitle
from resources.lib.modules import debrid
from resources.lib.modules import source_utils
from resources.lib.modules.crewruntime import c
from resources.lib.modules import client



class source:
    pack_capable = True

    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['torrentgalaxy.to']
        #self.base_link = 'https://torrentgalaxy.to' # cm - eu blocked
        self.base_link = "https://tgx.rs"
        #self.search_link = '/torrents.php?search=%s&sort=seeders&order=desc'
        self.search_link = '/torrents.php?search=%s'

    def sources(self, data, hostDict):
        sources = []
        try:
            if not data:
                return sources
            if debrid.status() is False:
                raise Exception()

            title = data.get('tvshowtitle') if data.get('tvshowtitle') else data.get('title')

            hdlr = f"S{int(data.get('season')):02d}E{int(data.get('episode')):02d}" if data.get('tvshowtitle') else data.get('year')

            query = f"{data.get('tvshowtitle')} s{int(data.get('season')):02d}e{int(data.get('episode')):02d}" if data.get('tvshowtitle') else f"{data.get('title')} {data.get('year')}"
            query = re.sub(r'(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', ' ', query)

            url = self.search_link % quote_plus(query)
            url = urljoin(self.base_link, url)

            try:
                r = client.request(url)
                posts = client.parseDom(r, 'div', attrs={'class': 'tgxtable'})
                for post in posts:
                    link = re.findall('a href="(magnet:.+?)"', post, re.DOTALL)
                    try:
                        size = re.findall(r'((?:\d+\,\d+\.\d+|\d+\.\d+|\d+\,\d+|\d+)\s*(?:GiB|MiB|GB|MB))', post)[0]
                        div = 1 if size.endswith('GB') else 1024
                        size = float(re.sub('[^0-9|/.|/,]', '', size.replace(',', '.'))) / div
                        size = f"{size:.2f} GB"
                    except Exception:
                        size = '0'
                    for url in link:
                        if hdlr not in url:
                            continue
                        quality, info = source_utils.get_release_quality(url)

                        url = url.split('&dn=', 1)[0]

                        #cm - this will never happen, only btih magnet link left
                        if any(x in url for x in ['FRENCH', 'Ita', 'italian', 'TRUEFRENCH', '-lat-', 'Dublado']):
                            continue

                        info.append(size)
                        info = ' | '.join(info)

                        sources.append({
                            'source': 'Torrent', 'quality': quality, 'language': 'en', 'url': url,
                            'info': info, 'direct': False, 'debridonly': True
                            })
            except Exception:
                return
            return sources
        except Exception:
            return sources

    def sources_packs(self, data, hostDict, search_series=False, total_seasons=0, bypass_filter=0):
        sources = []
        try:
            if debrid.status() is False:
                return sources

            tvshowtitle = data.get('tvshowtitle')
            year = data.get('year')
            season = int(data.get('season', 0))
            imdb = data.get('imdb')
            aliases = data.get('aliases', [])

            if not tvshowtitle:
                return sources

            title_query = cleantitle.get_query(tvshowtitle)

            queries = []
            if search_series:
                queries.append(f'{title_query} Complete Series')
                queries.append(f'{title_query} All Seasons')
            else:
                queries.append(f'{title_query} S{season:02d}')
                queries.append(f'{title_query} Season {season}')

            for query in queries:
                try:
                    url = self.search_link % quote_plus(query)
                    url = urljoin(self.base_link, url)
                    r = client.request(url)

                    posts = client.parseDom(r, 'div', attrs={'class': 'tgxtable'})
                    for post in posts:
                        try:
                            link = re.findall('a href="(magnet:.+?)"', post, re.DOTALL)
                            if not link:
                                continue

                            url_magnet = link[0]

                            # Filter using pack validation
                            if search_series:
                                valid, last_season = source_utils.filter_show_pack(
                                    tvshowtitle, aliases, imdb, year, season,
                                    source_utils.release_title_format(url_magnet), total_seasons
                                )
                                if not valid:
                                    continue
                                package_meta = {'package': 'show', 'last_season': last_season}
                            else:
                                valid, episode_start, episode_end = source_utils.filter_season_pack(
                                    tvshowtitle, aliases, year, season,
                                    source_utils.release_title_format(url_magnet)
                                )
                                if not valid:
                                    continue
                                package_meta = {
                                    'package': 'season',
                                    'episode_start': episode_start,
                                    'episode_end': episode_end
                                }

                            try:
                                size = re.findall(r'((?:\d+\,\d+\.\d+|\d+\.\d+|\d+\,\d+|\d+)\s*(?:GiB|MiB|GB|MB))', post)[0]
                                div = 1 if size.endswith('GB') else 1024
                                size = float(re.sub('[^0-9|/.|/,]', '', size.replace(',', '.'))) / div
                                size = f"{size:.2f} GB"
                            except Exception:
                                size = '0'

                            quality, info = source_utils.get_release_quality(url_magnet)
                            url_clean = url_magnet.split('&dn=', 1)[0]
                            info.append(size)
                            info = ' | '.join(info)

                            source_dict = {
                                'source': 'Torrent',
                                'quality': quality,
                                'language': 'en',
                                'url': url_clean,
                                'info': info,
                                'direct': False,
                                'debridonly': True
                            }
                            source_dict.update(package_meta)
                            sources.append(source_dict)

                        except Exception:
                            continue

                except Exception:
                    continue

            return sources
        except Exception:
            return sources

    def resolve(self, url):
        return url
