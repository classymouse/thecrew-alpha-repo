#!/usr/bin/env python3
"""Patch episodes.py to add show-level caching in Episodes class only."""

import re


def patch_fetch_tmdb_data():
    """Add caching to Episodes._fetch_tmdb_data (line ~1311, after line 1000 which is Episodes class)."""
    with open('lib/resources/lib/indexers/episodes.py', 'r', encoding='utf-8') as f:
        lines = f.readlines()

    # Find Episodes class (around line 1008)
    episodes_class_line = None
    for i, line in enumerate(lines):
        if i > 1000 and 'class Episodes:' in line:
            episodes_class_line = i
            break

    if not episodes_class_line:
        print("ERROR: Could not find Episodes class")
        return False

    print(f"Found Episodes class at line {episodes_class_line + 1}")

    # Find _fetch_tmdb_data in Episodes class (should be after line 1000)
    fetch_line = None
    for i in range(episodes_class_line, len(lines)):
        if '    def _fetch_tmdb_data(self, show_tmdb, season, episode):' in lines[i]:
            fetch_line = i
            break

    if not fetch_line:
        print("ERROR: Could not find _fetch_tmdb_data in Episodes class")
        return False

    print(f"Found Episodes._fetch_tmdb_data at line {fetch_line + 1}")

    # Find the try: block and the show_item = self.session.get(...) line
    show_item_line = None
    for i in range(fetch_line, min(fetch_line + 20, len(lines))):
        if 'show_item = self.session.get(url, timeout=15).json()' in lines[i]:
            show_item_line = i
            break

    if not show_item_line:
        print("ERROR: Could not find show_item fetch line")
        return False

    print(f"Found show_item fetch at line {show_item_line + 1}")

    # Check if already patched
    if '_show_data_cache' in lines[show_item_line - 1]:
        print("Already patched! Skipping.")
        return True

    # Insert caching logic before show_item fetch
    indent = '            '
    cache_check= [
        f"{indent}# Check cache for show data first (avoid redundant API calls for same show)\n",
        f"{indent}if show_tmdb in self._show_data_cache:\n",
        f"{indent}    show_item = self._show_data_cache[show_tmdb]\n",
        f"{indent}else:\n"
    ]

    # Find where to insert (right after url = ... line)
    url_line = None
    for i in range(fetch_line, show_item_line):
        if 'url = en_url if self.lang' in lines[i]:
            url_line = i
            break

    if not url_line:
        print("ERROR: Could not find url assignment")
        return False

    # Insert cache check after url line, indent the existing show_item line, and add cache store
    lines.insert(url_line + 1, '\n')
    for line in reversed(cache_check):
        lines.insert(url_line + 2, line)

    # Now indent the show_item line (it's now at url_line + 2 + len(cache_check) + offset)
    # Actually,let me recalculate - after inserting cache_check, I need to find show_item again
    new_show_item_line = url_line + 2 + len(cache_check) + lines[url_line + 2 + len(cache_check):].index(
       [l for l in lines[url_line + 2 + len(cache_check):] if 'show_item = self.session.get' in l][0]
    )

    # Indent existing lines until episode_url
    for i in range(url_line + 2 + len(cache_check), len(lines)):
        if 'episode_url = self.tmdb_episode_link' in lines[i]:
            # Add cache store before episode_url
            lines.insert(i, f"\n{indent}    # Cache show data for reuse across episodes\n")
            lines.insert(i + 1, f"{indent}    self._show_data_cache[show_tmdb] = show_item\n\n")
            lines.insert(i + 2, f"{indent}# Always fetch episode data (unique per episode)\n")
            break
        if 'show_item = self.session.get' in lines[i] or '_id = show_tmdb' in lines[i] or 'en_url = self.tmdb_api_link' in lines[i] or 'trans_url = ' in lines[i]:
            # Add 4 spaces indent
            lines[i] = '    ' + lines[i]

    # Write back
    with open('lib/resources/lib/indexers/episodes.py', 'w', encoding='utf-8') as f:
        f.writelines(lines)

    print("Successfully patched _fetch_tmdb_data!")
    return True


def patch_handle_artwork():
    """Add caching to Episodes._handle_artwork."""
    with open('lib/resources/lib/indexers/episodes.py', 'r', encoding='utf-8') as f:
        lines = f.readlines()

    # Find Episodes class
    episodes_class_line = None
    for i, line in enumerate(lines):
        if i > 1000 and 'class Episodes:' in line:
            episodes_class_line = i
            break

    if not episodes_class_line:
        print("ERROR: Could not find Episodes class for artwork patch")
        return False

    # Find _handle_artwork in Episodes class
    artwork_line = None
    for i in range(episodes_class_line, len(lines)):
        if '    def _handle_artwork(self, show_tvdb, show_tmdb):' in lines[i]:
            artwork_line = i
            break

    if not artwork_line:
        print("ERROR: Could not find _handle_artwork in Episodes class")
        return False

    print(f"Found Episodes._handle_artwork at line {artwork_line + 1}")

    # Check if already patched
    if '_artwork_cache' in ''.join(lines[artwork_line:artwork_line + 10]):
        print("Artwork already patched! Skipping.")
        return True

    # Find try: and first statement after it
    try_line = None
    for i in range(artwork_line, artwork_line + 10):
        if '        try:' in lines[i]:
            try_line = i
            break

    if not try_line:
        print("ERROR: Could not find try block in _handle_artwork")
        return False

    # Insert cache check right after try:
    cache_lines = [
        "            # Check cache first (artwork is show-level, not episode-level)\n",
        "            cache_key = (show_tvdb, show_tmdb)\n",
        "            if cache_key in self._artwork_cache:\n",
        "                return self._artwork_cache[cache_key]\n\n"
    ]

    for line in reversed(cache_lines):
        lines.insert(try_line + 1, line)

    # Find the return statement before except and insert cache store
    for i in range(try_line, len(lines)):
        if '            return {' in lines[i] and i > try_line + 20:  # Find the final return
            # Find end of return dict
            for j in range(i, min(i + 10, len(lines))):
                if '            }' in lines[j]:
                    # Insert cache store before return
                    lines.insert(i, "\n            artwork = {\n")
                    # Change return { to just the dict continuation
                    lines[i + 1] = lines[i + 1].replace('return {', '')
                    # After the closing }, add cache and return
                    lines[j + 1] = lines[j + 1].replace('}', '}\n            \n            # Cache for reuse across episodes of same show\n            self._artwork_cache[cache_key] = artwork\n            \n            return artwork')
                    break
            break

    # Write back
    with open('lib/resources/lib/indexers/episodes.py', 'w', encoding='utf-8') as f:
        f.writelines(lines)

    print("Successfully patched _handle_artwork!")
    return True


if __name__ == '__main__':
    print("Patching episodes.py for performance improvements...")
    if patch_fetch_tmdb_data():
        print("✓ _fetch_tmdb_data patched")
    if patch_handle_artwork():
        print("✓ _handle_artwork patched")
    print("Done!")
