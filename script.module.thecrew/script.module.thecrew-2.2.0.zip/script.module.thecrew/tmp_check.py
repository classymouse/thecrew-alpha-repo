from modules.crewruntime import c
print('Before set:', c.get_setting('gearsscrapers.enabled'))
try:
    c.set_setting('gearsscrapers.enabled','true')
except Exception as e:
    print('set_setting failed',e)
print('After set:', c.get_setting('gearsscrapers.enabled'))
from modules.sources import Sources
s=Sources()
print('s.gearsscrapers_enabled=', s.gearsscrapers_enabled)
print('s.gearsscrapers_installed=', s.gearsscrapers_installed)
