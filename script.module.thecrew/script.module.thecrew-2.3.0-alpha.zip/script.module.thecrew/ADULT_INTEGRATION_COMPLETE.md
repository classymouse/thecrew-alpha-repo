# Adult Section Integration - Complete

## Summary

Successfully integrated the new class-based adult content system into The Crew addon, replacing the old xxx.xml approach with a modern Python architecture.

## Changes Made

### 1. Fixed adult.py Syntax Error
- **Issue**: Line 204 had "except:" without matching "try:" due to indentation
- **Solution**: Corrected indentation and rebuilt entire file with proper structure
- **Result**: Clean Python file with no syntax errors

### 2. Updated URL Building
- **Old**: Used invalid format like `'url': f'adult_site={site.name}'`
- **New**: Proper query string format using `sys.argv[0]` and `quote_plus()`
- **Example**: `f'{sysaddon}?action=adult_play&site={site_name}&url={quote_plus(video_url)}'`

### 3. Implemented _addDirectory Method
- **Purpose**: Add directory items to Kodi interface  
- **Pattern**: Based on movies.py implementation
- **Features**: 
  - Handles icon, fanart, isPlayable, isFolder properties
  - Sets content type to 'videos'
  - Proper error handling with logging

### 4. Updated lists.py root_porn()
- **File**: `lib/resources/lib/indexers/lists.py` line 168
- **Old Code**: 
  ```python
  def root_porn(self):
      return self.create_list(ROOT_URLS.get('porn'))
  ```
- **New Code**:
  ```python
  def root_porn(self):
      """Adult Section - uses new class-based architecture"""
      from .adult import Adult
      return Adult().root()
  ```

### 5. Added Action Handlers to crew

.py
- **File**: `lib/resources/lib/modules/crew.py` 
- **Location**: Added after 'kidsgreyNavigator' in action_map (around line 288)
- **Handlers Added**:
  ```python
  'adult_site_handler': lambda: call_module('resources.lib.indexers.adult', 'Adult', inst=True, method='site_handler', site_name=p('site')),
  'adult_videos': lambda: call_module('resources.lib.indexers.adult', 'Adult', inst=True, method='videos', site_name=p('site'), url=p('url')),
  'adult_search': lambda: call_module('resources.lib.indexers.adult', 'Adult', inst=True, method='search', site_name=p('site')),
  'adult_play': lambda: call_module('resources.lib.indexers.adult', 'Adult', inst=True, method='play', site_name=p('site'), video_url=p('url')),
  ```

## Architecture Flow

### User Navigation Path:
1. **Main Menu** → Click "Adult" (action='porn')
   - Triggers: `lists.Indexer().root_porn()`
   - Calls: `adult.Adult().root()`
   - Shows: List of 8 sites + mPorno + Testings

2. **Site Selection** → Click a site (e.g., "RedTube")
   - URL: `plugin://...?action=adult_site_handler&site=redtube`
   - Triggers: crew.router → adult.Adult().site_handler('redtube')
   - Shows: Search option and/or categories

3. **Category/Videos** → Click category
   - URL: `plugin://...?action=adult_videos&site=redtube&url=<category_url>`
   - Triggers: adult.Adult().videos('redtube', url='<category_url>')
   - Shows: List of videos with thumbnails

4. **Search** → Enter keyword
   - URL: `plugin://...?action=adult_search&site=redtube`
   - Triggers: adult.Adult().search('redtube')
   - Shows: Keyboard input → Search results

5. **Play Video** → Click video
   - URL: `plugin://...?action=adult_play&site=redtube&url=<video_url>`
   - Triggers: adult.Adult().play('redtube', '<video_url>')
   - Actions: Resolves URL → Plays via lists.player()

## Sites Integrated

All 8 sites from xxx.xml converted to Python classes:

1. **RedTube** - Search functionality
2. **WhoresHub** - HD/UHD latest videos (concurrent pages)
3. **FreeOMovie** - Categories + videos + multi-source selection
4. **XXXFiles** - Latest videos
5. **HomePornKing** - Home porn using resolveurl
6. **Pornrewind** - HD porn using resolveurl
7. **CUMLOUDER** - Spanish HD content using resolveurl
8. **Motherless** - Amateur content using resolveurl

## Key Features

### CrewAdult Base Class
- **Location**: `lib/resources/lib/adult_sites/base.py`
- **Purpose**: Common functionality for all sites
- **Features**:
  - Site registration via `_register()` decorator
  - `_try_resolveurl()` - Delegates to resolveurl.xxx framework
  - `_cleanup_title()` - Removes HD/quality tags from titles
  - `_extract_video_url()` - Common regex patterns
  - PageFetcher helper - Concurrent HTTP requests

### Individual Site Modules
- **Location**: `lib/resources/lib/adult_sites/<sitename>.py`
- **Methods**:
  - `get_categories()` - Return list of categories (if applicable)
  - `get_videos(url=None)` - Fetch videos from page/category
  - `search(keyword)` - Search functionality (RedTube only)
  - `resolve(url)` - Get playable video URL
- **Pattern**: Each site is self-contained, easy to maintain/update

## Testing Checklist

- [ ] Navigate to Adult section from main menu
- [ ] RedTube search - keyword input → results → play
- [ ] FreeOMovie categories → select category → videos → play
- [ ] WhoresHub latest videos → multi-page load → play
- [ ] XXXFiles videos → play
- [ ] HomePornKing → resolveurl → playback
- [ ] Pornrewind → resolveurl → playback
- [ ] CUMLOUDER → resolveurl → playback
- [ ] Motherless → resolveurl → playback
- [ ] mPorno directory link (old XML system)
- [ ] Testings plugin link

## Dependencies

### Required Addons:
- **script.module.resolveurl.xxx** v2.0.1 or higher
  - Already added to both addon.xml files
  - Handles adult site URL resolution
  - Provides PluginSettings for resolver configuration

## Error Handling

All methods include try/except blocks with comprehensive logging:
- Site not found errors
- Video resolution failures
- HTTP request errors
- Empty result handling
- Keyboard cancellation handling

Log format: `c.log(f'[Adult] <context>: <message>')`

## Next Steps

1. **Test in Kodi**: Load addon and navigate through adult section
2. **Verify Playback**: Ensure videos play correctly from each site
3. **Check Logs**: Monitor Kodi log for any errors
4. **Optimize**: Adjust concurrent workers, timeout values if needed
5. **Extend**: Add more sites using the same pattern

## Benefits Over Old xxx.xml

✅ **Maintainability**: One file per site vs 997-line XML
✅ **Debugging**: Python tracebacks vs regex debugging
✅ **Extensibility**: Easy to add new sites - just copy template
✅ **Error Isolation**: One broken site doesn't break all sites
✅ **Code Reuse**: Base class handles common operations
✅ **Modern**: Proper Python classes vs embedded regex
✅ **Performance**: Concurrent page fetching for multi-page sites
✅ **Flexibility**: Easy to add features like pagination, sorting, filtering

## Files Modified

1. `lib/resources/lib/indexers/adult.py` - Main indexer (recreated)
2. `lib/resources/lib/indexers/lists.py` - Updated root_porn()
3. `lib/resources/lib/modules/crew.py` - Added action handlers
4. `addon.xml` (both) - Added resolveurl.xxx dependency (previous task)
5. `lib/resources/lib/adult_sites/` - 8 site modules + base.py (previous task)

## Total Lines of Code

- **Old System**: xxx.xml = 997 lines (unreadable embedded Python)
- **New System**: 
  - adult.py = 289 lines
  - base.py = ~150 lines
  - 8 site modules = ~100 lines each = 800 lines
  - **Total**: ~1,240 lines of clean, documented, testable Python

The slight increase in lines is offset by massive improvements in readability, maintainability, and extensibility.
