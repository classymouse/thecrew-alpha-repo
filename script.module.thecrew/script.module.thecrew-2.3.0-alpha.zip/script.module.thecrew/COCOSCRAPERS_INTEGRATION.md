This document has been moved to `docs/COCOSCRAPERS_INTEGRATION.md`.

Please see `docs/COCOSCRAPERS_INTEGRATION.md` for details.

## Implementation Details

### 1. User Settings

**File:** `plugin.video.thecrew/resources/settings.xml`

**Location:** Sources category (32330), after torrent settings

```xml
<setting type="lsep" label="CocoScrapers" />
<setting id="cocoscrapers.enabled" type="bool" label="Enable CocoScrapers" default="true" />
<setting id="cocoscrapers.info" type="text" label="(Requires script.module.cocoscrapers installed)" enable="false" />
```

**Setting ID:** `cocoscrapers.enabled`
**Type:** Boolean
**Default:** `true`
**Purpose:** Allows user to enable/disable cocoscrapers integration even when addon is installed

### 2. Source Loader

**File:** `lib/resources/lib/sources/__init__.py`

**Function:** `sources()`

**Changes:**
- Added check for both addon installation AND user setting
- Only loads cocoscrapers if BOTH conditions are true:
  1. `xbmc.getCondVisibility('System.HasAddon(script.module.cocoscrapers)')` returns True
  2. `c.get_setting('cocoscrapers.enabled') == 'true'`

**Loading Process:**
1. Detect addons directory (walk up 6 levels from current file)
2. Build path to `script.module.cocoscrapers/lib/cocoscrapers/sources_cocoscrapers`
3. Scan all subdirectories (torrents, hosters, etc.)
4. Use `importlib.spec_from_file_location()` to load each .py file
5. Call `module.source()` to get scraper instance
6. Add to sources list with proper module naming

**Logging:**
- `[Sources] CocoScrapers detected and enabled, attempting to load scrapers`
- `[Sources] Loaded X scrapers from cocoscrapers/torrents`
- `[Sources] CocoScrapers installed but disabled in settings`
- `[Sources] CocoScrapers not installed, using crew sources only`
- `[Sources] Total sources loaded: X`

### 3. Sources Class Integration

**File:** `lib/resources/lib/modules/sources.py`

**Class:** `Sources`

**New Instance Variables:**
```python
self.cocoscrapers_enabled = c.get_setting('cocoscrapers.enabled') == 'true'
self.cocoscrapers_installed = xbmc.getCondVisibility('System.HasAddon(script.module.cocoscrapers)')
self.cocoscrapers_sources = [
    '1337x', 'bitsearch', 'comet', 'eztv', 'kickass2', 'knaben',
    'limetorrents', 'mediafusion', 'nyaa', 'piratebay', 'prowlarr',
    'torrentdownload', 'torrentgalaxy', 'torrentio', 'torrentproject2', 'ytsmx'
]
```

**Purpose:**
- `cocoscrapers_enabled`: Cache setting value for performance
- `cocoscrapers_installed`: Cache addon detection for performance
- `cocoscrapers_sources`: List of known cocoscrapers names for adapter detection

### 4. Parameter Signature Adapter

#### The Problem

**The Crew sources signature:**
```python
def sources(self, url, hostDict, hostprDict):
    # url is a string (movie URL or episode URL)
    pass
```

**CocoScrapers sources signature:**
```python
def sources(self, data, hostDict):
    # data is a dict with metadata
    pass
```

The signatures are incompatible - calling cocoscrapers with The Crew's URL string causes crashes.

#### The Solution

**Episode Adapter** (`getEpisodeSource()` ~line 1100):

```python
try:
    sources = []

    # Check if this is a cocoscrapers source - use adapted signature
    if self.cocoscrapers_installed and self.cocoscrapers_enabled and source in self.cocoscrapers_sources:
        # Build data dict for cocoscrapers (2-param signature)
        scraper_data = {
            'title': title,
            'year': year,
            'imdb': imdb,
            'tmdb': tmdb,
            'season': season,
            'episode': episode,
            'tvshowtitle': tvshowtitle,
            'aliases': aliases
        }
        c.log(f'[Sources] Calling cocoscrapers source "{source}" with data dict')
        sources = call.sources(scraper_data, self.hostDict)
    else:
        # The Crew native sources (3-param signature)
        sources = call.sources(ep_url, self.hostDict, self.hostprDict)

    # ... rest of processing
```

**Movie Adapter** (`get_movie_source()` ~line 850):

```python
try:
    sources = []

    # Check if this is a cocoscrapers source - use adapted signature
    if self.cocoscrapers_installed and self.cocoscrapers_enabled and source in self.cocoscrapers_sources:
        # Build data dict for cocoscrapers (2-param signature)
        scraper_data = {
            'title': title,
            'year': year,
            'imdb': imdb,
            'aliases': aliases
        }
        c.log(f'[Sources] Calling cocoscrapers movie source "{source}" with data dict')
        sources = call.sources(scraper_data, self.hostDict)
    else:
        # The Crew native sources (3-param signature)
        sources = call.sources(url, self.hostDict, self.hostprDict)

    # ... rest of processing
```

#### Detection Logic

The adapter detects cocoscrapers sources by checking if:
1. CocoScrapers addon is installed (`self.cocoscrapers_installed`)
2. CocoScrapers is enabled in settings (`self.cocoscrapers_enabled`)
3. Source name is in known cocoscrapers list (`source in self.cocoscrapers_sources`)

All three conditions must be TRUE to use the adapted signature.

### 5. Data Structure Conversion

**CocoScrapers Expected Data (Episodes):**
```python
{
    'title': 'Episode Title',           # Episode title
    'year': '2023',                      # Show year
    'imdb': 'tt1234567',                 # IMDB ID
    'tmdb': '12345',                     # TMDB ID
    'season': '1',                       # Season number
    'episode': '5',                      # Episode number
    'tvshowtitle': 'Show Name',          # TV show title
    'aliases': ['Alternate Name']        # Alternative names
}
```

**CocoScrapers Expected Data (Movies):**
```python
{
    'title': 'Movie Title',              # Movie title
    'year': '2023',                      # Release year
    'imdb': 'tt1234567',                 # IMDB ID
    'aliases': ['Alternate Title']       # Alternative titles
}
```

**The Crew Provides:**
- Episodes: `ep_url` (string), plus individual metadata variables
- Movies: `url` (string), plus individual metadata variables

**Adapter converts:** Individual variables → Data dict

## Known CocoScrapers Sources

### Torrents (16 scrapers)
1. 1337x
2. bitsearch
3. comet
4. eztv
5. kickass2
6. knaben
7. limetorrents
8. mediafusion
9. nyaa
10. piratebay
11. prowlarr
12. torrentdownload
13. torrentgalaxy
14. torrentio
15. torrentproject2
16. ytsmx

### Future: Hosters
CocoScrapers may add hoster sources in future updates. The loader automatically scans all subdirectories in `sources_cocoscrapers/`, so new scraper types will be loaded automatically.

## User Guide

### Enabling CocoScrapers

1. Install `script.module.cocoscrapers` addon (separate addon)
2. Open The Crew addon settings
3. Navigate to "Sources" category
4. Scroll to "CocoScrapers" section
5. Enable "Enable CocoScrapers" toggle (default: ON)
6. CocoScrapers sources will now be available alongside Crew sources

### Disabling CocoScrapers

1. Open The Crew addon settings
2. Navigate to "Sources" category
3. Scroll to "CocoScrapers" section
4. Disable "Enable CocoScrapers" toggle
5. Only native Crew sources will be used

### Troubleshooting

**CocoScrapers not working:**
1. Check if `script.module.cocoscrapers` is installed
2. Check if "Enable CocoScrapers" setting is ON
3. Check Kodi log for source loading messages:
   - Look for `[Sources] CocoScrapers detected and enabled`
   - Look for `[Sources] Loaded X scrapers from cocoscrapers/torrents`
4. If no scrapers loaded, check cocoscrapers addon version/installation

**Sources not returning results:**
1. Check if debrid service is configured (cocoscrapers requires debrid)
2. Check source-specific settings in cocoscrapers addon
3. Check Kodi log for scraper errors
4. Try disabling/re-enabling cocoscrapers setting

## Technical Benefits

### Performance
- Settings cached in class instance (no repeated file reads)
- Addon detection cached (no repeated xbmc calls)
- Source list pre-defined (fast lookup)

### Compatibility
- Works with or without cocoscrapers installed
- Graceful fallback if addon removed
- No changes to existing crew sources
- Backward compatible with all Crew versions

### Maintainability
- Clear separation of crew vs cocoscrapers logic
- Centralized source name list (easy to update)
- Comprehensive logging for debugging
- Self-documenting code with comments

### Extensibility
- Automatically loads new cocoscrapers subdirectories
- Easy to add new scrapers to known list
- Adapter pattern allows future signature changes
- Setting framework supports additional options

## Testing

Run the integration test:
```bash
cd c:\Users\fvanb\AppData\Roaming\Kodi\addons\script.module.thecrew
python test_cocoscrapers_integration.py
```

Expected output:
- Settings test: PASS
- Addon detection: PASS (if installed)
- Source loading: PASS (if enabled)
- Sources class: PASS
- Parameter adapter: PASS

## Future Enhancements

### Possible Additions:
1. Per-scraper enable/disable settings
2. Scraper priority/sorting options
3. Timeout settings for cocoscrapers
4. Cache settings for cocoscrapers results
5. Statistics (sources found per scraper)
6. Auto-update cocoscrapers sources list

### Code Quality:
1. Extract adapter logic to separate method
2. Add type hints for data structures
3. Create unit tests for adapter
4. Add integration tests with mock scrapers
5. Performance profiling for signature conversion

## Migration Notes

### From Previous Implementations:
- Old code attempted to call cocoscrapers with 3 params → CRASH
- Old code didn't check user settings → Always on
- Old code didn't handle missing addon gracefully → ERRORS

### This Implementation:
- ✅ Correct 2-param signature for cocoscrapers
- ✅ User setting to enable/disable
- ✅ Graceful fallback if not installed
- ✅ Comprehensive logging
- ✅ No changes to crew sources
- ✅ Backward compatible

## Files Modified

1. `plugin.video.thecrew/resources/settings.xml`
   - Added cocoscrapers.enabled setting

2. `lib/resources/lib/sources/__init__.py`
   - Added setting check before loading
   - Added logging for enabled/disabled states

3. `lib/resources/lib/modules/sources.py`
   - Added cocoscrapers detection variables
   - Added parameter adapter in getEpisodeSource()
   - Added parameter adapter in get_movie_source()

## Files Added

1. `test_cocoscrapers_integration.py`
   - Integration test suite
   - Validates all components

2. `COCOSCRAPERS_INTEGRATION.md` (this file)
   - Complete documentation
   - User guide
   - Technical reference

## Changelog

### 2024-12-08: Initial Implementation
- Added user setting for enable/disable
- Implemented source loader with setting check
- Created parameter signature adapter for episodes
- Created parameter signature adapter for movies
- Added comprehensive logging
- Created test suite
- Created documentation

---

**Status:** ✅ Complete and ready for testing
**Version:** 1.0
**Author:** GitHub Copilot
**Date:** December 8, 2024
