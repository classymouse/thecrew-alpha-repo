This document has been moved to `docs/COCOSCRAPERS_QUICK_REFERENCE.md`.

Please see `docs/COCOSCRAPERS_QUICK_REFERENCE.md` for details.

## 🎯 What Was Implemented

### 1. User Setting
- **Location:** Settings → Sources → CocoScrapers
- **Setting:** "Enable CocoScrapers" (toggle)
- **Default:** ON (enabled)
- **Purpose:** Allows user to disable cocoscrapers even when installed

### 2. Smart Loading
- **Checks both:** Addon installed AND setting enabled
- **Loads from:** `script.module.cocoscrapers/lib/cocoscrapers/sources_cocoscrapers/`
- **Supports:** All subdirectories (torrents, future hosters, etc.)
- **Method:** Dynamic import using importlib

### 3. Parameter Adapter
- **Problem:** Different function signatures between Crew and CocoScrapers
  - Crew: `sources(url_string, hostDict, hostprDict)` ← 3 params
  - Cocos: `sources(data_dict, hostDict)` ← 2 params
- **Solution:** Automatic detection and conversion in both:
  - `getEpisodeSource()` for TV episodes
  - `get_movie_source()` for movies
- **Detection:** By source name (16 known cocoscrapers sources)

## 📋 Files Modified

| File | Changes |
|------|---------|
| `plugin.video.thecrew/resources/settings.xml` | Added cocoscrapers.enabled setting |
| `lib/resources/lib/sources/__init__.py` | Added setting check before loading |
| `lib/resources/lib/modules/sources.py` | Added adapter in __init__, getEpisodeSource, get_movie_source |

## 📝 Files Created

| File | Purpose |
|------|---------|
| `test_cocoscrapers_integration.py` | Test suite to validate integration |
| `COCOSCRAPERS_INTEGRATION.md` | Complete documentation |
| `COCOSCRAPERS_QUICK_REFERENCE.md` | This file |

## 🧪 Testing

```bash
# Run integration test
cd c:\Users\fvanb\AppData\Roaming\Kodi\addons\script.module.thecrew
python test_cocoscrapers_integration.py
```

Expected: All tests pass ✓

## 🔍 How It Works

### Flow Diagram

```
User opens The Crew
    ↓
Settings: cocoscrapers.enabled?
    ↓ YES
Check: script.module.cocoscrapers installed?
    ↓ YES
Load cocoscrapers sources
    ↓
User searches for episode/movie
    ↓
For each source:
    ↓
Is source in cocoscrapers list?
    ↓ YES
    Build data dict: {title, year, imdb, tmdb, season, episode, ...}
    Call: sources(data_dict, hostDict)  ← 2 params
    ↓ NO
    Call: sources(url, hostDict, hostprDict)  ← 3 params
    ↓
Return results
```

## 🎮 User Experience

### Before Integration
- CocoScrapers code existed but didn't work
- Called with wrong parameters → CRASH
- No user control

### After Integration
- ✅ Works correctly with proper parameters
- ✅ User can enable/disable in settings
- ✅ Graceful fallback if not installed
- ✅ Comprehensive logging for troubleshooting
- ✅ No impact on existing crew sources

## 🔧 Known CocoScrapers Sources (16)

**Torrents:**
1. 1337x
2. bitsearch
3. comet
4. eztv
5. kickass2
6. knaben
7. limetorrents
8. mediafusion
9. nyaa
10. piratebay
11. prowlarr
12. torrentdownload
13. torrentgalaxy
14. torrentio
15. torrentproject2
16. ytsmx

## 📊 Code Locations

### Sources Class Init (line ~65)
```python
# CocoScrapers integration
self.cocoscrapers_enabled = c.get_setting('cocoscrapers.enabled') == 'true'
self.cocoscrapers_installed = xbmc.getCondVisibility('System.HasAddon(...)')
self.cocoscrapers_sources = ['1337x', 'bitsearch', ...]
```

### Episode Adapter (line ~1100)
```python
if self.cocoscrapers_installed and self.cocoscrapers_enabled and source in self.cocoscrapers_sources:
    scraper_data = {'title': title, 'year': year, ...}
    sources = call.sources(scraper_data, self.hostDict)  # 2 params
else:
    sources = call.sources(ep_url, self.hostDict, self.hostprDict)  # 3 params
```

### Movie Adapter (line ~850)
```python
if self.cocoscrapers_installed and self.cocoscrapers_enabled and source in self.cocoscrapers_sources:
    scraper_data = {'title': title, 'year': year, 'imdb': imdb, 'aliases': aliases}
    sources = call.sources(scraper_data, self.hostDict)  # 2 params
else:
    sources = call.sources(url, self.hostDict, self.hostprDict)  # 3 params
```

## 🐛 Troubleshooting

### Issue: CocoScrapers not loading
**Check:**
1. Is `script.module.cocoscrapers` installed?
2. Is setting enabled? (Settings → Sources → CocoScrapers)
3. Check Kodi log for: `[Sources] CocoScrapers detected and enabled`

### Issue: No results from cocoscrapers
**Check:**
1. Is debrid service configured? (cocoscrapers requires debrid)
2. Check source-specific settings in cocoscrapers addon
3. Look for errors in Kodi log
4. Try disabling/re-enabling setting

### Issue: Errors when scraping
**Check:**
1. Kodi log for: `[Sources] Calling cocoscrapers source "..." with data dict`
2. Verify parameter signature is correct (2 params for cocos)
3. Check if source is in `cocoscrapers_sources` list

## 💡 Key Benefits

✅ **User Control:** Can disable cocoscrapers without uninstalling
✅ **Automatic:** No manual configuration needed
✅ **Safe:** Graceful fallback if addon removed
✅ **Fast:** Settings cached, no repeated checks
✅ **Logged:** Comprehensive logging for debugging
✅ **Compatible:** Works with all crew sources
✅ **Extensible:** Auto-loads new cocoscrapers subdirectories

## 📚 Documentation

- **Full docs:** `COCOSCRAPERS_INTEGRATION.md`
- **Test suite:** `test_cocoscrapers_integration.py`
- **This guide:** `COCOSCRAPERS_QUICK_REFERENCE.md`

## ✨ Next Steps

1. **Test the integration:**
   ```bash
   python test_cocoscrapers_integration.py
   ```

2. **Test in Kodi:**
   - Open The Crew addon
   - Search for a movie or episode
   - Check Kodi log for cocoscrapers sources loading

3. **Adjust settings:**
   - Settings → Sources → CocoScrapers
   - Toggle "Enable CocoScrapers" on/off
   - Test sources with both states

4. **Report issues:**
   - Check Kodi log for errors
   - Verify all conditions met (installed, enabled, debrid)
   - Test with specific sources

---

**Status:** ✅ Ready for testing
**Date:** December 8, 2024
**Version:** 1.0
