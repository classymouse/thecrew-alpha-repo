# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file 123movies.py
* @package script.module.thecrew
*
* @copyright (c) 2026, The Crew
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*
'''

import re
import json
import ast

from urllib.parse import parse_qs, urljoin, urlparse, urlencode, quote, unquote, quote_plus, unquote_plus

from ...modules import cleantitle
from ...modules import client
from ...modules import directstream
from ...modules.crewruntime import c
from ...modules import cfscrape

#from six.moves.urllib_parse import parse_qs, urljoin, urlparse, urlencode, quote, unquote, quote_plus, unquote_plus



class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        #self.domains = ['www11.123movie.movie', '123moviesfree.so', 'ww4.123moviesfree.net']
        self.domains = ['ww4.123moviesfree.net', 'https://ww5.123moviesfree.net/']
        #self.base_link = 'https://123moviesfree.so'
        self.base_link = 'https://ww4.123moviesfree.net'
        #self.search_link = '/movie/search/%s'
        self.search_link = '/search/?q=%s'

    def matchAlias(self, title, aliases):
        try:
            for alias in aliases:
                if cleantitle.get(title) == cleantitle.get(alias['title']):
                    return True
        except Exception:
            return False

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            aliases.append({'country': 'us', 'title': title})
            url = {'imdb': imdb, 'title': title, 'year': year, 'aliases': json.dumps(aliases)}
            url = urlencode(url)
            return url
        except Exception:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            aliases.append({'country': 'us', 'title': tvshowtitle})
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year, 'aliases': json.dumps(aliases)}
            url = urlencode(url)
            return url
        except Exception:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None:
                return
            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urlencode(url)
            return url
        except Exception:
            return

    def searchShow(self, title, season, aliases):
        scraper = cfscrape.create_scraper()
        try:
            search = f'{title} Season {int(season):01d}'
            url = urljoin(self.base_link, self.search_link % cleantitle.geturl(search))
            #c.log('123movies url: ' + url)
            r = scraper.get(url, timeout=10).text
            r = client.parseDom(r, 'div', attrs={'class': 'ml-item'})
            r = zip(client.parseDom(r, 'a', ret='href'), client.parseDom(r, 'a', ret='title'))
            r = [(i[0], i[1], re.findall(r'(.*?)\s+-\s+Season\s+(\d)', i[1])) for i in r]
            r = [(i[0], i[1], i[2][0]) for i in r if len(i[2]) > 0]
            url = [i[0] for i in r if self.matchAlias(i[2][0], aliases) and i[2][1] == season][0]
            url = urljoin(self.base_link, f'{url}/watching.html')
            return url
        except Exception:
            c.log('123movies1 exception', 1)
            return

    def searchMovie(self, title, year, aliases):
        scraper = cfscrape.create_scraper()
        try:
            title.replace(":", '').replace(' ', '+')
            #c.log(f"[CM Debug @ 95 in 123movies.py] title = {title}", 1)
            #title = quote_plus(title)
            #url = urljoin(self.base_link, self.search_link % cleantitle.geturl(title))
            url = urljoin(self.base_link, self.search_link % title)

            #c.log(f"[CM Debug @ 100 in 123movies.py] url = {url}", 1)

            r = scraper.get(url, timeout=10).text
            r = client.parseDom(r, 'div', attrs={'class': 'ml-item'})
            r = zip(client.parseDom(r, 'a', ret='href'), client.parseDom(r, 'a', ret='title'))
            results = [(i[0], i[1], re.findall('\((\d{4})', i[1])) for i in r]
            try:
                r = [(i[0], i[1], i[2][0]) for i in results if len(i[2]) > 0]
                url = [i[0] for i in r if self.matchAlias(i[1], aliases) and (year == i[2])][0]
            except Exception:
                url = None
                pass

            if url is None:
                url = [i[0] for i in results if self.matchAlias(i[1], aliases)][0]

            url = urljoin(self.base_link, f'{url}/watching.html')
            return url
        except Exception:
            c.log('123movies2 exception', 1)
            return

    def sources(self, url, hostDict, hostprDict):
        scraper = cfscrape.create_scraper()
        sources = []
        try:

            if url is None:
                return sources

            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            # aliases are now JSON-encoded when created; support legacy repr by falling back to ast.literal_eval
            aliases_str = data.get('aliases', '[]')
            try:
                aliases = json.loads(aliases_str)
            except Exception:
                try:
                    aliases = ast.literal_eval(aliases_str)
                except Exception:
                    aliases = []

            if 'tvshowtitle' in data:
                ep = data['episode']
                url = f'{self.base_link}/film/{cleantitle.geturl(data["tvshowtitle"])}-season-{int(data["season"])}/watching.html?ep={ep}'
                # r = client.request(url, timeout='10', output='geturl')
                # url = r if r else self.searchShow(data['tvshowtitle'], data['season'], aliases)
                # c.log('123movies url: ' + repr(url))

            else:
                url = self.searchMovie(data['title'], data['year'], aliases)

            if url is None:
                raise Exception()

            resp = scraper.get(url, timeout=10)
            try:
                status = resp.status_code
            except Exception:
                status = None
            if status is not None and status != 200:
                c.log(f"[123movies Debug] HTTP status {status} for {url}")
                return sources

            r = resp.text
            r = client.parseDom(r, 'div', attrs={'class': 'les-content'})

            if 'tvshowtitle' in data:
                ep = data['episode']
                links = client.parseDom(r, 'a', attrs={'episode-data': ep}, ret='player-data')
            else:
                links = client.parseDom(r, 'a', ret='player-data')

            # Fallback: if no links found, try iframes or direct player URLs
            if not links:
                c.log(f"[123movies Debug] No player-data links found for {url}, trying iframe fallback")
                iframe_srcs = client.parseDom(r, 'iframe', ret='src')
                links = iframe_srcs or []

            for link in links:
                try:
                    if link.startswith('//'):
                        link = 'https:' + link
                    host = re.findall(r'([\w]+[.][\w]+)$', urlparse(link.strip().lower()).netloc)[0]
                    if not host in hostDict:
                        raise Exception()
                    host = client.replaceHTMLCodes(host)
                    host = host.encode('utf-8')

                    if 'load.php' not in link:
                        sources.append({
                            'source': host, 'quality': '720p', 'language': 'en', 'url': link,
                            'direct': False, 'debridonly': False
                            })
                except Exception:
                    pass

            return sources
        except Exception:
            c.log('123movies0 exception', 1)
            return sources

    def resolve(self, url):
        if "google" in url:
            return directstream.googlepass(url)
        else:
            return url
