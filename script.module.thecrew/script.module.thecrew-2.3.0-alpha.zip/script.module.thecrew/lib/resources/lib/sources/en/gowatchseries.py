# -*- coding: utf-8 -*-

'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

# try: from urlparse import parse_qs, urljoin
# except ImportError: from urllib.parse import parse_qs, urljoin
# try: from urllib import urlencode, quote_plus
# except ImportError: from urllib.parse import urlencode, quote_plus

from urllib.parse import parse_qs, urljoin, urlencode, quote_plus

import json

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import source_utils
from resources.lib.modules.crewruntime import c

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['gowatchseries.io','gowatchseries.co']
        self.base_link = 'https://www5.gowatchseries.bz' # cm - blocked
        self.search_link = '/ajax-search.html?keyword=%s&id=-1'
        self.search_link2 = '/search.html?keyword=%s'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urlencode(url)
            return url
        except BaseException:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {
                'imdb': imdb,
                'tvdb': tvdb,
                'tvshowtitle': tvshowtitle,
                'year': year}
            url = urlencode(url)
            return url
        except BaseException:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None:
                return

            # Accept either a query-string or a dict; normalize to a simple dict of scalars
            if isinstance(url, dict):
                _data = {k: (v[0] if isinstance(v, (list, tuple)) else v) for k, v in url.items()}
            else:
                _data = parse_qs(url)
                _data = {k: (_data[k][0] if _data[k] else '') for k in _data}

            _data['title'], _data['premiered'], _data['season'], _data['episode'] = title, premiered, season, episode
            url = urlencode(_data)
            return url
        except BaseException:
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []

            if url is None:
                return sources

            # Accept either a query-string or a dict; normalize to a simple dict of scalars
            if isinstance(url, dict):
                data = {k: (v[0] if isinstance(v, (list, tuple)) else v) for k, v in url.items()}
            else:
                data = parse_qs(url)
                data = {k: (data[k][0] if data[k] else '') for k in data}

            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
            if 'season' in data:
                season = data['season']
            if 'episode' in data:
                episode = data['episode']
            year = data['year']

            try:
                r = client.request(self.base_link, output='extended', timeout='10')
            except Exception as e:
                c.log(f"[GoWatchSeries] Initial request failed: {e}")
                return sources

            try:
                cookie = r[4]
                headers = r[3]
            except Exception:
                try:
                    cookie = r[3]
                    headers = r[2]
                except Exception as e:
                    c.log(f"[GoWatchSeries] Unexpected initial response format: {e}")
                    return sources

            result = r[0] if r else ''
            headers['Cookie'] = cookie

            query = urljoin(self.base_link, self.search_link %quote_plus(cleantitle.getsearch(title)))
            query2 = urljoin(self.base_link, self.search_link % quote_plus(title).lower())

            try:
                r = client.request(query, headers=headers, XHR=True)
                if not r or len(str(r)) < 20:
                    r = client.request(query2, headers=headers, XHR=True)
            except Exception as e:
                c.log(f"[GoWatchSeries] Search request failed: {e}")
                return sources

            try:
                try:
                    content = json.loads(r).get('content', '')
                except Exception:
                    # Some endpoints return raw HTML/strings instead of JSON - fall back
                    c.log(f"[GoWatchSeries] Search response not JSON, using raw content")
                    content = c.ensure_text(r, errors='replace') if r is not None else ''
            except Exception as e:
                c.log(f"[GoWatchSeries] Failed to obtain search content: {e}")
                content = ''

            links = client.parseDom(content, 'a', ret='href') or []
            titles = client.parseDom(content, 'a') or []
            r = list(zip(links, titles))
            c.log(f"[GoWatchSeries] Parsed {len(r)} links from search content: {r}")


            try:
                if 'tvshowtitle' in data:
                    cltitle = cleantitle.get(title + 'season' + season)
                    cltitle2 = cleantitle.get(title + 'season%02d' % int(season))
                    r = [ i for i in r if cltitle == cleantitle.get(i[1]) or cltitle2 == cleantitle.get(i[1])]
                    vurl = '%s%s-episode-%s' % (self.base_link, str(r[0][0]).replace('/info', ''), episode) if r else ''
                    vurl2 = None

                else:
                    cltitle = cleantitle.getsearch(title)
                    cltitle2 = cleantitle.getsearch('%s (%s)' % (title, year))
                    r = [i for i in r if cltitle2 == cleantitle.getsearch(i[1]) or cltitle == cleantitle.getsearch(i[1])]
                    vurl = '%s%s-episode-0' % (self.base_link, str(r[0][0]).replace('/info', '')) if r else ''
                    vurl2 = '%s%s-episode-1' % (self.base_link, str(r[0][0]).replace('/info', '')) if r else None

                if not vurl:
                    c.log('[GoWatchSeries] No matching page found')
                    return sources

                r = client.request(vurl, headers=headers)
                headers['Referer'] = vurl

                slinks = client.parseDom(r, 'div', attrs={'class': 'anime_muti_link'}) or ''
                slinks = client.parseDom(slinks, 'li', ret='data-video') or []
                if len(slinks) == 0 and vurl2:
                    r = client.request(vurl2, headers=headers)
                    headers['Referer'] = vurl2
                    slinks = client.parseDom(r, 'div', attrs={'class': 'anime_muti_link'}) or ''
                    slinks = client.parseDom(slinks, 'li', ret='data-video') or []
            except Exception as e:
                c.log(f"[GoWatchSeries] Error finding slinks: {e}")
                return sources
            slinks = [slink if str(slink).startswith('http') else 'https:{0}'.format(slink) for slink in slinks]

            _slinks = []
            for url in slinks:
                try:
                    _slinks.append((url, 'HD'))
                except Exception as e:
                    c.log(f"[GoWatchSeries] Error normalizing slink {url}: {e}")
                    continue
            c.log(f"[GoWatchSeries] _slinks normalized: {_slinks}")
            c.log("[GoWatchSeries] Starting loop1")
            for url in _slinks:
                try:
                    quality = url[1]
                    url = url[0]
                    url = client.replaceHTMLCodes(url)
                    valid, host = source_utils.is_host_valid(url, hostDict)
                    c.log(f"[GoWatchSeries] loop1 candidate url={url} valid={valid} host={host}")
                    direct = False if valid else True
                    host = client.replaceHTMLCodes(host)
                    if not host:
                        c.log(f"[GoWatchSeries] Invalid host for url {url}")
                        continue
                    c.log(f"[GoWatchSeries] Adding source (loop1) host={host} url={url} quality={quality}")
                    sources.append({'source': host,
                                    'quality': quality,
                                    'language': 'en',
                                    'url': url,
                                    'direct': direct,
                                    'debridonly': False})
                except Exception as e:
                    c.log(f"[GoWatchSeries] loop1 item exception: {e}")
                    continue
            c.log(f"[GoWatchSeries] count now {len(sources)} after loop1")

            for url in _slinks:
                quality = url[1]
                url = url[0]
                url = client.replaceHTMLCodes(url)
                #url = url.encode('utf-8')
                valid, host = source_utils.is_host_valid(url, hostDict)
                direct = False if valid else True
                host = client.replaceHTMLCodes(host)
                #host = host.encode('utf-8')
                c.log(f"[GoWatchSeries] Adding source (loop2) host={host} url={url} quality={quality}")
                sources.append({'source': host,
                                'quality': quality,
                                'language': 'en',
                                'url': url,
                                'direct': direct,
                                'debridonly': False})
            return sources
        except BaseException:
            return sources

    def resolve(self, url):
        return url
