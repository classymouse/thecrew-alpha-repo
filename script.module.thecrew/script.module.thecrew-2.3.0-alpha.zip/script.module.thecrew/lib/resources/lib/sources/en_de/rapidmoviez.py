# -*- coding: utf-8 -*-

'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re,time

try: from urlparse import urljoin
except ImportError: from urllib.parse import urljoin
try: from urllib import quote_plus
except ImportError: from urllib.parse import quote_plus

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules.crewruntime import c
from resources.lib.modules import debrid
from resources.lib.modules import source_utils
from resources.lib.modules import workers
#from resources.lib.modules import cfscrape




class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['rmz.cr']
        self.base_link = 'https://rapidmoviez.website'
        self.search_link = '/search/%s'
        #self.scraper = cfscrape.create_scraper()

    def search(self, title, year):
        try:
            url = urljoin(self.base_link, self.search_link % (quote_plus(title)))
            headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:102.0) Gecko/20100101 Firefox/102.0'}
            r = client.request(url, headers=headers)
            r = c.ensure_text(r)
            div_items = client.parseDom(r, 'div', attrs={'class': 'list_items'})
            if not div_items:
                return
            list_items = client.parseDom(div_items[0], 'li')
            results = []
            for item in list_items:
                links = client.parseDom(item, 'a', attrs={'class': 'title'})
                if links:
                    href = client.parseDom(item, 'a', attrs={'class': 'title'}, ret='href')
                    text = links[0]
                    if href:
                        results.append((href[0], text))
            r = [(urljoin(self.base_link, i[0])) for i in results if cleantitle.get(title) in cleantitle.get(i[1]) and year in i[1]]
            if r: return r[0]
            else: return
        except:
            return

    def sources(self, data, hostDict):

        self.sources = []

        try:
            if not data:
                return self.sources

            if debrid.status() is False:
                return self.sources

            title = data.get('tvshowtitle') or data.get('title')
            title = cleantitle.get_query(title)

            hdlr = data.get('year')
            hdlr2 = 'S%02dE%02d' % (int(data.get('season', 0)), int(data.get('episode', 0))) if data.get('tvshowtitle') else ''
            imdb = data.get('imdb')

            url = self.search(title, hdlr)
            headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:102.0) Gecko/20100101 Firefox/102.0'}
            r = client.request(url, headers=headers)
            r = c.ensure_text(r)
            if hdlr2 == '':
                ul_list = client.parseDom(r, 'ul', attrs={'id': 'releases'})
            else:
                ul_list = client.parseDom(r, 'ul', attrs={'id': 'episodes'})

            if not ul_list:
                return self.sources

            links = client.parseDom(ul_list[0], 'a', ret='href')
            texts = client.parseDom(ul_list[0], 'a')
            r = [(texts[i], urljoin(self.base_link, links[i])) for i in range(min(len(texts), len(links))) if texts[i] != 'Watch']
            if hdlr2 != '':
                r = [(i[0], i[1]) for i in r if hdlr2.lower() in i[0].lower()]

            self.hostDict = hostDict
            threads = []

            for i in r:
                threads.append(workers.Thread(self._get_sources, i[0], i[1]))
            [i.start() for i in threads]

            alive = [x for x in threads if x.is_alive() is True]
            while alive:
                alive = [x for x in threads if x.is_alive() is True]
                time.sleep(0.1)
            return self.sources
        except:
            return self.sources

    def _get_sources(self, name, url):
        try:
            headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:102.0) Gecko/20100101 Firefox/102.0'}
            r = client.request(url, headers=headers)
            r = c.ensure_text(r)
            name = client.replaceHTMLCodes(name)
            try: _name = name.lower().replace('rr', '').replace('nf', '').replace('ul', '').replace('cu', '')
            except: _name = name
            link_blocks = client.parseDom(r, 'pre', attrs={'class': 'links'})
            s = ''
            for block in link_blocks:
                s += block
            urls = re.findall(r'''((?:http|ftp|https)://[\w_-]+(?:(?:\.[\w_-]+)+)[\w.,@?^=%&:/~+#-]*[\w@?^=%&/~+#-])''', s, flags=re.MULTILINE|re.DOTALL)
            urls = [i for i in urls if not i.endswith(('.rar', '.zip', '.iso', '.idx', '.sub', '.srt'))]
            for url in urls:
                if url in str(self.sources):
                    continue

                valid, host = source_utils.is_host_valid(url, self.hostDict)
                if not valid:
                    continue
                host = client.replaceHTMLCodes(host)
                host = host.encode('utf-8')
                quality, info = source_utils.get_release_quality(name, url)
                try:
                    size = re.findall(r'((?:\d+\.\d+|\d+\,\d+|\d+)\s*(?:GiB|MiB|GB|MB))', name)[0]
                    div = 1 if size.endswith(('GB', 'GiB')) else 1024
                    size = float(re.sub('[^0-9|/.|/,]', '', size)) / div
                    size = '%.2f GB' % size
                    info.append(size)
                except BaseException:
                    pass
                info = ' | '.join(info)
                self.sources.append({'source': host, 'quality': quality, 'language': 'en', 'url': url, 'info': info, 'direct': False, 'debridonly': True, 'name': _name})
        except:
            pass

    def resolve(self, url):
        return url
