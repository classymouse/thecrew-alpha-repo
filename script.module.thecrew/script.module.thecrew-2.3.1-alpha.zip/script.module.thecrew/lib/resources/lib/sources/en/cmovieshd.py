# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file cmovieshd.py
* @package script.module.thecrew
*
* @copyright (c) 2026, The Crew
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*
'''

import re

from urllib.parse import urlencode, quote_plus, parse_qs, urljoin

from ...modules import cleantitle
from ...modules import client
from ...modules import source_utils
from ...modules.crewruntime import c


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['cmovies.online'] # cm - blocked /
        #alternative https://en.cmovieshd-official.com/ is working but omg, the **** you have to go
        # through on popups and other stuff is overwhelming
        self.base_link = 'http://cmovies.vc/'
        self.movie_link = '/film/%s/watching.html?ep=0'
        self.tv_link = '/film/%s-season-%s/watching.html?ep=%s'


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urlencode(url)
            return url
        except:
            return


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urlencode(url)
            return url
        except:
            return


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return

            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urlencode(url)
            return url
        except:
            return


    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if url is None:
                return sources

            hostDict = hostprDict + hostDict

            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
            year = data['year']

            c_title = cleantitle.geturl(title).replace('--', '-')
            query = self.movie_link % c_title if 'tvshowtitle' not in data else\
                    self.tv_link % (c_title, data['season'], data['episode'])
            link = urljoin(self.base_link, query)
            #c.log('cmovies link: ' + link)

            r = client.request(link)
            if not r or 'Just a moment' in r or 'Enable JavaScript and cookies' in r or '404 Not Found' in r:
                c.log(f"[CMOVIESHD] Blocked or empty response for {link}")
                return sources
            try:
                qual_list = re.compile(r'class="quality">(.+?)</span>').findall(r)
                qual = qual_list[0] if qual_list else 'HD'
                u = re.compile(r'data-video="(.+?)"').findall(r) or []
            except Exception as e:
                c.log(f"[CMOVIESHD] Error extracting qualities/urls: {e}")
                return sources

            for url in u:
                try:
                    quality, _ = source_utils.get_release_quality(qual, url)
                    if not url.startswith('http'):
                        url =  "https:" + url
                    valid, host = source_utils.is_host_valid(url, hostDict)
                    if valid:
                        c.log(f"[CMOVIESHD] Adding source {host} {url} quality={quality}")
                        sources.append({'source': host, 'quality': quality, 'language': 'en', 'url': url, 'direct': False, 'debridonly': False})
                except Exception as e:
                    c.log(f"[CMOVIESHD] Error processing url {url}: {e}")
                    continue
            c.log(f"[CMOVIESHD] Returning {len(sources)} sources")
            return sources
        except:
            #c.log('CMOVIES - Exception', 1)
            return sources


    def resolve(self, url):
        return url
