# -*- coding: utf-8 -*-

'''
 ***********************************************************
 * The Crew Add-on - Scraper Module
 *
 *
 * @file torrentio.py
 * @package script.module.thecrew
 *
 * @copyright (c) 2025, The Crew
 * @license GNU General Public License, version 3 (GPL-3.0)
 *
  ***********************************************************cm*
'''


import re
import requests
import queue
import json

from urllib.parse import urlencode, parse_qs

from resources.lib.modules import cleantitle
from resources.lib.modules import debrid
from resources.lib.modules import source_utils
from resources.lib.modules import client
from resources.lib.modules.crewruntime import c


class source:
    priority = 1
    pack_capable = True
    hasMovies = True
    hasEpisodes = True
    _queue = queue.SimpleQueue()
    def __init__(self):
        '''
        Torrentio (v.0.0.15) supports YTS(+), EZTV(+), RARBG(+), 1337x(+), ThePirateBay(+),
        KickassTorrents(+), TorrentGalaxy(+), MagnetDL(+), HorribleSubs(+), NyaaSi(+), TokyoTosho(+),
        AniDex(+), Rutor(+), Rutracker(+), Comando(+), BluDV(+), Torrent9(+), ilCorSaRoNeRo(+),
        MejorTorrent(+), Wolfmax4k(+), Cinecalidad(+) and BestTorrents(+)
        '''
        self.language = ['en']
        self.base_link = "https://torrentio.strem.fun"
        self.movieSearch_link = '/stream/movie/%s.json'
        self.tvSearch_link = '/stream/series/%s:%s:%s.json'
        self.min_seeders = 0
        self.tv_cache_max_age = 3600 # cm get from json file: "cacheMaxAge": 3600, this is in secs
        self.movie_cache_max_age = 3600 # cm get from json file: "cacheMaxAge": 3600, this is in secs
        self.headers = {'User-Agent': 'Mozilla/5.0'}



    def sources(self, data, hostDict):
        sources = []
        if not data:
            return sources
        append = sources.append
        try:
            title = data.get('tvshowtitle') if data.get('tvshowtitle') else data.get('title')
            title = title.replace('&', 'and').replace('/', ' ')
            year = data.get('year')
            imdb = data.get('imdb')
            if data.get('tvshowtitle'):
                season = data.get('season')
                episode = data.get('episode')
                #hdlr = 'S%02dE%02d' % (int(season), int(episode))
                url = '%s%s' % (self.base_link, self.tvSearch_link % (imdb, season, episode))
                #url = f"{self.base_link}{self.tvSearch_link.format(imdb, season, episode)}"
            else:
                url = '%s%s' % (self.base_link, self.movieSearch_link % imdb)
                #url = f"{self.base_link}{self.movieSearch_link.format(imdb)}"
                hdlr = year
            try:
                c.log(f"[CM Debug @ 117 in torrentio.py] url = {url}")
                results = requests.get(url, headers=self.headers, timeout=15)
                c.log(f"[CM Debug @ 124 in torrentio.py] results = {results}")
                files = results.json()['streams']
            except (requests.RequestException, json.JSONDecodeError):
                files = []

            self._queue.put_nowait(files)
            self._queue.put_nowait(files)
            ITEMINFO = re.compile(r'👤.*')
        except Exception as e:
            c.scraper_error('Exception (1) in sources', exc_info=e)
            return sources

        for file in files:
            try:
                infohash = file['infoHash']
                file_title = file['title'].split('\n')
                file_info = [x for x in file_title if ITEMINFO.match(x)][0]
                #behaviourHints = file['behaviorHints']
                #b_filename = behaviourHints['filename']
                #b_bingegroup = behaviourHints['bingegroup']

                # cm - 2025/06/12
                # we can get a lot of info from the Bingegroup, things like HDR or DV, 10BIT etc,
                # but the info is too scattered, so we just use the filename and the old functions for now

                name = cleantitle.get(file_title[0])
                title = cleantitle.get(title)

                if str(title) not in str(name):
                    continue

                url = f'magnet:?xt=urn:btih:{infohash}&dn={name}'
                seeders_match = re.search(r'(\d+)', file_info)
                if seeders_match:
                    seeders = int(seeders_match.group(1))
                else:
                    seeders = 0

                quality, info = source_utils.get_release_quality(file_title[0], url)

                size_match = re.search(r'((?:\d+\,\d+\.\d+|\d+\.\d+|\d+\,\d+|\d+)\s*(?:GB|GiB|Gb|MB|MiB|Mb))', file_info)
                if size_match:
                    size = size_match.group(0)
                    dsize, isize = source_utils._size(size)
                    info.insert(0, isize)
                else:
                    dsize = 0

                info = ' | '.join(info)

                append({'provider': 'torrentio', 'source': 'torrent', 'seeders': seeders, 'hash': infohash, 'name': name, 'quality': quality,
                            'language': 'en', 'url': url, 'info': info, 'direct': False, 'debridonly': True, 'size': dsize})
            except Exception as e:
                c.scraper_error(f'Exception (2) in sources: {e}', 'Torrentio', 1)
        return sources

    def sources_packs(self, data, hostDict, search_series=False, total_seasons=0, bypass_filter=0):
        """
        Search for pack releases (season packs or show packs).
        Torrentio API includes packs in its standard response, so we query the API
        and filter for pack releases.
        """
        sources = []
        try:
            tvshowtitle = data.get('tvshowtitle')
            year = data.get('year')
            season = int(data.get('season', 0))
            imdb = data.get('imdb')
            aliases = data.get('aliases', [])

            if not tvshowtitle or not imdb:
                return sources

            # Torrentio's API returns packs when we query for episode 1
            # We'll query season 1 episode 1 to get potential packs
            try:
                # Query for the first episode of the season to get pack results
                url = f"{self.base_link}{self.tvSearch_link % (imdb, season, 1)}"
                c.log(f"[Torrentio Pack] Searching: {url}")

                results = requests.get(url, headers=self.headers, timeout=15)
                files = results.json().get('streams', [])

                ITEMINFO = re.compile(r'👤.*')

                for file in files:
                    try:
                        infohash = file.get('infoHash')
                        if not infohash:
                            continue

                        file_title = file['title'].split('\n')
                        name = file_title[0]

                        # Filter using pack validation
                        if search_series:
                            valid, last_season = source_utils.filter_show_pack(
                                tvshowtitle, aliases, imdb, year, season,
                                source_utils.release_title_format(name), total_seasons
                            )
                            if not valid:
                                continue
                            package_meta = {'package': 'show', 'last_season': last_season}
                        else:
                            valid, episode_start, episode_end = source_utils.filter_season_pack(
                                tvshowtitle, aliases, year, season,
                                source_utils.release_title_format(name)
                            )
                            if not valid:
                                continue
                            package_meta = {
                                'package': 'season',
                                'episode_start': episode_start,
                                'episode_end': episode_end
                            }

                        # Extract file info
                        file_info = [x for x in file_title if ITEMINFO.match(x)]
                        if file_info:
                            file_info = file_info[0]

                            # Get seeders
                            seeders_match = re.search(r'(\d+)', file_info)
                            seeders = int(seeders_match.group(1)) if seeders_match else 0

                            # Get size
                            size_match = re.search(r'((?:\d+\,\d+\.\d+|\d+\.\d+|\d+\,\d+|\d+)\s*(?:GB|GiB|Gb|MB|MiB|Mb))', file_info)
                            if size_match:
                                size = size_match.group(0)
                                dsize, isize = source_utils._size(size)
                            else:
                                dsize = 0
                                isize = ''
                        else:
                            seeders = 0
                            dsize = 0
                            isize = ''

                        # Build magnet URL
                        url_magnet = f'magnet:?xt=urn:btih:{infohash}&dn={cleantitle.get(name)}'

                        # Get quality
                        quality, info = source_utils.get_release_quality(name, url_magnet)
                        if isize:
                            info.insert(0, isize)
                        info = ' | '.join(info)

                        # Build source dict
                        source_dict = {
                            'provider': 'torrentio',
                            'source': 'torrent',
                            'seeders': seeders,
                            'hash': infohash,
                            'name': name,
                            'quality': quality,
                            'language': 'en',
                            'url': url_magnet,
                            'info': info,
                            'direct': False,
                            'debridonly': True,
                            'size': dsize
                        }
                        source_dict.update(package_meta)
                        sources.append(source_dict)

                    except Exception as e:
                        c.log(f'[Torrentio Pack] Error processing item: {e}')
                        continue

            except (requests.RequestException, json.JSONDecodeError) as e:
                c.log(f'[Torrentio Pack] Request error: {e}')
                return sources

            return sources

        except Exception as e:
            c.log(f'[Torrentio Pack] Exception: {e}')
            return sources

    def resolve(self, url):
        return url
