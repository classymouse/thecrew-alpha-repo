# Cache ETag & Conditional Fetch Helper

## Purpose
Provides a small, reusable helper for doing conditional HTTP requests using ETag and Last-Modified headers to avoid fetching unchanged payloads.

## API
`cache.get_with_etag(key, fetcher, ttl_seconds=60, namespace=None)`

- `key`: Cache key (string)
- `fetcher(conditional_headers)`: Callable that performs the network request. It should accept a dict of conditional headers (or None) and return a tuple `(body_text, response_headers, status_code)` where `status_code` is an integer.
- `ttl_seconds`: Short window during which a cached entry is returned without revalidation (default: 60s for `getWatchedActivity`).
- `namespace`: Optional namespace string stored alongside the key for separation.

## Behavior
1. If a cached value exists and is fresh (age <= `ttl_seconds`), return it immediately.
2. Otherwise, call `fetcher()` with conditional headers (`If-None-Match` / `If-Modified-Since`) if available.
3. On `304 Not Modified` the cached value is kept and timestamp updated.
4. On `2xx` the body is parsed and stored along with `ETag` and `Last-Modified` from response headers.
5. On network errors or other status codes, fallback to cached value if available.

## Usage Example (Trakt last_activities)

```py
def fetcher(headers):
    return get_trakt('/sync/last_activities', conditional_headers=headers)

value = cache.get_with_etag('trakt.last_activities', fetcher, ttl_seconds=60, namespace='trakt')
```

## Notes
- Designed for small, frequently-changing endpoints where conditional revalidation is cheap.
- Keep TTL small (30–60s) for highly dynamic endpoints like `getWatchedActivity` to balance freshness and server load.
