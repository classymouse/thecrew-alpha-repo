# Library Auto-Update for New Seasons - User Guide

## The Issue (Now Fixed!)

Previously, users reported that when a TV show's new season was released (e.g., Season 4 coming out months after Season 3), it wouldn't automatically appear in their Kodi library. They had to manually re-add the entire show.

**This has been fixed!** The auto-update now checks for new seasons every 3 days (reduced from 7 days) for better responsiveness.

## How to Enable Library Auto-Updates

### Settings Required

1. **Open The Crew Settings**
   - Go to The Crew addon
   - Open Settings

2. **Enable Library Service Update**
   - Navigate to: `Settings → Library → Service`
   - Enable: **"Auto-update library"** or **"Library service update"**
   - This allows The Crew to check for new content automatically

3. **Optional: Enable Notifications**
   - In the same Library settings section
   - Enable: **"Show notifications"** 
   - You'll get a notification like: "Breaking Bad: New season 4 added"

### How It Works

- **Service runs every 6 hours** - The Crew service checks your library periodically
- **New season detection** - For continuing shows, checks for new seasons every **3 days**
- **Automatic addition** - When a new season is detected, all episodes are automatically added to your library
- **Only for ongoing shows** - Ended shows are not rechecked (saves API calls)

### What Gets Updated

✅ **New episodes** in existing seasons (checked every service run)  
✅ **New seasons** for continuing/returning shows (checked every 3 days)  
✅ **Both TV shows and movies** from your Trakt collection  

### Troubleshooting

**Q: I added a show but new seasons still don't appear automatically**

A: Check these settings:
1. Library auto-update is enabled (see step 2 above)
2. The show status is "Continuing" or "Returning Series" (not "Ended")
3. The service has run at least once (wait up to 6 hours after enabling)
4. Check Kodi logs for "[LibTools]" messages to see update activity

**Q: How do I manually trigger an update?**

A: 
- Go to The Crew → Tools → Update Library
- Or restart Kodi (triggers an update on startup)

**Q: Will this work for shows from other sources (not Trakt)?**

A: The auto-update works for any show added to your library through The Crew, whether from Trakt, IMDB lists, or manual adds.

### Technical Details

- Season checks use Last-Modified headers to minimize API calls
- The system caches season counts and only fetches new data when needed
- Logs all activity to Kodi log with prefix `[LibTools]`
- Uses efficient database caching to track last check dates

### Recent Improvements (v2.3.0-alpha)

- Reduced new season check interval from 7 to 3 days
- Added user notifications when new seasons are detected
- Improved logging for better troubleshooting
- Fixed season detection logic to be more reliable

---

**Questions or Issues?**  
Report on GitHub: https://github.com/classymouse/script.module.thecrew/issues
