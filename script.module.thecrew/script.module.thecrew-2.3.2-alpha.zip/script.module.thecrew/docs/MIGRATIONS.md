# Database Migrations & Upgrade Plan

## Overview
We maintain a `CACHE_VERSION` and a `schema_migrations` table to track applied migrations. Migrations are idempotent and logged. Migration steps run on startup when needed.

## Strategy
- **Backup**: Always copy DB files to `*.bak.TIMESTAMP` before applying migrations.
- **Idempotence**: Migrations check for columns/tables before creating them.
- **Recording**: Each migration inserts a row into `schema_migrations(name, applied_at)`.
- **Recovery**: On failure the backup is restored and error is logged.

## Current migrations
- `cache_v2`: Adds `namespace`, `etag`, `last_modified` columns to unified `cache` table and records migration.

## How to add a migration
1. Add a function `_migrate_<name>()` in `cache.py` that performs the schema changes and data adjustments.
2. Update `_ensure_cache_table_schema()` to call the migration and record it in `schema_migrations`.
3. Add unit tests that simulate an old DB and assert migration result.

## Testing migrations
- Tests should create a temporary DB with the old schema, run `_ensure_cache_table_schema()`, and verify new columns and data migration.
- Add to CI integration or a dedicated migration test job.
