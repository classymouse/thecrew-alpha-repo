# CI for script.module.thecrew

This repository includes a lightweight GitHub Actions workflow that runs unit tests on pushes and pull requests to `main`.

Quick local steps to reproduce CI behavior:

- Ensure Python 3.8 or 3.9 is available
- From the repo root run:
  - `bash tests/run_ci.sh`

If you prefer to run tests directly:
- `python -m pip install --upgrade pip`
- `pip install pytest`
- `pytest -q`

Notes
- Tests are designed to be isolated with stubs for Kodi (`xbmc`, `xbmcgui`, etc.). If a test fails due to missing runtime dependencies, inspect the failing test log; many tests stub external modules at runtime.
