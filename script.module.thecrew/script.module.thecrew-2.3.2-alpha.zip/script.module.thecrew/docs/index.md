# Project Documentation Index

Welcome to the documentation index. Key docs:

- `SOURCE_CACHE_IMPLEMENTATION.md` - Source cache design and rationale
- `SCROBBLE_QUEUE_IMPLEMENTATION.md` - Trakt scrobble queue details
- `PYTHON3_MIGRATION.md` - Migration notes and status
- `PACK_SCRAPER_TEMPLATE.md` - Template and guide for pack scrapers
- `PACK_IMPLEMENTATION_STATUS.md` - Implementation progress
- `PACK_IMPLEMENTATION_COMPLETE.md` - Final pack implementation summary
- `COCOSCRAPERS_QUICK_REFERENCE.md` - CocoScrapers quick reference
- `COCOSCRAPERS_INTEGRATION.md` - CocoScrapers integration details
- `API_MODERNIZATION_SUMMARY.md` - API modernization details
- `CACHE_ETAG.md` - ETag / conditional fetch helper usage
- `MIGRATIONS.md` - Migration strategy and tests
- `README_CI.md` - CI test notes
- `Untitled-1.md` - Testing checklist

If you want a specific doc added or reorganized, mention it and I'll update the index.
