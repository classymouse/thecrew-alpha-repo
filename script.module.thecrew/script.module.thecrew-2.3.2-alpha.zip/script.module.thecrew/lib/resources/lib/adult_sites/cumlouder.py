# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file cumlouder.py
* @package script.module.thecrew
*
* @copyright (c) 2026, The Crew
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*
'''

import re
from .base import CrewAdult
from ..modules import client, workers
from ..modules.crewruntime import c


class CUMLOUDER(CrewAdult):
    def __init__(self):
        super().__init__(
            name='cumlouder',
            title='[B][COLOR orange]CUM[/COLOR]LOUDER[/B]'
        )
        self.base_url = 'https://www.cumlouder.com/'

    def get_categories(self):
        """Get series/categories"""
        c.log(f'[CUMLOUDER] Fetching categories')

        try:
            html = client.request(self.base_url, timeout=15)
            if not html:
                return []
        except Exception as e:
            c.log(f'[CUMLOUDER] Category fetch failed: {e}')
            return []

        # Extract series URLs (categories)
        pattern = r'(?s)href="(https://www\.cumlouder\.com/series/[^"]+)/"[^>]*>\s*<img[^>]+data-src="([^"]+)"[^>]*alt="([^"]+)"[^>]*>\s*<h2[^>]*>([^<]+)</h2>'
        matches = re.findall(pattern, html)

        results = []
        for cat_url, thumb_url, alt_text, title in matches:
            cat_name = self._cleanup_title(title.strip())
            results.append((cat_url, cat_name, thumb_url))

        c.log(f'[CUMLOUDER] Found {len(results)} categories')
        return results

    def get_videos(self, url, page=1):
        """Get videos from a series"""
        c.log(f'[CUMLOUDER] Fetching videos from: {url}, page: {page}')

        # Build page URL
        base = url if url.endswith('/') else url + '/'
        page_url = base + str(page) + '/'

        try:
            html = client.request(page_url, timeout=15)
            if not html:
                return []
        except Exception as e:
            c.log(f'[CUMLOUDER] Page fetch failed: {e}')
            return []

        # Extract videos
        pattern = r'(?s)<a class="muestra-escena" href="([^"]*).*?data-src="([^"]*).*?alt="([^"]*)'
        matches = re.findall(pattern, html)

        results = []
        for video_path, thumb, title in matches:
            video_url = 'https://www.cumlouder.com' + video_path
            title = self._cleanup_title(title)
            results.append((video_url, title, thumb))

        c.log(f'[CUMLOUDER] Found {len(results)} videos on page {page}')

        # Add next page indicator if we got results (assume more pages exist)
        if results:
            results.append(('NEXT_PAGE', f'Next Page ({page + 1})...', ''))

        return results

    def resolve(self, url):
        """Resolve video page using resolveurl"""
        c.log(f'[CUMLOUDER] Resolving: {url}')

        # Try resolveurl framework
        resolved = self._try_resolveurl(url)
        if resolved:
            return resolved

        # Fallback: fetch page and extract video URL
        c.log(f'[CUMLOUDER] Resolveurl failed, trying manual extraction')
        try:
            html = client.request(url, timeout=10)
            if html:
                # Try common video URL patterns
                video_url = self._extract_video_url(html)
                if video_url:
                    return video_url
        except Exception as e:
            c.log(f'[CUMLOUDER] Manual extraction failed: {e}')

        # Last resort
        c.log(f'[CUMLOUDER] All methods failed, returning None')
        return None


class PageFetcher:
    """Helper class for concurrent page fetching"""
    def __init__(self):
        self.results = []

    def run(self, urls):
        threads = []
        self.results = []
        indexed_urls = [(i+1, url) for i, url in enumerate(urls)]

        for idx, url in indexed_urls:
            thread = workers.Thread(self._fetch_page, (idx, url))
            threads.append(thread)

        [t.start() for t in threads]
        [t.join() for t in threads]

        # Sort by index and join results
        self.results.sort(key=lambda x: x[0])
        return ''.join([r[1] for r in self.results])

    def _fetch_page(self, data):
        idx, url = data
        try:
            html = client.request(url)
            if html:
                self.results.append((idx, html))
        except:
            pass


# Register the site
site = CUMLOUDER()
