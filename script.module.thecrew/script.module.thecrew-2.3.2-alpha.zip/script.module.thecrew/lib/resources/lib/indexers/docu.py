# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file docu.py
* @package script.module.thecrew
*
* @copyright (c) 2025, The Crew
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*
'''

import os
import re
import sys
import time
# import trace
import traceback

from urllib.parse import quote_plus, urlparse
import requests



import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin


# import urllib
# import six

import resolveurl
# from xbmcplugin import setResolvedUrl

from bs4 import BeautifulSoup as bs

from ..modules.listitem import ListItemInfoTag

from ..modules import cache
from ..modules import client
from ..modules import control
# from ..modules import workers
# from ..modules import log_utils
from ..modules.crewruntime import c

_handle = syshandle = int(sys.argv[1])

artPath = control.artPath()
addonFanart = control.addonFanart()


class Documentary:
    def __init__(self):
        self.list = []
        self.docu_link = 'https://topdocumentaryfilms.com/'
        self.docu_all = 'https://topdocumentaryfilms.com/all/'
        self.docu_cat_list = 'https://topdocumentaryfilms.com/list/'
        self.docu_top100 = 'https://topdocumentaryfilms.com/top-100/'
        self.session = requests.Session()
        self.addon = xbmcaddon.Addon
        self.session.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
            "Accept-Encoding": "gzip, deflate, br",
            "DNT": "1",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Site": "none",
            "Cache-Control": "max-age=0"
        }
        #self.YOUTUBE_PLUGIN = "plugin://plugin.video.youtube/"
        self.YOUTUBE_PLUGIN = "plugin://plugin.video.youtube/"
        self.VIMEO_PLUGIN = "plugin://plugin.video.vimeo/"
        self.DAILYMOTION_PLUGIN = "plugin://plugin.video.dailymotion_com/"

    def get_html(self, url):
        try:
            headers = self.session.headers.copy()
            headers['Referer'] = 'https://topdocumentaryfilms.com/'

            page_response = self.session.get(url, headers=headers, timeout=15, allow_redirects=True)
            page_response.raise_for_status()
            c.log(f"[CM Debug @ 77 in docu.py] Successfully fetched {url} - status: {page_response.status_code}")
            return bs(page_response.text, "html.parser")
        except Exception as e:
            c.log(f"[CM Debug @ 77 in docu.py] Failed to fetch {url}: {e}")
            # Try with client.request as fallback
            try:
                c.log(f"[CM Debug @ 81 in docu.py] Trying client.request for {url}")
                page_response = client.request(url, timeout=15)
                if page_response:
                    return bs(page_response, "html.parser")
            except Exception as e2:
                c.log(f"[CM Debug @ 86 in docu.py] client.request also failed: {e2}")
            return None

    def get_json(self, url):
        page_response = self.session.get(url)
        json = page_response.json()
        return json

    def root(self):
        """
        This function creates the main documentary menu with three options:
        All Documentaries, Categories List, and Top 100.

        Returns:
            list: The list of documentary menu options.
        """
        try:
            cat_icon = control.addonIcon()

            # All Documentaries
            self.list.append({
                'name': 'All Documentaries',
                'url': self.docu_all,
                'image': cat_icon,
                'action': f'docuHeaven&docuCat={self.docu_all}'
            })

            # Categories List
            self.list.append({
                'name': 'Categories',
                'url': self.docu_cat_list,
                'image': cat_icon,
                'action': f'docuHeaven&docuCategories={self.docu_cat_list}'
            })

            # Top 100
            self.list.append({
                'name': 'Top 100 Documentaries',
                'url': self.docu_top100,
                'image': cat_icon,
                'action': f'docuHeaven&docuCat={self.docu_top100}'
            })

            c.log(f'[CM Debug @ 108 in docu.py] Created {len(self.list)} menu items')
        except Exception as e:
            failure = traceback.format_exc()
            c.log(f'[CM Debug @ 119 in docu.py]Traceback:: {failure}')
            c.log(f'[CM Debug @ 119 in docu.py]Exception raised. Error = {e}')

        self.addDirectory(self.list)
        return self.list

    def docu_categories(self, url):
        """
        Show documentary categories.
        Using hardcoded category list since the website structure makes parsing unreliable.
        """
        try:
            # Known documentary categories from topdocumentaryfilms.com
            # Using /category/ prefix for proper category pages
            categories = [
                ('9/11', 'https://topdocumentaryfilms.com/category/9-11/'),
                ('Art and Artists', 'https://topdocumentaryfilms.com/category/art-and-artists/'),
                ('Biography', 'https://topdocumentaryfilms.com/category/biography/'),
                ('Conspiracy', 'https://topdocumentaryfilms.com/category/conspiracy/'),
                ('Crime', 'https://topdocumentaryfilms.com/category/crime/'),
                ('Cryptocurrency', 'https://topdocumentaryfilms.com/category/cryptocurrency/'),
                ('Drugs', 'https://topdocumentaryfilms.com/category/drugs/'),
                ('Economics', 'https://topdocumentaryfilms.com/category/economics/'),
                ('Environment', 'https://topdocumentaryfilms.com/category/environment/'),
                ('Health', 'https://topdocumentaryfilms.com/category/health/'),
                ('History', 'https://topdocumentaryfilms.com/category/history/'),
                ('Media', 'https://topdocumentaryfilms.com/category/media/'),
                ('Military and War', 'https://topdocumentaryfilms.com/category/military-and-war/'),
                ('Mystery', 'https://topdocumentaryfilms.com/category/mystery/'),
                ('Nature', 'https://topdocumentaryfilms.com/category/nature/'),
                ('Performing Arts', 'https://topdocumentaryfilms.com/category/performing-arts/'),
                ('Philosophy', 'https://topdocumentaryfilms.com/category/philosophy/'),
                ('Politics', 'https://topdocumentaryfilms.com/category/politics/'),
                ('Psychology', 'https://topdocumentaryfilms.com/category/psychology/'),
                ('Religion', 'https://topdocumentaryfilms.com/category/religion/'),
                ('Science', 'https://topdocumentaryfilms.com/category/science/'),
                ('Sexuality', 'https://topdocumentaryfilms.com/category/sexuality/'),
                ('Society', 'https://topdocumentaryfilms.com/category/society/'),
                ('Sports', 'https://topdocumentaryfilms.com/category/sports/'),
                ('Technology', 'https://topdocumentaryfilms.com/category/technology/')
            ]

            for title, href in categories:
                docu_action = f'docuHeaven&docuCat={href}'
                self.list.append({
                    'name': title,
                    'url': href,
                    'image': control.addonIcon(),
                    'action': docu_action
                })
                c.log(f"[CM Debug @ 315 in docu.py] Added category: {title}")

            c.log(f"[CM Debug @ 317 in docu.py] Total categories: {len(self.list)}")

        except Exception as e:
            import traceback
            failure = traceback.format_exc()
            c.log(f'[CM Debug @ 322 in docu.py]Traceback:: {failure}')
            c.log(f'[CM Debug @ 323 in docu.py]Exception raised. Error = {e}')

        self.addDirectory(self.list)
        return self.list

    def docu_list(self, url):
        try:
            soup = self.get_html(url)
            if soup is None:
                c.log(f'[CM Debug @ 155 in docu.py] Failed to retrieve documentary list - get_html returned None')
                self.addDirectory(self.list)
                return self.list

            # Log some HTML structure to debug
            c.log(f"[CM Debug @ 160 in docu.py] Page title: {soup.title.string if soup.title else 'No title'}")

            # For category pages, look for the main content area first
            main_content = soup.find('main') or soup.find('div', attrs={'id': 'content'}) or soup

            # Simplified approach: Find ALL links in main content, then filter
            c.log(f"[CM Debug @ 165 in docu.py] Extracting all links from main content")
            all_links = main_content.find_all('a', href=True)
            c.log(f"[CM Debug @ 166 in docu.py] Total <a> tags found: {len(all_links)}")

            # Filter to only documentary links
            exclude_patterns = ['#', 'javascript:', 'mailto:', '/list/', '/all/', '/top-100/',
                               '/about', '/contact', '/privacy', '/terms', '/feed', '/rss',
                               '/tag/', '/author/', '/search',
                               'facebook.com', 'twitter.com', 'youtube.com', 'instagram.com',
                               '/wp-', '/cdn-cgi/', '.css', '.js', '.jpg', '.png', '.gif']

            seen_urls = set()
            all_documentary_links = []

            for link in all_links:
                href = link.get('href', '')
                text = link.get_text(strip=True)

                # Must contain domain (or be relative path)
                if 'topdocumentaryfilms.com' not in href and not href.startswith('/'):
                    continue

                # Make URL absolute for comparison
                if href.startswith('/'):
                    full_href = 'https://topdocumentaryfilms.com' + href
                else:
                    full_href = href

                # Skip if URL matches exclude patterns
                if any(x in full_href.lower() for x in exclude_patterns):
                    continue

                # Skip /category/ in URL UNLESS we're already on a category page
                # (category pages contain links to documentaries, not more categories)
                is_on_category_page = '/category/' in url.lower()
                if '/category/' in full_href.lower() and not is_on_category_page:
                    continue

                # Skip /page/ pagination links (we handle those separately)
                if '/page/' in full_href.lower() and text.lower() not in ['next', '»', '›']:
                    continue

                # Skip if text matches exclude patterns
                if any(x in text.lower() for x in ['comment', 'reply', 'read more', 'continue reading', 'leave a comment']):
                    continue

                # Must not be the current page
                if full_href.rstrip('/') == url.rstrip('/'):
                    continue

                # Must have a path after domain (not just homepage)
                path_part = full_href.split('topdocumentaryfilms.com')[-1]
                if not path_part or path_part == '/' or len(path_part) < 3:
                    continue

                # Skip if already seen
                if full_href in seen_urls:
                    continue

                seen_urls.add(full_href)
                all_documentary_links.append(link)

            c.log(f"[CM Debug @ 192 in docu.py] Total documentary links found: {len(all_documentary_links)}")

            # Now process all the documentary links
            for link in all_documentary_links[:50]:  # Limit to first 50 documentaries
                try:
                    docu_url = link.get('href')
                    if not docu_url:
                        continue

                    # Make URL absolute if needed
                    if docu_url.startswith('/'):
                        docu_url = 'https://topdocumentaryfilms.com' + docu_url

                    docu_title = link.get('title') or link.text.strip()
                    if not docu_title or len(docu_title) < 2:
                        continue

                    # Skip navigation and category links by URL
                    skip_keywords = ['browse', 'list', 'top-100', 'verify', 'patron', '/category/', '/tag/', '/page/']
                    if any(keyword in docu_url.lower() for keyword in skip_keywords):
                        continue

                    # Skip non-documentary items by title
                    skip_titles = ['browse', 'list', 'top 100', 'verify', 'patron', 'about', 'contact',
                                  'search', 'read more', 'continue reading', 'leave a comment',
                                  'view all posts', 'posted in']
                    # Skip if title contains "comment" or "comments" as a standalone word
                    title_lower = docu_title.lower()
                    if (title_lower in skip_titles or
                        ' comment' in title_lower or
                        'comment' == title_lower or
                        title_lower.endswith(' comments') or
                        title_lower.startswith('comments')):
                        continue

                    # Skip gambling spam articles (these don't have real videos)
                    gambling_spam = ['casino', 'gambling', 'gamstop', 'payid', 'poker', 'bet',
                                    'slots', 'roulette', 'blackjack', 'rng-in', 'house-edge',
                                    'sportsbook', 'offshore', 'betting']
                    if any(spam in docu_url.lower() or spam in docu_title.lower() for spam in gambling_spam):
                        continue

                    # Skip if it's a category name (matches known categories)
                    category_names = ['9/11', 'art and artists', 'biography', 'conspiracy', 'crime',
                                     'cryptocurrency', 'drugs', 'economics', 'environment', 'gambling',
                                     'health', 'history', 'media', 'military and war', 'mystery',
                                     'nature', 'performing arts', 'philosophy', 'politics',
                                     'psychology', 'religion', 'science', 'sexuality', 'society',
                                     'sports', 'technology']
                    if docu_title.lower() in category_names:
                        continue

                    # Find image from the link or its parent
                    docu_img = link.find('img')
                    if not docu_img and link.parent:
                        docu_img = link.parent.find('img')
                    docu_icon = docu_img.get('src') if docu_img else control.addonIcon()

                    # Make image URL absolute if needed
                    if docu_icon and docu_icon.startswith('/'):
                        docu_icon = 'https://topdocumentaryfilms.com' + docu_icon

                    if docu_url and docu_title:
                        docu_action = f'docuHeaven&docuPlay={docu_url}'
                        self.list.append({'name': docu_title, 'url': docu_url, 'image': docu_icon, 'action': docu_action})
                        c.log(f"[CM Debug @ 192 in docu.py] Added: {docu_title}")
                except Exception as e:
                    c.log(f'[CM Debug @ 194 in docu.py] Error parsing item: {e}')
                    continue

            # Try to find pagination/next page
            try:
                # Look for pagination - could be in nav.navigation or div.pagination
                pagination = soup.find('nav', attrs={'class': 'navigation'})
                if not pagination:
                    pagination = soup.find('div', attrs={'class': 'pagination'})
                if not pagination:
                    # Try to find any link with 'page/2' or 'page/3' etc
                    next_links = soup.find_all('a', href=True)
                    for link in next_links:
                        href = link.get('href', '')
                        link_text = link.get_text(strip=True).lower()
                        # Look for "next" or page numbers
                        if '/page/' in href and ('next' in link_text or '»' in link_text or '>' in link_text or link_text.isdigit()):
                            pagination = link
                            break

                if pagination:
                    # If we found a specific link, use it
                    if pagination.name == 'a':
                        next_url = pagination.get('href')
                    else:
                        # Find the next/last link in the pagination container
                        links = pagination.find_all("a", href=True)
                        next_url = None
                        # Look for "next" link or highest page number
                        for link in links:
                            href = link.get('href', '')
                            link_text = link.get_text(strip=True).lower()
                            if '/page/' in href and ('next' in link_text or '»' in link_text):
                                next_url = href
                                break
                        # If no "next" found, use last link
                        if not next_url and links:
                            next_url = links[-1].get('href')

                    if next_url:
                        # Make URL absolute if needed
                        if next_url.startswith('/'):
                            next_url = 'https://topdocumentaryfilms.com' + next_url

                        docu_action = f'docuHeaven&docuCat={next_url}'
                        self.list.append({
                            'name': control.lang(32053),  # "Next Page"
                            'url': next_url,
                            'image': control.addonNext(),
                            'action': docu_action
                        })
                        c.log(f"[CM Debug @ 350 in docu.py] Added pagination: {next_url}")
            except Exception as e:
                c.log(f'[CM Debug @ 352 in docu.py] Pagination error: {e}')

        except Exception as e:
            import traceback
            failure = traceback.format_exc()
            c.log(f'[CM Debug @ 217 in docu.py]Traceback:: {failure}')
            c.log(f'[CM Debug @ 218 in docu.py]Exception raised. Error = {e}')
        self.addDirectory(self.list)
        return self.list

    def docu_play(self, url):
        """
        Retrieves the documentary video from the given URL and plays it.

        Args:
            url (str): The URL of the documentary video.

        Raises:
            Exception: If there is an error during the process.

        Returns:
            None
        """
        try:
            docu_page = client.request(url)

            # Try to extract video URL from meta tags - try multiple variations
            docu_item = None

            # Try embedUrl first
            try:
                docu_item = client.parseDom(docu_page, 'meta', attrs={'itemprop':'embedUrl'}, ret='content')[0]
                c.log(f'[CM Debug @ docu_play] Found embedUrl: {docu_item}')
            except:
                pass

            # Try contentUrl (case sensitive variations)
            if not docu_item:
                try:
                    docu_item = client.parseDom(docu_page, 'meta', attrs={'itemprop':'contentUrl'}, ret='content')[0]
                    c.log(f'[CM Debug @ docu_play] Found contentUrl: {docu_item}')
                except:
                    pass

            # Try contenturl (lowercase)
            if not docu_item:
                try:
                    docu_item = client.parseDom(docu_page, 'meta', attrs={'itemprop':'contenturl'}, ret='content')[0]
                    c.log(f'[CM Debug @ docu_play] Found contenturl: {docu_item}')
                except:
                    pass

            # If still not found, show error
            if not docu_item:
                c.log(f'[CM Debug @ docu_play] Failed to find any video meta tag (embedUrl, contentUrl, contenturl)')
                control.infoDialog("This page doesn't have a playable video", sound=False, icon='ERROR')
                return

            if 'http:' not in docu_item and  'https:' not in docu_item:
                docu_item = f'https:{docu_item}'
            url = docu_item

            # Try to extract title
            try:
                docu_title = client.parseDom(docu_page, 'meta', attrs={'property':'og:title'}, ret='content')[0].replace("&amp;","&").replace('&#39;',"'").replace('&quot;','"').replace('&#39;',"'").replace('&#8211;',' - ').replace('&#8217;',"'").replace('&#8216;',"'").replace('&#038;','&').replace('&acirc;','')
            except:
                docu_title = "Documentary"
            #c.log('[CLASSY @ 106] ' + str(docu_title))
            if 'youtube' in url:
                if 'videoseries' not in url:
                    # Extract video ID from various YouTube URL formats
                    # Handle: /embed/VIDEO_ID?params, /v/VIDEO_ID, /watch?v=VIDEO_ID
                    if '/embed/' in url or '/v/' in url:
                        # Format: https://www.youtube.com/embed/VIDEO_ID?params
                        video_id = url.split("/")[-1].split("?")[0]
                    elif 'v=' in url:
                        # Format: https://www.youtube.com/watch?v=VIDEO_ID&params
                        video_id = url.split('v=')[1].split('&')[0]
                    else:
                        # Fallback: assume last path segment
                        video_id = url.split("/")[-1].split("?")[0]

                    c.log(f'[CLASSY @ 418] video_id = {video_id}')
                    url = f'plugin://plugin.video.youtube/play/?video_id={video_id}'
                    c.log('[CLASSY @ 112] ' + str(url))
                else: pass
            elif 'dailymotion' in url:
                video_id = client.parseDom(docu_page, 'div', attrs={'class':'youtube-player'}, ret='data-id')[0]
                url = self.getDailyMotionStream(video_id)
            else:
                c.log(f'Play Documentary: Unknown Host: {url}', trace=1)
                c.infoDialog(message=f'Unknown Host - Report To Developer: {url}', heading='Unknown Host', icon='ERROR', time=3000, sound=False)

            c.log(f'[CM DEBUG @ 170] PlayMedia({url})')




            listitem = xbmcgui.ListItem(label=docu_title, offscreen=True)
            listitem.setProperty('IsPlayable', 'true')
            listitem.setInfo('video', {'Title': docu_title, 'Genre': 'docu', 'Plot': 'Plot created by Classy ;-)'})


            #play_item = ListItem(path=url)
            #setResolvedUrl(self.addon.handle, True, listitem=play_item)


            #xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)
            #xbmc.Player().play(url, listitem)
            #xbmc.Player().play(playlist, listitem, windowed, startpos)

#            name = docu_title
#            icon = control.infoLabel('ListItem.Icon')
#
#            item = control.item(label=name, path=url)
#            item.setArt({'icon': icon, 'thumb': icon, 'poster': icon})
#            item.setInfo(type="video", infoLabels={"title": name})
#
#            item.setProperty('IsPlayable','true')
#            #control.resolve(handle=int(sys.argv[1]), succeeded=True, listitem=item)
            #xbmc.Player().play(url, listitem)
            #xbmc.Player().play(playlist, listitem, windowed, startpos)

            #print url
            # YouTube plugin URLs don't need resolveurl, use directly
            if url.startswith('plugin://'):
                resolved = url
            else:
                hmf = resolveurl.HostedMediaFile(url)
                if hmf:
                    resolved = hmf.resolve()
                else:
                    resolved = url  # Fallback to original URL

            c.log(f'[CM DEBUG in docu.py @ 202] resolved = {resolved}')

            # Use setResolvedUrl for all URLs (including plugin URLs)
            # This is the standard method and matches how trailers work
            item = xbmcgui.ListItem(path=resolved)
            item.setProperty('IsPlayable', 'true')
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

        except Exception as e:
            import traceback
            failure = traceback.format_exc()
            c.log(f'[CM @ 210 in episodes]Traceback:: {str(failure)}')
            c.log(f'[CM @ 211 in episodes]Exception raised in docu_play. Error = {str(e)}')
            #c.log('tmdb-list1 Exception', 1)
            #c.log('docu_play() Exception: ' + str(e))




    # Code originally written by gujal, as part of the DailyMotion Addon in the official Kodi Repo. Modified to fit the needs here.
    def getDailyMotionStream(self, video_id):
        """
        Retrieves a playable URL for a given video id from DailyMotion.

        Args:
            video_id (str): The video id to retrieve the URL for.

        Returns:
            str: A playable URL for the given video id.

        Raises:
            Exception: If there is an error during the process.

        Notes:
            The function will return the first playable URL found in the metadata response.
            If no playable URL is found, the function will return None.
        """
        headers = {'User-Agent':'Android'}
        cookie = {'Cookie':"lang=en_US; ff=off"}
        r = requests.get(f"http://www.dailymotion.com/player/metadata/video/{video_id}", headers=headers, cookies=cookie, timeout=10)
        content = r.json()
        if content.get('error') is not None:
            error = (content['error']['title'])
            xbmc.executebuiltin(f'XBMC.Notification(Info:,{error} ,5000)')
            return
        else:
            cc = content['qualities']
            cc = cc.items()
            cc = sorted(cc,key=self.sort_key,reverse=True)
            m_url = ''
            other_playable_url = []
            for source,json_source in cc:
                source = source.split("@")[0]
                for item in json_source:
                    if m_url := item.get('url', None):
                        if source == "auto" :
                            continue
                        elif  int(source) <= 2 :
                            if 'video' in item.get('type', None):
                                return m_url
                        elif '.mnft' in m_url:
                            continue
                        other_playable_url.append(m_url)
            if other_playable_url: # probably not needed, only for last resort
                for m_url in other_playable_url:
                    if '.m3u8?auth' in m_url:
                        rr = requests.get(m_url, cookies=r.cookies.get_dict() ,headers=headers, timeout=10)
                        if rr.headers.get('set-cookie'):
                            c.log('[CM DEBUG] adding cookie to url')
                            return (
                                re.findall(r'(http.+)', rr.text)[0].split('#cell')[
                                    0
                                ]
                                + '|Cookie='
                                + rr.headers['set-cookie']
                            )
                        else:
                            return re.findall(r'(http.+)', rr.text)[0].split('#cell')[0]

    def addDirectoryItem(self, name, query, thumb, icon, context=None, queue=False, is_action=True, is_folder=True) -> None:
        try:
            name = control.lang(name)
        except Exception:
            pass
        sysaddon = sys.argv[0]
        syshandle = int(sys.argv[1])
        queueMenu = control.lang(32065)

        url = f'{sysaddon}?action={query}' if is_action is True else query
        thumb = os.path.join(artPath, thumb) if artPath is not None else icon
        cm = []
        if queue:
            cm.append((queueMenu, f'RunPlugin({sysaddon}?action=playlist_QueueItem)'))
        if context:
            cm.append((control.lang(context[0]), f'RunPlugin({sysaddon}?action={context[1]})'))
        try:
            item = control.item(label=name, offscreen=True)
        except Exception:
            item = control.item(label=name)



        item.setProperty('IsPlayable', 'true')
        infolabels={'title': name, 'plot': "Documentary"}
        info_tag = ListItemInfoTag(item, 'video')
        info_tag.set_info(infolabels)

        item.addContextMenuItems(cm)
        item.setArt({'icon': thumb, 'thumb': thumb, 'fanart': addonFanart})
        control.addItem(handle=syshandle, url=url, listitem=item, isFolder=is_folder)

    def endDirectory(self):
        syshandle = int(sys.argv[1])
        control.content(syshandle, 'addons')
        control.directory(syshandle, cacheToDisc=True)

    def _add_folder_item(self, items, title, url, icon_url, fanart_url,
                            sort_title="", isfolder=True, isplayable=False,
                            date=None, info=None, context_menu_items=None,
                            offscreen=True):

        if fanart_url is None:
            fanart_url = os.path.join(self.addon.media, "fanart_blur.jpg")

        if icon_url is None:
            icon_url = os.path.join(self.addon.media, "icon_trans.png")

        try:
            listitem = control.item(label=title, offscreen=offscreen)
        except Exception:
            listitem = control.item(label=title)
        list_item = ListItemInfoTag(listitem, 'video')
        listitem.setArt({"thumb": icon_url, "fanart": fanart_url})
        listitem.setInfo("video", {"title": title, "sorttitle": sort_title})

        if isplayable:
            listitem.setProperty("IsPlayable", "true")
        else:
            listitem.setProperty("IsPlayable", "false")

        if date is not None:
            listitem.setInfo("video", {"date": date})

        if info is not None:
            listitem.setInfo("video", {"plot": info})

        if context_menu_items is not None:
            listitem.addContextMenuItems(context_menu_items)

        items.append((url, listitem, isfolder))








    def addDirectory(self, items, queue=False, isFolder=True):
        if items is None or len(items) == 0:
            control.idle()
            c.infoDialog( 'No Documentaries Found', heading=f'{control.lang(32002)}', sound=True, )
                #sys.exit()
        sysaddon = sys.argv[0]
        syshandle = int(sys.argv[1])
        addonThumb = control.addonThumb()
        artPath = control.artPath()
        queueMenu = control.lang(32065)
        playRandom = control.lang(32535)
        addToLibrary = control.lang(32551)
        for i in items:
            try:
                name = i['name']
                if i['image'].startswith('http'):
                    thumb = i['image']
                elif artPath:
                    thumb = os.path.join(artPath, i['image'])
                else:
                    thumb = addonThumb
                try:
                    item = control.item(label=name, offscreen=True)
                except Exception:
                    item = control.item(label=name)

                url = f'{sysaddon}?action={i["action"]}'
                if 'url' in i:
                    url += f'&url={quote_plus(str(i["url"]))}'

                # Check if this is a playable item (docuPlay) or a folder (docuCat)
                is_playable = 'docuPlay' in i.get('action', '')
                item_is_folder = isFolder and not is_playable

                if item_is_folder:
                    item.setProperty('IsPlayable', 'false')
                else:
                    item.setProperty('IsPlayable', 'true')

                item.setArt({'icon': thumb, 'thumb': thumb, 'fanart': control.addonFanart()})
                control.addItem(handle=syshandle, url=url, listitem=item, isFolder=item_is_folder)
            except Exception as e:
                import traceback
                failure = traceback.format_exc()
                c.log(f'[CM Debug @ 430 in docu.py]Traceback:: {failure}')
                c.log(f'[CM Debug @ 430 in docu.py]Exception raised. Error = {e}')
                pass
            # except Exception as e:
            #     c.log(f'[CM DEBUG in docu.py @ 349] Exception in addDirectory: {e}')
            #     pass
        control.content(syshandle, 'addons')
        control.directory(syshandle, cacheToDisc=True)