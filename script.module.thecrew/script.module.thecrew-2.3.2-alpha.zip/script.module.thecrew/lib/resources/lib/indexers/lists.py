# -*- coding: utf-8 -*-

'''
 ********************************************************cm*
 * The Crew Add-on
 *
 * @package script.module.thecrew
 *
 * @copyright (c) 2023, The Crew
 * @license GNU General Public License, version 3 (GPL-3.0)
 *
 ********************************************************cm*
'''

import os
import re
import sys
import hashlib
import json
import base64
import random
import datetime
import sqlite3 as database
from urllib.parse import urlparse, parse_qs, quote_plus, unquote_plus, parse_qsl

import xbmc
import xbmcaddon
import xbmcvfs

from ..modules import cache
from ..modules import metacache
from ..modules import client
from ..modules import control
from ..modules import regex
from ..modules import trailer
from ..modules import workers
from ..modules import youtube
from ..modules import views
from ..modules import sources
from ..modules.crewruntime import c


# Consolidated list of URLs (single central dict for maintainability)
ROOT_URLS = {
    'porn': 'special://home/addons/script.module.thecrew/xml/xxx.xml',
    'base': 'https://pastebin.com/raw/K3YSAUsD',
    'waste': 'http://dystopiabuilds.xyz/waste/main.xml',
    'titan': 'http://magnetic.website/Mad%20Titan/main.xml',
    'greyhat': 'https://raw.githubusercontent.com/posadka/xmls2/main/kids/greyhat_main.xml',
    'debridkids': 'https://raw.githubusercontent.com/posadka/xmls2/main/kids/debridkids.xml',
    'waltdisney': 'https://raw.githubusercontent.com/posadka/xmls2/main/kids/disney_years/main.xml',
    'learning': 'https://raw.githubusercontent.com/posadka/xmls2/main/kids/learning.xml',
    'songs': 'https://raw.githubusercontent.com/posadka/xmls2/main/kids/songs.xml',
    'yellowhat': 'https://pastebin.com/raw/d5cb3Wxw',
    'redhat': 'https://raw.githubusercontent.com/posadka/xmls2/main/standup/main.xml',
    'blackhat': 'https://raw.githubusercontent.com/posadka/xmls2/main/fitness/main.xml',
    'food': 'https://raw.githubusercontent.com/posadka/xmls2/main/food/food_main.xml',
    'greenhat': 'http://thechains24.com/GREENHAT/green.xml',
    'whitehat': 'https://pastebin.com/raw/tMSGGbxc',
    'absolution': 'https://raw.githubusercontent.com/posadka/xmls2/main/absolution/absolution_main.xml',
    'ncaa': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/ncaa/ncaa.xml',
    'ncaab': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/ncaa/ncaab.xml',
    'lfl': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/lfl/lfl.xml',
    'mlb': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/mlb/mlb.xml',
    'nfl': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/nfl/nfl.xml',
    'nhl': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/nhl/nhl.xml',
    'nba': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/nba/nba.xml',
    'ufc': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/ufc_mma/ufc.xml',
    'motogp': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/motor/motogp.xml',
    'boxing': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/boxing/boxing.xml',
    'fifa': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/fifa/fifa.xml',
    'wwe': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/wwe/wwe.xml',
    'sports_channels': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/channels/channels.xml',
    'sreplays': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/replays/replays.xml',
    'misc_sports': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/misc/misc_sports.xml',
    'tennis': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/tennis/tennis.xml',
    'f1': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/motor/f1.xml',
    'pga': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/pga/pga.xml',
    'kiddo': 'http://cellardoortv.com/kiddo/master/main.xml',
    'purplehat': 'https://raw.githubusercontent.com/classymouse/cc/main/CCcinema.xml',
    # 'personal' handled via settings
    'git': 'https://raw.githubusercontent.com/posadka/xmls2/main/iptv/main.xml',
    'nascar': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/nascar/nascar.xml',
    'xfl': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/xfl/xfl.xml',
    'tubi': 'https://raw.githubusercontent.com/posadka/xmls2/main/iptv/tubitv.xml',
    'pluto': 'https://raw.githubusercontent.com/posadka/xmls2/main/iptv/pluto.xml',
    'bumble': 'https://raw.githubusercontent.com/posadka/xmls2/main/iptv/bumblebee.xml',
    'xumo': 'https://raw.githubusercontent.com/posadka/xmls2/main/iptv/xumo.xml',
    'distro': 'https://raw.githubusercontent.com/posadka/xmls2/main/iptv/distro.xml',
    'cricket': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/cricket/cricket.xml'
}

# helper functions for Python3-only environments
def ensure_text(txt, encoding='utf-8', errors='replace'):
    if isinstance(txt, str):
        return txt
    if txt is None:
        return ''
    try:
        return txt.decode(encoding, errors=errors)
    except Exception:
        return str(txt)

def ensure_bytes(txt, encoding='utf-8', errors='replace'):
    if isinstance(txt, bytes):
        return txt
    return b'' if txt is None else str(txt).encode(encoding, errors=errors)


class Indexer:
    def __init__(self):
        self.list = []
        self.hash = []
        self.imdb_info_link = 'http://www.omdbapi.com/?i=%s&plot=full&r=json'
        self.tvmaze_info_link = 'http://api.tvmaze.com/lookup/shows?thetvdb=%s'
        self.lang = 'en'
        self.meta = []

    def _get_local_xml_content(self, url):
        """
        Check if a local XML file exists for the given URL.
        If found, return the file content. Otherwise return None.

        Local XML files should be placed in: <addon_path>/xml/
        The filename is extracted from the URL (e.g., xxx.xml from the GitHub URL).
        """
        if not url or not isinstance(url, str):
            return None

        try:
            # Extract filename from URL
            # Examples:
            # https://raw.githubusercontent.com/posadka/pinkhat/main/pinkhat/xxx.xml -> xxx.xml
            # http://cellardoortv.com/kiddo/master/main.xml -> main.xml
            filename = url.split('/')[-1]

            # Only check for .xml files
            if not filename.endswith('.xml'):
                return None

            # Build local path: <addon_path>/xml/<filename>
            # Note: The code runs from plugin.video.thecrew context, but XML files
            # are stored in script.module.thecrew, so we need to explicitly get that path

            module_addon = xbmcaddon.Addon('script.module.thecrew')
            addon_path = xbmcvfs.translatePath(module_addon.getAddonInfo('path'))
            local_path = os.path.join(addon_path, 'xml', filename)
            c.log(f"[Local XML] Checking for local file at: {local_path}")

            #Check if local file exists
            if os.path.exists(local_path):
                c.log(f"[Local XML] Found local override for {filename} at {local_path}")
                with open(local_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                c.log(f"[Local XML] Loaded {len(content)} bytes from local file")
                # Log first 200 chars to verify content
                c.log(f"[Local XML] Content starts with: {content[:200]}")
                return content
            else:
                c.log(f"[Local XML] No local file found for {filename}, will fetch from remote")
                return None

        except Exception as e:
            c.log(f"[Local XML] Error checking for local file: {e}")
            return None

    # simplified root methods that use the central dict
    def root_porn(self):
        """Adult Section - uses new class-based architecture"""
        from .adult import Adult
        return Adult().root()
    def root_base(self):
        return self.create_list(ROOT_URLS.get('base'))
    def root_waste(self):
        return self.create_list(ROOT_URLS.get('waste'))
    def root_titan(self):
        return self.create_list(ROOT_URLS.get('titan'))
    def root_greyhat(self):
        return self.create_list(ROOT_URLS.get('greyhat'))
    def root_debridkids(self):
        return self.create_list(ROOT_URLS.get('debridkids'))
    def root_waltdisney(self):
        return self.create_list(ROOT_URLS.get('waltdisney'))
    def root_learning(self):
        return self.create_list(ROOT_URLS.get('learning'))
    def root_songs(self):
        return self.create_list(ROOT_URLS.get('songs'))
    def root_yellowhat(self):
        return self.create_list(ROOT_URLS.get('yellowhat'))
    def root_redhat(self):
        return self.create_list(ROOT_URLS.get('redhat'))
    def root_blackhat(self):
        return self.create_list(ROOT_URLS.get('blackhat'))
    def root_food(self):
        return self.create_list(ROOT_URLS.get('food'))
    def root_greenhat(self):
        return self.create_list(ROOT_URLS.get('greenhat'))
    def root_whitehat(self):
        return self.create_list(ROOT_URLS.get('whitehat'))
    def root_absolution(self):
        return self.create_list(ROOT_URLS.get('absolution'))
    def root_ncaa(self):
        return self.create_list(ROOT_URLS.get('ncaa'))
    def root_ncaab(self):
        return self.create_list(ROOT_URLS.get('ncaab'))
    def root_lfl(self):
        return self.create_list(ROOT_URLS.get('lfl'))
    def root_mlb(self):
        return self.create_list(ROOT_URLS.get('mlb'))
    def root_nfl(self):
        return self.create_list(ROOT_URLS.get('nfl'))
    def root_nhl(self):
        return self.create_list(ROOT_URLS.get('nhl'))
    def root_nba(self):
        return self.create_list(ROOT_URLS.get('nba'))
    def root_ufc(self):
        return self.create_list(ROOT_URLS.get('ufc'))
    def root_motogp(self):
        return self.create_list(ROOT_URLS.get('motogp'))
    def root_boxing(self):
        return self.create_list(ROOT_URLS.get('boxing'))
    def root_fifa(self):
        return self.create_list(ROOT_URLS.get('fifa'))
    def root_wwe(self):
        return self.create_list(ROOT_URLS.get('wwe'))
    def root_sports_channels(self):
        return self.create_list(ROOT_URLS.get('sports_channels'))
    def root_sreplays(self):
        return self.create_list(ROOT_URLS.get('sreplays'))
    def root_misc_sports(self):
        return self.create_list(ROOT_URLS.get('misc_sports'))
    def root_tennis(self):
        return self.create_list(ROOT_URLS.get('tennis'))
    def root_f1(self):
        return self.create_list(ROOT_URLS.get('f1'))
    def root_pga(self):
        return self.create_list(ROOT_URLS.get('pga'))
    def root_kiddo(self):
        return self.create_list(ROOT_URLS.get('kiddo'))
    def root_purplehat(self):
        return self.create_list(ROOT_URLS.get('purplehat'))
    def root_classy(self):
        return self.create_list(ROOT_URLS.get('classy'))
    def root_personal(self):
        return self.create_personal('personal.list')
    def root_git(self):
        return self.create_list(ROOT_URLS.get('git'))
    def root_nascar(self):
        return self.create_list(ROOT_URLS.get('nascar'))
    def root_xfl(self):
        return self.create_list(ROOT_URLS.get('xfl'))
    def root_tubi(self):
        return self.create_list(ROOT_URLS.get('tubi'))
    def root_pluto(self):
        return self.create_list(ROOT_URLS.get('pluto'))
    def root_bumble(self):
        return self.create_list(ROOT_URLS.get('bumble'))
    def root_xumo(self):
        return self.create_list(ROOT_URLS.get('xumo'))
    def root_distro(self):
        return self.create_list(ROOT_URLS.get('distro'))
    def root_cricket(self):
        return self.create_list(ROOT_URLS.get('cricket'))

#OH added 1-5-2021
    def create_list(self, url):
        try:
            c.log(f"[CM Debug @ 223 in lists.py]url = {url}")
            regex.clear()
            c.log(f"[CM Debug @ 225 in lists.py]url = {url}")

            self.list = self.the_crew_list(url)
            c.log(f"[CM Debug @ 228 in lists.py]self.list = {self.list}")
            for i in self.list:
                i.update({'content': 'addons'})
            self.addDirectory(self.list)
            return self.list
        except Exception:
            pass

#WhiteHat added 6-20-2022
    def create_personal(self, url):
        try:
            regex.clear()
            url = control.setting('personal.list')
            self.list = self.the_crew_list(url)
            for i in self.list:
                i.update({'content': 'addons'})
            self.addDirectory(self.list)
            return self.list
        except Exception:
            pass

#OH - checked
    def get(self, url):
        try:
            self.list = self.the_crew_list(url)
            self.worker()
            self.addDirectory(self.list)
            return self.list
        except Exception:
            pass

#TODO: check if this is working
    def getq(self, url):
        try:
            self.list = self.the_crew_list(url)
            self.worker()
            self.addDirectory(self.list, queue=True)
            return self.list
        except Exception:
            pass

#TODO: check if this is working
    def getx(self, url, worker=False):
        try:
            c.log(f"[CM Debug @ 401 in lists.py] url = {url}")
            r, x = re.findall(r'(.+?)\|regex=(.+?)$', url)[0]
            x = regex.fetch(x)
            r += unquote_plus(x)
            c.log(f"[CM Debug @ 405 in lists.py] r = {repr(r)} and x = {repr(x)}")
            url = regex.resolve(r)
            c.log(f"[CM Debug @ 407 in lists.py] resolved url = {repr(url)}")

            self.list = self.the_crew_list('', result=url)
            self.addDirectory(self.list)
            return self.list
        except Exception as e:
            import traceback
            failure = traceback.format_exc()
            c.log(f'[CM Debug @ 397 in lists.py]Traceback:: {failure}')
            c.log(f'[CM Debug @ 397 in lists.py]Exception raised. Error = {e}')
            pass

    def get_x_url(self, url):
        try:
            # Get the current listitem title in case we need to extract URL from it
            listitem_title = control.infoLabel('listitem.label')
            c.log(f"[CM Debug @ 425 in lists.py] listitem_title = {listitem_title}")

            r, x = re.findall(r'(.+?)\|regex=(.+?)$', url)[0]
            x = regex.fetch(x)
            r = unquote_plus(x)
            c.log(f"[CM Debug @ 425 in lists.py] r length = {len(r)}, x = {x}")

            # Extract the regex name from the fetched XML and prepend $doregex[name]
            # This is needed so pyFunctions will be executed by getRegexParsed()
            try:
                regex_name = re.findall(r'<name>([^<]+)</name>', r)[0]
                url_with_doregex = f'$doregex[{regex_name}]' + r
                c.log(f"[CM Debug @ 426 in lists.py] Prepended doregex trigger for {regex_name}")
            except Exception as e:
                c.log(f"[CM Debug @ 426 in lists.py] Failed to extract regex name: {e}, using raw regex")
                url_with_doregex = r

            url = regex.resolve(url_with_doregex)

            # Safe logging - handle binary data or large strings
            if isinstance(url, bytes):
                c.log(f"[CM Debug @ 427 in lists.py] Resolved url is binary data, length = {len(url)} bytes")
                c.log(f"[CM Debug @ 427 in lists.py] ERROR: adultresolver returned binary data instead of URL - this is incorrect")
                url = None  # Set to None to trigger fallback
            elif isinstance(url, str):
                preview_len = min(len(url), 200)
                c.log(f"[CM Debug @ 427 in lists.py] Resolved url (length={len(url)}): {url[:preview_len]}")
            else:
                c.log(f"[CM Debug @ 427 in lists.py] Resolved url type {type(url).__name__}: {repr(url)[:200]}")
                url = None  # Set to None to trigger fallback

            # Handle broken list entries where pyFunction returns 'async', None, or the real URL is in the title
            if not url or (isinstance(url, str) and url.strip().lower() in ['async', '']):
                c.log(f"[CM Debug @ 427 in lists.py] Detected invalid url '{url}', checking if title contains URL")
                c.log(f"[CM Debug @ 427 in lists.py] Detected invalid url '{url}', checking if title contains URL")
                if listitem_title and isinstance(listitem_title, str) and (listitem_title.startswith('http://') or listitem_title.startswith('https://')):
                    # Strip anchor fragments and use the URL from the title
                    url = listitem_title.split('#')[0].split('?')[0] if '#' in listitem_title or '?' in listitem_title else listitem_title
                    c.log(f"[CM Debug @ 427 in lists.py] Extracted URL from title: {url}")

            c.log(f"[CM Debug @ 428 in lists.py] get_x_url() returning: {url[:200] if isinstance(url, str) and len(url) > 200 else url}")
            self.list = self.the_crew_list('', result=url)
            return url

        except Exception as e:
            import traceback
            failure = traceback.format_exc()
            c.log(f'[CM Debug @ 432 in lists.py]Traceback:: {failure}')
            c.log(f'[CM Debug @ 433 in lists.py]Exception raised. Error = {e}')
            pass

#OH - checked
    def developer(self):
        try:
            url = os.path.join(control.dataPath, 'testings.xml')
            f = control.openFile(url)
            result = f.read()
            f.close()

            self.list = self.the_crew_list('', result=result)
            for i in self.list:
                i.update({'content': 'videos'})
            self.addDirectory(self.list)
            return self.list
        except Exception:
            pass



    #TODO getting key from trailers is just plain wrong. Needs a key from yt or settings
    def youtube(self, url, action):
        try:
            key = trailer.Trailers().key_link.split('=', 1)[-1]
            if 'PlaylistTuner' in action:
                self.list = cache.get(youtube.youtube(key=key).playlist, 1, url)
            elif 'Playlist' in action:
                self.list = cache.get(youtube.youtube(key=key).playlist, 1, url, True)
            elif 'ChannelTuner' in action:
                self.list = cache.get(youtube.youtube(key=key).videos, 1, url)
            elif 'Channel' in action:
                self.list = cache.get(youtube.youtube(key=key).videos, 1, url, True)
            if 'Tuner' in action:
                for i in self.list:
                    i.update({
                        'name': i['title'], 'poster': i['image'],
                        'action': 'plugin', 'folder': False
                        })
                if 'Tuner2' in action:
                    self.list = sorted(self.list, key=lambda x: random.random())
                self.addDirectory(self.list, queue=True)
            else:
                for i in self.list:
                    i.update({
                        'name': i['title'], 'poster': i['image'], 'nextaction': action,
                        'action': 'play', 'folder': False
                        })
                self.addDirectory(self.list)
            return self.list
        except Exception:
            pass


    def the_crew_list(self, url, result=None):
        """
        Parse a remote/local "the_crew" list format into a normalized list of dicts.
        - result: optional pre-fetched payload (string). If None, will fetch via cache.get(client.request, 0, url).
        Returns: list of items (each a dict)
        """
        try:
            # fetch if needed
            if result is None:
                # First check for local XML file override
                result = self._get_local_xml_content(url)

                if result is not None:
                    c.log(f"[Local XML] Using local file content ({len(result)} bytes)")
                else:
                    c.log(f"[Local XML] No local file, will fetch from remote cache")

                # If no local file, fetch from remote
                if result is None:
                    result = cache.get(client.request, 0, url)

            if result is None:
                result = ''

            if result.strip().startswith('#EXTM3U') and '#EXTINF' in result:
                try:
                    result = re.compile(r'#EXTINF:.+?,(.+?)\n(.+?)\n', re.MULTILINE|re.DOTALL).findall(result)
                    result = [
                        f'<item><title>{i[0]}</title><link>{i[1]}</link></item>' for i in result
                        ]
                    result = ''.join(result)
                except ValueError:
                    pass

            # try base64 decode; if decode fails treat as original result
            r = ''
            try:
                # If result is a string, sanitize it to base64 alphabet to avoid UnicodeEncodeError
                if isinstance(result, str):
                    clean = re.sub(r'[^A-Za-z0-9+/=]', '', result)
                    if not clean:
                        raise ValueError('no base64 characters found')
                    decoded = base64.b64decode(clean)
                else:
                    decoded = base64.b64decode(result)

                if isinstance(decoded, (bytes, bytearray)):
                    r = ensure_text(decoded, errors='replace')
                else:
                    r = str(decoded)
                c.log(f"[CM Debug @ 477 in lists.py] r length = {len(r)} bytes")
            except Exception as e:
                import traceback
                failure = traceback.format_exc()
                c.log(f'[CM Debug @ 479 in lists.py]Traceback:: {failure}')
                c.log(f'[CM Debug @ 479 in lists.py]Exception raised. Error = {e}')

                # Diagnostic logging: fetch extended response (headers + bytes) when base64 fails
                try:
                    if url and str(url).startswith(('http://', 'https://')):
                        c.log(f"[CM Debug @ 481 in lists.py] diagnostic: fetching extended response for url = {url}")
                        try:
                            ext = cache.get(client.request, 0, url, 'extended', None, None, None, None, None, None, None, None, True)
                        except Exception:
                            # older client.request signature compatibility
                            ext = cache.get(client.request, 0, url, output='extended', as_bytes=True)

                        if ext:
                            try:
                                data, headers, content_headers, cookie_str = ext
                            except Exception:
                                # fallback shape
                                try:
                                    data, headers, content_headers = ext
                                    cookie_str = ''
                                except Exception:
                                    data = ext
                                    headers = {}
                                    content_headers = {}
                                    cookie_str = ''

                            try:
                                ct = content_headers.get('Content-Type') if hasattr(content_headers, 'get') else None
                                ce = content_headers.get('Content-Encoding') if hasattr(content_headers, 'get') else None
                                cl = content_headers.get('Content-Length') if hasattr(content_headers, 'get') else None
                            except Exception:
                                ct = ce = cl = None

                            c.log(f"[CM Debug @ 482 in lists.py] diagnostic headers Content-Type={ct} Content-Encoding={ce} Content-Length={cl} cookie={cookie_str}")

                            try:
                                if isinstance(data, (bytes, bytearray)):
                                    preview = data[:200]
                                    hex_preview = preview.hex()
                                    text_preview = ensure_text(preview, errors='replace')
                                else:
                                    text_preview = ensure_text(data)[:200]
                                    hex_preview = text_preview.encode('utf-8', errors='replace').hex()

                                c.log(f"[CM Debug @ 482 in lists.py] diagnostic preview hex={hex_preview}")
                                c.log(f"[CM Debug @ 482 in lists.py] diagnostic preview text={text_preview}")
                            except Exception as diag_e:
                                c.log(f"[CM Debug @ 482 in lists.py] diagnostic preview error: {diag_e}")
                except Exception as diag_ex:
                    c.log(f"[CM Debug @ 482 in lists.py] diagnostic fetch failed: {diag_ex}")

                # Attempt alternate recovery strategies when input isn't base64
                try:
                    # Try stripping non-base64 bytes from a UTF-8-encoded representation
                    alt = (result.encode('utf-8', errors='ignore') if isinstance(result, str) else result)
                    alt = re.sub(rb'[^A-Za-z0-9+/=]', b'', alt)
                    decoded = base64.b64decode(alt)
                    r = ensure_text(decoded, errors='replace')
                    c.log(f"[CM Debug @ 483 in lists.py] alt base64 decoded, r length = {len(r)} bytes")
                except Exception:
                    try:
                        # Treat the original response as raw bytes (latin-1 preserves octets)
                        b = (result.encode('latin-1', errors='ignore') if isinstance(result, str) else bytes(result))

                        # Detect common compressed formats
                        if b.startswith(b'\x1f\x8b'):
                            import gzip
                            r = ensure_text(gzip.decompress(b), errors='replace')
                            c.log(f"[CM Debug @ 488 in lists.py] detected gzip, decompressed r length = {len(r)} bytes")
                        elif b.startswith(b'PK'):
                            # ZIP archive - try to read first file (best-effort)
                            try:
                                import zipfile, io
                                z = zipfile.ZipFile(io.BytesIO(b))
                                names = z.namelist()
                                if names:
                                    r = ensure_text(z.read(names[0]), errors='replace')
                                    c.log(f"[CM Debug @ 495 in lists.py] detected zip, extracted first file r length = {len(r)} bytes")
                                else:
                                    r = ''
                            except Exception:
                                r = ''
                        else:
                            # Try to decode as UTF-8 or latin-1 and hope for XML/text
                            try:
                                r = b.decode('utf-8', errors='replace')
                            except Exception:
                                r = b.decode('latin-1', errors='replace')
                            c.log(f"[CM Debug @ 505 in lists.py] interpreted bytes r length = {len(r)} bytes")

                        # If result still looks empty, fall back to original string
                        if not r:
                            r = result
                    except Exception:
                        r = result

            if '</link>' in r:
                result = r

            info = re.split(r'<item>|<dir>', result)[0]

            try:
                vip = re.findall(r'<poster>(.+?)</poster>', info)[0]
            except Exception:
                vip = '0'

            try:
                image = re.findall(r'<thumbnail>(.+?)</thumbnail>', info)[0]
            except Exception:
                image = '0'

            try:
                fanart = re.findall(r'<fanart>(.+?)</fanart>', info)[0]
            except Exception:
                fanart = '0'

            pattern = re.compile(
                r'((?:<item>.+?</item>|<dir>.+?</dir>|<plugin>.+?</plugin>|<info>.+?</info>|'
                r'<name>[^<]+</name><link>[^<]+</link><thumbnail>[^<]+</thumbnail><mode>[^<]+</mode>|'
                r'<name>[^<]+</name><link>[^<]+</link><thumbnail>[^<]+</thumbnail><date>[^<]+</date>))',
                re.MULTILINE|re.DOTALL
                )
            items = pattern.findall(result)

            # compiled patterns used for safer substitutions
            regex_pattern = re.compile(r'<regex>.+?</regex>', re.DOTALL)
            sublink_pattern = re.compile(r'<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>|<sublink></sublink>', re.DOTALL)
            link_empty_pattern = re.compile(r'<link></link>', re.DOTALL)

            for item in items:
                regdata_list = re.compile(r'(<regex>.+?</regex>)', re.MULTILINE|re.DOTALL).findall(item)
                regdata = ''.join(regdata_list)
                reglist = re.compile(r'(<listrepeat>.+?</listrepeat>)', re.MULTILINE|re.DOTALL).findall(regdata)
                # quote the regdata for storage
                regdata_q = quote_plus(regdata)

                # compute hash once from the full regdata bytes
                reghash = hashlib.md5()
                try:
                    reghash.update(regdata_q.encode('utf-8'))
                    reghash = str(reghash.hexdigest())
                except Exception:
                    reghash = hashlib.md5(regdata_q.encode('utf-8') if regdata_q else b'').hexdigest()

                # sanitize item
                item = item.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')

                # remove regex blocks and bad sublink placeholders
                item = regex_pattern.sub('', item)
                item = sublink_pattern.sub('', item)
                item = link_empty_pattern.sub('', item)

                name_block = re.sub(r'<meta>.+?</meta>', '', item, flags=re.DOTALL)
                try:
                    name = re.findall(r'<title>(.+?)</title>', name_block)[0]
                except Exception:
                    name = re.findall(r'<name>(.+?)</name>', name_block)[0]

                try:
                    date = re.findall(r'<date>(.+?)</date>', item)[0]
                except Exception:
                    date = ''

                if re.search(r'\d+', date):
                    name += f' [COLOR red] Updated {date}[/COLOR]'

                try:
                    image2 = re.findall(r'<thumbnail>(.+?)</thumbnail>', item)[0]
                except Exception:
                    image2 = image

                try:
                    fanart2 = re.findall(r'<fanart>(.+?)</fanart>', item)[0]
                except Exception:
                    fanart2 = fanart

                try:
                    meta = re.findall(r'<meta>(.+?)</meta>', item)[0]
                except Exception:
                    meta = '0'

                try:
                    url = re.findall(r'<link>(.+?)</link>', item)[0]
                except Exception:
                    url = '0'

                url = url.replace('>search<', f'><preset>search</preset>{meta}<')
                url = f'<preset>search</preset>{meta}' if url == 'search' else url
                url = url.replace('>searchsd<', f'><preset>searchsd</preset>{meta}<')
                url = f'<preset>searchsd</preset>{meta}'  if url == 'searchsd' else url
                url = sublink_pattern.sub('', url)

                if item.startswith('<item>'):
                    action = 'play'
                elif item.startswith('<plugin>'):
                    action = 'plugin'
                elif item.startswith('<info>') or url == '0':
                    action = '0'
                else:
                    action = 'directory'

                if action == 'play' and reglist:
                    action = 'xdirectory'

                if regdata != '':
                    self.hash.append({'regex': reghash, 'response': regdata_q})
                    url += f'|regex={reghash}'

                folder = action in ['directory', 'xdirectory', 'plugin']
                try:
                    content = re.findall(r'<content>(.+?)</content>', meta)[0]
                except Exception:
                    content = '0'

                if content == '0':
                    try:
                        content = re.findall(r'<content>(.+?)</content>', item)[0]
                    except Exception:
                        content = '0'

                if content != '0':
                    content += 's'

                if 'tvshow' in content and not url.strip().endswith('.xml'):
                    url = f'<preset>tvindexer</preset><url>{url}</url><thumbnail>{image2}</thumbnail><fanart>{fanart2}</fanart>{meta}'
                    action = 'tvtuner'

                if 'tvtuner' in content and not url.strip().endswith('.xml'):
                    url = f'<preset>tvtuner</preset><url>{url}</url><thumbnail>{image2}</thumbnail><fanart>{fanart2}</fanart>{meta}'
                    action = 'tvtuner'

                try:
                    imdb = re.findall(r'<imdb>(.+?)</imdb>', meta)[0]
                except Exception:
                    imdb = '0'

                try:
                    tvdb = re.findall(r'<tvdb>(.+?)</tvdb>', meta)[0]
                except Exception:
                    tvdb = '0'

                try:
                    tvshowtitle = re.findall(r'<tvshowtitle>(.+?)</tvshowtitle>', meta)[0]
                except Exception:
                    tvshowtitle = '0'

                try:
                    title = re.findall(r'<title>(.+?)</title>', meta)[0]
                except Exception:
                    title = '0'

                if title == '0' and tvshowtitle != '0':
                    title = tvshowtitle

                try:
                    year = re.findall(r'<year>(.+?)</year>', meta)[0]
                except Exception:
                    year = '0'

                try:
                    premiered = re.findall(r'<premiered>(.+?)</premiered>', meta)[0]
                except Exception:
                    premiered = '0'

                try:
                    season = re.findall(r'<season>(.+?)</season>', meta)[0]
                except Exception:
                    season = '0'

                try:
                    episode = re.findall(r'<episode>(.+?)</episode>', meta)[0]
                except Exception:
                    episode = '0'

                self.list.append({
                    'name': name, 'vip': vip, 'url': url, 'action': action, 'folder': folder,
                    'poster': image2, 'banner': '0', 'fanart': fanart2,
                    'content': content, 'imdb': imdb, 'tvdb': tvdb, 'tmdb': '0', 'title': title,
                    'originaltitle': title, 'tvshowtitle': tvshowtitle, 'year': year,
                    'premiered': premiered, 'season': season, 'episode': episode
                    })

            regex.insert(self.hash)
            return self.list

        except Exception as e:
            import traceback
            failure = traceback.format_exc()
            c.log(f'[CM Debug @ 649 in lists.py]Traceback:: {failure}')
            c.log(f'[CM Debug @ 650 in lists.py]Exception raised. Error = {e}')
            pass

# ...existing code...
    def worker(self):
        """
        Fetch and cache metadata for items in self.list using threading.
        Processes movies and TV shows, with special handling for single unique IMDB.
        """
        from concurrent.futures import ThreadPoolExecutor, as_completed  # Import here for clarity

        try:
            total = len(self.list)
            if total == 0:
                return

            # Initial metacache fetch (mark all as not cached)
            for item in self.list:
                item['metacache'] = False
            self.list = metacache.fetch(self.list, self.lang)

            # Deduplicate IMDB IDs and handle single unique IMDB case
            imdb_ids = [item.get('imdb', '0') for item in self.list if item.get('imdb', '0') != '0']
            unique_imdb = list(dict.fromkeys(imdb_ids))  # Preserve order, dedupe
            if len(unique_imdb) == 1:
                # Process all items with this IMDB (not just the first)
                single_imdb = unique_imdb[0]
                for idx, item in enumerate(self.list):
                    if item.get('imdb') == single_imdb:
                        if item.get('content') == 'movies':
                            self.movie_info(idx)
                        elif item.get('content') in ['tvshows', 'seasons', 'episodes']:
                            self.tv_info(idx)
                if self.meta:
                    metacache.insert(self.meta)
                    self.meta = []  # Reset after insert

            # Refetch from metacache after single-IMDB processing
            for item in self.list:
                item['metacache'] = False
            self.list = metacache.fetch(self.list, self.lang)

            # Batch processing with ThreadPoolExecutor (limit to 20 workers per batch)
            batch_size = 50
            max_workers_per_batch = 20
            for r in range(0, total, batch_size):
                batch_end = min(r + batch_size, total)
                batch_items = [(i, self.list[i]) for i in range(r, batch_end)]

                with ThreadPoolExecutor(max_workers=max_workers_per_batch) as executor:
                    # Submit tasks for movie_info and tv_info based on content
                    futures = []
                    for idx, item in batch_items:
                        content = item.get('content', '')
                        if content == 'movies':
                            futures.append(executor.submit(self.movie_info, idx))
                        elif content in ['tvshows', 'seasons', 'episodes']:
                            futures.append(executor.submit(self.tv_info, idx))

                    # Wait for all futures to complete and handle exceptions
                    for future in as_completed(futures):
                        try:
                            future.result()  # Raises exception if task failed
                        except Exception as e:
                            c.log(f"[CM Debug @ worker] Task failed: {e}")

                # Insert meta after each batch
                if self.meta:
                    try:
                        metacache.insert(self.meta)
                        self.meta = []  # Reset
                    except Exception as e:
                        c.log(f"[CM Debug @ worker] Failed to insert meta for batch starting at {r}: {e}")

            # Final meta insert if any remaining
            if self.meta:
                try:
                    metacache.insert(self.meta)
                except Exception as e:
                    c.log(f"[CM Debug @ worker] Failed final meta insert: {e}")

        except Exception as e:
            c.log(f"[CM Debug @ worker] Unexpected error: {e}")
# ...existing code...


    def worker_orig(self):
        try:
            total = len(self.list)

            if total == 0:
                return

            for i in range(total):
                self.list[i].update({'metacache': False})
            self.list = metacache.fetch(self.list, self.lang)

            multi = [i['imdb'] for i in self.list]
            multi = [x for y,x in enumerate(multi) if x not in multi[:y]]
            if len(multi) == 1:
                self.movie_info(0)
                self.tv_info(0)
                if self.meta:
                    metacache.insert(self.meta)

            for i in range(total):
                self.list[i].update({'metacache': False})
            self.list = metacache.fetch(self.list, self.lang)

            for r in range(0, total, 50):
                threads = []
                for i in list(range(r, r+50)):
                    if i <= total:
                        threads.append(workers.Thread(self.movie_info, i))
                    if i <= total:
                        threads.append(workers.Thread(self.tv_info, i))
                for thread in threads:
                    thread.start()
                for thread in threads:
                    thread.join()

                if self.meta:
                    metacache.insert(self.meta)

            if self.meta:
                metacache.insert(self.meta)
        except Exception:
            pass

    def movie_info(self, i):
        try:
            if self.list[i]['metacache'] is True or not self.list[i]['content'] == 'movies':
                #raise Exception()
                return

            #if not self.list[i]['content'] == 'movies':
            #    raise Exception()

            imdb = self.list[i]['imdb']
            if imdb == '0':
                raise Exception()

            url = self.imdb_info_link % imdb

            item = client.request(url, timeout='10')
            item = json.loads(item)

            if 'Error' in item and 'incorrect imdb' in item['Error'].lower():
                return self.meta.append({
                    'imdb': imdb, 'tmdb': '0', 'tvdb': '0', 'lang': self.lang,
                    'item': {'code': '0'}
                    })

            title = item['Title']
            if not title == '0':
                self.list[i].update({'title': title})

            year = item['Year']
            if year != '0':
                self.list[i].update({'year': year})

            imdb = item['imdbID']
            if imdb in ['', None, 'N/A']:
                imdb = '0'
            if imdb != '0':
                self.list[i].update({'imdb': imdb, 'code': imdb})

            premiered = item['Released']
            if premiered in ['', None, 'N/A']:
                premiered = '0'
            premiered = re.findall(r'(\d*) (.+?) (\d*)', premiered)
            try:
                premiered = '%s-%s-%s' % (
                    premiered[0][2],
                    {
                        'Jan':'01', 'Feb':'02', 'Mar':'03', 'Apr':'04', 'May':'05', 'Jun':'06',
                        'Jul':'07', 'Aug':'08', 'Sep':'09', 'Oct':'10', 'Nov':'11', 'Dec':'12'
                    }[premiered[0][1]],
                    premiered[0][0]
                    )
            except Exception:
                premiered = '0'
            if premiered != '0':
                self.list[i].update({'premiered': premiered})

            genre = item['Genre']
            if genre is None or genre == '' or genre == 'N/A':
                genre = '0'
            genre = genre.replace(', ', ' / ')
            if genre != '0':
                self.list[i].update({'genre': genre})

            duration = item['Runtime']
            if duration is None or duration == '' or duration == 'N/A':
                duration = '0'
            duration = re.sub('[^0-9]', '', str(duration))
            try:
                duration = str(int(duration) * 60)
            except Exception:
                pass
            if duration != '0':
                self.list[i].update({'duration': duration})

            rating = item['imdbRating']
            if rating is None or rating == '' or rating == 'N/A' or rating == '0.0':
                rating = '0'
            if rating != '0':
                self.list[i].update({'rating': rating})

            votes = item['imdbVotes']
            try:
                votes = str(format(int(votes),',d'))
            except Exception:
                pass
            if votes is None or votes == '' or votes == 'N/A':
                votes = '0'
            if votes != '0':
                self.list[i].update({'votes': votes})

            mpaa = item['Rated']
            if mpaa is None or mpaa == '' or mpaa == 'N/A':
                mpaa = '0'
            if mpaa != '0':
                self.list[i].update({'mpaa': mpaa})

            director = item['Director']
            if director is None or director == '' or director == 'N/A':
                director = '0'
            director = director.replace(', ', ' / ')
            director = re.sub(r'\(.*?\)', '', director)
            director = ' '.join(director.split())
            if director != '0':
                self.list[i].update({'director': director})

            writer = item['Writer']
            if writer is None or writer == '' or writer == 'N/A':
                writer = '0'
            writer = writer.replace(', ', ' / ')
            writer = re.sub(r'\(.*?\)', '', writer)
            writer = ' '.join(writer.split())
            if writer != '0':
                self.list[i].update({'writer': writer})

            cast = item['Actors']
            if cast is None or cast == '' or cast == 'N/A':
                cast = '0'
            cast = [x.strip() for x in cast.split(',') if not x == '']
            try:
                cast = [(c.ensure_str(x), '') for x in cast]
            except Exception:
                cast = []
            if cast == []:
                cast = '0'
            if not cast == '0':
                self.list[i].update({'cast': cast})

            plot = item['Plot']
            if plot is None or plot == '' or plot == 'N/A':
                plot = '0'
            plot = client.replaceHTMLCodes(plot)
            c.ensure_str(plot)
            if not plot == '0':
                self.list[i].update({'plot': plot})

            self.meta.append({
                'imdb': imdb, 'tmdb': '0', 'tvdb': '0', 'lang': self.lang,
                'item': {
                    'title': title, 'year': year, 'code': imdb, 'imdb': imdb,
                    'premiered': premiered, 'genre': genre, 'duration': duration,
                    'rating': rating, 'votes': votes, 'mpaa': mpaa,
                    'director': director, 'writer': writer, 'cast': cast, 'plot': plot
                    }
                })
        except Exception:
            pass

    def tv_info(self, i):
        try:
            if self.list[i]['metacache'] is True:
                raise Exception()

            if self.list[i]['content'] not in ['tvshows', 'seasons', 'episodes']:
                raise Exception()

            tvdb = self.list[i]['tvdb']
            if tvdb == '0':
                raise Exception()

            url = self.tvmaze_info_link % tvdb
            item = client.request(url, output='extended', error=True, timeout='10')

            if item[1] == '404':
                return self.meta.append({
                    'imdb': '0', 'tmdb': '0', 'tvdb': tvdb, 'lang': self.lang, 'item': {'code': '0'}
                    })

            item = json.loads(item[0])

            tvshowtitle = item['name']
            c.ensure_str(tvshowtitle)
            if not tvshowtitle == '0':
                self.list[i].update({'tvshowtitle': tvshowtitle})

            year = item['premiered']
            year = re.findall(r'(\d{4})', year)[0]
            c.ensure_str(year)
            if not year == '0':
                self.list[i].update({'year': year})

            try:
                imdb = item['externals']['imdb']
            except Exception:
                imdb = '0'
            if imdb == '' or imdb is None:
                imdb = '0'
            c.ensure_str(imdb)
            if self.list[i]['imdb'] == '0' and not imdb == '0':
                self.list[i].update({'imdb': imdb})

            try:
                studio = item['network']['name']
            except Exception:
                studio = '0'
            if studio == '' or studio is None:
                studio = '0'
            c.ensure_str(studio)
            if not studio == '0':
                self.list[i].update({'studio': studio})

            genre = item['genres']
            if genre == '' or genre is None or genre == []:
                genre = '0'
            genre = ' / '.join(genre)
            c.ensure_str(genre)
            if genre != '0':
                self.list[i].update({'genre': genre})

            try:
                duration = str(item['runtime'])
            except Exception:
                duration = '0'

            if duration in ['', None]:
                duration = '0'
            try:
                duration = str(int(duration) * 60)
            except Exception:
                pass
            c.ensure_str(duration)
            if not duration == '0':
                self.list[i].update({'duration': duration})

            rating = str(item['rating']['average'])
            if rating == '' or rating is None:
                rating = '0'
            c.ensure_str(rating)
            if not rating == '0':
                self.list[i].update({'rating': rating})

            plot = item['summary']
            if plot == '' or plot is None:
                plot = '0'
            plot = re.sub(r'\n|<.+?>|</.+?>|.+?#\d*:', '', plot)
            c.ensure_str(plot)
            if not plot == '0':
                self.list[i].update({'plot': plot})

            self.meta.append({
                'imdb': imdb, 'tmdb': '0', 'tvdb': tvdb, 'lang': self.lang,
                'item': {
                    'tvshowtitle': tvshowtitle, 'year': year, 'code': imdb, 'imdb': imdb,
                    'tvdb': tvdb, 'studio': studio, 'genre': genre,
                    'duration': duration, 'rating': rating, 'plot': plot
                    }
                })
        except Exception:
            pass

    def addDirectory(self, items, queue=False):
        if items is None or len(items) == 0:
            return

        sysaddon = sys.argv[0]
        addon_poster = addon_banner = control.addonInfo('icon')
        addon_fanart = control.addonFanart()

        playlist = control.playlist
        if queue is not False:
            playlist.clear()

        try:
            devmode = 'testings.xml' in control.listDir(control.dataPath)[1]
        except FileNotFoundError:
            devmode = False

        content_type = next((item['content'] for item in items if 'content' in item), None)
        key = content_type if content_type is not None else 'addons'
        mode = {
            'movies': 'movies',
            'tvshows': 'tvshows',
            'seasons': 'seasons',
            'episodes': 'episodes',
            'videos': 'videos'
        }.get(key, 'addons')

        for i in items:
            c.log(f"[CM Debug @ 1197 in lists.py] i = {repr(i)}")
            try:
                name = control.lang(int(i['name']))
            except (ValueError, TypeError):
                name = i['name']

            # Clean up URL titles - convert URLs to readable titles
            if name and isinstance(name, str) and (name.startswith('http://') or name.startswith('https://')):
                try:
                    # Extract path from URL and clean it up
                    # E.g., "https://www.naughtyblog.org/black-is-better-gina-valentina/#more-498720"
                    # becomes "Black Is Better Gina Valentina"
                    path = urlparse(name).path
                    # Remove leading/trailing slashes and split on slashes
                    parts = path.strip('/').split('/')
                    # Take the last part (usually the slug)
                    slug = parts[-1] if parts else ''
                    # Remove anchors and query params
                    slug = slug.split('#')[0].split('?')[0]
                    # Replace hyphens with spaces and title case
                    cleaned = slug.replace('-', ' ').replace('_', ' ').title()
                    if cleaned:
                        name = cleaned
                        c.log(f"[CM Debug @ lists.py] Converted URL title to: {name}")
                except Exception as e:
                    c.log(f"[CM Debug @ lists.py] Failed to clean URL title: {e}")
                    # Keep original name if cleaning fails

            url = f"{sysaddon}?action={i['action']}"

            try:
                url += f"&url={quote_plus(i['url'])}"
            except ValueError:
                pass

            try:
                url += f"&content={quote_plus(i['content'])}"
            except ValueError:
                pass

            if i['action'] == 'plugin' and 'url' in i:
                url = i['url']

            try:
                devurl = dict(parse_qsl(urlparse(url).query)).get('action')
            except ValueError:
                devurl = None

            if devurl == 'developer' and not devmode:
                continue
            poster = i['poster'] if 'poster' in i else '0'
            banner = i['banner'] if 'banner' in i else '0'
            fanart = i['fanart'] if 'fanart' in i else '0'
            if poster == '0':
                poster = addon_poster
            if banner == '0':
                banner = addon_banner if poster == '0' else poster
            content = i['content'] if 'content' in i else '0'
            folder = i['folder'] if 'folder' in i else True

            # Filter metadata to only include valid video info labels
            # Exclude keys like 'action', 'url', 'folder', 'metacache', 'name', 'poster', 'banner', 'fanart', 'content', 'next', 'nextaction'
            excluded_keys = {'action', 'url', 'folder', 'metacache', 'name', 'poster', 'banner', 'fanart', 'content', 'next', 'nextaction', 'context'}
            meta = {k: v for k, v in i.items() if k not in excluded_keys and v != '0'}

            cm = []

            if content in ['movies', 'tvshows']:
                meta['trailer'] = f'{sysaddon}?action=trailer&name={quote_plus(name)}'
                cm.append((control.lang(30707), f'RunPlugin({sysaddon}?action=trailer&name={quote_plus(name)})'))

            if content in ['movies', 'tvshows', 'seasons', 'episodes']:
                cm.append((control.lang(30708), 'XBMC.Action(Info)*'))

            if (folder is False and '|regex=' not in str(i.get('url'))) or (folder is True and content in ['tvshows', 'seasons']):
                cm.append((control.lang(30723), f'RunPlugin({sysaddon}?action=queueItem)'))

            if content == 'movies':
                dfile = f"{i['title']} ({i['year']})" or name
                cm.append((control.lang(30722),  f"RunPlugin({sysaddon}?action=addDownload&name={quote_plus(dfile)}&url={quote_plus(i['url'])}&image={quote_plus(poster)})"))

            elif content == 'episodes':
                dfile = f"{i['tvshowtitle']} S{int(i['season']):02d}E{int(i['episode']):02d}" or name
                cm.append((control.lang(30722),  f"RunPlugin({sysaddon}?action=addDownload&name={quote_plus(dfile)}&url={quote_plus(i['url'])}&image={quote_plus(poster)})"))

            elif content == 'songs':
                cm.append((control.lang(30722), f"RunPlugin({sysaddon}?action=addDownload&name={quote_plus(name)}&url={quote_plus(i['url'])}&image={quote_plus(poster)})"))

            if mode == 'movies':
                c.log(f"[CM Debug @ 1033 in lists.py] lang = {control.lang(30711)}")
                cm.append((control.lang(30711), f"RunPlugin({sysaddon}?action=addView&content=movies)"))
            elif mode == 'tvshows':
                cm.append((control.lang(30712), f"RunPlugin({sysaddon}?action=addView&content=tvshows)"))
            elif mode == 'seasons':
                cm.append((control.lang(30713), f"RunPlugin({sysaddon}?action=addView&content=seasons)"))
            elif mode == 'episodes':
                cm.append((control.lang(30714), f"RunPlugin({sysaddon}?action=addView&content=episodes)"))

            if devmode:
                cm.append(('Open in browser',f"RunPlugin({sysaddon}?action=browser&url={quote_plus(i['url'])}"))

            item = control.item(label=name)

            try:
                item.setArt({
                    'icon': poster, 'thumb': poster, 'poster': poster, 'tvshow.poster': poster,
                    'season.poster': poster, 'banner': banner, 'tvshow.banner': banner,
                    'season.banner': banner
                    })
            except Exception:
                pass

            if fanart != '0':
                item.setProperty('Fanart_Image', fanart)
            elif addon_fanart is not None:
                item.setProperty('Fanart_Image', addon_fanart)

            if not queue:
                item.setInfo(type='Video', infoLabels = meta)
                item.addContextMenuItems(cm)
                control.addItem(handle=int(sys.argv[1]), url=url, listitem=item, isFolder=folder)
            else:
                item.setInfo(type='Video', infoLabels = meta)
                playlist.add(url=url, listitem=item)


        if queue is not False:
            return control.player.play(playlist)

        try:
            # Only add "next page" item if items exist and the first item has valid 'next' and 'nextaction'
            if items and len(items) > 0:
                i = items[0]
                if 'next' in i and i['next'] and 'nextaction' in i:
                    url = f"{sysaddon}?action={i['nextaction']}&url={quote_plus(i['next'])}"

                    item = control.item(label=control.lang(30500))
                    item.setArt({
                        'addonPoster': addon_poster, 'thumb': addon_poster, 'poster': addon_poster,
                        'tvshow.poster': addon_poster, 'season.poster': addon_poster, 'banner': addon_poster,
                        'tvshow.banner': addon_poster, 'season.banner': addon_poster
                        })
                    item.setProperty('addonFanart_Image', addon_fanart)

                    control.addItem(handle=int(sys.argv[1]), url=url, listitem=item, isFolder=True)
                else:
                    c.log("[CM Debug @ addDirectory] No valid 'next' page found in first item")
        except Exception as e:
            import traceback
            failure = traceback.format_exc()
            c.log(f'[CM Debug @ addDirectory] Failed to add next page item: {failure}')
            c.log(f'[CM Debug @ addDirectory] Exception: {e}')
        #     pass
        # except Exception:
        #     pass

        if mode is not None:
            control.content(int(sys.argv[1]), mode)
        control.directory(int(sys.argv[1]), cacheToDisc=True)
        if mode in ['movies', 'tvshows', 'seasons', 'episodes']:
            views.set_view(mode, {'skin.estuary': 55})

# Compiled regex patterns for resolver - defined once for performance
_RESOLVER_PATTERNS = {
    'regex_url': re.compile(r'(.+?)\|regex=(.+?)$'),
    'timeout': re.compile(r'\s*timeout=(\d*)'),
    'preset_search': re.compile(
        r'<preset>(?P<preset>.+?)</preset>.*?'
        r'<title>(?P<title>.+?)</title>.*?'
        r'<year>(?P<year>.+?)</year>.*?'
        r'<imdb>(?P<imdb>.+?)</imdb>',
        re.DOTALL
    ),
    'tv_metadata': re.compile(
        r'<tvdb>(?P<tvdb>.+?)</tvdb>.*?'
        r'<tvshowtitle>(?P<tvshowtitle>.+?)</tvshowtitle>.*?'
        r'<premiered>(?P<premiered>.+?)</premiered>.*?'
        r'<season>(?P<season>.+?)</season>.*?'
        r'<episode>(?P<episode>.+?)</episode>',
        re.DOTALL
    )
}

class resolver:
    def browser(self, url):
        try:
            if not url or not url.startswith('http'):
                return
            url = self.get(url)
            if not url:
                return
            control.execute(f'RunPlugin(plugin://plugin.program.chrome.launcher/?url={quote_plus(url)}&mode=showSite&stopPlayback=no)')
        except Exception:
            pass


    def link(self, url):
        try:
            url = self.get(url)
            if url is False:
                return
            control.execute('ActivateWindow(busydialognocancel)')
            url = self.process(url)
            control.execute('Dialog.Close(busydialognocancel)')

            if url is None:
                return control.infoDialog(control.lang(32401))
            return url
        except Exception:
            pass


    def get(self, url):
        try:
            c.log(f"[CM Debug @ resolver.get] input url = {url}")
            if url is None:
                c.log(f"[CM Debug @ resolver.get] url is None, returning None")
                return None
            items = re.compile(r'<sublink(?:\s+name=|)(?:\'|\"|)(.*?)(?:\'|\"|)>(.+?)</sublink>').findall(url)
            c.log(f"[CM Debug @ resolver.get] items found = {items}")

            if len(items) == 0:
                c.log(f"[CM Debug @ resolver.get] no sublinks found, returning original url")
                return url
            if len(items) == 1:
                c.log(f"[CM Debug @ resolver.get] single sublink found, returning = {items[0][1]}")
                return items[0][1]

            # Give unnamed sublinks a default label
            items = [(i[0] or f'Link {idx+1}', i[1]) for idx, i in enumerate(items)]

            select = control.selectDialog([i[0] for i in items], control.infoLabel('listitem.label'))

            if select == -1:
                return False
            else:
                return items[select][1]
        except Exception as e:
            c.log(f"[CM Debug @ resolver.get] Exception: {e}")
            # Return original URL on error instead of None
            return url

    #!TODO - check f4mproxy
    def f4m(self, url, name):
        try:
            if not any(i in url for i in ['.f4m', '.ts']):
                raise Exception()
            ext = url.split('?')[0].split('&')[0].split('|')[0].rsplit('.')[-1].replace('/', '').lower()
            if ext not in ['f4m', 'ts']:
                raise Exception()

            params = parse_qs(url)

            try:
                proxy = params['proxy'][0]
            except Exception:
                proxy = None

            try:
                proxy_use_chunks = json.loads(params['proxy_for_chunks'][0])
            except Exception:
                proxy_use_chunks = True

            try:
                maxbitrate = int(params['maxbitrate'][0])
            except Exception:
                maxbitrate = 0

            try:
                simpleDownloader = json.loads(params['simpledownloader'][0])
            except Exception:
                simpleDownloader = False

            try:
                auth_string = params['auth'][0]
            except Exception:
                auth_string = ''

            try:
                streamtype = params['streamtype'][0]
            except Exception:
                streamtype = 'TSDOWNLOADER' if ext == 'ts' else 'HDS'

            try:
                swf = params['swf'][0]
            except Exception:
                swf = None

            from F4mProxy import f4mProxyHelper
            return f4mProxyHelper().playF4mLink(url, name, proxy, proxy_use_chunks, maxbitrate, simpleDownloader, auth_string, streamtype, False, swf)
        except Exception:
            pass


    def process(self, url, direct=True):
        c.log(f"[CM Debug @ resolver.process] input url = {url}")

        # Handle None URL
        if url is None:
            c.log(f"[CM Debug @ resolver.process] url is None, returning None")
            return None

        # Handle image URLs
        if any(i in url for i in ['.jpg', '.png', '.gif']):
            ext = url.split('?')[0].split('&')[0].split('|')[0].rsplit('.')[-1].replace('/', '').lower()
            if ext in ['jpg', 'png', 'gif']:
                try:
                    i = os.path.join(control.dataPath, 'img')
                    control.deleteFile(i)
                    f = control.openFile(i, 'w')
                    f.write(client.request(url))
                    f.close()
                    control.execute(f'ShowPicture("{i}")')
                    return False
                except Exception:
                    return

        # Handle regex URLs
        match = _RESOLVER_PATTERNS['regex_url'].search(url)
        if match:
            try:
                r, x = match.groups()
                x = regex.fetch(x)
                r += unquote_plus(x)
                if '</regex>' in r:
                    u = regex.resolve(r)
                    if u is not None:
                        url = u
            except Exception:
                pass

        # Handle RTMP URLs
        if url.startswith('rtmp'):
            if not _RESOLVER_PATTERNS['timeout'].search(url):
                url += ' timeout=10'
            return url

        # Handle direct streaming formats (m3u8, f4m, ts)
        if any(i in url for i in ['.m3u8', '.f4m', '.ts']):
            ext = url.split('?')[0].split('&')[0].split('|')[0].rsplit('.')[-1].replace('/', '').lower()
            if ext in ['m3u8', 'f4m', 'ts']:
                return url

        # Handle preset search (movie/TV scraping)
        match = _RESOLVER_PATTERNS['preset_search'].search(url)
        if match:
            try:
                data = match.groupdict()
                if 'search' in data['preset']:
                    # Try to extract TV metadata
                    tv_match = _RESOLVER_PATTERNS['tv_metadata'].search(url)
                    if tv_match:
                        tv_data = tv_match.groupdict()
                        tvdb = tv_data['tvdb']
                        tvshowtitle = tv_data['tvshowtitle']
                        premiered = tv_data['premiered']
                        season = tv_data['season']
                        episode = tv_data['episode']
                    else:
                        tvdb = tvshowtitle = premiered = season = episode = None

                    direct = False
                    quality = 'SD' if data['preset'] == 'searchsd' else 'HD'

                    u = sources.Sources().getSources(
                        data['title'], data['year'], data['imdb'],
                        tvdb, season, episode, tvshowtitle, premiered, quality
                    )
                    if u is not None:
                        return u
            except Exception:
                pass

        # Handle sources2 module
        try:
            from ..modules import sources2
            u = sources2.sources().getURISource(url)
            if u is not False:
                direct = False
            if u is not None and u is not False:
                return u
        except ImportError:
            # sources2 module not found - this is expected, continue to next resolver
            pass
        except Exception as e:
            c.log(f"[CM Debug @ resolver.process] sources2 error: {e}")
            pass

        # Handle filmon.com URLs
        if 'filmon.com/' in url:
            try:
                from ..modules import filmon
                u = filmon.resolve(url)
                if u:
                    return u
            except Exception:
                pass

        # Handle google.com URLs
        if '.google.com' in url:
            try:
                from ..modules import directstream
                u = directstream.google(url)[0]['url']
                if u:
                    return u
            except Exception:
                pass

        # Handle resolveurl (ResolveURL/URLResolver for various hosters)
        try:
            import resolveurl
            hmf = resolveurl.HostedMediaFile(url=url)
            if hmf.valid_url():
                direct = False
                u = hmf.resolve()
                if u:
                    return u
        except Exception:
            pass

        # If nothing else worked and it's a direct URL, return it
        if direct is True:
            return url


# Backwards-compatible factory for older code expecting `indexer()` to exist
def indexer():
    """Return a new Indexer instance for backward compatibility."""
    return Indexer()

class player(xbmc.Player):
    def __init__ (self):
        self.totalTime = 0
        self.currentTime = 0
        self.name = ''
        self.title = ''
        self.year = ''
        self.season = None
        self.episode = None
        self.DBID = None
        self.getbookmark = False
        self.offset = '0'
        self.imdb = None
        self.tmdb = None

        xbmc.Player.__init__(self)


    def play(self, url, content=None):
        base = url

        c.log(f"[CM Debug @ 1397 in lists.py] inside lists.player.play(), url = {url}")

        if '$doregex[playurl]|' in url:
            url = Indexer().get_x_url(url)
            c.log(f"[CM Debug @ 1439 in lists.py] url = {url}")



        url = resolver().get(url)
        c.log(f"[CM Debug @ play after resolver.get] url = {url}")
        if url is False or url is None:
            c.log(f"[CM Debug @ 1445 in lists.py] url is False or None = {url}")
            return

        control.execute('ActivateWindow(busydialog)')
        url = resolver().process(url)
        c.log(f"[CM Debug @ play after resolver.process] url = {url}")
        control.execute('Dialog.Close(busydialog)')

        if url is None:
            #return control.infoDialog(control.lang(30705))
            return control.infoDialog('No working url found')
        if url is False:
            return

        meta = {}
        for i in [
            'title', 'originaltitle', 'tvshowtitle', 'year', 'season', 'episode', 'genre',
            'rating', 'votes', 'director', 'writer', 'plot', 'tagline'
            ]:
            try:
                meta[i] = control.infoLabel(f'listitem.{i}')
            except Exception:
                pass
        meta = dict((k,v) for k, v in meta.items() if not v == '')
        if 'title' not in meta:
            meta['title'] = control.infoLabel('listitem.label')
        icon = control.infoLabel('listitem.icon')


        self.name = meta['title']
        self.year = meta['year'] if 'year' in meta else '0'
        self.getbookmark = True if content in ['episodes', 'movies'] else False
        self.offset = bookmarks().get(self.name, self.year)

        f4m = resolver().f4m(url, self.name)
        if f4m is not None:
            return


        item = control.item(path=url)
        try:
            item.setArt({'icon': icon})
        except Exception:
            pass
        item.setInfo(type='Video', infoLabels = meta)
        control.player.play(url, item)
        control.resolve(int(sys.argv[1]), True, item)

        self.totalTime = 0
        self.currentTime = 0

        for _ in range(240):
            if self.isPlayingVideo():
                break
            control.sleep(1000)
        while self.isPlayingVideo():
            try:
                self.totalTime = self.getTotalTime()
                self.currentTime = self.getTime()
            except Exception:
                pass
            control.sleep(2000)
        control.sleep(5000)

    def onPlayBackStarted(self):
        control.execute('Dialog.Close(all,true)')
        if self.getbookmark is True and self.offset != '0':
            self.seekTime(float(self.offset))

    def onPlayBackStopped(self):
        if self.getbookmark is True:
            bookmarks().reset(self.currentTime, self.totalTime, self.name, self.year)

    def onPlayBackEnded(self):
        self.onPlayBackStopped()


class bookmarks:
    def get(self, name, year='0'):
        try:
            offset = '0'

            idFile = hashlib.md5()
            idFile.update(ensure_bytes(name))
            idFile.update(ensure_bytes(year))
            idFile = str(idFile.hexdigest())

            dbcon = database.connect(control.bookmarksFile)
            dbcur = dbcon.cursor()
            dbcur.execute("SELECT * FROM bookmark WHERE idFile = '%s'" % idFile)
            match = dbcur.fetchone()
            self.offset = str(match[1])
            dbcon.commit()

            if self.offset == '0':
                raise Exception()

            # split into two statements (no semicolon)
            minutes, seconds = divmod(float(self.offset), 60)
            hours, minutes = divmod(minutes, 60)

            label = f'{hours:02d}:{minutes:02d}:{seconds:02d}'
            label = control.lang(32502) % label

            try:
                yes = control.dialog.contextmenu([label, control.lang(32501), ])
            except Exception:
                yes = control.yesnoDialog(label, '', '', str(name), control.lang(32503), control.lang(32501))

            if yes:
                self.offset = '0'

            return self.offset
        except Exception:
            return offset

    def reset(self, currentTime, totalTime, name, year='0'):
        try:
            timeInSeconds = str(currentTime)
            ok = int(currentTime) > 180 and (currentTime / totalTime) <= .92

            idFile = hashlib.md5()
            idFile.update(ensure_bytes(name))
            idFile.update(ensure_bytes(year))
            idFile = str(idFile.hexdigest())

            control.makeFile(control.dataPath)
            dbcon = database.connect(control.bookmarksFile)
            dbcur = dbcon.cursor()
            dbcur.execute("CREATE TABLE IF NOT EXISTS bookmark (""idFile TEXT, ""timeInSeconds TEXT, ""UNIQUE(idFile)"");")
            dbcur.execute("DELETE FROM bookmark WHERE idFile = '%s'" % idFile)
            # expand inline if into a block (no semicolon)
            if ok:
                dbcur.execute("INSERT INTO bookmark Values (?, ?)", (idFile, timeInSeconds))
            dbcon.commit()
        except Exception:
            pass