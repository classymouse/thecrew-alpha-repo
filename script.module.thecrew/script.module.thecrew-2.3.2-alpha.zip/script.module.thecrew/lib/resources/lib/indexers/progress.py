# -*- coding: utf-8 -*-
'''
 ***********************************************************
 * The Crew Add-on - Progress Indexer
 *
 * @package script.module.thecrew
 *
 * Clean implementation of Trakt progress features using new model classes.
 * Provides Gears-style menu items:
 *   1. In Progress Shows - TV shows you're watching (alphabetical, show posters)
 *   2. Next Episodes - Next unwatched episodes to watch (auto-advance)
 *   3. In Progress Episodes - Episodes with resume points (partially watched)
 *
 * @copyright (c) 2025, The Crew
 * @license GNU General Public License, version 3 (GPL-3.0)
 *
 ***********************************************************
'''

import concurrent.futures
from contextlib import suppress

from ..models.tvshow import TVShow
from ..models.episode import Episode
from ..modules import trakt
from ..modules import cache
from ..modules import control
from ..modules import workers
from ..modules.crewruntime import c


class Progress:
    """
    Indexer for Trakt progress features.
    Uses clean model classes (TVShow, Episode) instead of monolithic approach.
    """

    def __init__(self):
        self.list = []
        self.trakt_user = c.get_setting('trakt.username').strip()
        self.lang = control.apiLanguage()['trakt']
        self.hidecinema = c.get_setting('hidecinema') == 'true'

        # Trakt API endpoints
        self.progress_link = 'https://api.trakt.tv/sync/watched/shows'
        self.trakthistory_link = 'https://api.trakt.tv/sync/history/episodes?limit=25'

    def get_in_progress_shows(self):
        """
        Get list of TV shows user is currently watching.
        Returns show-level objects (not episodes) alphabetically sorted.

        Filters out:
        - Shows that are both ended AND fully watched
        - Shows hidden from calendar via Trakt

        When set to ICONS view, shows TV show posters (like Gears).
        User can select show to see seasons/episodes.

        Returns:
            list: List of TVShow objects as dicts
        """
        try:
            c.log("[Progress] Fetching In Progress Shows")

            # Get hidden shows from Trakt (to filter them out)
            hidden_shows = set()
            try:
                hidden_url = "https://api.trakt.tv/users/hidden/calendar?type=show&limit=1000"
                hidden_result = trakt.getTraktAsJson(hidden_url)
                if hidden_result:
                    hidden_shows = {
                        str(item.get('show', {}).get('ids', {}).get('trakt'))
                        for item in hidden_result
                        if item.get('show', {}).get('ids', {}).get('trakt')
                    }
                    c.log(f"[Progress] Found {len(hidden_shows)} hidden shows")
            except Exception as e:
                c.log(f"[Progress] Could not fetch hidden shows: {e}")

            # Get progress from Trakt
            url = f"{self.progress_link}?extended=full"
            result = trakt.getTraktAsJson(url)

            if not result:
                c.log("[Progress] No Trakt progress data")
                self.list = []
                self.shows_directory(self.list)
                return self.list

            shows = []

            def process_show(item):
                """Process single show from Trakt progress."""
                try:
                    # Get show data for filtering
                    show_data = item.get('show', {})
                    status = show_data.get('status', '').lower()
                    aired_episodes = int(show_data.get('aired_episodes', 0))

                    # Get show IDs
                    show_ids = show_data.get('ids', {})
                    trakt_id = str(show_ids.get('trakt', '0'))

                    # FILTER 1: Exclude hidden shows
                    if trakt_id in hidden_shows:
                        c.log(f"[Progress] Filtering out hidden show: {show_data.get('title')}")
                        return None

                    # Calculate what episode user is on
                    seasons = item.get('seasons', [])
                    if isinstance(seasons, dict):
                        seasons = list(seasons.values())

                    # Count watched episodes (excluding specials - season 0)
                    watched_count = sum(
                        len(s.get('episodes', []))
                        for s in seasons
                        if s.get('number', 0) > 0
                    )

                    # FILTER 2: Exclude shows that are BOTH ended AND fully watched
                    if status in ['ended', 'canceled'] and watched_count >= aired_episodes and aired_episodes > 0:
                        c.log(f"[Progress] Filtering out ended & fully watched show: {show_data.get('title')}")
                        return None

                    # Create TVShow from Trakt data
                    show = TVShow.from_trakt_progress(item)
                    if not show:
                        return None

                    # Find last watched episode
                    last_season = 0
                    last_episode = 0
                    last_timestamp = None

                    sorted_seasons = sorted(
                        [s for s in seasons if s.get('number', 0) > 0],
                        key=lambda s: s.get('number', 0)
                    )

                    for s in sorted_seasons:
                        season_num = s.get('number')
                        eps = s.get('episodes') or []

                        for e in eps:
                            if e.get('last_watched_at'):
                                if last_timestamp is None or e.get('last_watched_at') > last_timestamp:
                                    last_season = season_num
                                    last_episode = e.get('number')
                                    last_timestamp = e.get('last_watched_at')

                    show.last_watched_season = last_season
                    show.last_watched_episode = last_episode
                    show.last_watched_at = last_timestamp

                    # Fetch metadata from TMDB (includes season poster fallback)
                    fetch_success = show.fetch_tmdb_metadata(extended=True)
                    if not fetch_success:
                        c.log(f"[Progress] TMDB metadata fetch failed for: {show.tvshowtitle} (TMDB: {show.tmdb}, IMDB: {show.imdb})")

                    return show

                except Exception as e:
                    c.log(f"[Progress] Error processing show: {e}")
                    return None

            # Process shows in parallel
            max_threads = c.get_max_threads(len(result))
            with concurrent.futures.ThreadPoolExecutor(max_workers=max_threads) as executor:
                futures = [executor.submit(process_show, item) for item in result]

                for future in concurrent.futures.as_completed(futures):
                    with suppress(Exception):
                        show = future.result()
                        if show:
                            shows.append(show.to_dict())

            # Sort by last_watched_at (most recent first)
            shows.sort(
                key=lambda x: x.get('last_watched_at') or '1900-01-01T00:00:00.000Z',
                reverse=True
            )

            c.log(f"[Progress] Returning {len(shows)} In Progress Shows (sorted by most recent)")
            self.list = shows
            self.shows_directory(self.list)
            return self.list

        except Exception as e:
            c.log(f"[Progress] Error in get_in_progress_shows: {e}")
            self.list = []
            self.shows_directory(self.list)
            return self.list

    def get_next_episodes(self):
        """
        Get next unwatched episodes user should watch.
        Auto-advances to first unwatched episode of each show.

        Returns episode-level objects with episode stills (like Gears).

        Returns:
            list: List of Episode objects as dicts
        """
        try:
            c.log("[Progress] Fetching Next Episodes")

            # Get progress from Trakt
            url = f"{self.progress_link}?extended=full"
            result = trakt.getTraktAsJson(url)

            if not result:
                c.log("[Progress] No Trakt progress data")
                self.list = []
                self.episodes_directory(self.list)
                return self.list

            episodes = []

            # Shared artwork cache for all episodes (avoids redundant fetches for same show)
            # Key: show_tmdb_id, Value: {poster, fanart, banner, clearlogo, etc.}
            artwork_cache = {}

            def process_show(item):
                """Find next unwatched episode for show."""
                try:
                    show_data = item.get('show', {})
                    seasons = item.get('seasons', [])

                    if isinstance(seasons, dict):
                        seasons = list(seasons.values())

                    # Check if all episodes watched
                    num_watched = sum(
                        len(s.get('episodes', []))
                        for s in seasons
                        if s.get('number', 0) > 0
                    )
                    aired_episodes = int(show_data.get('aired_episodes', 0))

                    if num_watched >= aired_episodes and aired_episodes > 0:
                        # All watched, skip
                        return None

                    # Find the highest watched episode
                    sorted_seasons = sorted(
                        [s for s in seasons if s.get('number', 0) > 0],
                        key=lambda s: s.get('number', 0)
                    )

                    next_season = None
                    next_episode_num = None

                    # Find highest watched episode across all seasons
                    # Also capture the most recent watch timestamp for sorting
                    max_season = 0
                    max_episode = 0
                    last_watched_at = None

                    for s in sorted_seasons:
                        season_num = s.get('number')
                        eps = s.get('episodes') or []

                        if eps:
                            max_ep_in_season = max(e.get('number', 0) for e in eps)
                            if season_num > max_season or (season_num == max_season and max_ep_in_season > max_episode):
                                max_season = season_num
                                max_episode = max_ep_in_season
                                # Get the most recent watch timestamp from this episode
                                for ep in eps:
                                    if ep.get('number') == max_ep_in_season:
                                        ep_timestamp = ep.get('last_watched_at')
                                        if ep_timestamp:
                                            last_watched_at = ep_timestamp
                                        break

                    if max_season == 0:
                        # No watched episodes, start at S01E01
                        next_season = 1
                        next_episode_num = 1
                    else:
                        # Try next episode in same season first
                        next_season = max_season
                        next_episode_num = max_episode + 1

                    # Create episode and validate it exists
                    episode = Episode.from_trakt_progress(
                        show_data,
                        next_season,
                        next_episode_num
                    )

                    if episode:
                        # Fetch episode metadata from TMDB to validate it exists
                        success = episode.fetch_tmdb_metadata()

                        # If episode doesn't exist (404), try next season episode 1
                        if not success and next_episode_num > 1:
                            c.log(f"[Progress] S{next_season:02d}E{next_episode_num:02d} doesn't exist, trying S{next_season+1:02d}E01")
                            episode = Episode.from_trakt_progress(
                                show_data,
                                next_season + 1,
                                1
                            )
                            if episode:
                                success = episode.fetch_tmdb_metadata()

                        if success:
                            # Fetch show artwork with caching
                            episode.fetch_show_artwork(artwork_cache)

                            # Store last_watched_at for sorting
                            episode.last_watched_at = last_watched_at

                            return episode

                    return None

                except Exception as e:
                    c.log(f"[Progress] Error processing show for next episode: {e}")
                    return None

            # Process shows in parallel
            max_threads = c.get_max_threads(len(result))
            with concurrent.futures.ThreadPoolExecutor(max_workers=max_threads) as executor:
                futures = [executor.submit(process_show, item) for item in result]

                for future in concurrent.futures.as_completed(futures):
                    with suppress(Exception):
                        episode = future.result()
                        if episode:
                            episodes.append(episode.to_dict())

            # Sort by last_watched_at (most recent first)
            episodes.sort(
                key=lambda x: x.get('last_watched_at') or '1900-01-01T00:00:00.000Z',
                reverse=True
            )

            c.log(f"[Progress] Returning {len(episodes)} Next Episodes (sorted by last watched)")
            self.list = episodes
            self.episodes_directory(self.list)
            return self.list

        except Exception as e:
            c.log(f"[Progress] Error in get_next_episodes: {e}")
            self.list = []
            self.episodes_directory(self.list)
            return self.list

    def get_in_progress_episodes(self):
        """
        Get episodes with resume points (partially watched).
        Shows episodes user started but hasn't finished (resume_point > 0%).

        Returns episode-level objects with episode stills (like Gears).

        Returns:
            list: List of Episode objects as dicts
        """
        try:
            c.log("[Progress] Fetching In Progress Episodes")

            # Get playback progress from Trakt
            url = "https://api.trakt.tv/sync/playback/episodes?extended=full"
            result = trakt.getTraktAsJson(url)

            if not result:
                c.log("[Progress] No Trakt playback progress data")
                self.list = []
                self.episodes_directory(self.list)
                return self.list

            episodes = []
            artwork_cache = {}  # Cache show-level artwork for performance

            def process_episode(item):
                """Process single episode with resume point."""
                try:
                    progress = float(item.get('progress', 0))

                    # Only include if between 0% and 92% (not fully watched)
                    if progress <= 0 or progress >= 92:
                        return None

                    episode_data = item.get('episode', {})
                    show_data = item.get('show', {})

                    season_num = episode_data.get('season')
                    episode_num = episode_data.get('number')

                    if not season_num or not episode_num:
                        return None

                    # Create Episode object
                    episode = Episode.from_trakt_progress(
                        show_data,
                        season_num,
                        episode_num,
                        episode_data
                    )

                    if episode:
                        # Calculate resume point in seconds
                        # Trakt gives progress as percentage and paused_at timestamp
                        episode.resume_point = progress  # Store percentage

                        # Store paused_at for sorting
                        paused_at = item.get('paused_at')
                        if paused_at:
                            episode.last_watched_at = paused_at  # Use for sorting

                        # Fetch episode metadata
                        episode.fetch_tmdb_metadata()
                        # Fetch show artwork with caching
                        episode.fetch_show_artwork(artwork_cache)

                    return episode

                except Exception as e:
                    c.log(f"[Progress] Error processing episode: {e}")
                    return None

            # Process episodes in parallel
            max_threads = c.get_max_threads(len(result))
            with concurrent.futures.ThreadPoolExecutor(max_workers=max_threads) as executor:
                futures = [executor.submit(process_episode, item) for item in result]

                for future in concurrent.futures.as_completed(futures):
                    with suppress(Exception):
                        episode = future.result()
                        if episode:
                            episodes.append(episode.to_dict())

            # Sort by paused_at (most recent first)
            episodes.sort(
                key=lambda x: x.get('last_watched_at') or x.get('paused_at') or '1900-01-01T00:00:00.000Z',
                reverse=True
            )

            c.log(f"[Progress] Returning {len(episodes)} In Progress Episodes (sorted by most recent)")
            self.list = episodes
            self.episodes_directory(self.list)
            return self.list

        except Exception as e:
            c.log(f"[Progress] Error in get_in_progress_episodes: {e}")
            self.list = []
            self.episodes_directory(self.list)
            return self.list

    def shows_directory(self, items):
        """
        Create Kodi directory listing for TV shows.
        Shows show posters in ICONS view.

        Args:
            items (list): List of show dictionaries
        """
        if not items:
            control.idle()
            control.infoDialog(c.lang(32500), sound=False, icon='INFO')
            return

        from ..indexers import tvshows
        from ..modules import playcount
        from ..modules.listitem import ListItemInfoTag
        import sys
        import json
        from urllib.parse import quote_plus

        sysaddon = sys.argv[0]
        syshandle = int(sys.argv[1])

        trakt_credentials = trakt.get_trakt_credentials_info()
        indicators = playcount.get_tvshow_indicators()
        addon_poster = c.addon_poster()

        for i in items:
            try:
                label = i.get('tvshowtitle', i.get('title', ''))
                imdb = i.get('imdb', '')
                tmdb = i.get('tmdb', '')
                tvdb = i.get('tvdb', '')
                year = i.get('year', '')

                # Use addon poster/fanart as fallback for missing artwork ('0' means not found)
                poster = i.get('poster', addon_poster)
                if poster in ['0', '', None]:
                    poster = addon_poster

                fanart = i.get('fanart', c.addon_fanart())
                if fanart in ['0', '', None]:
                    fanart = c.addon_fanart()

                systitle = quote_plus(label)

                # URL to open seasons list
                url = f'{sysaddon}?action=seasons&tvshowtitle={systitle}&year={year}&imdb={imdb}&tmdb={tmdb}&tvdb={tvdb}'

                # Create listitem
                try:
                    listitem = control.item(label=label, offscreen=True)
                except:
                    listitem = control.item(label=label)

                # Set artwork
                listitem.setArt({
                    'icon': poster,
                    'thumb': poster,
                    'poster': poster,
                    'tvshow.poster': poster,
                    'fanart': fanart
                })

                # Set info using InfoTag
                info_tag = ListItemInfoTag(listitem, 'video')

                infodata = {
                    'title': label,
                    'tvshowtitle': label,
                    'year': year,
                    'plot': i.get('plot', ''),
                    'mediatype': 'tvshow'
                }

                info_tag.set_info(control.tagdataClean(infodata))
                info_tag.set_unique_ids({'imdb': imdb, 'tmdb': tmdb, 'tvdb': tvdb})

                # Add to directory
                control.addItem(handle=syshandle, url=url, listitem=listitem, isFolder=True)

            except Exception as e:
                c.log(f"[Progress] Error adding show to directory: {e}")
                continue

        control.content(syshandle, 'tvshows')
        control.directory(syshandle, cacheToDisc=True)

    def episodes_directory(self, items):
        """
        Create Kodi directory listing for episodes.
        Shows episode stills in ICONS view.

        Args:
            items (list): List of episode dictionaries
        """
        if not items:
            control.idle()
            control.infoDialog(c.lang(32500), sound=False, icon='INFO')
            return

        from ..modules import playcount
        from ..modules import bookmarks
        from ..modules.listitem import ListItemInfoTag
        import sys
        import json
        from urllib.parse import quote_plus

        sysaddon = sys.argv[0]
        syshandle = int(sys.argv[1])

        indicators = playcount.get_tvshow_indicators()
        is_playable = 'plugin' not in control.infoLabel('Container.PluginName')

        for i in items:
            try:
                label = i.get('title', i.get('label', ''))
                season = str(i.get('season', 0)).zfill(2)
                episode = str(i.get('episode', 0)).zfill(2)
                tvshowtitle = i.get('tvshowtitle', '')

                # Build episode label with TV show title
                ep_label = f'{tvshowtitle} ({season}x{episode}) : {label}'

                # For episode playback, we need SHOW IDs (episodes don't have their own IMDB/TMDB IDs)
                # If episode-level IDs are missing/invalid, use show-level IDs
                imdb = i.get('imdb', '0')
                if imdb in ['0', '', None]:
                    imdb = i.get('showimdb', '0')

                tmdb = i.get('tmdb', '0')
                if tmdb in ['0', '', None]:
                    tmdb = i.get('showtmdb', '0')

                tvdb = i.get('tvdb', '0')
                if tvdb in ['0', '', None]:
                    tvdb = i.get('showtvdb', '0')

                year = i.get('year', '')
                duration = i.get('duration', 45) or 45  # minutes, handle empty string

                # Convert to int if string
                try:
                    duration = int(duration)
                except (ValueError, TypeError):
                    duration = 45

                # Get artwork (use addon defaults for missing artwork - '0' means not found)
                thumb = i.get('thumb', c.addon_thumb())
                if thumb in ['0', '', None]:
                    thumb = c.addon_thumb()

                poster = i.get('poster', c.addon_poster())
                if poster in ['0', '', None]:
                    poster = c.addon_poster()

                fanart = i.get('fanart', c.addon_fanart())
                if fanart in ['0', '', None]:
                    fanart = c.addon_fanart()

                # Build playback URL (match existing episodes.py format)
                systitle = quote_plus(label)
                systvshowtitle = quote_plus(tvshowtitle)

                premiered = i.get('premiered', i.get('first_aired', ''))
                syspremiered = quote_plus(premiered) if premiered else '0'

                # Build meta dict - keep required artwork fields even if '0' for old episodes.py compatibility
                required_fields = {'banner', 'clearlogo', 'clearart', 'landscape'}
                meta = {
                    k: v for k, v in i.items()
                    if v not in [None, ''] or k in required_fields
                }
                # Ensure required fields exist with '0' default
                for field in required_fields:
                    if field not in meta:
                        meta[field] = '0'

                sysmeta = quote_plus(json.dumps(meta))

                # Import time for unique cache-busting parameter
                import time
                systime = str(int(time.time()))

                url = (f'{sysaddon}?action=play&title={systitle}&year={year}&imdb={imdb}&tmdb={tmdb}'
                       f'&season={i.get("season")}&episode={i.get("episode")}'
                       f'&tvshowtitle={systvshowtitle}&premiered={syspremiered}&meta={sysmeta}&t={systime}')

                # Create listitem
                try:
                    listitem = control.item(label=ep_label, offscreen=True)
                except:
                    listitem = control.item(label=ep_label)

                if is_playable:
                    listitem.setProperty('IsPlayable', 'true')

                # Set artwork
                listitem.setArt({
                    'icon': thumb,
                    'thumb': thumb,
                    'poster': poster,
                    'tvshow.poster': poster,
                    'season.poster': poster,
                    'fanart': fanart
                })

                # Get watch status
                try:
                    overlay = int(playcount.get_episode_overlay(indicators, imdb, tmdb, i.get('season'), i.get('episode')))
                except:
                    overlay = 6

                # Prepare comprehensive metadata for InfoTag
                infodata = {
                    'title': label,
                    'tvshowtitle': tvshowtitle,
                    'season': i.get('season'),
                    'episode': i.get('episode'),
                    'year': year,
                    'plot': i.get('plot', ''),
                    'duration': str(int(duration) * 60),  # convert to seconds
                    'mediatype': 'episode',
                    'playcount': 1 if overlay == 7 else 0,
                    'overlay': overlay,
                    'rating': i.get('rating', '0'),
                    'votes': i.get('votes', '0'),
                    'premiered': i.get('premiered', ''),
                    'aired': i.get('first_aired', i.get('premiered', '')),
                    'mpaa': i.get('mpaa', ''),
                }

                # Add lists (genre, studio, director, writer)
                if genre := i.get('genre'):
                    infodata['genre'] = c.string_split_to_list(genre)
                if studio := i.get('studio'):
                    infodata['studio'] = c.string_split_to_list(studio)
                if director := i.get('director'):
                    infodata['director'] = c.string_split_to_list(director)
                if writer := i.get('writer'):
                    infodata['writer'] = c.string_split_to_list(writer)

                info_tag = ListItemInfoTag(listitem, 'video')
                info_tag.set_info(control.tagdataClean(infodata))
                info_tag.set_unique_ids({'imdb': imdb, 'tmdb': tmdb, 'tvdb': tvdb})

                # Set cast separately (required format: list of dicts with name, role, thumbnail)
                if castwiththumb := i.get('castwiththumb'):
                    if castwiththumb and castwiththumb != '0':
                        info_tag.set_cast(castwiththumb)

                # Context menu (clean and minimal - just browsing options)
                cm = []

                # Debug: Log IDs for troubleshooting
                c.log(f"[Progress CM] {tvshowtitle} S{i.get('season'):02d}E{i.get('episode'):02d}: imdb={imdb}, tmdb={tmdb}, tvdb={tvdb}")

                # 1. Browse Series (all seasons)
                browse_series_label = control.lang(32071)  # "Browse Series"
                browse_series_url = f'ActivateWindow(Videos,{sysaddon}?action=seasons&tvshowtitle={systvshowtitle}&year={year}&imdb={imdb}&tmdb={tmdb}&meta={sysmeta},return)'
                cm.append((browse_series_label, browse_series_url))

                # 2. Browse Season (all episodes in this season)
                browse_season_label = f'Browse Season {i.get("season")}'
                browse_season_url = f'ActivateWindow(Videos,{sysaddon}?action=episodes&tvshowtitle={systvshowtitle}&year={year}&imdb={imdb}&tmdb={tmdb}&meta={sysmeta}&season={i.get("season")},return)'
                cm.append((browse_season_label, browse_season_url))

                listitem.addContextMenuItems(cm)

                # Handle resume point if present (for In Progress Episodes)
                resume_point = i.get('resume_point')
                if resume_point is not None and resume_point > 0:
                    # resume_point is a percentage (0-100)
                    duration_seconds = int(duration) * 60

                    # Convert percentage to seconds
                    resume_seconds = (duration_seconds * resume_point) / 100.0

                    # Calculate remaining time in minutes
                    remaining_seconds = duration_seconds - resume_seconds
                    remaining_minutes = int(remaining_seconds / 60)

                    # Add remaining time to label in gold
                    if remaining_minutes > 0:
                        ep_label = f'{ep_label} [COLOR gold]({remaining_minutes} mins left)[/COLOR]'
                        listitem.setLabel(ep_label)

                    # Set resume point using InfoTag (Kodi v21+ method)
                    # This automatically sets the overlay indicator (arrow vs checkmark)
                    try:
                        infodata['offset'] = resume_seconds
                        info_tag.set_resume_point(infodata, 'offset', 'duration', False)
                        listitem.setProperty('resumetime', str(resume_seconds))
                        percent_played = int((resume_seconds / duration_seconds) * 100)
                        listitem.setProperty('percentplayed', str(percent_played))
                    except Exception as e:
                        c.log(f"[Progress] Error setting resume point: {e}")

                # Add to directory
                control.addItem(handle=syshandle, url=url, listitem=listitem, isFolder=False)

            except Exception as e:
                c.log(f"[Progress] Error adding episode to directory: {e}")
                import traceback
                c.log(f"[Progress] Traceback: {traceback.format_exc()}")
                continue

        control.content(syshandle, 'episodes')
        control.directory(syshandle, cacheToDisc=True)
