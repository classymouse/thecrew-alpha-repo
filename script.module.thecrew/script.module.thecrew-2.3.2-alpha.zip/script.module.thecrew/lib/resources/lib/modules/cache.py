# -*- coding: utf-8 -*-

'''
 ***********************************************************
 * The Crew Add-on
 *
 *
 * @file cache.py
 * @package script.module.thecrew
 *
 * @copyright (c) 2023, The Crew
 * @license GNU General Public License, version 3 (GPL-3.0)
 *
 ********************************************************cm*
'''

import hashlib
import re
import time
import os
import json

from sqlite3 import dbapi2 as db, OperationalError
from resources.lib.modules import control
from resources.lib.modules import utils
from resources.lib.modules.crewruntime import c

cache_table = 'cache'
CACHE_VERSION = 2  # Increment when cache schema changes


def get_dynamic_ttl(metadata=None):
    """
    Calculate dynamic TTL based on content status.

    Args:
        metadata: Dict with show/movie metadata (status, air_date, etc.)

    Returns:
        int: TTL in hours (6 for airing shows, 720 for ended)
    """
    if not metadata:
        return 24  # Default 24 hours

    try:
        status = metadata.get('status', '').lower()

        # Currently airing shows get shorter cache (6 hours)
        if status in ['returning series', 'in production', 'continuing']:
            return 6

        # Ended shows get longer cache (30 days)
        elif status in ['ended', 'canceled', 'cancelled']:
            return 720

        # Check if movie is recently released (within last year)
        if 'premiered' in metadata or 'release_date' in metadata:
            try:
                date_str = metadata.get('premiered') or metadata.get('release_date')
                if date_str:
                    import datetime
                    release_date = datetime.datetime.strptime(date_str[:10], '%Y-%m-%d')
                    days_old = (datetime.datetime.now() - release_date).days

                    # Recent releases: 6 hour cache
                    if days_old < 365:
                        return 6
                    # Older content: 30 day cache
                    else:
                        return 720
            except:
                pass

        # Default to 24 hours if status unknown
        return 24
    except:
        return 24


def get(function_, duration, *args, **table):

    try:

        response = None

        # Build stable key using function repr + arguments
        # Use _hash_function to canonicalize hashing and handle non-string args safely
        key = _hash_function(function_, *args)

    except:
        pass

    try:
        table_name = table.get('table') if isinstance(table, dict) else None
    except:
        table_name = None

    try:
        # Try unified cache first (honor TTL)
        cached = cache_get(key, timeout=int(duration) if duration is not None else None, table=table_name)
        if cached is not None:
            try:
                return json.loads(cached['value']) if isinstance(cached['value'], str) else cached['value']
            except Exception:
                c.log(f'[CM Debug @ get in cache.py] Failed to decode cached value for key={key}')
    except Exception as e:
        c.log(f'Cache lookup failed: {e}')

    # Cache miss or expired -> compute value
    try:
        if not callable(function_):
            return function_
        r = function_(*args)
    except Exception as e:
        c.log(f'Function execution failed: {e}')
        return None

    # If function returned None or empty list, return prior cached response if available
    if r is None or r == []:
        if cached is not None:
            try:
                return json.loads(cached['value']) if isinstance(cached['value'], str) else cached['value']
            except Exception:
                return cached['value']
        return r

    # Persist to unified cache
    try:
        serialized = json.dumps(r)
        cache_insert(key, serialized, table=table_name)
    except Exception as e:
        c.log(f'Failed to insert into cache: {e}')

    return r




def timeout(function_, *args):
    try:
        key = _hash_function(function_, *args)
        result = cache_get(key)
        return int(result['date']) if result else 0
    except Exception:
        return 0


def cache_delete(key, table=None):
    """Delete a cache key from the unified cache table."""
    try:
        cursor = _get_connection_cursor()
        if table:
            cursor.execute(f"DELETE FROM {cache_table} WHERE key = ? AND namespace = ?", (key, table))
        else:
            cursor.execute(f"DELETE FROM {cache_table} WHERE key = ?", (key,))
        cursor.connection.commit()
    except Exception as e:
        c.log(f'[CM Debug @ cache_delete] Failed to delete key={key}: {e}')



def cache_get(key, timeout=None, table=None):
    # Returns dict row if present and not expired, else None
    try:
        cursor = _get_connection_cursor()

        # Ensure schema is up-to-date (adds 'namespace', 'etag', 'last_modified')
        _ensure_cache_table_schema(cursor)

        sql = f"SELECT * FROM {cache_table} WHERE key = ?"
        params = [key]
        if table:
            sql += " AND namespace = ?"
            params.append(table)

        cursor.execute(sql, params)
        row = cursor.fetchone()
        if not row:
            return None

        if timeout is None:
            return row

        # timeout is in hours
        now = int(time.time())
        if (now - int(row.get('date', 0))) >= int(timeout) * 3600:
            return None

        return row
    except OperationalError:
        return None
    except Exception as e:
        c.log(f'[CM Debug @ cache_get] Error reading cache for key={key}: {e}')
        return None


def get_with_etag(key, fetcher, ttl_seconds=60, namespace=None):
    """
    Conditional fetch using ETag/Last-Modified.

    - fetcher(conditional_headers) should return (body_text, response_headers, status_code)
    - ttl_seconds: how fresh cached data can be before conditional revalidation
    """
    try:
        row = cache_get(key, table=namespace)

        now = int(time.time())
        # If we have a fresh cached row within ttl, return it immediately
        if row and (now - int(row.get('date', 0))) <= int(ttl_seconds):
            try:
                return json.loads(row['value']) if isinstance(row['value'], str) else row['value']
            except Exception:
                return row['value']

        # Prepare conditional headers if we have etag/last_modified
        conditional = {}
        if row and row.get('etag'):
            conditional['If-None-Match'] = row.get('etag')
        if row and row.get('last_modified'):
            conditional['If-Modified-Since'] = row.get('last_modified')

        # Perform the conditional fetch
        result = fetcher(conditional) if conditional else fetcher(None)
        if not result:
            # No response; fallback to cached value if available
            if row:
                try:
                    return json.loads(row['value']) if isinstance(row['value'], str) else row['value']
                except Exception:
                    return row['value']
            return None

        # Normalize result to (body, headers, status)
        body, headers, status = (result[0], result[1], result[2]) if len(result) >= 3 else (result[0], result[1], 200)

        if status == 304:
            # Not modified - do NOT update the cached timestamp to allow
            # subsequent calls to revalidate in case server content changes shortly after.
            try:
                return json.loads(row['value']) if isinstance(row['value'], str) else row['value']
            except Exception:
                return row['value']

        if status and (200 <= int(status) < 300):
            # New content - store and return
            parsed = json.loads(body) if isinstance(body, str) else body
            etag = headers.get('ETag') or headers.get('Etag')
            last_mod = headers.get('Last-Modified') or headers.get('last-modified')
            cache_insert(key, json.dumps(parsed), table=namespace, etag=etag, last_modified=last_mod)
            c.log(f'Fetched fresh content for key={key}, etag={etag}')
            return parsed

        # Other status - fallback to cached if available
        if row:
            try:
                return json.loads(row['value']) if isinstance(row['value'], str) else row['value']
            except Exception:
                return row['value']

        return None
    except Exception as e:
        c.log(f'[CM Debug @ get_with_etag] Error during conditional fetch for key={key}: {e}')
        return None

def _ensure_cache_table_schema(cursor):
    """Ensure the unified cache table exists and has the expected columns."""
    try:
        # Create base table if missing
        cursor.execute(f"CREATE TABLE IF NOT EXISTS {cache_table} (key TEXT PRIMARY KEY, value TEXT, date INTEGER, namespace TEXT)")
        cursor.connection.commit()

        # Ensure 'table' column exists (for older DBs)
        pragma = cursor.execute(f"PRAGMA table_info({cache_table})").fetchall()
        cols = [row['name'] if isinstance(row, dict) else row[1] for row in pragma]
        if 'namespace' not in cols:
            try:
                cursor.execute(f"ALTER TABLE {cache_table} ADD COLUMN namespace TEXT")
                cursor.connection.commit()

                # If older DB used 'table' column, copy values across
                if 'table' in cols:
                    try:
                        # Copy values from 'table' into new 'namespace' column
                        cursor.execute(f"UPDATE {cache_table} SET namespace = table")
                        cursor.connection.commit()
                        c.log(f'[CM Debug @ _ensure_cache_table_schema] Migrated existing "table" values into "namespace" column')
                    except Exception as e:
                        c.log(f'[CM Debug @ _ensure_cache_table_schema] Failed to migrate "table" to "namespace": {e}')

            except Exception as e:
                c.log(f'[CM Debug @ _ensure_cache_table_schema] Failed to add column namespace: {e}')

        # Ensure etag and last_modified columns exist for conditional requests
        if 'etag' not in cols:
            try:
                cursor.execute(f"ALTER TABLE {cache_table} ADD COLUMN etag TEXT")
                cursor.connection.commit()
                c.log(f'[CM Debug @ _ensure_cache_table_schema] Added column etag')
            except Exception as e:
                c.log(f'[CM Debug @ _ensure_cache_table_schema] Failed to add column etag: {e}')

        if 'last_modified' not in cols:
            try:
                cursor.execute(f"ALTER TABLE {cache_table} ADD COLUMN last_modified TEXT")
                cursor.connection.commit()
                c.log(f'[CM Debug @ _ensure_cache_table_schema] Added column last_modified')
            except Exception as e:
                c.log(f'[CM Debug @ _ensure_cache_table_schema] Failed to add column last_modified: {e}')

        # Record migration as applied (idempotent)
        try:
            cursor.execute("CREATE TABLE IF NOT EXISTS schema_migrations (name TEXT PRIMARY KEY, applied_at INTEGER)")
            # Check whether migration already recorded to avoid noisy duplicate logs
            cursor.execute("SELECT 1 FROM schema_migrations WHERE name = ? LIMIT 1", ('cache_v2',))
            exists = cursor.fetchone()
            if not exists:
                # Use INSERT OR IGNORE to avoid race-condition errors if another process inserts simultaneously
                cursor.execute("INSERT OR IGNORE INTO schema_migrations (name, applied_at) VALUES (?,?)", ('cache_v2', int(time.time())))
                cursor.connection.commit()
                # Verify insertion actually took place before logging
                cursor.execute("SELECT 1 FROM schema_migrations WHERE name = ? LIMIT 1", ('cache_v2',))
                now_exists = cursor.fetchone()
                if now_exists:
                    c.log('[CM Debug @ _ensure_cache_table_schema] Recorded migration cache_v2')
            # If exists already, silently continue to avoid repetitive log entries
        except Exception as e:
            c.log(f'[CM Debug @ _ensure_cache_table_schema] Failed to record migration: {e}')
    except Exception as e:
        c.log(f'[CM Debug @ _ensure_cache_table_schema] Failed to ensure schema: {e}')


def cache_insert(key, value, table=None, etag=None, last_modified=None):
    # Insert or update a key in the unified cache table. 'table' is optional metadata.
    cursor = _get_connection_cursor()

    # Ensure schema is ready
    _ensure_cache_table_schema(cursor)

    now = int(time.time())

    # Upsert using parameterized queries
    namespace_val = table if table is not None else None
    update_result = cursor.execute(f"UPDATE {cache_table} SET value=?,date=?,namespace=?,etag=?,last_modified=? WHERE key= ?", (value, now, namespace_val, etag, last_modified, key))

    if update_result.rowcount == 0:
        cursor.execute(f"INSERT INTO {cache_table} (key, value, date, namespace, etag, last_modified) VALUES (?, ?, ?, ?, ?, ?)", (key, value, now, namespace_val, etag, last_modified))

    cursor.connection.commit()



def clear_caches(cache_types=None):
    """
    General function to clear specified cache types.
    - cache_types: List of strings (e.g., ['main', 'meta', 'providers', 'debrid', 'search']) or None for all.
    - Maintains ability to call individual functions separately.
    - Uses improved exception handling for robustness.
    """
    if cache_types is None:
        cache_types = ['main', 'meta', 'providers', 'debrid', 'search']

    cache_functions = {
        'main': _clear_main_cache,
        'meta': _clear_meta_cache,
        'providers': _clear_providers_cache,
        'debrid': _clear_debrid_cache,
        'search': _clear_search_cache
    }

    for cache_type in cache_types:
        if cache_type in cache_functions:
            try:
                cache_functions[cache_type]()
                c.log(f"[CM Debug @ clear_caches] Successfully cleared {cache_type} cache")
            except Exception as e:
                c.log(f"[CM Debug @ clear_caches] Failed to clear {cache_type} cache: {e}")
        else:
            c.log(f"[CM Debug @ clear_caches] Unknown cache type: {cache_type}")

def _clear_main_cache():
    """Clear main cache tables (cache_table, rel_list, rel_lib)."""
    try:
        cursor = _get_connection_cursor()
        for t in [cache_table, 'rel_list', 'rel_lib']:
            try:
                cursor.execute(f"DROP TABLE IF EXISTS {t}")
                cursor.execute("VACUUM")
                cursor.connection.commit()
            except OperationalError as e:
                c.log(f"[CM Debug @ _clear_main_cache] SQLite error clearing table '{t}': {e}")
            except Exception as e:
                c.log(f"[CM Debug @ _clear_main_cache] Unexpected error clearing table '{t}': {e}")
    except Exception as e:
        c.log(f"[CM Debug @ _clear_main_cache] Failed to initialize cursor: {e}")

def _clear_meta_cache():
    """Clear meta cache tables (meta)."""
    try:
        cursor = _get_connection_cursor_meta()
        for t in ['meta']:
            try:
                cursor.execute(f"DROP TABLE IF EXISTS {t}")
                cursor.execute("VACUUM")
                cursor.connection.commit()
            except OperationalError as e:
                c.log(f"[CM Debug @ _clear_meta_cache] SQLite error clearing table '{t}': {e}")
            except Exception as e:
                c.log(f"[CM Debug @ _clear_meta_cache] Unexpected error clearing table '{t}': {e}")
    except Exception as e:
        c.log(f"[CM Debug @ _clear_meta_cache] Failed to initialize cursor: {e}")

def _clear_providers_cache():
    """Clear providers cache tables (rel_src, rel_url)."""
    try:
        cursor = _get_connection_cursor_providers()
        for t in ['rel_src', 'rel_url']:
            try:
                cursor.execute(f"DROP TABLE IF EXISTS {t}")
                cursor.execute("VACUUM")
                cursor.connection.commit()
            except OperationalError as e:
                c.log(f"[CM Debug @ _clear_providers_cache] SQLite error clearing table '{t}': {e}")
            except Exception as e:
                c.log(f"[CM Debug @ _clear_providers_cache] Unexpected error clearing table '{t}': {e}")
    except Exception as e:
        c.log(f"[CM Debug @ _clear_providers_cache] Failed to initialize cursor: {e}")

def _clear_debrid_cache():
    """Clear debrid cache tables (debrid_data)."""
    try:
        cursor = _get_connection_cursor_debrid()
        for t in ['debrid_data']:
            try:
                cursor.execute(f"DROP TABLE IF EXISTS {t}")
                cursor.execute("VACUUM")
                cursor.connection.commit()
            except OperationalError as e:
                c.log(f"[CM Debug @ _clear_debrid_cache] SQLite error clearing table '{t}': {e}")
            except Exception as e:
                c.log(f"[CM Debug @ _clear_debrid_cache] Unexpected error clearing table '{t}': {e}")
    except Exception as e:
        c.log(f"[CM Debug @ _clear_debrid_cache] Failed to initialize cursor: {e}")

def _clear_search_cache():
    """Clear search cache tables (tvshow, movies)."""
    try:
        cursor = _get_connection_cursor_search()
        for t in ['tvshow', 'movies']:
            try:
                cursor.execute(f"DROP TABLE IF EXISTS {t}")
                cursor.execute("VACUUM")
                cursor.connection.commit()
            except OperationalError as e:
                c.log(f"[CM Debug @ _clear_search_cache] SQLite error clearing table '{t}': {e}")
            except Exception as e:
                c.log(f"[CM Debug @ _clear_search_cache] Unexpected error clearing table '{t}': {e}")
    except Exception as e:
        c.log(f"[CM Debug @ _clear_search_cache] Failed to initialize cursor: {e}")

# Keep individual functions for backward compatibility and separate calls
def cache_clear():
    _clear_main_cache()

def cache_clear_meta():
    _clear_meta_cache()

def cache_clear_providers():
    _clear_providers_cache()

def cache_clear_debrid():
    _clear_debrid_cache()

def cache_clear_search():
    _clear_search_cache()

# Update cache_clear_all to use the new general function
def cache_clear_all():
    clear_caches()  # Clears all by default

def cache_clear_all_old():
    cache_clear()
    cache_clear_meta()
    cache_clear_providers()
    cache_clear_debrid()

def _get_connection_cursor():
    conn = _get_connection()
    return conn.cursor()

def _get_connection():
    control.makeFile(control.dataPath)
    conn = db.connect(control.cacheFile)
    conn.row_factory = _dict_factory
    return conn

def _get_connection_cursor_meta():
    conn = _get_connection_meta()
    return conn.cursor()

def _get_connection_meta():
    control.makeFile(control.dataPath)
    conn = db.connect(control.metacacheFile)
    conn.row_factory = _dict_factory
    return conn

def _get_connection_cursor_providers():
    conn = _get_connection_providers()
    return conn.cursor()

def _get_connection_providers():
    control.makeFile(control.dataPath)
    conn = db.connect(control.providercacheFile)
    conn.row_factory = _dict_factory
    return conn

def _get_connection_cursor_debrid():
    conn = _get_connection_debrid()
    return conn.cursor()

def _get_connection_debrid():
    control.makeFile(control.dataPath)
    conn = db.connect(control.dbFile)
    conn.row_factory = _dict_factory
    return conn

def _get_connection_cursor_search():
    conn = _get_connection_search()
    return conn.cursor()

def _get_connection_search():
    control.makeFile(control.dataPath)
    conn = db.connect(control.searchFile)
    conn.row_factory = _dict_factory
    return conn

def _dict_factory(cursor, row):
    d = {}
    for idx, col in enumerate(cursor.description):
        d[col[0]] = row[idx]
    return d


def _hash_function(function_instance, *args):
    return _get_function_name(function_instance) + _generate_md5(args)


def _get_function_name(function_instance):
    return re.sub(r'.+\smethod\s|.+function\s|\sat\s.+|\sof\s.+', '', repr(function_instance))


def _generate_md5(*args):
    md5_hash = hashlib.md5()
    args = utils.traverse(args)
    for arg in args:
        if isinstance(arg, str):
            md5_hash.update(arg.encode('utf-8', errors='replace'))
        elif isinstance(arg, bytes):
            md5_hash.update(arg)
        else:
            md5_hash.update(str(arg).encode('utf-8', errors='replace'))
    return str(md5_hash.hexdigest())


def _is_cache_valid(cached_time, cache_timeout):
    now = int(time.time())
    diff = now - cached_time
    return (cache_timeout * 3600) > diff


def cache_version_check():
    if _find_cache_version():
        control.infoDialog(control.lang(32057), sound=True, icon='INFO') # Keep calm and expect us!


def _find_cache_version():
    version_file = os.path.join(control.dataPath, 'cache.v')
    try:
        with open(version_file, 'r', encoding="utf8") as fh:
            old_version = fh.read()
    except:
        old_version = '0'

    try:
        cur_version = control.addon('script.module.thecrew').getAddonInfo('version')
        if old_version != cur_version:
            with open(version_file, 'w', encoding="utf8") as fh:
                fh.write(cur_version)
            return True
        return False
    except:
        return False