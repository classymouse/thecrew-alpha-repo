# -*- coding: utf-8 -*-

'''
 ***********************************************************
 * The Crew Add-on
 *
 *
 * @file scenerls.py
 * @package script.module.thecrew
 *
 * @copyright (c) 2023, The Crew
 * @license GNU General Public License, version 3 (GPL-3.0)
 *
 ********************************************************cm*
'''

import re
from urllib.parse import parse_qs, urljoin, urlparse, urlencode, quote_plus

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import debrid
from resources.lib.modules import source_utils
from resources.lib.modules import cfscrape
from resources.lib.modules.crewruntime import c


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['scene-rls.com', 'scene-rls.net']
        self.base_link = 'http://scene-rls.net'
        self.search_link = '/?s=%s&submit=Find'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urlencode(url)
            return url
        except Exception as e:
            c.scraper_error('Exception in movie method', exc_info=e)
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urlencode(url)
            return url
        except Exception as e:
            c.scraper_error('Exception in tvshow method', exc_info=e)
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None:
                return

            # Accept either a query-string or a dict; normalize to a simple dict of scalars
            if isinstance(url, dict):
                _data = {k: (v[0] if isinstance(v, (list, tuple)) else v) for k, v in url.items()}
            else:
                _data = parse_qs(url)
                _data = {k: (_data[k][0] if _data[k] else '') for k in _data}

            _data['title'], _data['premiered'], _data['season'], _data['episode'] = title, premiered, season, episode
            url = urlencode(_data)
            return url
        except Exception as e:
            c.scraper_error('Exception in episode method', exc_info=e)
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []

            if url is None:
                return sources

            if debrid.status() is False:
                raise Exception()

            hostDict = hostprDict + hostDict

            # Accept either a query-string or a dict; normalize to a simple dict of scalars
            if isinstance(url, dict):
                data = {k: (v[0] if isinstance(v, (list, tuple)) else v) for k, v in url.items()}
            else:
                data = parse_qs(url)
                data = {k: (data[k][0] if data[k] else '') for k in data}

            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
            title = cleantitle.get_query(title)

            hdlr = f"s{int(data['season']):02d}e{int(data['episode']):02d}" if 'tvshowtitle' in data else data['year']

            query = f"{title} s{int(data['season']):02d}e{int(data['episode']):02d}" if 'tvshowtitle' in data else f"{title} {data['year']}"
            query = re.sub(r'(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', ' ', query)

            items = []

            try:
                url = self.search_link % quote_plus(query)
                url = urljoin(self.base_link, url)

                r = client.request(url)
                if not r:
                    c.log(f"[SceneRLS] Empty or None response for {url}")
                    posts = []
                else:
                    r = c.ensure_text(r, errors='replace')

                    # Detect blocking/empty responses
                    if not r or 'Just a moment' in r or 'Enable JavaScript and cookies' in r or '404 Not Found' in r:
                        c.log(f"[SceneRLS] Blocked or empty response for {url}")
                        posts = []
                    else:
                        posts = client.parseDom(r, 'div', attrs={'class': 'post'}) or []

                for post in posts:
                    try:
                        u = client.parseDom(post, "div", attrs={"class": "postContent"}) or []
                        size = re.findall(r'((?:\d+\,\d+\.\d+|\d+\.\d+|\d+\,\d+|\d+)\s*(?:GiB|MiB|GB|MB))', u[0])[0] if u else '0'
                        u = client.parseDom(u, "h2") or []
                        u = client.parseDom(u, 'a', ret='href') or []
                        u = [(i.strip('/').split('/')[-1], i, size) for i in u]
                        items += u
                    except Exception as e:
                        c.log(f"[SceneRLS] Error parsing post: {e}")
                        continue
            except Exception as e:
                c.log(f"[SceneRLS] Search request failed: {e}")
                posts = []

            if not items:
                c.log('[SceneRLS] No items found from search')

            for item in items:
                try:
                    name = item[0]
                    name = client.replaceHTMLCodes(name)

                    t = re.sub(r'(\.|\(|\[|\s)(\d{4}|S\d*E\d*|S\d*|3D)(\.|\)|\]|\s|)(.+|)', '', name)

                    if cleantitle.get(t) != cleantitle.get(title):
                        continue

                    quality, info = source_utils.get_release_quality(name, item[1])

                    try:
                        dsize, isize = source_utils._size(item[2])
                    except Exception:
                        dsize, isize = 0.0, ''
                    info.insert(0, isize)

                    info = ' | '.join(info)

                    url = item[1]
                    if any(x in url for x in ['.rar', '.zip', '.iso']):
                        continue
                    url = client.replaceHTMLCodes(url)
                    url = c.ensure_text(url)

                    try:
                        host_match = re.findall(r'([\w]+[.][\w]+)$', urlparse(url.strip().lower()).netloc)
                        host = host_match[0] if host_match else ''
                    except Exception:
                        host = ''

                    if not host or host not in hostDict:
                        continue

                    host = client.replaceHTMLCodes(host)
                    host = c.ensure_text(host)

                    sources.append({'source': host, 'quality': quality, 'language': 'en', 'url': url, 'info': info, 'direct': False, 'debridonly': True, 'size': dsize, 'name': name})
                except Exception as e:
                    c.log(f"[SceneRLS] Error processing item: {e}")
                    continue

            return sources
        except Exception as e:
            c.scraper_error('Exception in sources method', exc_info=e)
            return sources

    def resolve(self, url):
        return url
