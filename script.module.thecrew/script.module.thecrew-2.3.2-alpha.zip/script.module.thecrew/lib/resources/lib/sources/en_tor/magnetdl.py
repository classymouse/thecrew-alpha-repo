# -*- coding: utf-8 -*-

'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

from resources.lib.modules import debrid
from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import source_utils
from resources.lib.modules.crewruntime import c

from urllib.parse import parse_qs, urljoin, urlencode, quote_plus, quote


class source:
    pack_capable = True

    def __init__(self):
        self.priority = 1
        self.language = ['en']
        #self.domains = ['magnetdl.com']
        self.domains = ['magnetdl.hair']
        self.base_link = 'https://www.magnetdl.hair'
        self.search_link = '/{0}/{1}'

    def sources(self, data, hostDict):
        sources = []
        try:
            if debrid.status() is False:
                raise Exception()

            if not data:
                return sources

            title = data.get('tvshowtitle') if data.get('tvshowtitle') else data.get('title')
            hdlr = 'S%02dE%02d' % (int(data.get('season')), int(data.get('episode'))) if data.get('tvshowtitle') else data.get('year')

            query = '%s s%02de%02d' % (data.get('tvshowtitle'), int(data.get('season')), int(data.get('episode')))\
                if data.get('tvshowtitle') else '%s %s' % (data.get('title'), data.get('year'))
            query = re.sub(r'(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', ' ', query)

            url = urljoin(self.base_link, self.search_link.format(query[0].lower(), cleantitle.geturl(query)))

            r = client.request(url)
            r = client.parseDom(r, 'tbody')[0]
            posts = client.parseDom(r, 'tr')
            posts = [i for i in posts if 'magnet:' in i]
            for post in posts:
                post = post.replace('&nbsp;', ' ')
                name = client.parseDom(post, 'a', ret='title')[1]

                t = name.split(hdlr)[0]
                if not cleantitle.get(re.sub('(|)', '', t)) == cleantitle.get(title): continue

                try:
                    y = re.findall(r'[\.|\(|\[|\s|\_|\-](S\d+E\d+|S\d+)[\.|\)|\]|\s|\_|\-]', name, re.I)[-1].upper()
                except BaseException:
                    y = re.findall(r'[\.|\(|\[|\s\_|\-](\d{4})[\.|\)|\]|\s\_|\-]', name, re.I)[-1].upper()
                if y != hdlr:
                    continue

                links = client.parseDom(post, 'a', ret='href')
                magnet = [i.replace('&amp;', '&') for i in links if 'magnet:' in i][0]
                url = magnet.split('&tr')[0]

                quality, info = source_utils.get_release_quality(name, name)
                try:
                    size = re.findall('((?:\d+\,\d+\.\d+|\d+\.\d+|\d+\,\d+|\d+)\s*(?:GiB|MiB|GB|MB))', post)[0]
                    div = 1 if size.endswith(('GB', 'GiB')) else 1024
                    size = float(re.sub('[^0-9|/.|/,]', '', size.replace(',', '.'))) / div
                    size = '%.2f GB' % size
                except BaseException:
                    size = '0'
                info.append(size)
                info = ' | '.join(info)

                sources.append({
                    'source': 'Torrent', 'quality': quality, 'language': 'en', 'url': url,
                    'info': info,  'direct': False, 'debridonly': True})

            return sources
        except BaseException:
            return sources

    def sources_packs(self, data, hostDict, search_series=False, total_seasons=0, bypass_filter=0):
        sources = []
        try:
            if debrid.status() is False:
                return sources

            tvshowtitle = data.get('tvshowtitle')
            year = data.get('year')
            season = int(data.get('season', 0))
            imdb = data.get('imdb')
            aliases = data.get('aliases', [])

            if not tvshowtitle:
                return sources

            queries = []
            if search_series:
                queries.append(f'{tvshowtitle} Complete Series')
            else:
                queries.append(f'{tvshowtitle} S{season:02d}')

            for query in queries:
                try:
                    url = urljoin(self.base_link, self.search_link.format(query[0].lower(), cleantitle.geturl(query)))
                    r = client.request(url)
                    r = client.parseDom(r, 'tbody')[0]
                    posts = client.parseDom(r, 'tr')
                    posts = [i for i in posts if 'magnet:' in i]

                    for post in posts:
                        try:
                            post = post.replace('&nbsp;', ' ')
                            name = client.parseDom(post, 'a', ret='title')[1]

                            if search_series:
                                valid, last_season = source_utils.filter_show_pack(
                                    tvshowtitle, aliases, imdb, year, season,
                                    source_utils.release_title_format(name), total_seasons
                                )
                                if not valid:
                                    continue
                                package_meta = {'package': 'show', 'last_season': last_season}
                            else:
                                valid, episode_start, episode_end = source_utils.filter_season_pack(
                                    tvshowtitle, aliases, year, season,
                                    source_utils.release_title_format(name)
                                )
                                if not valid:
                                    continue
                                package_meta = {'package': 'season', 'episode_start': episode_start, 'episode_end': episode_end}

                            links = client.parseDom(post, 'a', ret='href')
                            magnet = [i.replace('&amp;', '&') for i in links if 'magnet:' in i][0]
                            url_magnet = magnet.split('&tr')[0]

                            quality, info = source_utils.get_release_quality(name, name)
                            try:
                                size = re.findall(r'((?:\d+\.\d+|\d+\,\d+|\d+)\s*(?:GB|GiB|MB|MiB))', name)[-1]
                                div = 1 if size.endswith(('GB', 'GiB')) else 1024
                                size = float(re.sub('[^0-9|/.|/,]', '', size.replace(',', '.'))) / div
                                size = '%.2f GB' % size
                            except BaseException:
                                size = '0'
                            info.append(size)
                            info = ' | '.join(info)

                            source_dict = {'source': 'Torrent', 'quality': quality, 'language': 'en',
                                         'url': url_magnet, 'info': info, 'direct': False, 'debridonly': True}
                            source_dict.update(package_meta)
                            sources.append(source_dict)
                        except BaseException:
                            continue
                except BaseException:
                    continue
            return sources
        except BaseException:
            return sources

    def resolve(self, url):
        return url
