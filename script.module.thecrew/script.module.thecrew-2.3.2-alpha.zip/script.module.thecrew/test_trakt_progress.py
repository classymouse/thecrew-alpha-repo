# -*- coding: utf-8 -*-
"""
Test file to diagnose Trakt API issues with the new Progress feature.
Can be run from Kodi Python console or imported as a module.

Usage from Kodi:
    import test_trakt_progress
    test_trakt_progress.run_all_tests()
"""

import sys
import os

def test_imports():
    """Test that all required modules can be imported."""
    print("\n=== Testing Imports ===")
    results = []

    try:
        # Add paths if not already in sys.path
        addon_path = os.path.join(os.path.dirname(__file__), 'lib','resources', 'lib')
        if addon_path not in sys.path:
            sys.path.insert(0, addon_path)

        from resources.lib.modules import trakt
        print("✓ trakt module imported")
        results.append(True)
    except Exception as e:
        print(f"✗ trakt import failed: {e}")
        results.append(False)

    try:
        from resources.lib.modules import control
        print("✓ control module imported")
        results.append(True)
    except Exception as e:
        print(f"✗ control import failed: {e}")
        results.append(False)

    try:
        from resources.lib.modules.crewruntime import c
        print("✓ crewruntime imported")
        results.append(True)
    except Exception as e:
        print(f"✗ crewruntime import failed: {e}")
        results.append(False)

    try:
        from resources.lib.models.tvshow import TVShow
        print("✓ TVShow model imported")
        results.append(True)
    except Exception as e:
        print(f"✗ TVShow import failed: {e}")
        results.append(False)

    try:
        from resources.lib.models.episode import Episode
        print("✓ Episode model imported")
        results.append(True)
    except Exception as e:
        print(f"✗ Episode import failed: {e}")
        results.append(False)

    try:
        from resources.lib.indexers.progress import Progress
        print("✓ Progress indexer imported")
        results.append(True)
    except Exception as e:
        print(f"✗ Progress import failed: {e}")
        import traceback
        traceback.print_exc()
        results.append(False)

    return all(results)

def test_trakt_connection():
    """Test basic Trakt API connection and headers."""
    print("\n=== Testing Trakt Connection ===")
    try:
        from modules import trakt
        from modules.crewruntime import c

        # Check if Trakt is authorized
        print(f"Trakt token exists: {bool(c.get_setting('trakt.token'))}")
        print(f"Trakt user: {c.get_setting('trakt.username')}")

        # Try to get Trakt credentials info
        creds = trakt.get_trakt_credentials_info()
        print(f"Trakt credentials valid: {bool(creds)}")

        # Show the headers that will be sent
        print("\nHeaders being sent to Trakt API:")
        print(f"  CLIENT_ID: {trakt.CLIENT_ID[:20]}...")
        print(f"  User-Agent: {trakt.USER_AGENT}")
        print(f"  trakt-api-version: 2")
        print(f"  Authorization: {'Bearer <token>' if c.get_setting('trakt.token') else 'Not authenticated'}")

        return True
    except Exception as e:
        print(f"✗ Trakt connection test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_simple_trakt_call():
    """Test a simple Trakt API call."""
    print("\n=== Testing Simple Trakt API Call ===")
    try:
        from resources.lib.modules import trakt

        # Try a simple API call that doesn't require auth
        print("Calling Trakt API: GET /movies/trending (public endpoint)")
        url = 'https://api.trakt.tv/movies/trending?limit=1'
        result = trakt.getTraktAsJson(url)

        if result and len(result) > 0:
            print(f"✓ API call successful! Got {len(result)} result(s)")
            movie_title = result[0].get('movie', {}).get('title', 'Unknown')
            print(f"  Sample result: {movie_title}")
            return True
        else:
            print("✗ API call returned empty or null result")
            print("  This might indicate a network or API issue")
            return False

    except Exception as e:
        print(f"✗ API call failed: {e}")
        print(f"  Error type: {type(e).__name__}")
        import traceback
        traceback.print_exc()
        return False

def test_watched_shows_call():
    """Test the watched shows API call (requires auth)."""
    print("\n=== Testing Watched Shows API Call (Auth Required) ===")
    try:
        from resources.lib.modules import trakt
        from resources.lib.modules.crewruntime import c

        # Check auth first
        if not c.get_setting('trakt.token'):
            print("⚠ No Trakt token found - skipping authenticated call")
            print("  This is expected if you haven't authorized Trakt yet")
            return None  # Skip, not fail

        print("Calling Trakt API: GET /sync/watched/shows?extended=full")
        url = 'https://api.trakt.tv/sync/watched/shows?extended=full'
        result = trakt.getTraktAsJson(url)

        if result and len(result) > 0:
            print(f"✓ API call successful! Got {len(result)} show(s)")
            # Show details of first show
            show = result[0]
            show_info = show.get('show', {})
            print(f"  First show: {show_info.get('title', 'Unknown')}")
            print(f"  Seasons watched: {len(show.get('seasons', []))}")
            print(f"  Total plays: {show.get('plays', 0)}")
            return True
        elif result is not None and len(result) == 0:
            print("✓ API call successful but returned 0 shows")
            print("  You may not have watched anything yet")
            return True
        else:
            print("✗ API call returned null/None")
            print("  This suggests an API error")
            return False

    except Exception as e:
        print(f"✗ API call failed: {e}")
        print(f"  Error type: {type(e).__name__}")
        print(f"  Error message: {str(e)}")
        import traceback
        traceback.print_exc()
        return False
resources.lib.modules.crewruntime import c
        from resources.lib.indexers.progress import Progress

        # Check auth first
        if not c.get_setting('trakt.token'):
            print("⚠ No Trakt token found - skipping Progress test")
            print("  Progress feature requires Trakt authorization")
            return None  # Skip, not fail

        print("Creating Progress instance...")
        progress = Progress()
        print("✓ Progress instance created")

        print("Testing get_in_progress_shows() method...")
        print("  (This calls Trakt API and processes results)")

        # Call the method - it returns None but creates directory listing
        # We're just testing that it doesn't crash
        result = progress.get_in_progress_shows()

        print(f"✓ Method executed successfully")
        print(f"  Return value type: {type(result).__name__}")

        # If we got this far without exception, it worked
        return True

    except Exception as e:
        print(f"✗ Progress test failed: {e}")
        print(f"  Error type: {type(e).__name__}")
        print(f"  Error message: {str(e)}")

        # Show which line failed
        import traceback
        print("\n  Full traceback:")
    except Excep70)
    print("TRAKT PROGRESS DIAGNOSTIC TEST")
    print("For: script.module.thecrew - Progress Feature")
    print("=" * 70)

    results = {}

    # Test 1: Imports
    print("\n[1/5] Testing imports...")
    results['imports'] = test_imports()

    if not results['imports']:
        print("\n⚠ Import test failed - cannot continue with remaining tests")
        print("  Please check that addon files are installed correctly")
        print_summary(results)
        return results

    # Test 2: Connection
    print("\n[2/5] Testing Trakt connection...")
    results['connection'] = test_trakt_connection()

    # Test 3: Simple API call
    print("\n[3/5] Testing simple API call...")
    results['simple_call'] = test_simple_trakt_call()

    # Test 4: Watched shows call
    print("\n[4/5] Testing authenticated API call...")
    results['watched_shows'] = test_watched_shows_call()

    # Test 5: Progress method
    print("\n[5/5] Testing Progress feature...")
    results['progress'] = test_progress_in_progress_shows()

    # Summary
    print_summary(results)
    return results
"""
    Run tests when executed as script.
    Can also import and call run_all_tests() from Kodi Python console.
    """
    print("\nDiagnostic Test Runner")
    print("----------------------")
    print("This will test the Trakt Progress feature implementation")
    print()

    try:
        results = run_all_tests()

        print("\n" + "=" * 70)
        print("Test execution completed")
        print("=" * 70)

    except KeyboardInterrupt:
        print("\n\n⚠ Test interrupted by user")
    except Exception as e:
        print(f "\n\n✗ Unexpected error during test execution: {e}")
        import traceback
        traceback.print_exc()

    # Keep window open if running from command line
    try:
        input("\nPress Enter to exit..."

    for test_name, result in results.items():
        status = status_map.get(result, "? UNKNOWN")
        print(f"{test_name:20s}: {status}")

    # Count results
    passed = sum(1 for r in results.values() if r is True)
    failed = sum(1 for r in results.values() if r is False)
    skipped = sum(1 for r in results.values() if r is None)

    print("=" * 70)
    print(f"Passed: {passed} | Failed: {failed} | Skipped: {skipped} | Total: {len(results)}")
    print("=" * 70)

    if failed > 0:
        print("\n⚠ Some tests failed - check errors above")
    elif skipped == len(results):
        print("\n⚠ All tests skipped - likely missing Trakt authorization")
    elif passed == len(results):
        print("\n✓ All tests passed - Progress feature should work!")
    else:
        print(f"\n⚠ {passed} tests passed, {skipped} skipped" test_progress_in_progress_shows()

    # Summary
    print("\n" + "=" * 60)
    print("TEST SUMMARY")
    print("=" * 60)
    for test_name, result in results.items():
        status = "✓ PASS" if result is True else ("⚠ SKIP" if result is None else "✗ FAIL")
        print(f"{test_name:20s}: {status}")

    print("\n" + "=" * 60)

if __name__ == '__main__':
    """
    Run tests when executed as script.
    Can also import and call run_all_tests() from Kodi Python console.
    """
    print("\nDiagnostic Test Runner")
    print("----------------------")
    print("This will test the Trakt Progress feature implementation")
    print()

    try:
        results = run_all_tests()

        print("\n" + "=" * 70)
        print("Test execution completed")
        print("=" * 70)

    except KeyboardInterrupt:
        print("\n\n⚠ Test interrupted by user")
    except Exception as e:
        print(f"\n\n✗ Unexpected error during test execution: {e}")
        import traceback
        traceback.print_exc()

    # Keep window open if running from command line
    try:
        input("\nPress Enter to exit...")
    except:
        pass
