# Moved from tests/debug_load_module.py
# Use a relative path to the project when running locally
import importlib.util, os, sys
module_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'lib', 'resources', 'lib', 'sources', 'en_tor', 'yourbittorrent.py'))
spec = importlib.util.spec_from_file_location('testmod', module_path)
mod = importlib.util.module_from_spec(spec)
try:
    spec.loader.exec_module(mod)
    print('module loaded')
    if hasattr(mod, 'source'):
        try:
            s = mod.source()
            print('source() returned type', type(s))
        except Exception as e:
            print('source() raised', e)
    else:
        print('no source()')
except Exception as e:
    print('exec_module failed', e)
    import traceback
    traceback.print_exc()