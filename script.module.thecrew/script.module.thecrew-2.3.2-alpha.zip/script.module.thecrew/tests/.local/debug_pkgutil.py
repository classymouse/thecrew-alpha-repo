# Moved from tests/debug_pkgutil.py
# Use relative paths when running locally
import pkgutil, os
base = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'lib', 'resources', 'lib', 'sources', 'en'))
print('path exists', os.path.isdir(base))
for loader, module_name, is_pkg in pkgutil.walk_packages([base]):
    print('found', module_name, 'pkg?', is_pkg, 'loader', type(loader))