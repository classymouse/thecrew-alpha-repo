# Moved from tests/tmp_analyze_log.py
# Preserved for local debugging only

import re
from collections import defaultdict
logfile = None
call_re = re.compile(r'Calling (movie|tvshow) source "([^"]+)"')
no_res_re = re.compile(r'No results from source ([^\n\r]+)')
exception_re = re.compile(r'Exception while calling ([^:]+): (.+)')
loaded_re = re.compile(r'Loaded (\d+) scrapers from ([^\n\r]+)')

# (script truncated)