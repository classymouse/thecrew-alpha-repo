# Moved from tests/tmp_check_torrentio.py
# Preserved for local debugging
import requests

url='https://torrentio.strem.fun/stream/movie/tt5519340.json'
try:
    r=requests.get(url, headers={'User-Agent':'Mozilla/5.0'}, timeout=15)
    print('status', r.status_code)
    print('ct', r.headers.get('content-type'))
    print('len text', len(r.text))
    try:
        j=r.json()
        print('keys', list(j.keys()))
        streams=j.get('streams')
        if streams is None:
            print('no streams key')
        else:
            print('streams len', len(streams))
            if len(streams)>0:
                print(streams[0])
    except Exception as e:
        print('json error', e)
except Exception as e:
    print('request error', e)
