# Moved from tests/tmp_fetch_1337x.py
# Preserved local debug script for manual runs
import requests
q='Bright 2017'
url=f'https://1337x.to/sort-category-search/{requests.utils.quote(q)}/Movies/size/desc/1/'
print('url',url)
try:
    r=requests.get(url, headers={'User-Agent':'Mozilla/5.0'}, timeout=15)
    print('status', r.status_code)
    print('len', len(r.text))
    print(r.text[:2000])
except Exception as e:
    print('error', e)
