# Moved from tests/tmp_provider_summary.py
# See tests/.local/tmp_provider_summary.py for preserved local debugging script

import re
import ast
from collections import defaultdict

import sys
logfile = sys.argv[1] if len(sys.argv) > 1 else None

returned_re = re.compile(r'\[Sources\]\s+([^\s]+)\s+returned\s+(\d+)\s+items\s+\(debridonly=(\d+),\s*non-debrid=(\d+)\)\s+providers=(\[.*\])')
nores_re = re.compile(r'\[Sources\] No results from source ([^\n\r]+)')
loaded_re = re.compile(r'Loaded (\d+) scrapers from ([^\n\r]+)')

provider_totals = defaultdict(lambda: {'total': 0, 'debrid': 0, 'non_debrid': 0, 'lines': 0})
no_results = defaultdict(int)
loaded = defaultdict(int)

if logfile:
    with open(logfile, 'r', encoding='utf-8', errors='ignore') as fh:
        for line in fh:
            m = returned_re.search(line)
            if m:
                src = m.group(1).strip()
                total = int(m.group(2))
                debrid = int(m.group(3))
                non_debrid = int(m.group(4))
                provs = m.group(5)
                try:
                    prov_list = ast.literal_eval(provs)
                except Exception:
                    prov_list = []
                provider_totals[src]['total'] += total
                provider_totals[src]['debrid'] += debrid
                provider_totals[src]['non_debrid'] += non_debrid
                provider_totals[src]['lines'] += 1
                continue
            m = nores_re.search(line)
            if m:
                name = m.group(1).strip()
                no_results[name] += 1
                continue
            m = loaded_re.search(line)
            if m:
                count = int(m.group(1))
                key = m.group(2).strip()
                loaded[key] += count

# Compute totals and top providers
all_providers = sorted(provider_totals.items(), key=lambda x: x[1]['total'], reverse=True)

total_items = sum(v['total'] for v in provider_totals.values())
total_debrid = sum(v['debrid'] for v in provider_totals.values())
total_non_debrid = sum(v['non_debrid'] for v in provider_totals.values())

print('Loaded packs:')
for k,v in loaded.items():
    print(f'  {k}: {v}')

print('\nOverall totals:')
print(f'  providers reporting: {len(provider_totals)}')
print(f'  total items: {total_items} (debridonly={total_debrid}, non-debrid={total_non_debrid})')

print('\nTop 10 providers by returned items:')
for i,(name,stats) in enumerate(all_providers[:10], 1):
    kind = 'gear' if name.startswith('gearsscrapers.') else 'internal'
    print(f'{i:2d}. {name} ({kind}) — total={stats['total']}, debrid={stats['debrid']}, non-debrid={stats['non_debrid']}, lines={stats['lines']}')

print('\nProviders with NoResults (count):')
for name,count in sorted(no_results.items(), key=lambda x: x[0]):
    print(f'  {name}: {count}')

print('\nAll providers summary (sorted by total desc):')
for name, stats in all_providers:
    kind = 'gear' if name.startswith('gearsscrapers.') else 'internal'
    print(f'  {name:40} {kind:8} total={stats['total']:5} debrid={stats['debrid']:5} non-debrid={stats['non_debrid']:5} lines={stats['lines']}')
