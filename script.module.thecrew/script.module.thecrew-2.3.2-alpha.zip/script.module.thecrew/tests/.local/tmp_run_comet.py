# Moved from tests/tmp_run_comet.py
# This script was relocated to tests/.local/ to avoid running as part of the test suite.
# Original content preserved for local debugging by developers.

import sys, os, importlib.util, types, json
lib_parent = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
gearlib = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'script.module.gearsscrapers', 'lib'))
# Add gearsscrapers lib dir to path
if gearlib not in sys.path:
    sys.path.insert(0, gearlib)
# Minimal xbmc stub required by gearsscrapers.modules.control
if 'xbmc' not in sys.modules:
    class _XBMCStub:
        def getCondVisibility(self, *a, **k):
            return False
        def getLocalizedString(self, *a, **k):
            return ''
        def getInfoLabel(self, *a, **k):
            return ''
        def log(self, *a, **k):
            print('[xbmc]', *a)
        def executebuiltin(self, *a, **k):
            return None
        def executeJSONRPC(self, *a, **k):
            return '{}'
        class Monitor:
            def __init__(self, *a, **k):
                pass
            def abortRequested(self):
                return False
    sys.modules['xbmc'] = _XBMCStub()
if 'xbmcaddon' not in sys.modules:
    class _AddonStub:
        def __init__(self, *a, **k):
            self._settings = {}
        def getSetting(self, id=None, *args, **kwargs):
            return self._settings.get(id, '')
        def getLocalizedString(self, k):
            return str(k)
        def getAddonInfo(self, id=None, **kwargs):
            return ''
    sys.modules['xbmcaddon'] = types.SimpleNamespace(Addon=_AddonStub)
if 'xbmcgui' not in sys.modules:
    class _Dialog:
        def notification(self, *a, **k): return True
    class _Window:
        def __init__(self, *a, **k):
            self._props = {}
        def setProperty(self, k, v): self._props[k] = v
    class _DialogProgress:
        def create(self, *a, **k): pass
        def update(self, *a, **k): return True
        def iscanceled(self): return False
        def close(self): pass
    sys.modules['xbmcgui'] = types.SimpleNamespace(Dialog=_Dialog, ListItem=object, Window=_Window, DialogProgress=_DialogProgress)

# Prepare minimal gearshims
if 'gearsscrapers.modules.log_utils' not in sys.modules:
    m = types.ModuleType('gearsscrapers.modules.log_utils')
    m.log = lambda *a, **k: print('[GLOG]', *a)
    m.request_error = lambda url, *a, **k: print('[GLOG] Request-Error url=({})'.format(url))
    sys.modules['gearsscrapers.modules.log_utils'] = m
if 'gearsscrapers.modules.source_utils' not in sys.modules:
    su = types.ModuleType('gearsscrapers.modules.source_utils')
    su.scraper_error = lambda name, *a, **k: print('[GERR]', name)
    su.get_undesirables = lambda: []
    su.check_foreign_audio = lambda: False
    su.clean_name = lambda s: s
    su.check_title = lambda title, aliases, name, hdlr=None, year=None: (str(title).lower() in str(name).lower() or any(str(a).lower() in str(name).lower() for a in (aliases or [])) or (year and str(year) in str(name)))
    su.info_from_name = lambda name, title, year, hdlr, episode_title=None: {'raw': name}
    su.remove_lang = lambda *a, **k: False
    su.remove_undesirables = lambda *a, **k: False
    su.get_release_quality = lambda name, url=None: ('720p', [])
    su._size = lambda s: (0, '')
    sys.modules['gearsscrapers.modules.source_utils'] = su
# Minimal client using requests
try:
    import requests
except Exception:
    requests = None
class ClientStub:
    @staticmethod
    def request(url, timeout=10):
        print('[Client] fetching', url)
        if requests:
            r = requests.get(url, headers={'User-Agent':'Mozilla/5.0'}, timeout=timeout)
            return r.text
        raise Exception('requests not available')
sys.modules['gearsscrapers.modules.client'] = types.SimpleNamespace(request=ClientStub.request)

# Import comet provider module file directly
spec = importlib.util.spec_from_file_location('gearsscrapers.providers.torrents.comet', os.path.join(gearlib, 'gearsscrapers', 'providers', 'torrents', 'comet.py'))
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

s = mod.source()
print('=== Calling sources ===')
data = {'title':'Bright','localtitle':'Bright','aliases':[],'year':'2017','imdb':'tt5519340'}
res = s.sources(data, {})
print('Returned count:', len(res))
if res:
    for r in res[:3]:
        print('-', r)
