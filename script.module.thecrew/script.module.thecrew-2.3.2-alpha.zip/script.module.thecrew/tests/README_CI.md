This document has been moved to `docs/README_CI.md`.

Please see `docs/README_CI.md` for details.
