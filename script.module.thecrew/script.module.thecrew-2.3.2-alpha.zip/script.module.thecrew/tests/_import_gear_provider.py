import sys, importlib, os
gearlib = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'script.module.gearsscrapers', 'lib'))
if gearlib not in sys.path:
    sys.path.insert(0, gearlib)
try:
    mod = importlib.import_module('gearsscrapers.providers.torrentio')
    print('import ok, has source:', hasattr(mod, 'source'), 'type:', type(getattr(mod, 'source', None)))
except Exception as e:
    print('import error:', e)