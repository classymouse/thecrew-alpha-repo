from resources.lib.modules.sources import Sources

class _GearProviderMinimal:
    def movie(self, *a, **k):
        return None

s = Sources()
print('gearsscrapers_enabled=', getattr(s, 'gearsscrapers_enabled', None), '_gearsscrapers_setting_explicit=', getattr(s, '_gearsscrapers_setting_explicit', None))
sd = [('gearsscrapers.providers.torrents.minimal', _GearProviderMinimal())]
filtered, content = s.filter_source_dict(None, sd)
print('filtered:', filtered)
print('content:', content)
