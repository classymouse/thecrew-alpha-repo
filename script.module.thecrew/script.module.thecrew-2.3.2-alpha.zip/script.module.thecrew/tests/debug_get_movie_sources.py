from resources.lib.modules.sources import Sources
import traceback
s = Sources()
source_dict = [
    ('resources.lib.sources.en_tor.torrentio', None, 0),
    ('resources.lib.sources.en_tor.glodls', None, 0),
    ('gearsscrapers.providers.torrents.example', None, 0),
]
try:
    mains, labels = s.get_movie_episode_sources('Test', 2017, 'tt0000', '0', None, None, None, None, source_dict, 'movie', [])
    print('mains:', mains)
    print('labels:', labels)
except Exception as e:
    print('EXCEPTION:')
    traceback.print_exc()
