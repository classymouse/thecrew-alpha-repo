# Moved to tests/.local/debug_load_module.py
print('debug_load_module moved to tests/.local/debug_load_module.py')
