# Moved to tests/.local/debug_pkgutil.py
print('debug_pkgutil moved to tests/.local/debug_pkgutil.py')
