import os
import sqlite3
from resources.lib.modules import control, db_schema, crewruntime
# Setup: create legacy cache.v
addon_data_dir = os.path.dirname(control.dataPath)
pv_dir = os.path.join(addon_data_dir, 'plugin.video.thecrew')
os.makedirs(pv_dir, exist_ok=True)
cache_v = os.path.join(pv_dir, 'cache.v')
with open(cache_v, 'w', encoding='utf-8') as f:
    f.write('1.0.0')
# create fake DB files
for p in (control.cacheFile, control.viewsFile):
    if not p:
        continue
    d = os.path.dirname(p) or os.getcwd()
    os.makedirs(d, exist_ok=True)
    with open(p, 'w', encoding='utf-8') as f:
        f.write('dummy')
# Remove traktsyncFile if exists
if os.path.exists(control.traktsyncFile):
    try:
        os.remove(control.traktsyncFile)
    except Exception:
        pass
# Force pluginversion
crewruntime.c.pluginversion='2.2.0'
# Run check
print('Running check_and_migrate_version...')
db_schema.check_and_migrate_version()
# Inspect schema_migrations
conn=sqlite3.connect(control.traktsyncFile)
rows=list(conn.cursor().execute('SELECT name, applied_at FROM schema_migrations').fetchall())
print('schema_migrations rows:', rows)
# Inspect service table
print('service rows:', list(conn.cursor().execute('SELECT setting, value FROM service').fetchall()))
# Check backups in cache dir
cache_dir = os.path.dirname(control.cacheFile) or os.getcwd()
backups = [p for p in os.listdir(cache_dir) if p.startswith(os.path.basename(control.cacheFile) + '.bak')]
print('backups:', backups)
# show cache.v exists?
print('legacy cache.v exists?', os.path.exists(cache_v))
