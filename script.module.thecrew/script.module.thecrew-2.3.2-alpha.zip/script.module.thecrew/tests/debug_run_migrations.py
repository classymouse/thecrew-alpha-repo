from resources.lib.modules import db_schema, crewruntime
import sqlite3
# Clean any previous test migrations
db_schema.MIGRATIONS[:] = [m for m in db_schema.MIGRATIONS if not m['name'].startswith('test_upgrade_report')]
print('MIGRATIONS before:', db_schema.MIGRATIONS)
ran={'v':False}
def fn():
    ran['v']=True

# Register and run
db_schema.register_migration('test_upgrade_report_2','2.1.0',fn)
print('MIGRATIONS after register:', db_schema.MIGRATIONS)
# Set legacy recorded version
db_schema._set_service_setting('addon_version','2.0.0')
# Ensure plugin current version set
crewruntime.c.pluginversion='2.2.0'
# Clear one-time flag
db_schema._set_service_setting('upgrade_report_shown_2.2.0','0')
# Test run migrations helper directly
print('_run_migrations returned:', db_schema._run_migrations('2.0.0','2.2.0'))
# Run check
db_schema.check_and_migrate_version()
print('ran:', ran['v'])
# Inspect schema_migrations table
import resources.lib.modules.control as control
conn = sqlite3.connect(control.traktsyncFile)
rows = [r for r in conn.cursor().execute('SELECT name, applied_at FROM schema_migrations').fetchall()]
print('schema_migrations rows:', rows)
# Inspect service table
rows2 = [r for r in conn.cursor().execute("SELECT setting, value FROM service").fetchall()]
print('service rows:', rows2)
