import os, sys
lib_parent = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
resources_dir = os.path.join(lib_parent, 'lib', 'resources', 'lib', 'sources')
print('sources dir exists?', os.path.isdir(resources_dir))
for root, dirs, files in os.walk(resources_dir):
    print('ROOT', root)
    print('DIRS', dirs[:10])
    pyfiles = [f for f in files if f.endswith('.py')]
    print('PYFILES sample', pyfiles[:20])
    break

# print subdirectories computed by module
from resources.lib.sources import all_files
print('all_files:', all_files)