import importlib
import sys
import traceback

try:
    importlib.invalidate_caches()
    importlib.import_module('resources.lib.sources')
    print('Imported resources.lib.sources OK')
except Exception as e:
    traceback.print_exc()
    print('IMPORT FAILED:', e)
    sys.exit(1)
