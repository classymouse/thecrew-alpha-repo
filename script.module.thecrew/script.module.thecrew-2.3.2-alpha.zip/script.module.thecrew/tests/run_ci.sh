#!/usr/bin/env bash
set -euo pipefail

# Simple CI runner that mirrors what GitHub Actions does locally.
# Usage: ./tests/run_ci.sh

python -m pip install --upgrade pip
pip install pytest
pytest -q
