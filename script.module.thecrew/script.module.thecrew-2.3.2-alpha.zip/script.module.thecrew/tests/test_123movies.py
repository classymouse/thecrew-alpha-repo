# Smoke test for 123movies parser
import sys, os, importlib.util
# Reuse the same minimal stubs approach as test_rlsbb
lib_parent = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'lib'))
if lib_parent not in sys.path:
    sys.path.insert(0, lib_parent)

import types
# minimal xbmc/xbmcaddon/xbmcgui/xmcvfs stubs (same as in test_rlsbb)
if 'xbmc' not in sys.modules:
    sys.modules['xbmc'] = types.SimpleNamespace(getInfoLabel=lambda *a, **k: '21.3.0', getCondVisibility=lambda *a, **k: False, log=lambda *a, **k: None, getLocalizedString=lambda *a, **k: '')
if 'xbmcaddon' not in sys.modules:
    class _AddonStub:
        def __init__(self, addon_id=None):
            self._settings = {}
            self.addon_id = addon_id
        def getSetting(self, id=None, *args, **kwargs):
            return self._settings.get(id, '0')
        def getLocalizedString(self, k):
            return str(k)
        def getSettingInfo(self, k):
            return ''
        def getAddonInfo(self, id=None, key=None):
            return ''
        def setSetting(self, id, value):
            self._settings[id] = value
    sys.modules['xbmcaddon'] = types.SimpleNamespace(Addon=_AddonStub)
if 'xbmcgui' not in sys.modules:
    class _DialogStub:
        def notification(self, *args, **kwargs):
            return True
        def ok(self, *args, **kwargs):
            return True
    class _ListItemStub:
        def __init__(self, *args, **kwargs):
            pass
    sys.modules['xbmcgui'] = types.SimpleNamespace(Dialog=_DialogStub, ListItem=_ListItemStub)
if 'xbmcplugin' not in sys.modules:
    sys.modules['xbmcplugin'] = types.SimpleNamespace(setProperty=lambda *a, **k: None)
if 'xbmcvfs' not in sys.modules:
    sys.modules['xbmcvfs'] = types.SimpleNamespace(translatePath=lambda x: x)

# Minimal resources.lib.modules stubs
if 'resources' not in sys.modules:
    resources = types.ModuleType('resources')
    sys.modules['resources'] = resources
if 'resources.lib' not in sys.modules:
    sys.modules['resources.lib'] = types.ModuleType('resources.lib')
if 'resources.lib.modules' not in sys.modules:
    modpkg = types.ModuleType('resources.lib.modules')
    cleantitle = types.SimpleNamespace(get_query=lambda x: x, geturl=lambda x: x)
    client = types.SimpleNamespace(parseDom=lambda *a, **k: [], replaceHTMLCodes=lambda x: x, ensure_text=lambda x, **k: x, ensure_str=lambda x, **k: str(x))
    debrid = types.SimpleNamespace(status=lambda: True)
    source_utils = types.SimpleNamespace(get_release_quality=lambda x: ('SD', []))
    cfscrape = types.SimpleNamespace(create_scraper=lambda: None)
    c_stub = types.SimpleNamespace(log=lambda *a, **k: None, ensure_text=lambda x, **k: x, ensure_str=lambda x, **k: str(x))
    directstream = types.SimpleNamespace(googlepass=lambda url: url)
    modpkg.cleantitle = cleantitle
    modpkg.client = client
    modpkg.debrid = debrid
    modpkg.source_utils = source_utils
    modpkg.cfscrape = cfscrape
    modpkg.directstream = directstream
    modpkg.crewruntime = types.SimpleNamespace(c=c_stub)
    sys.modules['resources.lib.modules'] = modpkg
    crewruntime_mod = types.ModuleType('resources.lib.modules.crewruntime')
    crewruntime_mod.c = c_stub
    sys.modules['resources.lib.modules.crewruntime'] = crewruntime_mod

# Load 123movies module via importlib
spec = importlib.util.spec_from_file_location('resources.lib.sources.en.123movies', os.path.join(os.path.dirname(__file__), '..', 'lib', 'resources', 'lib', 'sources', 'en', '123movies.py'))
mod = importlib.util.module_from_spec(spec)
# Ensure relative imports resolve properly by setting package context
mod.__package__ = 'resources.lib.sources.en'
spec.loader.exec_module(mod)

# Fake scraper and response
class FakeResp:
    def __init__(self, status=200, text='<div class="les-content"></div>'):
        self.status_code = status
        self.text = text

class FakeScraper:
    def get(self, url, timeout=None):
        return FakeResp()

# Monkeypatch stub
orig_create = sys.modules['resources.lib.modules'].cfscrape.create_scraper
sys.modules['resources.lib.modules'].cfscrape.create_scraper = lambda: FakeScraper()

s = mod.source()
res = s.sources('imdb=tt5519340&title=Bright&year=2017&aliases=[]', hostDict=['example'], hostprDict=[])
print('123movies sources result length:', len(res))

# Restore
sys.modules['resources.lib.modules'].cfscrape.create_scraper = orig_create
