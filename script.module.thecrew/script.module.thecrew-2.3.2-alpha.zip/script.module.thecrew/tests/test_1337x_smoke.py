# Smoke test for internal 1337x provider
import pytest
pytestmark = pytest.mark.integration
import sys, os, importlib.util, types
lib_parent = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
lib_lib_dir = os.path.abspath(os.path.join(lib_parent, 'lib'))
resources_lib = os.path.abspath(os.path.join(lib_parent, 'lib', 'resources', 'lib'))
# Ensure package paths are importable
if lib_lib_dir not in sys.path:
    sys.path.insert(0, lib_lib_dir)
if resources_lib not in sys.path:
    sys.path.insert(0, resources_lib)

# minimal runtime stubs
if 'xbmc' not in sys.modules:
    sys.modules['xbmc'] = types.SimpleNamespace(getInfoLabel=lambda *a, **k: '21.3.0', getCondVisibility=lambda *a, **k: False, getLocalizedString=lambda *a, **k: '', executeJSONRPC=lambda *a, **k: '{}', executebuiltin=lambda *a, **k: None, Keyboard=lambda *a, **k: None, Monitor=lambda *a, **k: types.SimpleNamespace(abortRequested=lambda : False), getSkinDir=lambda *a, **k: 'skin', Player=lambda *a, **k: None, PlayList=lambda *a, **k: None, PLAYLIST_VIDEO=1, LOGDEBUG=0, LOGINFO=1, LOGERROR=2)
if 'xbmcaddon' not in sys.modules:
    class _AddonStub:
        def __init__(self, *args, **kwargs):
            self._settings = {}
        def getSetting(self, id=None, *args, **kwargs):
            return self._settings.get(id, '')
        def setSetting(self, id, value):
            self._settings[id] = value
        def getLocalizedString(self, k):
            return str(k)
        def getAddonInfo(self, id=None, **kwargs):
            return ''
    sys.modules['xbmcaddon'] = types.SimpleNamespace(Addon=_AddonStub)
if 'xbmcgui' not in sys.modules:
    class _Dialog: pass
    sys.modules['xbmcgui'] = types.SimpleNamespace(
        Dialog=_Dialog,
        ListItem=object,
        Window=lambda *a, **k: None,
        DialogProgress=lambda *a, **k: None,
        DialogProgressBG=lambda *a, **k: None,
        WindowDialog=lambda *a, **k: None,
        ControlButton=lambda *a, **k: None,
        ControlImage=lambda *a, **k: None,
        getCurrentWindowDialogId=lambda *a, **k: 0,
        Keyboard=lambda *a, **k: None
    )
if 'xbmcvfs' not in sys.modules:
    sys.modules['xbmcvfs'] = types.SimpleNamespace(
        exists=lambda *a, **k: True,
        translatePath=lambda x: x,
        makeLegalFilename=lambda x: x,
        File=lambda *a, **k: None,
        mkdir=lambda *a, **k: None,
        delete=lambda *a, **k: None,
        rmdir=lambda *a, **k: None,
        listdir=lambda *a, **k: ([], [])
    )
if 'xbmcplugin' not in sys.modules:
    sys.modules['xbmcplugin'] = types.SimpleNamespace(setResolvedUrl=lambda *a, **k: None, addDirectoryItem=lambda *a, **k: None, endOfDirectory=lambda *a, **k: None, addDirectoryItems=lambda *a, **k: None, setContent=lambda *a, **k: None, addSortMethod=lambda *a, **k: None, setProperty=lambda *a, **k: None)
# stub crewruntime.c and debrid to avoid heavy init
import importlib
import types as _types
# crewruntime stub
_crewruntime = _types.ModuleType('resources.lib.modules.crewruntime')
_crewruntime.c = _types.SimpleNamespace(log=lambda *a, **k: None, ensure_text=lambda x, **k: x, scraper_error=lambda *a, **k: None, get_setting=lambda *a, **k: '', name='thecrew', pluginversion='1.0.0', moduleversion='1.0.0', kodiversion='21.3.0', platform='windows')
sys.modules['resources.lib.modules.crewruntime'] = _crewruntime
sys.modules['resources.lib.modules.crewruntime'] = _crewruntime
# debrid stub
_debrid = _types.ModuleType('resources.lib.modules.debrid')
_debrid.debrid_resolvers = []
_debrid.status = lambda *a, **k: True
sys.modules['resources.lib.modules.debrid'] = _debrid

# ensure client uses requests
try:
    import requests
except Exception:
    requests = None
class ClientStub:
    @staticmethod
    def request(url, timeout=10):
        if requests:
            r = requests.get(url, headers={'User-Agent':'Mozilla/5.0'}, timeout=timeout)
            return r.text
        raise Exception('requests not available')
# inject client
sys.modules['resources.lib.modules.client'] = _types.SimpleNamespace(request=ClientStub.request, parseDom=lambda *a, **k: [])

# import 1337x provider file directly
module_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'lib', 'resources', 'lib', 'sources', 'en_tor', '1337x.py'))
# Prefer package import so relative imports work; fallback to file import
try:
    mod = importlib.import_module('resources.lib.sources.en_tor.1337x')
except Exception:
    spec = importlib.util.spec_from_file_location('1337x_local', module_path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

s = mod.source()
print('Calling 1337x.sources...')
data = {'title':'Bright','localtitle':'Bright','aliases':[],'year':'2017','imdb':'tt5519340'}
res = s.sources(data, {})
print('Returned:', len(res))
if res:
    for r in res[:3]:
        print('-', r)
else:
    print('No results from 1337x (smoke)')
