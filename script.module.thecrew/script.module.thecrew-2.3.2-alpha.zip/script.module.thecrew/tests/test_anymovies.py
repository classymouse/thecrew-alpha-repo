# Smoke test for anymovies parser
import sys, os, importlib.util
lib_parent = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'lib'))
if lib_parent not in sys.path:
    sys.path.insert(0, lib_parent)

import types
if 'resources' not in sys.modules:
    resources = types.ModuleType('resources')
    sys.modules['resources'] = resources
if 'resources.lib' not in sys.modules:
    sys.modules['resources.lib'] = types.ModuleType('resources.lib')
if 'resources.lib.modules' not in sys.modules:
    modpkg = types.ModuleType('resources.lib.modules')
    source_utils = types.SimpleNamespace(is_host_valid=lambda u,h: (True,'example.com'))
    client = types.SimpleNamespace(request=lambda *a, **k: '', agent=lambda: 'agent')
    modpkg.source_utils = source_utils
    modpkg.client = client
    modpkg.crewruntime = types.SimpleNamespace(c=types.SimpleNamespace(log=lambda *a, **k: print(*a)))
    sys.modules['resources.lib.modules'] = modpkg
    crewruntime_mod = types.ModuleType('resources.lib.modules.crewruntime')
    crewruntime_mod.c = types.SimpleNamespace(log=lambda *a, **k: print(*a))
    sys.modules['resources.lib.modules.crewruntime'] = crewruntime_mod

spec = importlib.util.spec_from_file_location('resources.lib.sources.en.anymovies', os.path.join(os.path.dirname(__file__), '..', 'lib', 'resources', 'lib', 'sources', 'en', 'anymovies.py'))
mod = importlib.util.module_from_spec(spec)
# Ensure relative imports resolve properly by setting package context
mod.__package__ = 'resources.lib.sources.en'
spec.loader.exec_module(mod)
import re
s = mod.source()

# Test blocked
mod.client.request = lambda *a, **k: '<html>404 Not Found</html>'
res = s.sources('imdb=tt0000000&title=Test&year=2017', hostDict=['example.com'], hostprDict=[])
print('anymovies blocked result length:', len(res))

# Test valid search
html = 'class="result_title"><a href="https://example.com/post/1">Test Movie 2017</a></div>'
page_html = '<span class="text"><a href="https://video.example.com/vid1" target="_blank">Watch</a></span>'
mod.client.request = lambda url, **k: html if 'search.php' in url else page_html
# debug
post = mod.client.request('https://www.downloads-anymovies.com/search.php?zoom_query=test')
print('post:', post)
links = re.compile(r'class="result_title"><a href="(.+?)">(.+?)</a></div>').findall(post)
print('links found:', links)
# replicate inner loop for debug
for _url, data in links:
    page = mod.client.request(_url)
    print('fetched page for', _url, '->', page)
    found = re.findall(r'<span class="text"><a href="(.+?)" target="_blank">', page) or []
    print('found outgoing links on page:', found)
    for link in found:
        valid, host = mod.source_utils.is_host_valid(link, ['example.com'])
        print('is_host_valid ->', valid, host)

res = s.sources('imdb=tt0000000&title=Test+Movie&year=2017', hostDict=['example.com'], hostprDict=[])
print('anymovies valid result length:', len(res))
print('anymovies result:', res)