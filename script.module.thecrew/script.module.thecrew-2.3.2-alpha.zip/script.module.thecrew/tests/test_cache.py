import json
import time
import pytest

from resources.lib.modules import cache


def setup_function(function):
    # Ensure a clean slate before each test
    cache.cache_clear_all()


def test_cache_basic_and_expiry(monkeypatch):
    calls = {'c': 0}

    def f(x):
        calls['c'] += 1
        return {'x': x, 'count': calls['c']}

    # initial call computes and stores
    v1 = cache.get(lambda: f('a'), 2)
    assert v1 == {'x': 'a', 'count': 1}

    # second call should return cached value (no new computation)
    v2 = cache.get(lambda: f('a'), 2)
    assert v2 == {'x': 'a', 'count': 1}
    assert calls['c'] == 1

    # simulate time passing beyond TTL (2 hours)
    orig_time = time.time()
    monkeypatch.setattr(time, 'time', lambda: orig_time + (2 * 3600) + 10)

    v3 = cache.get(lambda: f('a'), 2)
    assert v3 == {'x': 'a', 'count': 2}
    assert calls['c'] == 2


def test_cache_key_value_and_table():
    key = 'test-key-123'
    data = {'a': 1}

    # insert with table
    cache.cache_insert(key, json.dumps(data), table='meta')

    row = cache.cache_get(key, table='meta')
    assert row is not None
    assert json.loads(row['value']) == data

    # query with wrong table returns None
    assert cache.cache_get(key, table='other') is None


def test_cache_non_string_args():
    calls = {'c': 0}

    def f(a, b):
        calls['c'] += 1
        return {'a': a, 'b': b, 'count': calls['c']}

    # Use non-string args: int, dict
    v1 = cache.get(lambda: f(1, {'k': 'v'}), 1)
    assert v1['count'] == 1

    # Cached result should be returned on subsequent calls
    v2 = cache.get(lambda: f(1, {'k': 'v'}), 1)
    assert v2['count'] == 1


@pytest.mark.parametrize('duration', [0, 1])
def test_get_with_duration_zero(duration):
    calls = {'c': 0}

    def f():
        calls['c'] += 1
        return 'ok'

    v1 = cache.get(f, duration)
    v2 = cache.get(f, duration)

    if duration == 0:
        # duration 0 means always recalc
        assert calls['c'] >= 2
    else:
        assert calls['c'] == 1


def test_get_with_etag_200_and_304(monkeypatch):
    # Ensure clean cache
    cache.cache_clear_all()

    key = 'test-etag'
    body_v1 = {'a': 1}
    headers_v1 = {'ETag': 'W/"1"', 'Last-Modified': 'Mon, 01 Feb 2026 00:00:00 GMT'}

    # Fetcher that returns 200 on first call, then 304 on second call
    calls = {'c': 0}

    def fetcher(conditional):
        calls['c'] += 1
        if calls['c'] == 1:
            return (json.dumps(body_v1), headers_v1, 200)
        else:
            return ('', {}, 304)

    # First call should store and return body_v1
    r1 = cache.get_with_etag(key, fetcher, ttl_seconds=1, namespace='test')
    assert r1 == body_v1

    # Simulate TTL expiry by sleeping 2 seconds
    import time as _time
    _time.sleep(2)

    # Second call should get 304 and return cached value
    r2 = cache.get_with_etag(key, fetcher, ttl_seconds=1, namespace='test')
    assert r2 == body_v1

    # Now simulate a 200 with new content
    body_v2 = {'a': 2}

    def fetcher2(conditional):
        return (json.dumps(body_v2), {'ETag': 'W/"2"', 'Last-Modified': 'Mon, 01 Feb 2026 00:01:00 GMT'}, 200)

    r3 = cache.get_with_etag(key, fetcher2, ttl_seconds=1, namespace='test')
    assert r3 == body_v2
