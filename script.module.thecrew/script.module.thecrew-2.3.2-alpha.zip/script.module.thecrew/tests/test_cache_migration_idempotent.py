import os
import sqlite3
import pytest
from resources.lib.modules import control, cache


def test_migration_recorded_once(tmp_path):
    # Use control.cacheFile from conftest (temporary test dir)
    dbfile = control.cacheFile
    try:
        if os.path.exists(dbfile):
            os.remove(dbfile)
    except Exception:
        pass

    conn = sqlite3.connect(dbfile)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()

    # Load the real cache module directly from file to avoid test stubs
    import importlib.util
    cache_path = os.path.join(os.getcwd(), 'lib', 'resources', 'lib', 'modules', 'cache.py')
    spec = importlib.util.spec_from_file_location('real_cache', cache_path)
    real_cache = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(real_cache)

    # Use public API to trigger schema creation; call twice to simulate repeated calls
    real_cache.cache_insert('test.migration.key', 'value', table='test')
    real_cache.cache_insert('test.migration.key', 'value', table='test')

    # Check schema_migrations for single cache_v2 row
    cur.execute("SELECT count(*) as cnt FROM schema_migrations WHERE name = ?", ('cache_v2',))
    row = cur.fetchone()
    assert row and row['cnt'] == 1, f"Expected one cache_v2 row, found {row['cnt'] if row else 'none'}"

    conn.close()