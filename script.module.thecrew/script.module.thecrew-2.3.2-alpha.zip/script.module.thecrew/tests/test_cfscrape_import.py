def test_import_cfscrape():
    import cfscrape

    # module should expose either create_scraper or get_cookie_string
    assert hasattr(cfscrape, "create_scraper") or hasattr(cfscrape, "get_cookie_string")

    # call the functions to ensure no immediate errors
    if hasattr(cfscrape, "create_scraper"):
        s = cfscrape.create_scraper()
        # ensure a minimal interface
        assert hasattr(s, "get")

    if hasattr(cfscrape, "get_cookie_string"):
        cookies = cfscrape.get_cookie_string("https://example.com")
        assert isinstance(cookies, tuple)
