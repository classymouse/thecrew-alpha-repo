# Smoke test for cmovieshd parser
import sys, os, importlib.util
lib_parent = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'lib'))
if lib_parent not in sys.path:
    sys.path.insert(0, lib_parent)

import types
if 'resources' not in sys.modules:
    resources = types.ModuleType('resources')
    sys.modules['resources'] = resources
if 'resources.lib' not in sys.modules:
    sys.modules['resources.lib'] = types.ModuleType('resources.lib')
if 'resources.lib.modules' not in sys.modules:
    modpkg = types.ModuleType('resources.lib.modules')
    cleantitle = types.SimpleNamespace(geturl=lambda x: x)
    client = types.SimpleNamespace(request=lambda *a, **k: '', parseDom=lambda *a, **k: [])
    source_utils = types.SimpleNamespace(get_release_quality=lambda q,u: ('HD', None), is_host_valid=lambda u,h: (True,'example.com'))
    c_stub = types.SimpleNamespace(log=lambda *a, **k: None)
    modpkg.cleantitle = cleantitle
    modpkg.client = client
    modpkg.source_utils = source_utils
    modpkg.crewruntime = types.SimpleNamespace(c=c_stub)
    sys.modules['resources.lib.modules'] = modpkg
    crewruntime_mod = types.ModuleType('resources.lib.modules.crewruntime')
    crewruntime_mod.c = c_stub
    sys.modules['resources.lib.modules.crewruntime'] = crewruntime_mod

spec = importlib.util.spec_from_file_location('resources.lib.sources.en.cmovieshd', os.path.join(os.path.dirname(__file__), '..', 'lib', 'resources', 'lib', 'sources', 'en', 'cmovieshd.py'))
mod = importlib.util.module_from_spec(spec)
# Ensure relative imports resolve properly by setting package context
mod.__package__ = 'resources.lib.sources.en'
spec.loader.exec_module(mod)

s = mod.source()
# Blocked response
mod.client.request = lambda *a, **k: '<html>404 Not Found</html>'
res = s.sources({'imdb':'tt0000000','title':'Test','year':'2017'}, hostDict=['example.com'], hostprDict=[])
print('cmovieshd blocked result length:', len(res))

# Valid response
html = 'class="quality">HD</span> data-video="//video.example.com/vid1"'
mod.client.request = lambda *a, **k: html
res = s.sources({'imdb':'tt0000000','title':'Test','year':'2017'}, hostDict=['example.com'], hostprDict=[])
print('cmovieshd valid result length:', len(res))
print('cmovieshd result:', res)