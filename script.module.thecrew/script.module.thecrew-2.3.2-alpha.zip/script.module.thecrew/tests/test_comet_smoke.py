# Smoke test for Gearsscrapers comet provider
import pytest
pytestmark = pytest.mark.integration
import os, sys, importlib.util, types

# Prepare import paths (same as harness)
lib_parent = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
gearlib = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'script.module.gearsscrapers', 'lib'))
if gearlib not in sys.path:
    sys.path.insert(0, gearlib)

# Minimal xbmc stubs
if 'xbmc' not in sys.modules:
    class _XBMCStub:
        def getCondVisibility(self, *a, **k): return False
        def getLocalizedString(self, *a, **k): return ''
        def getInfoLabel(self, *a, **k): return ''
        def log(self, *a, **k): pass
        def executebuiltin(self, *a, **k): pass
        def executeJSONRPC(self, *a, **k): return '{}'
        class Monitor:
            def __init__(self, *a, **k): pass
            def abortRequested(self): return False
    sys.modules['xbmc'] = _XBMCStub()

if 'xbmcaddon' not in sys.modules:
    class _AddonStub:
        def __init__(self, *a, **k): self._settings = {}
        def getSetting(self, id=None, *args, **kwargs): return self._settings.get(id, '')
        def getLocalizedString(self, k): return str(k)
        def getAddonInfo(self, id=None, **kwargs): return ''
    sys.modules['xbmcaddon'] = types.SimpleNamespace(Addon=_AddonStub)

if 'xbmcgui' not in sys.modules:
    class _Dialog: pass
    class _Window:
        def __init__(self, *a, **k):
            self._props = {}
        def setProperty(self, k, v): self._props[k] = v
        def getProperty(self, k): return self._props.get(k, '')
    class _DialogProgress:
        def create(self,*a,**k): pass
        def update(self,*a,**k): return True
        def iscanceled(self): return False
    sys.modules['xbmcgui'] = types.SimpleNamespace(Dialog=_Dialog, ListItem=object, Window=_Window, DialogProgress=_DialogProgress)

if 'xbmcvfs' not in sys.modules:
    class _FileStub:
        def __init__(self,*a,**k): pass
        def read(self): return ''
        def write(self,*a,**k): pass
        def close(self): pass
    def _listdir(x):
        try: return (os.listdir(x), [])
        except Exception: return ([],[])
    sys.modules['xbmcvfs'] = types.SimpleNamespace(exists=lambda *a, **k: True, translatePath=lambda x: x, delete=lambda *a, **k: None, listdir=_listdir, File=_FileStub, mkdir=lambda *a, **k: None, mkdirs=lambda *a, **k: None, makeLegalFilename=lambda x: x, rename=lambda *a, **k: None)

# Gearshims
if 'gearsscrapers.modules.log_utils' not in sys.modules:
    m = types.ModuleType('gearsscrapers.modules.log_utils')
    m.log = lambda *a, **k: None
    m.request_error = lambda url, *a, **k: None
    sys.modules['gearsscrapers.modules.log_utils'] = m
if 'gearsscrapers.modules.source_utils' not in sys.modules:
    su = types.ModuleType('gearsscrapers.modules.source_utils')
    su.scraper_error = lambda name, *a, **k: None
    su.get_undesirables = lambda: []
    su.check_foreign_audio = lambda: False
    su.clean_name = lambda s: s
    su.check_title = lambda title, aliases, name, hdlr=None, year=None: (str(title).lower() in str(name).lower() or any(str(a).lower() in str(name).lower() for a in (aliases or [])) or (year and str(year) in str(name)))
    su.info_from_name = lambda name, title, year, hdlr, episode_title=None: {'raw': name}
    su.remove_lang = lambda *a, **k: False
    su.remove_undesirables = lambda *a, **k: False
    su.get_release_quality = lambda name, url=None: ('720p', [])
    su._size = lambda s: (0, '')
    sys.modules['gearsscrapers.modules.source_utils'] = su

# Minimal client
try:
    import requests
except Exception:
    requests = None
class ClientStub:
    @staticmethod
    def request(url, timeout=10):
        if requests:
            return requests.get(url, headers={'User-Agent':'Mozilla/5.0'}, timeout=timeout).text
        raise Exception('requests not available')
sys.modules['gearsscrapers.modules.client'] = types.SimpleNamespace(request=ClientStub.request)

# Import provider and run
spec = importlib.util.spec_from_file_location('gearsscrapers.providers.torrents.comet', os.path.join(gearlib, 'gearsscrapers', 'providers', 'torrents', 'comet.py'))
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

s = mod.source()
print('Comet provider created; performing smoke run...')
data = {'title':'Bright','localtitle':'Bright','aliases':[],'year':'2017','imdb':'tt5519340'}
res = s.sources(data, {})
print('Returned count:', len(res))
assert len(res) > 0, 'Comet provider returned no sources'
print('Smoke test passed')

if __name__ == '__main__':
    pass
