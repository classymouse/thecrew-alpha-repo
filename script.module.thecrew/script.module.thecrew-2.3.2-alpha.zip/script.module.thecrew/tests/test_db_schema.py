import os
import sqlite3
from resources.lib.modules import control
from resources.lib.modules import db_schema


def _table_columns(dbpath, table):
    conn = sqlite3.connect(dbpath)
    cur = conn.cursor()
    cur.execute(f"PRAGMA table_info({table})")
    rows = cur.fetchall()
    conn.close()
    return [r[1] for r in rows]


def _ensure_clean(dbpath):
    # If the file exists but is not a valid sqlite DB, back it up and recreate (best-effort)
    try:
        if os.path.exists(dbpath):
            import sqlite3 as _sqlite
            try:
                _conn = _sqlite.connect(dbpath)
                _cur = _conn.cursor()
                # use a generic pragma that will error on corrupt db
                _cur.execute("PRAGMA integrity_check")
                _conn.close()
            except _sqlite.DatabaseError:
                try:
                    # try backing up first
                    from resources.lib.modules import db_schema as _dbs
                    _dbs._backup_file(dbpath)
                    # recreate minimal DB depending on filename
                    base = os.path.basename(dbpath)
                    if base == 'views.db':
                        _dbs._create_fresh_db(dbpath, ["CREATE TABLE IF NOT EXISTS views (skin TEXT, view_type TEXT, view_id TEXT, UNIQUE(skin, view_type));"])
                    elif base == 'cache.db':
                        _dbs._create_fresh_db(dbpath, ["CREATE TABLE IF NOT EXISTS cache (key TEXT PRIMARY KEY, value TEXT, date INTEGER, namespace TEXT);"])
                    else:
                        # generic recreate
                        _dbs._create_fresh_db(dbpath, [])
                except Exception:
                    try:
                        os.remove(dbpath)
                    except Exception:
                        pass
    except Exception:
        pass


def test_views_created(tmp_path):
    # Use isolated temp dir per-test to avoid interference
    control.dataPath = str(tmp_path)
    control.viewsFile = os.path.join(control.dataPath, 'views.db')
    control.cacheFile = os.path.join(control.dataPath, 'cache.db')

    vfile = control.viewsFile
    # Clean potentially corrupt files left by other tests
    _ensure_clean(vfile)
    _ensure_clean(control.cacheFile)

    # Ensure schemas are present
    db_schema.ensure_all()

    assert os.path.exists(vfile), "views DB file should be created"
    cols = _table_columns(vfile, 'views')
    assert 'skin' in cols and 'view_type' in cols and 'view_id' in cols


def test_cache_schema_created(tmp_path):
    # Use isolated temp dir per-test to avoid interference
    control.dataPath = str(tmp_path)
    control.viewsFile = os.path.join(control.dataPath, 'views.db')
    control.cacheFile = os.path.join(control.dataPath, 'cache.db')

    cfile = control.cacheFile
    # Leave any existing DB alone (it may be used by other tests); ensure schemas are present
    db_schema.ensure_all()

    assert os.path.exists(cfile), "cache DB file should be created"
    cols = _table_columns(cfile, 'cache')
    for expected in ('key', 'value', 'date', 'namespace', 'etag', 'last_modified'):
        assert expected in cols, f"Expected {expected} in cache table columns"

    # schema_migrations should exist
    # If it does, the pragma will return rows else an empty list
    conn = sqlite3.connect(cfile)
    cur = conn.cursor()
    cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='schema_migrations'")
    assert cur.fetchone() is not None
    conn.close()


def test_idempotent_calls(tmp_path):
    # Use isolated temp dir per-test to avoid interference
    control.dataPath = str(tmp_path)
    control.viewsFile = os.path.join(control.dataPath, 'views.db')
    control.cacheFile = os.path.join(control.dataPath, 'cache.db')

    # Ensure running ensure_all twice does not raise and doesn't change schema
    db_schema.ensure_all()
    db_schema.ensure_all()
    # quick sanity check: views table still present
    conn = sqlite3.connect(control.viewsFile)
    cur = conn.cursor()
    cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='views'")
    assert cur.fetchone() is not None
    conn.close()


def test_startup_invokes_schema(monkeypatch):
    called = {'v': False}

    def _mark():
        called['v'] = True

    # Prevent network calls by stubbing tmdb_get_json
    import resources.lib.modules.http_client as http_client
    monkeypatch.setattr(http_client, 'tmdb_get_json', lambda *a, **k: {})

    monkeypatch.setattr(db_schema, 'ensure_all', _mark)

    # Call startupMaintenance; our patched ensure_all should be invoked
    control.startupMaintenance()
    assert called['v'] is True


def test_trakt_tables_created(tmp_path):
    tfile = control.traktsyncFile
    db_schema.ensure_all()
    conn = sqlite3.connect(tfile)
    cur = conn.cursor()
    for table in ('watched', 'scrobble_queue'):
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table,))
        assert cur.fetchone() is not None, f"Expected {table} in traktsync DB"
    conn.close()


def test_search_and_bookmarks_created(tmp_path):
    db_schema.ensure_all()
    # search
    conn = sqlite3.connect(control.searchFile)
    cur = conn.cursor()
    cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='movies'")
    assert cur.fetchone() is not None
    conn.close()

    # bookmarks
    conn = sqlite3.connect(control.bookmarksFile)
    cur = conn.cursor()
    for table in ('bookmarks', 'bookmark'):
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table,))
        assert cur.fetchone() is not None
    conn.close()
