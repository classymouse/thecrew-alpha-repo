import os
import sqlite3
from resources.lib.modules import control
from resources.lib.modules import db_schema
from resources.lib.modules import crewruntime


def test_register_and_run_migration(tmp_path, monkeypatch):
    # Ensure traktsync DB fresh
    if os.path.exists(control.traktsyncFile):
        try:
            os.remove(control.traktsyncFile)
        except Exception:
            pass

    # Setup: recorded old version
    monkeypatch.setattr(crewruntime.c, 'pluginversion', '2.2.0')
    db_schema._set_service_setting('addon_version', '2.0.0')

    applied = {'ran': False}

    def _fn():
        applied['ran'] = True
        # create a table to indicate migration executed
        conn = sqlite3.connect(control.traktsyncFile)
        cur = conn.cursor()
        cur.execute("CREATE TABLE IF NOT EXISTS mig_test (id INTEGER)")
        conn.commit()
        conn.close()

    # register migration for 2.1.0
    db_schema.register_migration('test_mig_2_1', '2.1.0', _fn)

    # Capture logs and infoDialog
    logs = []
    monkeypatch.setattr(db_schema.c, 'log', lambda *a, **k: logs.append(a[0]))
    dialog_called = {'v': False}
    monkeypatch.setattr(control, 'infoDialog', lambda msg: dialog_called.update({'v': True}))

    # Run check
    db_schema.check_and_migrate_version()

    # Assert migration function ran and table exists
    assert applied['ran'] is True
    conn = sqlite3.connect(control.traktsyncFile)
    cur = conn.cursor()
    cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='mig_test'")
    assert cur.fetchone() is not None

    # Migration recorded
    cur.execute("SELECT name FROM schema_migrations WHERE name = 'test_mig_2_1'")
    assert cur.fetchone() is not None
    conn.close()

    assert any('Applied migration test_mig_2_1' in l for l in logs)
    assert dialog_called['v'] is True

    # cleanup: remove the registered test migration so other tests aren't affected
    db_schema.MIGRATIONS[:] = [m for m in db_schema.MIGRATIONS if m['name'] != 'test_mig_2_1']
