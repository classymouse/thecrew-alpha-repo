# Smoke test for easynews parser
import sys, os, importlib.util
# Reuse the same minimal stubs approach as test_rlsbb/test_123movies
lib_parent = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'lib'))
if lib_parent not in sys.path:
    sys.path.insert(0, lib_parent)

import types
# minimal xbmc/xbmcaddon/xbmcgui/xbmcvfs stubs
if 'xbmc' not in sys.modules:
    sys.modules['xbmc'] = types.SimpleNamespace(getInfoLabel=lambda *a, **k: '21.3.0', getCondVisibility=lambda *a, **k: False, log=lambda *a, **k: None, getLocalizedString=lambda *a, **k: '')
if 'xbmcaddon' not in sys.modules:
    class _AddonStub:
        def __init__(self, addon_id=None):
            self._settings = {}
            self.addon_id = addon_id
        def getSetting(self, id=None, *args, **kwargs):
            return self._settings.get(id, '')
        def getLocalizedString(self, k):
            return str(k)
        def getSettingInfo(self, k):
            return ''
        def getAddonInfo(self, id=None, key=None):
            return ''
        def setSetting(self, id, value):
            self._settings[id] = value
    sys.modules['xbmcaddon'] = types.SimpleNamespace(Addon=_AddonStub)
if 'xbmcgui' not in sys.modules:
    class _DialogStub:
        def notification(self, *args, **kwargs):
            return True
        def ok(self, *args, **kwargs):
            return True
    class _ListItemStub:
        def __init__(self, *args, **kwargs):
            pass
    sys.modules['xbmcgui'] = types.SimpleNamespace(Dialog=_DialogStub, ListItem=_ListItemStub)
if 'xbmcplugin' not in sys.modules:
    sys.modules['xbmcplugin'] = types.SimpleNamespace(setProperty=lambda *a, **k: None)
if 'xbmcvfs' not in sys.modules:
    sys.modules['xbmcvfs'] = types.SimpleNamespace(translatePath=lambda x: x)

# Minimal resources.lib.modules stubs
if 'resources' not in sys.modules:
    resources = types.ModuleType('resources')
    sys.modules['resources'] = resources
if 'resources.lib' not in sys.modules:
    sys.modules['resources.lib'] = types.ModuleType('resources.lib')
if 'resources.lib.modules' not in sys.modules:
    modpkg = types.ModuleType('resources.lib.modules')
    cleantitle = types.SimpleNamespace(get_query=lambda x: x, geturl=lambda x: x, normalize=lambda x: x)
    client = types.SimpleNamespace(parseDom=lambda *a, **k: [], replaceHTMLCodes=lambda x: x, ensure_text=lambda x, **k: x, ensure_str=lambda x, **k: str(x))
    debrid = types.SimpleNamespace(status=lambda: True)
    source_utils = types.SimpleNamespace(get_release_quality=lambda x: ('SD', []), get_file_type=lambda x: 'MKV')
    cfscrape = types.SimpleNamespace(create_scraper=lambda: None)
    c_stub = types.SimpleNamespace(log=lambda *a, **k: None, ensure_text=lambda x, **k: x, ensure_str=lambda x, **k: str(x))
    control = types.SimpleNamespace(setting=lambda k: '')
    directstream = types.SimpleNamespace(googlepass=lambda url: url)
    modpkg.cleantitle = cleantitle
    modpkg.client = client
    modpkg.debrid = debrid
    modpkg.control = control
    modpkg.source_utils = source_utils
    modpkg.cfscrape = cfscrape
    modpkg.directstream = directstream
    modpkg.crewruntime = types.SimpleNamespace(c=c_stub)
    sys.modules['resources.lib.modules'] = modpkg
    crewruntime_mod = types.ModuleType('resources.lib.modules.crewruntime')
    crewruntime_mod.c = c_stub
    sys.modules['resources.lib.modules.crewruntime'] = crewruntime_mod

# Load easynews module via importlib
spec = importlib.util.spec_from_file_location('measy', os.path.join(os.path.dirname(__file__), '..', 'lib', 'resources', 'lib', 'sources', 'en', 'easynews.py'))
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

# Helpers to fake requests behavior
class FakeResp:
    def __init__(self, status=200, text='{}'):
        self.status_code = status
        self.text = text

class FakeRequests:
    def __init__(self, resp):
        self._resp = resp
    def get(self, url, params=None, headers=None, timeout=None):
        print(f"[FakeRequests] GET {url} headers={headers} params={params} timeout={timeout} -> {self._resp.status_code}")
        return self._resp

# Test case 1: No credentials configured - should return None
s = mod.source()
res = s.sources({'imdb': 'tt0000000', 'title': 'Test Movie', 'year': 2017}, hostDict=['example'], hostprDict=[])
print('easynews no-creds result:', res)

# Test case 2: Credentials present but HTTP non-200
# NOTE: dummy test credentials only — no real secrets
# Monkeypatch xbmcaddon Addon.getSetting to return credentials
sys.modules['xbmcaddon'].Addon.getSetting = lambda self, id=None, *a, **k: 'u' if id == 'easynews.user' else ('p' if id == 'easynews.password' else '')
# Ensure resources.lib.modules.control.setting also returns credentials
sys.modules['resources.lib.modules'].control.setting = lambda k: 'u' if k == 'easynews.user' else ('p' if k == 'easynews.password' else '')
orig_requests = sys.modules.get('requests')
# Patch the requests object used inside the loaded module
mod.requests = FakeRequests(FakeResp(status=404, text=''))
res = s.sources({'imdb': 'tt0000000', 'title': 'Test Movie', 'year': 2017}, hostDict=['example'], hostprDict=[])
print('easynews non-200 result length:', len(res))

# Test case 3: Credentials present and valid JSON with one item
# Let runtime logging print to stdout for debugging
sys.modules['resources.lib.modules'].crewruntime.c.log = print
fake_json = {
    'downURL': 'https://members.easynews.com/download',
    'dlFarm': 'farm',
    'dlPort': '8080',
    'data': [
        {
            '0': 'hash123',
            '10': 'Test.Movie.2017.1080p.mkv',
            '11': '.mkv',
            '14': '120m',
            'rawSize': '2147483648',
            'alangs': ['eng'],
            'type': 'VIDEO'
        }
    ]
}
json_text = __import__('json').dumps(fake_json)
# Debug: confirm requests module
print('requests module before valid-json test:', sys.modules.get('requests'))
# Patch the requests object used in the already-imported module
mod.requests = FakeRequests(FakeResp(status=200, text=json_text))
print('module.requests after patch:', getattr(mod, 'requests', None))
res = s.sources({'imdb': 'tt0000000', 'title': 'Test Movie', 'year': 2017}, hostDict=['example'], hostprDict=[])
print('easynews valid-json result:', res)

# Restore requests
if orig_requests is not None:
    sys.modules['requests'] = orig_requests
else:
    del sys.modules['requests']
