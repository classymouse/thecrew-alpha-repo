from resources.lib.modules.sources import Sources


class _GearProviderMinimal:
    # No hasMovies flag, but implements movie()
    def movie(self, *a, **k):
        return None

class _GearProviderSources:
    # No hasMovies flag, but implements sources()
    def sources(self, *a, **k):
        return None


def test_gear_provider_with_movie_is_included():
    s = Sources()
    sd = [ ('gearsscrapers.providers.torrents.minimal', _GearProviderMinimal()) ]
    filtered, content = s.filter_source_dict(None, sd)
    assert filtered and any(name.startswith('gearsscrapers.') for name, _ in filtered)


def test_gear_provider_with_sources_is_included():
    s = Sources()
    sd = [ ('gearsscrapers.providers.torrents.srctest', _GearProviderSources()) ]
    filtered, content = s.filter_source_dict(None, sd)
    assert filtered and any(name.startswith('gearsscrapers.') for name, _ in filtered)


class _GearProviderSearch:
    # No hasMovies flag, but implements search()
    def search(self, *a, **k):
        return None

class _GearProviderTvSearch:
    # No hasEpisodes flag, but implements tvsearch()
    def tvsearch(self, *a, **k):
        return None


def test_gear_provider_with_search_is_included():
    s = Sources()
    sd = [ ('gearsscrapers.providers.torrents.searchtest', _GearProviderSearch()) ]
    filtered, content = s.filter_source_dict(None, sd)
    assert filtered and any(name.startswith('gearsscrapers.') for name, _ in filtered)


def test_gear_provider_with_tvsearch_is_included():
    s = Sources()
    sd = [ ('gearsscrapers.providers.torrents.tvsearchtest', _GearProviderTvSearch()) ]
    filtered, content = s.filter_source_dict('Some Show', sd)
    assert filtered and any(name.startswith('gearsscrapers.') for name, _ in filtered)
