# Gearsscrapers integration test
import sys
import os
import importlib.util

# Add lib to path
lib_parent = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'lib'))
lib_path = os.path.join(lib_parent, 'resources', 'lib')
if lib_parent not in sys.path:
    sys.path.insert(0, lib_parent)
if lib_path not in sys.path:
    sys.path.insert(0, lib_path)

import types
# Minimal xbmc stubs to allow module imports outside Kodi
if 'xbmc' not in sys.modules:
    sys.modules['xbmc'] = types.SimpleNamespace(
        getCondVisibility=lambda *a, **k: False,
        log=lambda *a, **k: None,
        getInfoLabel=lambda *a, **k: '21.3.0',
        getLocalizedString=lambda *a, **k: '',
        executeJSONRPC=lambda *a, **k: '{}'
    )
if 'xbmcaddon' not in sys.modules:
    class _AddonStub:
        def __init__(self, addon_id=None):
            self._settings = {}
        def getSetting(self, id=None, *args, **kwargs):
            # Provide sensible defaults for settings used during initialization and tests
            defaults = {
                'fanart.quality': '2',
                'addon_debug': 'false',
                'dev_pw': '',
                'HEVC': 'true',
                'sources.cache.duration': '15',
                'cocoscrapers.enabled': 'true',
                'gearsscrapers.enabled': 'true',
                'hosts.quality': '0',
                'progress.dialog': '0'
            }
            if id in self._settings:
                return self._settings.get(id)
            return defaults.get(id, '')
        def getLocalizedString(self, k):
            return str(k)
        def getSettingInfo(self, k):
            return ''
        def getAddonInfo(self, id=None, **kwargs):
            return ''
        def setSetting(self, id=None, value=None, *args, **kwargs):
            self._settings[id] = value
            return None
    sys.modules['xbmcaddon'] = types.SimpleNamespace(Addon=_AddonStub)
if 'xbmcvfs' not in sys.modules:
    sys.modules['xbmcvfs'] = types.SimpleNamespace(translatePath=lambda x: x)
if 'xbmcgui' not in sys.modules:
    class _DialogStub:
        def notification(self, *args, **kwargs):
            return True
        def ok(self, *args, **kwargs):
            return True
    class _ListItemStub:
        def __init__(self, *args, **kwargs):
            pass
    class _WindowStub:
        def __init__(self, *args, **kwargs):
            self._props = {}
        def getProperty(self, k):
            return self._props.get(k, '')
        def setProperty(self, k, v):
            self._props[k] = v
        def clearProperty(self, k):
            if k in self._props:
                del self._props[k]
    class _DialogProgress:
        def __init__(self, *args, **kwargs):
            self._canceled = False
        def create(self, header, message=''):
            self._canceled = False
        def update(self, percent, message=None):
            return True
        def iscanceled(self):
            return self._canceled
        def close(self):
            self._canceled = True
    class _WindowDialog:
        def __init__(self, *args, **kwargs):
            pass
    sys.modules['xbmcgui'] = types.SimpleNamespace(Dialog=_DialogStub, ListItem=_ListItemStub, Window=_WindowStub, DialogProgress=_DialogProgress, DialogProgressBG=_DialogProgress, WindowDialog=_WindowDialog)
if 'xbmcplugin' not in sys.modules:
    sys.modules['xbmcplugin'] = types.SimpleNamespace(
    setProperty=lambda *a, **k: None,
    addDirectoryItem=lambda *a, **k: None,
    addDirectoryItems=lambda *a, **k: None,
    endOfDirectory=lambda *a, **k: None,
    setResolvedUrl=lambda *a, **k: None,
    setContent=lambda *a, **k: None,
    addSortMethod=lambda *a, **k: None,
    addSortMethodEx=lambda *a, **k: None
)


def test_settings():
    print('\n=== Testing Settings ===')
    try:
        from modules.crewruntime import c
        gears_enabled = c.get_setting('gearsscrapers.enabled')
        print(f"✓ Setting 'gearsscrapers.enabled' = '{gears_enabled}'")
        if gears_enabled == 'true':
            print('  Gearsscrapers is ENABLED in settings')
        else:
            print('  Gearsscrapers is DISABLED in settings')
        return True
    except Exception as e:
        print(f"✗ Settings test failed: {e}")
        return False


def test_addon_detection():
    print('\n=== Testing Addon Detection ===')
    try:
        try:
            import xbmc
            is_installed = xbmc.getCondVisibility('System.HasAddon(script.module.gearsscrapers)')
        except ImportError:
            print('  Note: xbmc module not available, checking filesystem')
            addons_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
            gears_path = os.path.join(addons_dir, 'script.module.gearsscrapers')
            is_installed = os.path.isdir(gears_path)
        print(f"✓ Gearsscrapers addon {'IS' if is_installed else 'IS NOT'} installed")
        return True
    except Exception as e:
        print(f"✗ Addon detection test failed: {e}")
        return False


def test_sources_class_and_formatters():
    print('\n=== Testing Sources Class & Formatters ===')
    try:
        # Formatter test using same logic as in Sources
        def format_gearsscrapers_name(source_name):
            if not (isinstance(source_name, str) and source_name.startswith('gearsscrapers.')):
                return source_name
            try:
                parts = source_name.split('_', 1)
                if len(parts) == 2:
                    scraper_name = parts[1].replace('_', ' ').title()
                else:
                    scraper_name = source_name.split('.')[-1].replace('_', ' ').title()
                return f"[Gears] {scraper_name}"
            except:
                return source_name

        formatted = format_gearsscrapers_name('gearsscrapers.torrents_example_scraper')
        print(f"  - format_gearsscrapers_name -> {formatted}")
        return True
    except Exception as e:
        import traceback
        print(f"✗ Sources class test failed: {e}")
        print(traceback.format_exc())
        return False


if __name__ == '__main__':
    results = []
    results.append(('Settings', test_settings()))
    results.append(('Addon Detection', test_addon_detection()))
    results.append(('Sources Class', test_sources_class_and_formatters()))

    print('\nTEST RESULTS')
    for name, ok in results:
        print(f"{name}: {'PASS' if ok else 'FAIL'}")
