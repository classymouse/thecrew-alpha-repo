# Smoke test for gowatchseries parser
import sys, os, importlib.util
lib_parent = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'lib'))
if lib_parent not in sys.path:
    sys.path.insert(0, lib_parent)

import types
# Ensure simplejson is available for the module
import json as _json
sys.modules['simplejson'] = _json
if 'resources' not in sys.modules:
    resources = types.ModuleType('resources')
    sys.modules['resources'] = resources
if 'resources.lib' not in sys.modules:
    sys.modules['resources.lib'] = types.ModuleType('resources.lib')
if 'resources.lib.modules' not in sys.modules:
    modpkg = types.ModuleType('resources.lib.modules')
    import re as _re
    cleantitle = types.SimpleNamespace(getsearch=lambda x: _re.sub('[^a-z0-9]','',str(x).lower()), get=lambda x: _re.sub('[^a-z0-9]','',str(x).lower()))
    client = types.SimpleNamespace(request=lambda *a, **k: '', parseDom=lambda *a, **k: [])
    source_utils = types.SimpleNamespace(is_host_valid=lambda u,h: (True, 'example.com'))
    c_stub = types.SimpleNamespace(log=lambda *a, **k: print(*a), ensure_text=lambda x, **k: x)
    modpkg.cleantitle = cleantitle
    modpkg.client = client
    modpkg.source_utils = source_utils
    modpkg.crewruntime = types.SimpleNamespace(c=c_stub)
    sys.modules['resources.lib.modules'] = modpkg
    crewruntime_mod = types.ModuleType('resources.lib.modules.crewruntime')
    crewruntime_mod.c = c_stub
    sys.modules['resources.lib.modules.crewruntime'] = crewruntime_mod

spec = importlib.util.spec_from_file_location('mgw', os.path.join(os.path.dirname(__file__), '..', 'lib', 'resources', 'lib', 'sources', 'en', 'gowatchseries.py'))
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

s = mod.source()
# Test blocked initial response
mod.client.request = lambda *a, **k: ''
res = s.sources({'imdb':'tt0000000','title':'Test','year':'2017'}, hostDict=['example.com'], hostprDict=[])
print('gowatchseries blocked result length:', len(res))

# Test valid search/links
content = '{"content":"<a href=\\"/info/123\\">Test.Movie</a>"}'

def _request(url, **k):
    if url == s.base_link:
        # emulate extended response with headers and cookie at indices used by the scraper
        return ['result', None, {'User-Agent': 'agent'}, {'Cookie': 'cookieval'}, 'cookieval']
    if 'ajax-search' in url:
        return content
    return '<div class="anime_muti_link"><li data-video="//video.example.com/vid1"></li></div>'

mod.client.request = _request
mod.client.parseDom = lambda txt, tag, ret=None, attrs=None, **k: (['/info/123'] if tag=='a' and ret=='href' else (['Test.Movie'] if tag=='a' else ['//video.example.com/vid1']))
mod.client.replaceHTMLCodes = lambda x: x
# Debug: inspect flow
r0 = mod.client.request(s.base_link, output='extended', timeout='10')
print('initial request r0:', r0)
from urllib.parse import quote_plus, urljoin
query = s.search_link % quote_plus(mod.cleantitle.getsearch('Test Movie'))
query = urljoin(s.base_link, query)
print('search query:', query)
r1 = mod.client.request(query, headers=r0[3], XHR=True)
print('search response r1:', r1)
content = __import__('json').loads(r1).get('content')
print('parsed content:', content)
# Inspect parsed links/titles and filtering
links = mod.client.parseDom(content, 'a', ret='href')
titles = mod.client.parseDom(content, 'a')
r_pairs = list(zip(links, titles))
print('r_pairs before filter:', r_pairs)
cltitle = mod.cleantitle.get('Test Movie')
cltitle2 = mod.cleantitle.get('Test Movie (2017)')
filtered = [i for i in r_pairs if cltitle2 == mod.cleantitle.getsearch(i[1]) or cltitle == mod.cleantitle.getsearch(i[1])]
print('filtered r:', filtered)

# Inspect the vurl and slinks steps manually
r_pairs_filtered = filtered
if r_pairs_filtered:
    vurl = '%s%s-episode-0' % (s.base_link, str(r_pairs_filtered[0][0]).replace('/info', ''))
    print('constructed vurl:', vurl)
    r_v = mod.client.request(vurl, headers=r0[3])
    print('vurl response:', r_v)
    slinks = mod.client.parseDom(r_v, 'div', attrs={'class': 'anime_muti_link'}) or ''
    print('slinks div result:', slinks)
    slinks_li = mod.client.parseDom(slinks, 'li', ret='data-video') or []
    print('slinks li result:', slinks_li)
    slinks_norm = [slink if str(slink).startswith('http') else 'https:{0}'.format(slink) for slink in slinks_li]
    print('_slinks normalized:', slinks_norm)
    _slinks = [(url, 'HD') for url in slinks_norm]
    print('_slinks:', _slinks)
    for url in _slinks:
        valid, host = mod.source_utils.is_host_valid(url[0], ['example.com'])
        print('is_host_valid for', url[0], '->', (valid, host))

# Now call sources
res = s.sources({'imdb':'tt0000000','title':'Test Movie','year':'2017'}, hostDict=['example.com'], hostprDict=[])
print('gowatchseries valid result length:', len(res))
print('gowatchseries result:', res)