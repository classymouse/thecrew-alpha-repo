from resources.lib.modules.sources import Sources


def test_internal_prefix_in_finalize_label():
    s = Sources()
    src = {
        'provider': 'resources.lib.sources.crew.internal',
        'quality': '1080p',
        'source': 'crew',
        'info': '4.2 GB | AAC'
    }
    base_label, base_multiline = s.build_labels(src, 0)
    final_label, final_multiline = s.finalize_label(src, base_label, base_multiline, 0)

    # Prefix should be applied to provider display, not the entire label start
    assert ' | [CREW] ' in final_label
    assert ' | [CREW] ' in final_multiline


def test_torrentio_is_prefixed_as_internal():
    s = Sources()
    src = {
        'provider': 'resources.lib.sources.en_tor.torrentio',
        'quality': '720p',
        'source': 'torrent',
        'info': '700 MB | MP4'
    }
    base_label, base_multiline = s.build_labels(src, 0)
    final_label, final_multiline = s.finalize_label(src, base_label, base_multiline, 0)

    assert ' | [CREW] ' in final_label
    assert ' | [CREW] ' in final_multiline


def test_external_packs_not_prefixed():
    s = Sources()
    src = {
        'provider': 'cocoscrapers.some_scraper',
        'quality': '720p',
        'source': 'cocoscrapers',
        'info': '700 MB | MP4'
    }
    base_label, base_multiline = s.build_labels(src, 0)
    final_label, final_multiline = s.finalize_label(src, base_label, base_multiline, 0)

    # Should not be prefixed with [CREW], but format_provider_display should return a [Coco] prefix
    assert not final_label.startswith('[CREW] ')
    assert '[Coco]' in final_label or 'Coco' in final_label