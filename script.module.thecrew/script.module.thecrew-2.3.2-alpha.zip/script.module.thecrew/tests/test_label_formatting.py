# Tests for label formatting (single-line vs multi-line)
import sys, os, types

lib_parent = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
lib_lib_dir = os.path.abspath(os.path.join(lib_parent, 'lib'))
resources_lib = os.path.abspath(os.path.join(lib_parent, 'lib', 'resources', 'lib'))
if lib_lib_dir not in sys.path:
    sys.path.insert(0, lib_lib_dir)
if resources_lib not in sys.path:
    sys.path.insert(0, resources_lib)

# Minimal runtime stubs
if 'xbmc' not in sys.modules:
    sys.modules['xbmc'] = types.SimpleNamespace(log=lambda *a, **k: None, getInfoLabel=lambda *a, **k: '21.3.0', getCondVisibility=lambda *a, **k: False, getLocalizedString=lambda k: str(k), executeJSONRPC=lambda *a, **k: '{}', executebuiltin=lambda *a, **k: None, Keyboard=lambda *a, **k: None, Monitor=lambda *a, **k: types.SimpleNamespace(abortRequested=lambda : False), getSkinDir=lambda *a, **k: 'skin', Player=lambda *a, **k: None, PlayList=lambda *a, **k: None, PLAYLIST_VIDEO=1, LOGDEBUG=0, LOGINFO=1, LOGERROR=2, Actor=object, VideoStreamDetail=object, AudioStreamDetail=object, SubtitleStreamDetail=object)

if 'xbmcaddon' not in sys.modules:
    class _AddonStub:
        def __init__(self, *a, **k):
            self._settings = {}
        def getSetting(self, id=None, *a, **k):
            return self._settings.get(id, '')
        def setSetting(self, id, value):
            self._settings[id]=value
        def getLocalizedString(self, k):
            return str(k)
        def getAddonInfo(self, id=None, **k):
            return ''
    sys.modules['xbmcaddon'] = types.SimpleNamespace(Addon=_AddonStub)

if 'xbmcgui' not in sys.modules:
    class _Dialog: pass
    sys.modules['xbmcgui'] = types.SimpleNamespace(Dialog=_Dialog, ListItem=object, Window=lambda *a, **k: None, DialogProgress=lambda *a, **k: None, DialogProgressBG=lambda *a, **k: None, WindowDialog=lambda *a, **k: None, ControlButton=lambda *a, **k: None, ControlImage=lambda *a, **k: None, getCurrentWindowDialogId=lambda *a, **k: 0, Keyboard=lambda *a, **k: None)

if 'xbmcplugin' not in sys.modules:
    sys.modules['xbmcplugin'] = types.SimpleNamespace(setResolvedUrl=lambda *a, **k: None, addDirectoryItem=lambda *a, **k: None, endOfDirectory=lambda *a, **k: None, addDirectoryItems=lambda *a, **k: None, setContent=lambda *a, **k: None, addSortMethod=lambda *a, **k: None, setProperty=lambda *a, **k: None)

if 'xbmcvfs' not in sys.modules:
    sys.modules['xbmcvfs'] = types.SimpleNamespace(exists=lambda *a, **k: True, translatePath=lambda x: x, makeLegalFilename=lambda x: x, File=lambda *a, **k: None, mkdir=lambda *a, **k: None, delete=lambda *a, **k: None, rmdir=lambda *a, **k: None, listdir=lambda *a, **k: ([], []))

# crewruntime stub
_crewruntime = types.ModuleType('resources.lib.modules.crewruntime')
_crewruntime.c = types.SimpleNamespace(log=lambda *a, **k: None, ensure_text=lambda x, **k: x, scraper_error=lambda *a, **k: None, get_setting=lambda *a, **k: '', is_orion_installed=lambda: False, name='thecrew', pluginversion='1.0.0', moduleversion='1.0.0', kodiversion='21.3.0', platform='windows')
sys.modules['resources.lib.modules.crewruntime'] = _crewruntime

# resolveurl stub
if 'resolveurl' not in sys.modules:
    _resolveurl = types.ModuleType('resolveurl')
    class HostedStub:
        def __init__(self, url, include_disabled=True, include_universal=False):
            self._url = url
        def valid_url(self):
            return False
        def resolve(self):
            return None
    _resolveurl.HostedMediaFile = HostedStub
    sys.modules['resolveurl'] = _resolveurl

from resources.lib.modules.label_utils import build_labels_static


def test_single_line_includes_size_and_info():
    source = {
        'provider': 'torrents.torrentio',
        'quality': '4K',
        'source': 'TORRENT',
        'info': '23.32 GB | WEB | H.264 | DD+',
        'debrid': 'real-debrid'
    }

    label, multiline = build_labels_static(source, 0, multi_language=False)

    # Single-line should include the size and other info (joined with ' / ')
    assert 'GB' in label
    assert 'WEB' in label and 'H.264' in label and 'DD+' in label

    # Multi-line should include the size and a newline
    assert '23.32 GB' in multiline
    assert '\n' in multiline


def test_final_single_line_format_includes_debrid_and_provider():
    from resources.lib.modules.sources import Sources

    s = Sources()
    source = {
        'provider': 'gearsscrapers.torrents.torrentio',
        'quality': '4K',
        'source': 'TORRENT',
        'info': '32.8 GB | WEB-DL | DD+ | DolbyAtmos',
        'debrid': 'real-debrid'
    }

    base_label, base_multiline = build_labels_static(source, 0)

    # Use finalize_label with compact=True to simulate setting enabled
    label, multiline = s.finalize_label(source, base_label, base_multiline, 0, compact=True)

    assert 'RD' in label
    assert '[Gears] Torrentio' in label
    assert '32.8 GB' in label
    assert 'WEB-DL' in label and 'DD+' in label and 'DolbyAtmos' in label


def test_final_single_line_uses_multiline_fallback_when_info_only_size():
    # Some providers only set 'info' to size and attach extra info into multiline
    from resources.lib.modules.sources import Sources
    s = Sources()
    source = {
        'provider': 'gearsscrapers.torrents.torrentio',
        'quality': '4K',
        'source': 'TORRENT',
        'info': '23.32 GB',
        'debrid': 'real-debrid'
    }

    # craft a base_multiline that includes the extra info in the details line
    base_label = '01 | 4K | [Gears] Torrentio | TORRENT'
    base_multiline = base_label + ' \n       [I]23.32 GB [/I] | WEB | H.264 | DD+'

    label, multiline = s.finalize_label(source, base_label, base_multiline, 0, compact=False, list_multiline=False)

    assert '23.32 GB' in label
    assert 'DD+' in label
    assert 'WEB' in label


def test_final_single_line_falls_back_to_source_multiline_field():
    # Some providers already populated source['multiline_label'] despite info only containing size
    from resources.lib.modules.sources import Sources
    s = Sources()
    source = {
        'provider': 'torrentio',
        'quality': '4K',
        'source': 'TORRENT',
        'info': '23.32 GB',
        'debrid': 'real-debrid',
        'multiline_label': '[COLOR blue]01 | RD | TORRENTIO | 4K | TORRENT \n       [I]23.32 GB [/I] | WEB[COLOR LAWNGREEN] / [/COLOR]H.264[COLOR LAWNGREEN] / [/COLOR]DD+[/COLOR]'
    }

    base_label, base_multiline = build_labels_static(source, 0)
    label, multiline = s.finalize_label(source, base_label, base_multiline, 0, compact=False, list_multiline=False)

    # Ensure extra info is present and not duplicated in multiline
    assert 'WEB' in label and 'DD+' in label
    assert multiline.count('WEB') == 1
    assert multiline.count('DD+') == 1




def test_label_has_no_trailing_separators_or_double_pipes():
    from resources.lib.modules.sources import Sources
    s = Sources()
    # Simulate a provider that yields an incomplete info producing 'WEB/TS |  | '
    source = {
        'provider': 'provider.test',
        'quality': '1080p',
        'source': 'TORRENT',
        'info': 'WEB/TS | |',
        'debrid': ''
    }

    base_label, base_multiline = build_labels_static(source, 0)
    label, multiline = s.finalize_label(source, base_label, base_multiline, 0, compact=True)

    # No double pipes and no trailing '|'
    assert '||' not in label
    assert not label.strip().endswith('|')
    # other info should be normalized to 'WEB/TS'
    assert 'WEB/TS' in label
