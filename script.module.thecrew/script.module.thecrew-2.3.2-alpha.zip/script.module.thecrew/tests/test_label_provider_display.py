from resources.lib.modules.sources import Sources


def test_finalize_label_uses_short_provider():
    s = Sources()
    source = {'provider': 'resources.lib.sources.en_tor.torrentio', 'quality': 'sd', 'name':'test', 'info':'1 GB'}
    label, multiline = s.finalize_label(source, 'label_base', 'multiline_base', index=0, compact=False)
    assert 'Torrentio' in label or 'TORRENTIO' in label
