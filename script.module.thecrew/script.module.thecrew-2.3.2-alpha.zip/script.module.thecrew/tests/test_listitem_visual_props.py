import sys, os, types

lib_parent = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
lib_lib_dir = os.path.abspath(os.path.join(lib_parent, 'lib'))
resources_lib = os.path.abspath(os.path.join(lib_parent, 'lib', 'resources', 'lib'))
if lib_lib_dir not in sys.path:
    sys.path.insert(0, lib_lib_dir)
if resources_lib not in sys.path:
    sys.path.insert(0, resources_lib)

# Minimal xbmcgui ListItem stub to capture properties
class _ListItemStub:
    def __init__(self, label=None):
        self.label = label
        self._props = {}
    def setProperty(self, k, v):
        self._props[k] = v
    def getProperty(self, k):
        return self._props.get(k)

# Minimal runtime stubs (like other tests) so importing Sources doesn't hit Kodi APIs
if 'xbmc' not in sys.modules:
    sys.modules['xbmc'] = types.SimpleNamespace(log=lambda *a, **k: None, getInfoLabel=lambda *a, **k: '21.3.0', getCondVisibility=lambda *a, **k: False, getLocalizedString=lambda k: str(k), executeJSONRPC=lambda *a, **k: '{}', executebuiltin=lambda *a, **k: None, Keyboard=lambda *a, **k: None, Monitor=lambda *a, **k: types.SimpleNamespace(abortRequested=lambda : False), getSkinDir=lambda *a, **k: 'skin', Player=lambda *a, **k: None, PlayList=lambda *a, **k: None, PLAYLIST_VIDEO=1, LOGDEBUG=0, LOGINFO=1, LOGERROR=2, Actor=object, VideoStreamDetail=object, AudioStreamDetail=object, SubtitleStreamDetail=object)

if 'xbmcaddon' not in sys.modules:
    class _AddonStub:
        def __init__(self, *a, **k):
            self._settings = {}
        def getSetting(self, id=None, *a, **k):
            return self._settings.get(id, '')
        def setSetting(self, id, value):
            self._settings[id]=value
        def getLocalizedString(self, k):
            return str(k)
        def getAddonInfo(self, id=None, **k):
            return ''
    sys.modules['xbmcaddon'] = types.SimpleNamespace(Addon=_AddonStub)

if 'xbmcgui' not in sys.modules:
    class _Dialog: pass
    sys.modules['xbmcgui'] = types.SimpleNamespace(Dialog=_Dialog, ListItem=_ListItemStub, Window=lambda *a, **k: None, DialogProgress=lambda *a, **k: None, DialogProgressBG=lambda *a, **k: None, WindowDialog=lambda *a, **k: None, ControlButton=lambda *a, **k: None, ControlImage=lambda *a, **k: None, getCurrentWindowDialogId=lambda *a, **k: 0, Keyboard=lambda *a, **k: None)

if 'xbmcvfs' not in sys.modules:
    sys.modules['xbmcvfs'] = types.SimpleNamespace(exists=lambda *a, **k: True, translatePath=lambda x: x, makeLegalFilename=lambda x: x, File=lambda *a, **k: None, mkdir=lambda *a, **k: None, delete=lambda *a, **k: None, rmdir=lambda *a, **k: None, listdir=lambda *a, **k: ([], []))

# minimal xbmcplugin stub
if 'xbmcplugin' not in sys.modules:
    sys.modules['xbmcplugin'] = types.SimpleNamespace(setResolvedUrl=lambda *a, **k: None, addDirectoryItem=lambda *a, **k: None, endOfDirectory=lambda *a, **k: None, addDirectoryItems=lambda *a, **k: None, setContent=lambda *a, **k: None, addSortMethod=lambda *a, **k: None, setProperty=lambda *a, **k: None)

# crewruntime stub to avoid CrewRuntime initialization
if 'resources.lib.modules.crewruntime' not in sys.modules:
    _crewruntime = types.ModuleType('resources.lib.modules.crewruntime')
    _crewruntime.c = types.SimpleNamespace(log=lambda *a, **k: None, ensure_text=lambda x, **k: x, scraper_error=lambda *a, **k: None, get_setting=lambda *a, **k: '', is_orion_installed=lambda: False, name='thecrew', pluginversion='1.0.0', moduleversion='1.0.0', kodiversion='213.0', platform='windows')
    sys.modules['resources.lib.modules.crewruntime'] = _crewruntime

# Avoid importing player module implementation (stub minimal player)
sys.modules['resources.lib.modules.player'] = types.SimpleNamespace(player=type('player', (), {}))

# resolveurl stub
if 'resolveurl' not in sys.modules:
    _resolveurl = types.ModuleType('resolveurl')
    class HostedStub:
        def __init__(self, url, include_disabled=True, include_universal=False):
            self._url = url
        def valid_url(self, *a, **k):
            return False
        def resolve(self):
            return None
    _resolveurl.HostedMediaFile = HostedStub
    sys.modules['resolveurl'] = _resolveurl

# import the helper
from resources.lib.modules.sources import Sources


def test_apply_visual_props_free_and_internal():
    s = Sources.__new__(Sources)
    stub = _ListItemStub('01 | 4K | [CREW] Test')
    source = {'provider': 'thecrew', 'debrid': '', 'source': 'CREW'}

    s.apply_visual_props(stub, source)

    assert stub.getProperty('source.type') == 'free'
    assert stub.getProperty('source.free') == 'true'
    assert stub.getProperty('source.internal') == 'true'


def test_apply_visual_props_paid():
    s = Sources.__new__(Sources)
    stub = _ListItemStub('01 | 4K | Test')
    source = {'provider': 'torrents.something', 'debrid': 'real-debrid'}

    s.apply_visual_props(stub, source)

    assert stub.getProperty('source.type') == 'paid'
    assert stub.getProperty('source.premium') == 'true'
    assert stub.getProperty('source.internal') is None
