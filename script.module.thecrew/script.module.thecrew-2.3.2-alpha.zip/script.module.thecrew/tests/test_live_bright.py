# Live test run for Bright (2017)
# This runs Sources.getSources for Bright (2017) using a minimal runtime stub

import pytest
pytestmark = pytest.mark.integration

import sys, os, importlib.util, types
lib_parent = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'lib'))
lib_path = os.path.join(lib_parent, 'resources', 'lib')
if lib_parent not in sys.path:
    sys.path.insert(0, lib_parent)
if lib_path not in sys.path:
    sys.path.insert(0, lib_path)

# Minimal Kodi and runtime stubs
if 'xbmc' not in sys.modules:
    class _Keyboard:
        def __init__(self, *args, **kwargs):
            pass
        def doModal(self):
            return 0
        def isConfirmed(self):
            return False
        def getText(self):
            return ''
    class _Monitor:
        def __init__(self, *args, **kwargs):
            pass
        def abortRequested(self):
            return False
    class _Player:
        def __init__(self, *args, **kwargs):
            pass
        def isPlaying(self):
            return False
    class _PlayList:
        def __init__(self, *args, **kwargs):
            self.items = []
        def clear(self):
            self.items.clear()
        def add(self, item):
            self.items.append(item)

    class _Actor: pass
    class _VideoStreamDetail: pass
    class _AudioStreamDetail: pass
    class _SubtitleStreamDetail: pass
    sys.modules['xbmc'] = types.SimpleNamespace(
        getInfoLabel=lambda *a, **k: '21.3.0',
        getCondVisibility=lambda *a, **k: False,
        getLocalizedString=lambda *a, **k: '',
        executeJSONRPC=lambda *a, **k: '{}',
        log=lambda *a, **k: None,
        Keyboard=_Keyboard,
        Monitor=_Monitor,
        Player=_Player,
        PlayList=_PlayList,
        PLAYLIST_VIDEO=1,
        executebuiltin=lambda *a, **k: None,
        getSkinDir=lambda *a, **k: 'skin',
        LOGDEBUG=1,
        LOGERROR=2,
        LOGWARNING=3,
        Actor=_Actor,
        VideoStreamDetail=_VideoStreamDetail,
        AudioStreamDetail=_AudioStreamDetail,
        SubtitleStreamDetail=_SubtitleStreamDetail,
        LOGINFO=0
    )

if 'xbmcaddon' not in sys.modules:
    class _AddonStub:
        def __init__(self, addon_id=None):
            self._settings = {}
        def getSetting(self, id=None, *args, **kwargs):
            return self._settings.get(id, '')
        def getLocalizedString(self, k):
            return str(k)
        def getSettingInfo(self, k):
            return ''
        def getAddonInfo(self, id=None, **kwargs):
            return ''
        def setSetting(self, id, value):
            self._settings[id] = value
    sys.modules['xbmcaddon'] = types.SimpleNamespace(Addon=_AddonStub)

if 'xbmcgui' not in sys.modules:
    class _DialogStub:
        def notification(self, *args, **kwargs):
            return True
        def ok(self, *args, **kwargs):
            return True
    class _ListItemStub:
        def __init__(self, *args, **kwargs):
            pass
    class _WindowStub:
        def __init__(self, *args, **kwargs):
            self._props = {}
        def getProperty(self, k):
            return self._props.get(k, '')
        def setProperty(self, k, v):
            self._props[k] = v
        def clearProperty(self, k):
            if k in self._props:
                del self._props[k]
    class _DialogProgress:
        def __init__(self, *args, **kwargs):
            self._canceled = False
        def create(self, header, message=''):
            self._canceled = False
        def update(self, percent, message=None):
            return True
        def iscanceled(self):
            return self._canceled
        def close(self):
            self._canceled = True

    # Additional UI stubs used by external packs
    class WindowXMLDialog:
        def __init__(self, *args, **kwargs):
            pass
        def onInit(self):
            return None
        def doModal(self):
            return 0

    class ControlProgress(_DialogProgress):
        pass

    # ListItem class used by many addons
    class _ListItemStub:
        def __init__(self, *args, **kwargs):
            self._props = {}
        def setProperty(self, k, v):
            self._props[k] = v
        def getProperty(self, k):
            return self._props.get(k, '')
    class _ControlImage:
        def __init__(self, *args, **kwargs):
            pass
    def _getCurrentWindowDialogId():
        return 0
    class _Keyboard:
        def __init__(self, *args, **kwargs):
            pass
        def doModal(self):
            return 0
        def isConfirmed(self):
            return False
        def getText(self):
            return ''
    sys.modules['xbmcgui'] = types.SimpleNamespace(Dialog=_DialogStub, ListItem=_ListItemStub, Window=_WindowStub, DialogProgress=_DialogProgress, DialogProgressBG=_DialogProgress, WindowDialog=object, WindowXMLDialog=WindowXMLDialog, ControlProgress=ControlProgress, ControlButton=object, ControlImage=_ControlImage, getCurrentWindowDialogId=_getCurrentWindowDialogId, Keyboard=_Keyboard)

if 'xbmcplugin' not in sys.modules:
    sys.modules['xbmcplugin'] = types.SimpleNamespace(setProperty=lambda *a, **k: None, addDirectoryItem=lambda *a, **k: None, addDirectoryItems=lambda *a, **k: None, endOfDirectory=lambda *a, **k: None, setResolvedUrl=lambda *a, **k: None, setContent=lambda *a, **k: None, addSortMethod=lambda *a, **k: None, addSortMethodEx=lambda *a, **k: None)

if 'xbmcvfs' not in sys.modules:
    class _FileStub:
        def __init__(self, *args, **kwargs):
            pass
        def read(self):
            return ''
        def write(self, *a, **k):
            return
        def close(self):
            return
    def _makeLegalFilename(x):
        return x.replace(':', '_')
    def _mkdir(x):
        try:
            os.makedirs(x, exist_ok=True)
        except Exception:
            pass
    def _mkdirs(x, exist_ok=True):
        try:
            os.makedirs(x, exist_ok=exist_ok)
        except Exception:
            pass
    def _delete(x):
        try:
            os.remove(x)
        except Exception:
            pass
    def _rmdir(x):
        try:
            os.rmdir(x)
        except Exception:
            pass
    def _rename(src, dst):
        try:
            os.replace(src, dst)
        except Exception:
            try:
                os.rename(src, dst)
            except Exception:
                pass
    def _listdir(x):
        try:
            return os.listdir(x), []
        except Exception:
            return [], []
    sys.modules['xbmcvfs'] = types.SimpleNamespace(translatePath=lambda x: x, makeLegalFilename=_makeLegalFilename, File=_FileStub, mkdir=_mkdir, mkdirs=_mkdirs, delete=_delete, rmdir=_rmdir, listdir=_listdir, exists=lambda x: os.path.exists(x), rename=_rename)

# Provide a minimal crewruntime.c stub to avoid full initialization but permit needed settings
c_stub = types.SimpleNamespace(
    name='The Crew',
    pluginversion='2.1.0',
    moduleversion='2.2.0',
    kodiversion='21.3.0',
    platform=sys.platform,
    get_setting=lambda k: {
        'sources.cache.enabled': 'false',
        'scrapers.timeout.1': '15',
        'hosts.quality': '0',
        'debrid.only': 'false',
        'progress.dialog': '0',
        'cocoscrapers.enabled': 'true',
        'gearsscrapers.enabled': 'true',
        'addon_debug': 'false',
        'debug.location': '0'
    }.get(k, ''),
    is_orion_installed=lambda: False,
    ensure_text=lambda x, **k: x if isinstance(x, str) else str(x),
    ensure_str=lambda x, **k: str(x),
    log=lambda *a, **k: print(*a)
)
crewruntime_mod = types.ModuleType('resources.lib.modules.crewruntime')
crewruntime_mod.c = c_stub
sys.modules['resources.lib.modules.crewruntime'] = crewruntime_mod

# Minimal modules used by Sources during run
# Use actual modules but allow functions to operate normally

# Provide a fake resolveurl module for imports
import types as _types
if 'resolveurl' not in sys.modules:
    sys.modules['resolveurl'] = _types.ModuleType('resolveurl')

# Run getSources for Bright (2017) - using imdb used earlier in tests
if __name__ == '__main__':
    from resources.lib.modules.sources import Sources
    s = Sources()
    print('\n=== Running live sources get for Bright (2017) ===')
    res = s.getSources('Bright', '2017', 'tt5519340', '', None, None, None, '', quality='HD', timeout=20)
    print('\nTotal sources returned:', len(res))
    if len(res) > 0:
        print('First 10 sources:')
        for i, src in enumerate(res[:10], 1):
            print(i, src)
    else:
        print('No sources found (this may be due to site blocking, debrid requirements, or timeouts)')
