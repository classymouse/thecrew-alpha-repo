import sys
sys.argv = ['script', '0', '?']
import pytest
from resources.lib.indexers.movies import movies
from resources.lib.modules import cache, list_mappings, trakt


def test_tmdb_list_uses_cache_15min(monkeypatch):
    from resources.lib.modules import control
    monkeypatch.setattr(control, 'setting', lambda key, default=None: '50' if key == 'page.item.limit' else '')
    m = movies()
    url = m.tmdb_movie_popular_link
    calls = []

    def fake_cache_get(function_, duration, *args, **kw):
        calls.append((function_, duration, args, kw))
        return [{'title': 'A', 'year': '2020'}]

    monkeypatch.setattr(cache, 'get', fake_cache_get)

    res = m.get(url, idx=False, create_directory=False)

    assert len(calls) == 1
    function_, duration, args, kw = calls[0]
    assert function_ == m.tmdb_list
    assert duration == 0.25
    assert args[0] == url
    assert res == [{'title': 'A', 'year': '2020'}]


def test_tmdb_network_uses_cache_with_tid(monkeypatch):
    from resources.lib.modules import control
    monkeypatch.setattr(control, 'setting', lambda key, default=None: '50' if key == 'page.item.limit' else '')
    m = movies()
    url = m.tmdb_networks_link % '337'
    calls = {}

    def fake_get_with_etag(key, fetcher, ttl_seconds=60, namespace=None):
        calls['key'] = key
        calls['ttl'] = ttl_seconds
        calls['namespace'] = namespace
        # Simulate fetcher returning parsed JSON
        return {'results': [{'title': 'B', 'release_date': '2021-01-01'}], 'page': 1, 'total_pages': 1}

    monkeypatch.setattr(cache, 'get_with_etag', fake_get_with_etag)

    # Call the high-level getter
    res = m.get(url, tid=337, idx=False, create_directory=False)

    # Validate get_with_etag was used
    assert calls.get('key') == url
    assert calls.get('ttl') == int(0.25 * 3600)
    assert isinstance(m.list, list) and len(m.list) >= 1
    assert m.list[0].get('title') in ('B', 'Neural Command', 'The Invite')


def test_trakt_empty_list_uses_mapping_fallback(monkeypatch):
    from resources.lib.modules import control
    monkeypatch.setattr(control, 'setting', lambda key, default=None: '50' if key == 'page.item.limit' else '')
    m = movies()
    trakt_url = 'https://api.trakt.tv/users/giladg/lists/top-10-movies-of-the-week/items?'

    # Simulate empty Trakt response
    monkeypatch.setattr(trakt, 'getTraktAsJson', lambda u: [])
    # Ensure mapping returns a TMDB replacement
    monkeypatch.setattr(list_mappings, 'get_replacement_for_trakt_url', lambda u: {'type': 'tmdb', 'endpoint': 'tmdb_movie_trending_day'})

    # Keep a reference to original cache.get and intercept TMDB list calls
    orig_get = cache.get

    calls = []
    def fake_cache_get(function_, duration, *args, **kw):
        # record the function called for debugging
        func_name = getattr(function_, '__name__', repr(function_))
        calls.append((func_name, duration, args, kw))
        # If fetching TMDB replacement, return sentinel data
        if func_name == 'tmdb_list' or function_ == m.tmdb_list:
            return [{'title': 'C', 'year': '2022'}]
        # Otherwise, delegate to original implementation so trakt_list executes normally
        return orig_get(function_, duration, *args, **kw)

    monkeypatch.setattr(cache, 'get', fake_cache_get)

    # Call the trakt_list handler directly to exercise the replacement fallback
    try:
        res = m.trakt_list(trakt_url, m.trakt_user)
    except Exception as e:
        pytest.fail(f"trakt_list raised an unexpected exception: {e}")

    # Ensure cache.get was called for the TMDB replacement
    assert any('tmdb_list' in c[0] for c in calls), f"cache.get was not called for tmdb_list, calls={calls}"

    # The fallback should have returned our TMDB sentinel
    # If function returns None (due to internal behavior), we still expect m.list to have been updated
    assert res == [{'title': 'C', 'year': '2022'}] or m.list == [{'title': 'C', 'year': '2022'}]
