import os
import sqlite3
from types import SimpleNamespace
import resources.lib.modules.db_schema as db_schema
from resources.lib.modules import control


def test_reads_versions_from_addon_xml(monkeypatch, tmp_path):
    # Ensure fresh DB
    if os.path.exists(control.traktsyncFile):
        try:
            os.remove(control.traktsyncFile)
        except Exception:
            pass

    # Stub xbmcaddon.Addon to return paths and versions
    class DummyAddon:
        def __init__(self, aid):
            self.aid = aid
        def getAddonInfo(self, key):
            if key == 'version':
                if self.aid == 'plugin.video.thecrew':
                    return '2.1.0'
                if self.aid == 'script.module.thecrew':
                    return '2.0.5'
                if self.aid == 'script.thecrew.artwork':
                    return '1.9.9'
            if key == 'path':
                return str(tmp_path)
            return ''

    import xbmcaddon
    monkeypatch.setattr(xbmcaddon, 'Addon', DummyAddon)

    # Ensure crewruntime has no override values
    from resources.lib.modules import crewruntime
    monkeypatch.setattr(crewruntime.c, 'pluginversion', None)
    monkeypatch.setattr(crewruntime.c, 'moduleversion', None)

    # Run check
    db_schema.check_and_migrate_version()

    conn = sqlite3.connect(control.traktsyncFile)
    cur = conn.cursor()
    cur.execute("SELECT value FROM service WHERE setting = 'addon_version_plugin'")
    assert cur.fetchone() is not None
    cur.execute("SELECT value FROM service WHERE setting = 'addon_version_module'")
    assert cur.fetchone() is not None
    cur.execute("SELECT value FROM service WHERE setting = 'addon_version_artwork'")
    assert cur.fetchone() is not None
    conn.close()