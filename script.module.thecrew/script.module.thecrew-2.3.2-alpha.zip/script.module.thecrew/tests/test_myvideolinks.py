# Smoke test for myvideolinks parser
import sys, os, importlib.util
lib_parent = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'lib'))
if lib_parent not in sys.path:
    sys.path.insert(0, lib_parent)

import types
# minimal xbmc/xbmcaddon/xbmcgui/xbmcvfs stubs
if 'xbmc' not in sys.modules:
    sys.modules['xbmc'] = types.SimpleNamespace(getInfoLabel=lambda *a, **k: '21.3.0', getCondVisibility=lambda *a, **k: False, log=lambda *a, **k: None, getLocalizedString=lambda *a, **k: '')
if 'xbmcaddon' not in sys.modules:
    class _AddonStub:
        def __init__(self, addon_id=None):
            self._settings = {}
            self.addon_id = addon_id
        def getSetting(self, id=None, *args, **kwargs):
            return self._settings.get(id, '')
        def getLocalizedString(self, k):
            return str(k)
        def getSettingInfo(self, k):
            return ''
        def getAddonInfo(self, id=None, key=None):
            return ''
        def setSetting(self, id, value):
            self._settings[id] = value
    sys.modules['xbmcaddon'] = types.SimpleNamespace(Addon=_AddonStub)
if 'xbmcgui' not in sys.modules:
    class _DialogStub:
        def notification(self, *args, **kwargs):
            return True
        def ok(self, *args, **kwargs):
            return True
    class _ListItemStub:
        def __init__(self, *args, **kwargs):
            pass
    sys.modules['xbmcgui'] = types.SimpleNamespace(Dialog=_DialogStub, ListItem=_ListItemStub)
if 'xbmcplugin' not in sys.modules:
    sys.modules['xbmcplugin'] = types.SimpleNamespace(setProperty=lambda *a, **k: None)
if 'xbmcvfs' not in sys.modules:
    sys.modules['xbmcvfs'] = types.SimpleNamespace(translatePath=lambda x: x)

# Minimal resources.lib.modules stubs
if 'resources' not in sys.modules:
    resources = types.ModuleType('resources')
    sys.modules['resources'] = resources
if 'resources.lib' not in sys.modules:
    sys.modules['resources.lib'] = types.ModuleType('resources.lib')
if 'resources.lib.modules' not in sys.modules:
    modpkg = types.ModuleType('resources.lib.modules')
    import re as _re
    cleantitle = types.SimpleNamespace(get_query=lambda x: x, geturl=lambda x: x, get=lambda x: _re.sub('[^a-z0-9]', '', str(x).lower()))
    client = types.SimpleNamespace(request=lambda *a, **k: '', parseDom=lambda *a, **k: [], replaceHTMLCodes=lambda x: x, ensure_text=lambda x, **k: x, ensure_str=lambda x, **k: str(x), agent=lambda: 'agent')
    debrid = types.SimpleNamespace(status=lambda: True)
    source_utils = types.SimpleNamespace(is_host_valid=lambda u, h: (True, 'example.com'), get_release_quality=lambda n, u: ('SD', []))
    c_stub = types.SimpleNamespace(log=lambda *a, **k: None, ensure_text=lambda x, **k: x, ensure_str=lambda x, **k: str(x))
    modpkg.cleantitle = cleantitle
    modpkg.client = client
    modpkg.debrid = debrid
    modpkg.source_utils = source_utils
    modpkg.crewruntime = types.SimpleNamespace(c=c_stub)
    sys.modules['resources.lib.modules'] = modpkg
    crewruntime_mod = types.ModuleType('resources.lib.modules.crewruntime')
    crewruntime_mod.c = c_stub
    sys.modules['resources.lib.modules.crewruntime'] = crewruntime_mod

# Load myvideolinks module via importlib
spec = importlib.util.spec_from_file_location('mvid', os.path.join(os.path.dirname(__file__), '..', 'lib', 'resources', 'lib', 'sources', 'en_de', 'myvideolinks.py'))
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

# Test case 1: No posts -> empty sources
mod.client.request = lambda *a, **k: '<html></html>'
s = mod.source()
res = s.sources({'imdb': 'tt0000000', 'title': 'Test Movie', 'year': 2017}, hostDict=['example'], hostprDict=[])
print('myvideolinks empty-posts result length:', len(res))

# Test case 2: Single post with one valid link
html = '<article><img title="Test.Movie.2017.720p.mkv"><a href="https://example.com/file"></a></article>'
mod.client.request = lambda *a, **k: html
mod.client.parseDom = lambda txt, tag, ret=None, **k: [ 'https://example.com/file' ] if tag == 'a' and ret == 'href' else (['Test.Movie.2017.720p.mkv'] if tag == 'img' and ret == 'title' else [html])
res = s.sources({'imdb': 'tt0000000', 'title': 'Test Movie', 'year': 2017}, hostDict=['example'], hostprDict=[])
print('myvideolinks valid-post result length:', len(res))
print('myvideolinks result:', res)