# Smoke test for ororo parser
import sys, os, importlib.util
lib_parent = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'lib'))
if lib_parent not in sys.path:
    sys.path.insert(0, lib_parent)

import types
# minimal xbmc/xbmcaddon/xbmcgui/xbmcvfs stubs
if 'xbmc' not in sys.modules:
    sys.modules['xbmc'] = types.SimpleNamespace(getInfoLabel=lambda *a, **k: '21.3.0')
if 'xbmcaddon' not in sys.modules:
    class _AddonStub:
        def __init__(self, addon_id=None):
            self._settings = {}
            self.addon_id = addon_id
        def getSetting(self, id=None, *args, **kwargs):
            return self._settings.get(id, '')
        def setSetting(self, id, value):
            self._settings[id] = value
    sys.modules['xbmcaddon'] = types.SimpleNamespace(Addon=_AddonStub)
if 'xbmcgui' not in sys.modules:
    class _DialogStub:
        def notification(self, *args, **kwargs):
            return True
    sys.modules['xbmcgui'] = types.SimpleNamespace(Dialog=_DialogStub)
if 'xbmcvfs' not in sys.modules:
    sys.modules['xbmcvfs'] = types.SimpleNamespace(translatePath=lambda x: x)

# Minimal resources.lib.modules stubs
if 'resources' not in sys.modules:
    resources = types.ModuleType('resources')
    sys.modules['resources'] = resources
if 'resources.lib' not in sys.modules:
    sys.modules['resources.lib'] = types.ModuleType('resources.lib')
if 'resources.lib.modules' not in sys.modules:
    modpkg = types.ModuleType('resources.lib.modules')
    cache = types.SimpleNamespace(get=lambda *a, **k: [])
    control = types.SimpleNamespace(setting=lambda k: '')
    client = types.SimpleNamespace(request=lambda *a, **k: '', parseDom=lambda *a, **k: [])
    crewruntime = types.SimpleNamespace(c=types.SimpleNamespace(log=lambda *a, **k: None))
    modpkg.cache = cache
    modpkg.control = control
    modpkg.client = client
    modpkg.crewruntime = crewruntime
    sys.modules['resources.lib.modules'] = modpkg
    crewruntime_mod = types.ModuleType('resources.lib.modules.crewruntime')
    crewruntime_mod.c = crewruntime.c
    sys.modules['resources.lib.modules.crewruntime'] = crewruntime_mod

# Load ororo module via importlib
spec = importlib.util.spec_from_file_location('resources.lib.sources.en.ororo', os.path.join(os.path.dirname(__file__), '..', 'lib', 'resources', 'lib', 'sources', 'en', 'ororo.py'))
mod = importlib.util.module_from_spec(spec)
# Ensure relative imports resolve properly by setting package context
mod.__package__ = 'resources.lib.sources.en'
spec.loader.exec_module(mod)

s = mod.source()

# Test 1: No credentials configured
res_movie = s.movie('tt0000000', 'Title', 'Title', [], 2017)
print('ororo no-creds movie:', res_movie)
res_sources = s.sources('/api/v2/movies/1', hostDict=['example'], hostprDict=[])
print('ororo no-creds sources length:', len(res_sources))

# Test 2: Credentials present but network/invalid JSON
# NOTE: these are dummy test credentials for unit testing only — no real secrets
sys.modules['resources.lib.modules'].control.setting = lambda k: 'u' if k == 'ororo.user' else ('p' if k == 'ororo.pass' else '')
# update the instantiated source with credentials (tests instantiate source before changing control.setting)
s.user = 'u'
s.password = 'p'
s.user = f"{s.user}:{s.password}"
import base64
s.encoded = base64.b64encode(s.user.encode('utf-8')).decode('utf-8')
s.headers = {'Authorization': 'Basic %s' % s.encoded, 'User-Agent': 'Kodi'}
# simulate client.request raising
orig_client_request = sys.modules['resources.lib.modules'].client.request
sys.modules['resources.lib.modules'].client.request = lambda *a, **k: ''
res_movie = s.movie('tt0000000', 'Title', 'Title', [], 2017)
print('ororo creds but empty cache movie:', res_movie)
res_sources = s.sources('/api/v2/movies/1', hostDict=['example'], hostprDict=[])
print('ororo creds but empty response sources length:', len(res_sources))

# Test 3: Valid cache and media URL
# Patch ororo_moviecache to return one matching entry
mod.source.ororo_moviecache = lambda self, user: [('123', 'tt0000000')]
# Patch client.request to return JSON with media URL when called for movie endpoint
mod.client.request = lambda url, headers=None: __import__('json').dumps({'url': 'https://ororo.tv/stream/123'})
res_movie = s.movie('tt0000000', 'Title', 'Title', [], 2017)
print('ororo movie url:', res_movie)
res_sources = s.sources(res_movie, hostDict=['example'], hostprDict=[])
print('ororo valid sources length:', len(res_sources))
print('ororo valid sources:', res_sources)

# Restore client.request
sys.modules['resources.lib.modules'].client.request = orig_client_request
