from resources.lib.modules.sources import Sources


def test_format_provider_display_shortens_package_names():
    s = Sources()
    long_name = 'resources.lib.sources.en_tor.torrentio'
    assert s.format_provider_display(long_name) == 'Torrentio'


def test_format_provider_display_handles_simple_name():
    s = Sources()
    assert s.format_provider_display('torrentio') == 'Torrentio'


def test_format_provider_display_cocos_and_gears():
    s = Sources()
    # cocoscrapers
    coco = 'cocoscrapers.torrents_mediafusion'
    assert '[Coco]' in s.format_provider_display(coco)
    # gearsscrapers
    gears = 'gearsscrapers.torrents_example'
    assert '[Gears]' in s.format_provider_display(gears)
