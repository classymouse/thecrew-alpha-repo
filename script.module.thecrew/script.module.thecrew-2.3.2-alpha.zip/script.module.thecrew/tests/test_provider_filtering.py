# Test: ensure gearsscrapers providers are not filtered when enabled
import sys
import os
import types

# Add lib to path
lib_parent = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'lib'))
lib_path = os.path.join(lib_parent, 'resources', 'lib')
if lib_parent not in sys.path:
    sys.path.insert(0, lib_parent)
if lib_path not in sys.path:
    sys.path.insert(0, lib_path)

# Minimal xbmc stubs to allow module imports outside Kodi
if 'xbmc' not in sys.modules:
    sys.modules['xbmc'] = types.SimpleNamespace(
        getCondVisibility=lambda *a, **k: False,
        log=lambda *a, **k: None,
        getInfoLabel=lambda *a, **k: '21.3.0',
        getLocalizedString=lambda *a, **k: '',
        executeJSONRPC=lambda *a, **k: '{}',
        Keyboard=object,
        Monitor=lambda *a, **k: object(),
        Player=object,
        PlayList=lambda *a, **k: [],
        PLAYLIST_VIDEO=1,
        getSkinDir=lambda *a, **k: '',
        executebuiltin=lambda *a, **k: None,
        LOGDEBUG=1,
        LOGINFO=2,
        LOGERROR=3,
        Actor=object,
        VideoStreamDetail=object,
        AudioStreamDetail=object,
        SubtitleStreamDetail=object
    )
if 'xbmcaddon' not in sys.modules:
    class _AddonStub:
        def __init__(self, addon_id=None):
            self._settings = {}
        def getSetting(self, id=None, *args, **kwargs):
            defaults = {
                'fanart.quality': '2',
                'addon_debug': 'false',
                'dev_pw': '',
                'HEVC': 'true',
                'sources.cache.duration': '15',
                'cocoscrapers.enabled': 'true',
                'gearsscrapers.enabled': 'true',
                'hosts.quality': '0',
                'progress.dialog': '0'
            }
            if id in self._settings:
                return self._settings.get(id)
            return defaults.get(id, '')
        def getLocalizedString(self, k):
            return str(k)
        def getSettingInfo(self, k):
            return ''
        def getAddonInfo(self, id=None, **kwargs):
            return ''
        def setSetting(self, id=None, value=None, *args, **kwargs):
            self._settings[id] = value
            return None
    sys.modules['xbmcaddon'] = types.SimpleNamespace(Addon=_AddonStub)
if 'xbmcvfs' not in sys.modules:
    sys.modules['xbmcvfs'] = types.SimpleNamespace(
        translatePath=lambda x: x,
        makeLegalFilename=lambda x: x,
        File=lambda *a, **k: None,
        mkdir=lambda *a, **k: None,
        delete=lambda *a, **k: None,
        rmdir=lambda *a, **k: None,
        listdir=lambda *a, **k: ([], [])
    )
if 'xbmcgui' not in sys.modules:
    class _DialogStub:
        def notification(self, *args, **kwargs):
            return True
        def ok(self, *args, **kwargs):
            return True
    class _ListItemStub:
        def __init__(self, *args, **kwargs):
            pass
    class _WindowStub:
        def __init__(self, *args, **kwargs):
            self._props = {}
        def getProperty(self, k):
            return self._props.get(k, '')
        def setProperty(self, k, v):
            self._props[k] = v
        def clearProperty(self, k):
            if k in self._props:
                del self._props[k]
    class _DialogProgress:
        def __init__(self, *args, **kwargs):
            self._canceled = False
        def create(self, header, message=''):
            self._canceled = False
        def update(self, percent, message=None):
            return True
        def iscanceled(self):
            return self._canceled
        def close(self):
            self._canceled = True
    class _WindowDialog:
        def __init__(self, *args, **kwargs):
            pass
    sys.modules['xbmcgui'] = types.SimpleNamespace(
        Dialog=_DialogStub,
        ListItem=_ListItemStub,
        Window=_WindowStub,
        DialogProgress=_DialogProgress,
        DialogProgressBG=_DialogProgress,
        WindowDialog=_WindowDialog,
        ControlButton=object,
        ControlImage=object,
        getCurrentWindowDialogId=lambda: 10000,
        Keyboard=object,
        Monitor=lambda *a, **k: object(),
        Player=object,
        PlayList=lambda *a, **k: [],
        PLAYLIST_VIDEO=1
    )
if 'xbmcplugin' not in sys.modules:
    sys.modules['xbmcplugin'] = types.SimpleNamespace(
        setProperty=lambda *a, **k: None,
        addDirectoryItem=lambda *a, **k: None,
        addDirectoryItems=lambda *a, **k: None,
        endOfDirectory=lambda *a, **k: None,
        setResolvedUrl=lambda *a, **k: None,
        setContent=lambda *a, **k: None,
        addSortMethod=lambda *a, **k: None,
        addSortMethodEx=lambda *a, **k: None
    )

# Provide simple resolveurl stub
if 'resolveurl' not in sys.modules:
    sys.modules['resolveurl'] = types.SimpleNamespace()

# Run the test
try:
    from modules.crewruntime import c
    from modules.sources import Sources

    # Ensure setting is enabled before instantiation
    c.set_setting('gearsscrapers.enabled', 'true')

    s = Sources()

    # Dummy provider that exposes a 'sources' attribute and language
    class DummyProvider:
        def __init__(self):
            self.sources = lambda *a, **k: []
            self.language = ['en']
            self.priority = 0

    source_dict = [('gearsscrapers.providers.torrents.1337x', DummyProvider())]

    filtered, content = s.filter_source_dict(None, source_dict)

    gear_names = []
    for item in filtered:
        if isinstance(item, (list, tuple)) and item:
            name = item[0]
            if isinstance(name, str) and name.startswith('gearsscrapers.'):
                gear_names.append(name)

    # ASSERTION: ensure at least one gearsscrapers provider survived filtering
    assert gear_names, f"Expected gearsscrapers provider to be included after filtering, got {repr(filtered)}"

    print('\n=== Testing Provider Filtering ===')
    if gear_names:
        print(f"✓ Gear providers included after filtering: {gear_names}")
        print('Provider Filtering: PASS')
    else:
        print('✗ Gear providers were filtered out')
        print('Filtered snapshot:')
        print(repr(filtered))
        print('Provider Filtering: FAIL')
        # Fail fast with pytest-friendly assertion
        assert False, f"Gear providers were filtered out: {repr(filtered)}"

    # --- Test 2: per-provider override ---
    print('\n=== Testing per-provider override (gear global OFF, provider.<name> ON) ===')
    # Turn global gear off
    try:
        c.set_setting('gearsscrapers.enabled', 'false')
    except Exception:
        pass

    # Temporarily override control.setting to return 'true' for provider.1337x
    from resources.lib.modules import control as _control
    _orig_setting = _control.setting
    def _mock_setting(k):
        if k == 'provider.1337x':
            return 'true'
        return _orig_setting(k)
    _control.setting = _mock_setting

    try:
        print('DEBUG test: c.get_setting gearsscrapers.enabled =', c.get_setting('gearsscrapers.enabled'))
        print('DEBUG test: control.setting provider.1337x =', _control.setting('provider.1337x'))
        print('DEBUG test: id(_control)=', id(_control))
        import resources.lib.modules as _pkg
        print('DEBUG test: id(pkg.control)=', id(_pkg.control))
        import sys as _sys
        for k, v in list(_sys.modules.items()):
            if k.endswith('.control'):
                print('MODULE', k, id(v))
        s2 = Sources()
        print('DEBUG test: s2.gearsscrapers_enabled =', s2.gearsscrapers_enabled)
        filtered2, content2 = s2.filter_source_dict(None, source_dict)
        print('DEBUG test: filtered2 =', filtered2)
        gear_names2 = []
        for item in filtered2:
            if isinstance(item, (list, tuple)) and item:
                name = item[0]
                if isinstance(name, str) and name.startswith('gearsscrapers.'):
                    gear_names2.append(name)

        assert gear_names2, f"Per-provider override failed; expected gear provider to be included, got {repr(filtered2)}"
        print(f"✓ Per-provider override kept gear provider: {gear_names2}")
        print('\nALL TESTS PASSED')
        # restore
        _control.setting = _orig_setting
    except Exception as e:
        _control.setting = _orig_setting
        import traceback
        print(f"✗ Per-provider override test failed: {e}")
        print(traceback.format_exc())
        import pytest
        pytest.fail(f"Per-provider override test failed: {e}\n{traceback.format_exc()}")

    # --- Test 3: dev-mode forces gear providers enabled ---
    print('\n=== Testing dev-mode override (dev_mode ON, global OFF) ===')
    try:
        c.set_setting('gearsscrapers.enabled', 'false')
    except Exception:
        pass

    try:
        s3 = Sources()
        s3.dev_mode = True
        filtered3, content3 = s3.filter_source_dict(None, source_dict)
        gear_names3 = [item[0] for item in filtered3 if isinstance(item, (list, tuple)) and item and isinstance(item[0], str) and item[0].startswith('gearsscrapers.')]
        assert gear_names3, f"Dev-mode override failed; expected gear provider to be included when dev_mode=True, got {repr(filtered3)}"
        print(f"✓ Dev-mode override kept gear provider: {gear_names3}")
        print('\nALL TESTS PASSED')
    except Exception as e:
        import traceback
        print(f"✗ Dev-mode override test failed: {e}")
        print(traceback.format_exc())
        import pytest
        pytest.fail(f"Dev-mode override test failed: {e}\n{traceback.format_exc()}")

except Exception as e:
    import traceback
    print(f"✗ Provider filtering test failed: {e}")
    print(traceback.format_exc())
    import pytest
    pytest.fail(f"Provider filtering test failed: {e}\n{traceback.format_exc()}")
