import base64
import json

from resources.lib.modules.sources import Sources


def test_provider_mask_decode():
    full = 'resources.lib.sources.en_tor.torrentio'
    enc = base64.b64encode(full.encode('utf-8')).decode('ascii')
    items = json.loads(json.dumps([{'provider': 'TORRENTIO', '_provider_enc': enc}]))

    # simulate the decode block used in playItem
    try:
        for it in items:
            enc_val = it.pop('_provider_enc', None)
            if enc_val:
                it['provider'] = base64.b64decode(enc_val.encode('ascii')).decode('utf-8')
    except Exception:
        pass

    assert items[0]['provider'] == full


def test_additem_fallback_does_not_leak_provider(monkeypatch):
    import json as _json
    from urllib.parse import urlparse, parse_qs, unquote
    from resources.lib.modules import control as control_mod

    full_provider = 'resources.lib.sources.en_tor.torrentio'
    item = {'provider': full_provider, 'label': '01 | Test', 'url': 'http://example'}

    # Prepare window property that addItem will read
    s = Sources()
    try:
        control_mod.window.props.pop(s.itemProperty, None)
    except Exception:
        pass
    control_mod.window.props[s.itemProperty] = _json.dumps([item])

    # Force format_provider_display to raise to hit the fallback path
    def raise_exc(_):
        raise Exception('boom')
    monkeypatch.setattr(s, 'format_provider_display', raise_exc)

    captured = []

    # Capture URLs passed to control.addItem
    def fake_addItem(handle=None, url=None, listitem=None, isFolder=False):
        captured.append(url)
    monkeypatch.setattr(control_mod, 'addItem', fake_addItem)

    # Ensure meta property exists minimally so addItem proceeds
    control_mod.window.props[s.metaProperty] = _json.dumps({'poster': '', 'studio': '', 'genre': '', 'director': '', 'writer': ''})

    # Run addItem which should use the hardened fallback when masking fails
    s.addItem('TestTitle')

    assert captured, 'control.addItem was not called'
    url = captured[0]
    qs = parse_qs(urlparse(url).query)
    source_field = qs.get('source', [''])[0]
    decoded = _json.loads(unquote(source_field))[0]

    # Provider should not contain the full dotted module path
    assert 'resources.lib.' not in str(decoded.get('provider', ''))
    # The encoded provider, if present, should decode to the original full provider
    enc = decoded.get('_provider_enc', None)
    if enc:
        import base64 as _base64
        assert _base64.b64decode(enc.encode('ascii')).decode('utf-8') == full_provider
