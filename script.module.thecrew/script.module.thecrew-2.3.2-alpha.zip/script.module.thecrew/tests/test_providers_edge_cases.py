import pytest

from resources.lib.modules import debrid
from resources.lib.modules import client as main_client


def test_scenerls_handles_empty_response(monkeypatch):
    from resources.lib.sources.en_de.scenerls import source as SceneRLS

    # ensure debrid allows running
    monkeypatch.setattr(debrid, 'status', lambda: True)

    # client.request returns None (simulating blocked/empty)
    monkeypatch.setattr(main_client, 'request', lambda url: None)

    src = SceneRLS()
    res = src.sources({'title': 'Test Movie', 'year': '2020', 'season': 1, 'episode': 1}, {}, {})
    assert isinstance(res, list)
    assert res == []


def test_1337x_handles_empty_response(monkeypatch):
    import importlib
    X1337 = importlib.import_module('resources.lib.sources.en_tor.1337x').source
    from resources.lib.modules import client

    monkeypatch.setattr(debrid, 'status', lambda: True)

    # Make client.request return None to simulate failure/empty page
    monkeypatch.setattr(client, 'request', lambda url, timeout=10: None)

    src = X1337()
    data = {'tvshowtitle': 'Test Show', 'season': 1, 'episode': 1, 'aliases': [], 'year': '2020'}
    res = src.sources(data, {})
    assert isinstance(res, list)
    assert res == []


def test_torrentgalaxy_base_links_and_time():
    # Simple import-level checks to validate previous NameError and base_links bug
    import importlib
    tgx_mod = importlib.import_module('gearsscrapers.providers.torrents.torrentgalaxy')
    src = tgx_mod.source()
    assert isinstance(src.base_links, list) and len(src.base_links) > 0
    assert hasattr(tgx_mod, 'time') and callable(tgx_mod.time)


def test_gear_shim_has_clean_name():
    import importlib
    su = importlib.import_module('gearsscrapers.modules.source_utils')
    assert hasattr(su, 'clean_name') and callable(su.clean_name)
    assert isinstance(su.clean_name('Test Title (2020)'), str)


def test_databasegdriveplayer_malformed_html(monkeypatch):
    from resources.lib.sources.en.databasegdriveplayer import source as DBG
    from resources.lib.modules import client

    monkeypatch.setattr(debrid, 'status', lambda: True)
    # return HTML with malformed content that could break parseDom regex
    monkeypatch.setattr(client, 'request', lambda url: "<html><ul class='list-server-items'><li><a href=\"http://example.com/video(\"></li></ul></html>")

    src = DBG()
    res = src.sources({'title': 'Test', 'year': '2020', 'imdb': 'tt1234567'}, {})
    assert isinstance(res, list)
    assert res == []


def test_torz_handles_invalid_json(monkeypatch):
    from gearsscrapers.providers.torrents.torz import source as Torz
    from gearsscrapers.modules import client

    monkeypatch.setattr(client, 'request', lambda url, timeout=10: 'not-a-json')

    src = Torz()
    data = {'title': 'Test Movie', 'year': '2020', 'aliases': [], 'imdb': 'tt12345'}
    res = src.sources(data, {})
    assert isinstance(res, list)
    assert res == []


def test_torrentio_handles_invalid_json(monkeypatch):
    from gearsscrapers.providers.torrents.torrentio import source as TI
    from gearsscrapers.modules import client

    monkeypatch.setattr(client, 'request', lambda url, timeout=10: 'not-a-json')

    src = TI()
    data = {'title': 'Test Movie', 'year': '2020', 'aliases': [], 'imdb': 'tt12345'}
    res = src.sources(data, {})
    assert isinstance(res, list)
    assert res == []


def test_comet_handles_invalid_json(monkeypatch):
    from gearsscrapers.providers.torrents.comet import source as Comet
    from gearsscrapers.modules import client

    monkeypatch.setattr(client, 'request', lambda url, timeout=10: 'not-a-json')

    src = Comet()
    data = {'title': 'Test Movie', 'year': '2020', 'aliases': [], 'imdb': 'tt12345'}
    res = src.sources(data, {})
    assert isinstance(res, list)
    assert res == []


def test_bitmagnet_handles_invalid_json(monkeypatch):
    from gearsscrapers.providers.torrents.bitmagnet import source as BM
    from gearsscrapers.modules import client

    monkeypatch.setattr(client, 'request', lambda url, headers=None, timeout=10: 'not-a-json')

    src = BM()
    data = {'title': 'Test Movie', 'year': '2020', 'aliases': [], 'imdb': 'tt12345'}
    res = src.sources(data, {})
    assert isinstance(res, list)
    assert res == []


def test_torrentdownloads_handles_empty_rss(monkeypatch):
    from resources.lib.sources.en_tor.torrentdownloads import source as TD
    from resources.lib.modules import client

    monkeypatch.setattr(client, 'request', lambda url, headers=None: None)

    src = TD()
    data = {'tvshowtitle': 'Test Show', 'season': 1, 'episode': 1, 'title': 'Test Ep', 'year': '2020'}
    res = src.sources(data, {})
    assert isinstance(res, list)
    assert res == []


def test_torrentdownload_handles_malformed_rows(monkeypatch):
    # Simulate a response with a <tr> that lacks the expected href format so re.search(...).group(1) fails
    from gearsscrapers.providers.torrents.torrentdownload import source as TD
    from gearsscrapers.modules import client

    monkeypatch.setattr(client, 'request', lambda url, timeout=5: '<table><tr><td>no href here</td></tr></table>')

    src = TD()
    data = {'title': 'Test Movie', 'year': '2020', 'aliases': [], 'imdb': 'tt12345'}
    res = src.sources(data, {})
    assert isinstance(res, list)
    assert res == []


def test_knaben_handles_missing_hash_or_dn(monkeypatch):
    from gearsscrapers.providers.torrents.knaben import source as KB
    from gearsscrapers.modules import client

    # Simulate a row where the magnet has no btih or no dn param
    html = '<table><tr class="text-nowrap border-start"><td></td><td>magnet:?xt=urn:btih:&tr=tracker</td></tr></table>'
    monkeypatch.setattr(client, 'request', lambda url, timeout=7: html)

    src = KB()
    data = {'title': 'Test Movie', 'year': '2020', 'aliases': [], 'imdb': 'tt12345'}
    res = src.sources(data, {})
    assert isinstance(res, list)
    assert res == []
