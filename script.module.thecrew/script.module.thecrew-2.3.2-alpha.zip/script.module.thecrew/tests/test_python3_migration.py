#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Test suite for Python 3 migration validation.
Tests core modules without requiring Kodi runtime.
"""

import sys
import os

# Add lib to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'lib', 'resources', 'lib'))

def test_imports():
    """Test that all core modules can be imported."""
    print("Testing module imports...")
    errors = []

    try:
        from modules import string_utils
        print("✓ string_utils")
    except Exception as e:
        errors.append(f"string_utils: {e}")

    try:
        from modules import cache
        print("✓ cache")
    except Exception as e:
        errors.append(f"cache: {e}")

    try:
        from modules import cleantitle
        print("✓ cleantitle")
    except Exception as e:
        errors.append(f"cleantitle: {e}")

    try:
        from modules import cleangenre
        print("✓ cleangenre")
    except Exception as e:
        errors.append(f"cleangenre: {e}")

    try:
        from modules import workers
        print("✓ workers")
    except Exception as e:
        errors.append(f"workers: {e}")

    return errors


def test_string_utils():
    """Test string_utils functions."""
    print("\nTesting string_utils functions...")
    from modules import string_utils

    # Test ensure_str
    assert string_utils.ensure_str("test") == "test"
    assert string_utils.ensure_str(b"test") == "test"
    assert string_utils.ensure_str(123) == "123"
    print("✓ ensure_str")

    # Test ensure_bytes
    assert string_utils.ensure_bytes("test") == b"test"
    assert string_utils.ensure_bytes(b"test") == b"test"
    print("✓ ensure_bytes")

    # Test safe_decode
    assert string_utils.safe_decode(b"test") == "test"
    assert string_utils.safe_decode("test") == "test"
    print("✓ safe_decode")

    # Test clean_html
    html = "<p>Hello <b>World</b></p>"
    assert "Hello World" in string_utils.clean_html(html)
    print("✓ clean_html")

    # Test normalize_string
    assert string_utils.normalize_string("  Test  String  ") == "Test String"
    assert string_utils.normalize_string("Test", lowercase=True) == "test"
    print("✓ normalize_string")

    # Test truncate
    assert string_utils.truncate("Hello World", 8) == "Hello..."
    assert string_utils.truncate("Hi", 10) == "Hi"
    print("✓ truncate")

    # Test join_non_empty
    assert string_utils.join_non_empty(" - ", "A", None, "B", "") == "A - B"
    print("✓ join_non_empty")

    return []


def test_no_six_usage():
    """Verify no six library usage in core modules."""
    print("\nChecking for six library usage...")

    import glob
    files_to_check = []

    # Check modules
    modules_path = os.path.join(os.path.dirname(__file__), 'lib', 'resources', 'lib', 'modules', '*.py')
    files_to_check.extend(glob.glob(modules_path))

    issues = []
    for filepath in files_to_check:
        if '__pycache__' in filepath:
            continue

        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
            if 'import six' in content or 'from six' in content:
                issues.append(os.path.basename(filepath))

    if issues:
        print(f"⚠ Found six usage in: {', '.join(issues)}")
    else:
        print("✓ No six library usage detected")

    return issues


def test_no_python2_patterns():
    """Check for common Python 2 patterns."""
    print("\nChecking for Python 2 patterns...")

    import glob
    files_to_check = []

    # Check modules
    modules_path = os.path.join(os.path.dirname(__file__), 'lib', 'resources', 'lib', 'modules', '*.py')
    files_to_check.extend(glob.glob(modules_path))

    patterns = {
        'xrange': [],
        'iteritems': [],
        'basestring': [],
        'from __future__': [],
    }

    for filepath in files_to_check:
        if '__pycache__' in filepath:
            continue

        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
            for pattern in patterns:
                if pattern in content:
                    patterns[pattern].append(os.path.basename(filepath))

    issues = []
    for pattern, files in patterns.items():
        if files:
            print(f"⚠ Found '{pattern}' in: {', '.join(files)}")
            issues.extend(files)
        else:
            print(f"✓ No '{pattern}' usage")

    return issues


def main():
    """Run all tests."""
    print("=" * 60)
    print("Python 3 Migration Validation")
    print("=" * 60)
    print(f"Python version: {sys.version}")
    print()

    all_errors = []

    # Test 1: Imports
    errors = test_imports()
    all_errors.extend(errors)

    # Test 2: String utils
    try:
        errors = test_string_utils()
        all_errors.extend(errors)
    except Exception as e:
        print(f"✗ String utils test failed: {e}")
        all_errors.append(str(e))

    # Test 3: No six usage
    errors = test_no_six_usage()
    all_errors.extend(errors)

    # Test 4: No Python 2 patterns
    errors = test_no_python2_patterns()
    all_errors.extend(errors)

    # Summary
    print("\n" + "=" * 60)
    if all_errors:
        print(f"FAILED - {len(all_errors)} issues found")
        for error in all_errors:
            print(f"  - {error}")
        return 1
    else:
        print("✓ ALL TESTS PASSED")
        print("Python 3 migration validated successfully!")
        return 0


if __name__ == '__main__':
    sys.exit(main())
