# Simple smoke test for rlsbb parser
import sys, os
# Load rlsbb via importlib to avoid package-relative import issues
import importlib.util
spec = importlib.util.spec_from_file_location('resources.lib.sources.en_de.rlsbb', os.path.join(os.path.dirname(__file__), '..', 'lib', 'resources', 'lib', 'sources', 'en_de', 'rlsbb.py'))
rlsbb = importlib.util.module_from_spec(spec)
# Ensure relative imports resolve properly by setting package context
rlsbb.__package__ = 'resources.lib.sources.en_de'
# Ensure 'resources' package is importable by adding the parent 'lib' path
import sys
lib_parent = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'lib'))
if lib_parent not in sys.path:
    sys.path.insert(0, lib_parent)

# Provide minimal xbmc stubs so module imports succeed outside Kodi
import types
# xbmc
if 'xbmc' not in sys.modules:
    sys.modules['xbmc'] = types.SimpleNamespace(getInfoLabel=lambda *a, **k: '21.3.0', getCondVisibility=lambda *a, **k: False, log=lambda *a, **k: None, getLocalizedString=lambda *a, **k: '')
# xbmcaddon
if 'xbmcaddon' not in sys.modules:
    class _AddonStub:
        def __init__(self, addon_id=None):
            self._settings = {}
            self.addon_id = addon_id
        def getSetting(self, id=None, *args, **kwargs):
            # Provide sensible defaults expected during initialization
            return self._settings.get(id, '0')
        def getLocalizedString(self, k):
            return str(k)
        def getSettingInfo(self, k):
            return ''
        def getAddonInfo(self, id=None, key=None):
            # return minimal expected addon info
            return ''
        def setSetting(self, id, value):
            self._settings[id] = value
    sys.modules['xbmcaddon'] = types.SimpleNamespace(Addon=_AddonStub)
# xbmcgui
if 'xbmcgui' not in sys.modules:
    class _DialogStub:
        def notification(self, *args, **kwargs):
            return True
        def ok(self, *args, **kwargs):
            return True
    class _ListItemStub:
        def __init__(self, *args, **kwargs):
            pass
    sys.modules['xbmcgui'] = types.SimpleNamespace(Dialog=_DialogStub, ListItem=_ListItemStub)
# xbmcplugin
if 'xbmcplugin' not in sys.modules:
    sys.modules['xbmcplugin'] = types.SimpleNamespace(setProperty=lambda *a, **k: None)
# xbmcvfs
if 'xbmcvfs' not in sys.modules:
    sys.modules['xbmcvfs'] = types.SimpleNamespace(translatePath=lambda x: x)

# Create light-weight 'resources.lib.modules' stubs used by rlsbb to avoid importing the full stack
import types
if 'resources' not in sys.modules:
    resources = types.ModuleType('resources')
    sys.modules['resources'] = resources
if 'resources.lib' not in sys.modules:
    sys.modules['resources.lib'] = types.ModuleType('resources.lib')
if 'resources.lib.modules' not in sys.modules:
    modpkg = types.ModuleType('resources.lib.modules')
    # cleantitle stub
    cleantitle = types.SimpleNamespace(get_query=lambda x: x)
    # client stub (only minimal functions used before 404 detection)
    client = types.SimpleNamespace(parseDom=lambda *a, **k: [], replaceHTMLCodes=lambda x: x, ensure_text=lambda x, **k: x, ensure_str=lambda x, **k: str(x))
    # debrid stub
    debrid = types.SimpleNamespace(status=lambda: True)
    # source_utils stub
    source_utils = types.SimpleNamespace(get_release_quality=lambda x: ('SD', []))
    # cfscrape stub
    cfscrape = types.SimpleNamespace(create_scraper=lambda: None)
    # crewruntime.c stub (minimal needed methods)
    c_stub = types.SimpleNamespace(log=lambda *a, **k: None, ensure_text=lambda x, **k: x, ensure_str=lambda x, **k: str(x))
    modpkg.cleantitle = cleantitle
    modpkg.client = client
    modpkg.debrid = debrid
    modpkg.source_utils = source_utils
    modpkg.cfscrape = cfscrape
    modpkg.crewruntime = types.SimpleNamespace(c=c_stub)
    sys.modules['resources.lib.modules'] = modpkg
    # Also ensure the crewruntime submodule object exists so 'from resources.lib.modules.crewruntime import c' works
    crewruntime_mod = types.ModuleType('resources.lib.modules.crewruntime')
    crewruntime_mod.c = c_stub
    sys.modules['resources.lib.modules.crewruntime'] = crewruntime_mod

spec.loader.exec_module(rlsbb)

# Create fake scraper/response
class FakeResp:
    def __init__(self, status=404, content=b'404 Not Found'):
        self.status_code = status
        self.content = content

class FakeScraper:
    def get(self, url):
        return FakeResp()

# Monkeypatch cfscrape.create_scraper on the resources stub
orig_create = sys.modules['resources.lib.modules'].cfscrape.create_scraper
sys.modules['resources.lib.modules'].cfscrape.create_scraper = lambda: FakeScraper()

# Monkeypatch debrid status to True
orig_debrid_status = sys.modules['resources.lib.modules'].debrid.status
sys.modules['resources.lib.modules'].debrid.status = lambda: True

s = rlsbb.source()
res = s.sources('imdb=tt5519340&title=Bright&year=2017', hostDict=['rlsbb'], hostprDict=[])
print('rlsbb sources result length:', len(res))

# Restore
sys.modules['resources.lib.modules'].cfscrape.create_scraper = orig_create
sys.modules['resources.lib.modules'].debrid.status = orig_debrid_status
