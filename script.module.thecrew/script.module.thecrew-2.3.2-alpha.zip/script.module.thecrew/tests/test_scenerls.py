# Smoke test for scenerls parser
import sys, os, importlib.util
lib_parent = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'lib'))
if lib_parent not in sys.path:
    sys.path.insert(0, lib_parent)

import types
# minimal stubs
if 'resources' not in sys.modules:
    resources = types.ModuleType('resources')
    sys.modules['resources'] = resources
if 'resources.lib' not in sys.modules:
    sys.modules['resources.lib'] = types.ModuleType('resources.lib')
if 'resources.lib.modules' not in sys.modules:
    modpkg = types.ModuleType('resources.lib.modules')
    import re as _re
    cleantitle = types.SimpleNamespace(get_query=lambda x: x, get=lambda x: _re.sub('[^a-z0-9]','',str(x).lower()))
    client = types.SimpleNamespace(request=lambda *a, **k: '', parseDom=lambda *a, **k: [])
    cfscrape = types.SimpleNamespace(create_scraper=lambda: None)
    debrid = types.SimpleNamespace(status=lambda: True)
    source_utils = types.SimpleNamespace(get_release_quality=lambda n,u: ('SD', []), _size=lambda s: (0.0, ''))
    c_stub = types.SimpleNamespace(log=lambda *a, **k: print(*a), ensure_text=lambda x, **k: x)
    modpkg.cleantitle = cleantitle
    modpkg.client = client
    modpkg.debrid = debrid
    modpkg.source_utils = source_utils
    modpkg.cfscrape = cfscrape
    modpkg.crewruntime = types.SimpleNamespace(c=c_stub)
    sys.modules['resources.lib.modules'] = modpkg
    crewruntime_mod = types.ModuleType('resources.lib.modules.crewruntime')
    crewruntime_mod.c = c_stub
    sys.modules['resources.lib.modules.crewruntime'] = crewruntime_mod

spec = importlib.util.spec_from_file_location('mscn', os.path.join(os.path.dirname(__file__), '..', 'lib', 'resources', 'lib', 'sources', 'en_de', 'scenerls.py'))
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

s = mod.source()
# Test blocked response
mod.client.request = lambda *a, **k: '<html>404 Not Found</html>'
res = s.sources({'imdb':'tt0000000', 'title':'Test', 'year':'2017'}, hostDict=['example.com'], hostprDict=[])
print('scenerls blocked result length:', len(res))

# Test valid post
html = '<div class="post"><div class="postContent">\n<h2><a href="https://example.com/Test.Movie.2017.1080p.mkv">Test.Movie.2017.1080p.mkv</a></h2>Size: 1.2 GB</div></div>'
mod.client.request = lambda *a, **k: html
mod.client.replaceHTMLCodes = lambda x: x
mod.client.parseDom = lambda txt, tag, ret=None, attrs=None, **k: (['Size: 1.2 GB'] if tag=='div' and attrs=={'class':'postContent'} else (['https://example.com/Test.Movie.2017.1080p.mkv'] if tag=='a' and ret=='href' else ['Test.Movie.2017.1080p.mkv'] ))
res = s.sources({'imdb':'tt0000000', 'title':'Test Movie', 'year':'2017'}, hostDict=['example.com'], hostprDict=[])
print('scenerls valid-post result length:', len(res))
print('scenerls result:', res)