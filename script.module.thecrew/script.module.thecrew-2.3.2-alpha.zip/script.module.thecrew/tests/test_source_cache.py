# Minimal test for source cache roundtrip
import sys, os, types, json

lib_parent = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
lib_lib_dir = os.path.abspath(os.path.join(lib_parent, 'lib'))
resources_lib = os.path.abspath(os.path.join(lib_parent, 'lib', 'resources', 'lib'))
if lib_lib_dir not in sys.path:
    sys.path.insert(0, lib_lib_dir)
if resources_lib not in sys.path:
    sys.path.insert(0, resources_lib)

# Stubs used by Sources
if 'xbmc' not in sys.modules:
    sys.modules['xbmc'] = types.SimpleNamespace(log=lambda *a, **k: None, getInfoLabel=lambda *a, **k: '21.3.0', getCondVisibility=lambda *a, **k: False, getLocalizedString=lambda k: str(k), executeJSONRPC=lambda *a, **k: '{}', executebuiltin=lambda *a, **k: None, Keyboard=lambda *a, **k: None, Monitor=lambda *a, **k: types.SimpleNamespace(abortRequested=lambda : False), getSkinDir=lambda *a, **k: 'skin', Player=lambda *a, **k: None, PlayList=lambda *a, **k: None, PLAYLIST_VIDEO=1, LOGDEBUG=0, LOGINFO=1, LOGERROR=2, Actor=object, VideoStreamDetail=object, AudioStreamDetail=object, SubtitleStreamDetail=object)

# xbmcaddon stub
if 'xbmcaddon' not in sys.modules:
    class _AddonStub:
        def __init__(self, *a, **k):
            self._settings = {}
        def getSetting(self, id=None, *a, **k):
            return self._settings.get(id, '')
        def setSetting(self, id, value):
            self._settings[id]=value
        def getLocalizedString(self, k):
            return str(k)
        def getAddonInfo(self, id=None, **k):
            return ''
    sys.modules['xbmcaddon'] = types.SimpleNamespace(Addon=_AddonStub)

# xbmcgui stub
if 'xbmcgui' not in sys.modules:
    class _Dialog: pass
    sys.modules['xbmcgui'] = types.SimpleNamespace(Dialog=_Dialog, ListItem=object, Window=lambda *a, **k: None, DialogProgress=lambda *a, **k: None, DialogProgressBG=lambda *a, **k: None, WindowDialog=lambda *a, **k: None, ControlButton=lambda *a, **k: None, ControlImage=lambda *a, **k: None, getCurrentWindowDialogId=lambda *a, **k: 0, Keyboard=lambda *a, **k: None)

# xbmcvfs stub
if 'xbmcvfs' not in sys.modules:
    sys.modules['xbmcvfs'] = types.SimpleNamespace(exists=lambda *a, **k: True, translatePath=lambda x: x, makeLegalFilename=lambda x: x, File=lambda *a, **k: None, mkdir=lambda *a, **k: None, delete=lambda *a, **k: None, rmdir=lambda *a, **k: None, listdir=lambda *a, **k: ([], []))

# xbmcplugin stub
if 'xbmcplugin' not in sys.modules:
    sys.modules['xbmcplugin'] = types.SimpleNamespace(setResolvedUrl=lambda *a, **k: None, addDirectoryItem=lambda *a, **k: None, endOfDirectory=lambda *a, **k: None, addDirectoryItems=lambda *a, **k: None, setContent=lambda *a, **k: None, addSortMethod=lambda *a, **k: None, setProperty=lambda *a, **k: None)

# crewruntime stub
_crewruntime = types.ModuleType('resources.lib.modules.crewruntime')
_crewruntime.c = types.SimpleNamespace(log=lambda *a, **k: None, ensure_text=lambda x, **k: x, scraper_error=lambda *a, **k: None, get_setting=lambda *a, **k: '', is_orion_installed=lambda: False, name='thecrew', pluginversion='1.0.0', moduleversion='1.0.0', kodiversion='21.3.0', platform='windows')
sys.modules['resources.lib.modules.crewruntime'] = _crewruntime

# player stub
sys.modules['resources.lib.modules.player'] = types.ModuleType('player')
setattr(sys.modules['resources.lib.modules.player'], 'player', object)

# resolveurl stub
if 'resolveurl' not in sys.modules:
    _resolveurl = types.ModuleType('resolveurl')
    class HostedStub:
        def __init__(self, url, include_disabled=True, include_universal=False):
            self._url = url
        def valid_url(self):
            return False
        def resolve(self):
            return None
    _resolveurl.HostedMediaFile = HostedStub
    sys.modules['resolveurl'] = _resolveurl

# control and database helper
from resources.lib.modules import sources


def test_cache_roundtrip():
    s = sources.Sources()
    imdb = 'tt0123456'
    tmdb = '1234'
    sample_sources = [
        {'provider': 'test.provider', 'quality': '1080p', 'source': 'torrent', 'info': '2.38 GB', 'url': 'magnet:?xt=1'},
        {'provider': 'test.provider', 'quality': '720p', 'source': 'torrent', 'info': '1.12 GB', 'url': 'magnet:?xt=2'}
    ]

    # Ensure no cached data initially
    _ = s.get_cached_sources(imdb, tmdb)

    # Cache and retrieve
    s.cache_sources(sample_sources, imdb, tmdb)
    retrieved = s.get_cached_sources(imdb, tmdb)

    assert isinstance(retrieved, list)
    assert len(retrieved) == 2
    assert retrieved[0]['quality'] == '1080p'


if __name__ == '__main__':
    test_cache_roundtrip()
    print('source_cache test passed')
