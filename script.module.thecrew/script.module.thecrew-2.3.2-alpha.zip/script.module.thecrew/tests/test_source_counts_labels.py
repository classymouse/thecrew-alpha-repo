import sys, os, types

lib_parent = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
lib_lib_dir = os.path.abspath(os.path.join(lib_parent, 'lib'))
resources_lib = os.path.abspath(os.path.join(lib_parent, 'lib', 'resources', 'lib'))
if lib_lib_dir not in sys.path:
    sys.path.insert(0, lib_lib_dir)
if resources_lib not in sys.path:
    sys.path.insert(0, resources_lib)

# Minimal runtime stubs (same as other tests)
if 'xbmc' not in sys.modules:
    sys.modules['xbmc'] = types.SimpleNamespace(log=lambda *a, **k: None, getInfoLabel=lambda *a, **k: '21.3.0', getCondVisibility=lambda *a, **k: False, getLocalizedString=lambda k: str(k), executeJSONRPC=lambda *a, **k: '{}', executebuiltin=lambda *a, **k: None, Keyboard=lambda *a, **k: None, Monitor=lambda *a, **k: types.SimpleNamespace(abortRequested=lambda : False), getSkinDir=lambda *a, **k: 'skin', Player=lambda *a, **k: None, PlayList=lambda *a, **k: None, PLAYLIST_VIDEO=1, LOGDEBUG=0, LOGINFO=1, LOGERROR=2, Actor=object, VideoStreamDetail=object, AudioStreamDetail=object, SubtitleStreamDetail=object)

if 'xbmcaddon' not in sys.modules:
    class _AddonStub:
        def __init__(self, *a, **k):
            self._settings = {}
        def getSetting(self, id=None, *a, **k):
            return self._settings.get(id, '')
        def setSetting(self, id, value):
            self._settings[id]=value
        def getLocalizedString(self, k):
            return str(k)
        def getAddonInfo(self, id=None, **k):
            return ''
    sys.modules['xbmcaddon'] = types.SimpleNamespace(Addon=_AddonStub)

if 'xbmcgui' not in sys.modules:
    class _Dialog: pass
    sys.modules['xbmcgui'] = types.SimpleNamespace(Dialog=_Dialog, ListItem=object, Window=lambda *a, **k: None, DialogProgress=lambda *a, **k: None, DialogProgressBG=lambda *a, **k: None, WindowDialog=lambda *a, **k: None, ControlButton=lambda *a, **k: None, ControlImage=lambda *a, **k: None, getCurrentWindowDialogId=lambda *a, **k: 0, Keyboard=lambda *a, **k: None)

if 'xbmcplugin' not in sys.modules:
    sys.modules['xbmcplugin'] = types.SimpleNamespace(setResolvedUrl=lambda *a, **k: None, addDirectoryItem=lambda *a, **k: None, endOfDirectory=lambda *a, **k: None, addDirectoryItems=lambda *a, **k: None, setContent=lambda *a, **k: None, addSortMethod=lambda *a, **k: None, setProperty=lambda *a, **k: None)

if 'xbmcvfs' not in sys.modules:
    sys.modules['xbmcvfs'] = types.SimpleNamespace(exists=lambda *a, **k: True, translatePath=lambda x: x, makeLegalFilename=lambda x: x, File=lambda *a, **k: None, mkdir=lambda *a, **k: None, delete=lambda *a, **k: None, rmdir=lambda *a, **k: None, listdir=lambda *a, **k: ([], []))

# crewruntime stub
_crewruntime = types.ModuleType('resources.lib.modules.crewruntime')
_crewruntime.c = types.SimpleNamespace(log=lambda *a, **k: None, ensure_text=lambda x, **k: x, scraper_error=lambda *a, **k: None, get_setting=lambda *a, **k: '', is_orion_installed=lambda: False, name='thecrew', pluginversion='1.0.0', moduleversion='1.0.0', kodiversion='21.3.0', platform='windows')
sys.modules['resources.lib.modules.crewruntime'] = _crewruntime

# resolveurl stub
if 'resolveurl' not in sys.modules:
    _resolveurl = types.ModuleType('resolveurl')
    class HostedStub:
        def __init__(self, url, include_disabled=True, include_universal=False):
            self._url = url
        def valid_url(self):
            return False
        def resolve(self):
            return None
    _resolveurl.HostedMediaFile = HostedStub
    sys.modules['resolveurl'] = _resolveurl

# Minimal stubs for modules imported at package level to avoid executing heavy code
sys.modules['resources.lib.modules.player'] = types.SimpleNamespace(player=type('player', (), {}))
sys.modules['resources.lib.modules.listitem'] = types.SimpleNamespace(ListItemInfoTag=object)

from resources.lib.modules.sources import Sources


def test_debrid_labels_include_sd_slot():
    # instantiate without running __init__ to avoid heavy imports
    s = Sources.__new__(Sources)
    # create 1 source per quality and set a dummy url and source names
    s.sources = [
        {'quality': '4K', 'url': 'u1', 'source': 'X'},
        {'quality': '1080p', 'url': 'u2', 'source': 'X'},
        {'quality': '720p', 'url': 'u3', 'source': 'X'},
        {'quality': 'SD', 'url': 'u4', 'source': 'X'},
    ]

    class DebridStub:
        def valid_url(self, url, source):
            return True

    debrid_list = [DebridStub()]

    d4, d1080, d720, dsd, dtotal = s._get_debrid_source_counts(debrid_list)
    assert (d4, d1080, d720, dsd, dtotal) == (1, 1, 1, 1, 4)

    total_format = '%s:%s'
    debrid_labels = s._get_debrid_labels(d4, d1080, d720, dsd, dtotal, total_format)
    # expect 5 labels: 4K,1080,720,SD,total
    assert len(debrid_labels) == 5
    assert '1' in debrid_labels[0]
    assert '1' in debrid_labels[3]  # SD slot
    assert '4' in debrid_labels[4]  # total
