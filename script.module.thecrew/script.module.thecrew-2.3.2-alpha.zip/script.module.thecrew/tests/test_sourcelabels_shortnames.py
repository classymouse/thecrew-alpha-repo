from resources.lib.modules.sources import Sources


def test_sourcelabels_short_names():
    s = Sources()
    # build a fake source_dict where module names appear
    source_dict = [
        ('resources.lib.sources.en_tor.torrentio', None, 0),
        ('resources.lib.sources.en_tor.glodls', None, 0),
        ('gearsscrapers.providers.torrents.example', None, 0),
    ]
    mains, labels = s.get_movie_episode_sources('Test', 2017, 'tt0000', '0', None, None, None, None, source_dict, 'movie', [])
    # Labels should be short display names uppercase
    assert labels and 'TORRENTIO' in labels.values()
    assert 'GLO DLS' not in labels.values()  # sanity; glodls -> Glodls
    # Gear provider should be formatted with [Gears] (case-insensitive)
    assert any('gears' in (v or '').lower() for v in labels.values())
