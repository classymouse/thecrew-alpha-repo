import sys, os, types

lib_parent = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
lib_lib_dir = os.path.abspath(os.path.join(lib_parent, 'lib'))
resources_lib = os.path.abspath(os.path.join(lib_parent, 'lib', 'resources', 'lib'))
if lib_lib_dir not in sys.path:
    sys.path.insert(0, lib_lib_dir)
if resources_lib not in sys.path:
    sys.path.insert(0, resources_lib)

# minimal xbmc and crewruntime stubs
if 'xbmc' not in sys.modules:
    sys.modules['xbmc'] = types.SimpleNamespace(getCondVisibility=lambda *a, **k: False, getInfoLabel=lambda *a, **k: '21.3.0')
if 'resources.lib.modules.crewruntime' not in sys.modules:
    _crewruntime = types.ModuleType('resources.lib.modules.crewruntime')
    _crewruntime.c = types.SimpleNamespace(get_setting=lambda *a, **k: 'false', log=lambda *a, **k: None)
    sys.modules['resources.lib.modules.crewruntime'] = _crewruntime

from resources.lib.sources import sources

s = sources()
print('loaded', len(s), 'sources')
print('sample', [i[0] for i in s[:10]])
