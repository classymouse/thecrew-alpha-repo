# Tests for debrid and hosted resolver logging and behavior
import sys, os, types, importlib.util

# Ensure package paths
lib_parent = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
lib_lib_dir = os.path.abspath(os.path.join(lib_parent, 'lib'))
resources_lib = os.path.abspath(os.path.join(lib_parent, 'lib', 'resources', 'lib'))
if lib_lib_dir not in sys.path:
    sys.path.insert(0, lib_lib_dir)
if resources_lib not in sys.path:
    sys.path.insert(0, resources_lib)

# Minimal xbmc stubs
if 'xbmc' not in sys.modules:
    sys.modules['xbmc'] = types.SimpleNamespace(
        getInfoLabel=lambda *a, **k: '21.3.0',
        getCondVisibility=lambda *a, **k: False,
        getLocalizedString=lambda k: str(k),
        executeJSONRPC=lambda *a, **k: '{}',
        executebuiltin=lambda *a, **k: None,
        Keyboard=lambda *a, **k: None,
        Monitor=lambda *a, **k: types.SimpleNamespace(abortRequested=lambda : False),
        getSkinDir=lambda *a, **k: 'skin',
        Player=lambda *a, **k: None,
        PlayList=lambda *a, **k: None,
        PLAYLIST_VIDEO=1,
        LOGDEBUG=0,
        LOGINFO=1,
        LOGERROR=2,
        Actor=object,
        VideoStreamDetail=object,
        AudioStreamDetail=object,
        SubtitleStreamDetail=object,
        log=lambda *a, **k: None
    )
if 'xbmcaddon' not in sys.modules:
    class _AddonStub:
        def __init__(self, *args, **kwargs):
            self._settings = {}
        def getSetting(self, id=None, *args, **kwargs):
            return self._settings.get(id, '')
        def setSetting(self, id, value):
            self._settings[id] = value
        def getLocalizedString(self, k):
            return str(k)
        def getAddonInfo(self, id=None, **kwargs):
            return ''
    sys.modules['xbmcaddon'] = types.SimpleNamespace(Addon=_AddonStub)
if 'xbmcgui' not in sys.modules:
    class _Dialog: pass
    sys.modules['xbmcgui'] = types.SimpleNamespace(
        Dialog=_Dialog,
        ListItem=object,
        Window=lambda *a, **k: None,
        DialogProgress=lambda *a, **k: None,
        DialogProgressBG=lambda *a, **k: None,
        WindowDialog=lambda *a, **k: None,
        ControlButton=lambda *a, **k: None,
        ControlImage=lambda *a, **k: None,
        getCurrentWindowDialogId=lambda *a, **k: 0,
        Keyboard=lambda *a, **k: None
    )
if 'xbmcvfs' not in sys.modules:
    sys.modules['xbmcvfs'] = types.SimpleNamespace(
        exists=lambda *a, **k: True,
        translatePath=lambda x: x,
        makeLegalFilename=lambda x: x,
        File=lambda *a, **k: None,
        mkdir=lambda *a, **k: None,
        delete=lambda *a, **k: None,
        rmdir=lambda *a, **k: None,
        listdir=lambda *a, **k: ([], [])
    )
if 'xbmcplugin' not in sys.modules:
    sys.modules['xbmcplugin'] = types.SimpleNamespace(setResolvedUrl=lambda *a, **k: None, addDirectoryItem=lambda *a, **k: None, endOfDirectory=lambda *a, **k: None, addDirectoryItems=lambda *a, **k: None, setContent=lambda *a, **k: None, addSortMethod=lambda *a, **k: None, setProperty=lambda *a, **k: None)

# Create crewruntime stub that captures logs to a list
_crewruntime = types.ModuleType('resources.lib.modules.crewruntime')
log_capture = []
_crewruntime.c = types.SimpleNamespace(
    log=lambda *a, **k: log_capture.append(' '.join(map(str, a))),
    ensure_text=lambda x, **k: x,
    scraper_error=lambda *a, **k: None,
    get_setting=lambda *a, **k: '',
    is_orion_installed=lambda : False,
    name='thecrew', pluginversion='1.0.0', moduleversion='1.0.0', kodiversion='21.3.0', platform='windows'
)
sys.modules['resources.lib.modules.crewruntime'] = _crewruntime

# Stub debrid resolver
_debrid = types.ModuleType('resources.lib.modules.debrid')
_debrid.debrid_resolvers = [types.SimpleNamespace(name='Real-Debrid'), types.SimpleNamespace(name='AllDebrid')]
def resolver_stub(url, name):
    if name and 'Real-Debrid' in str(name) and 'btih' in url:
        return 'https://rd-resolved.example/stream.mp4'
    return None
_debrid.resolver = resolver_stub
_debrid.status = lambda *a, **k: True
sys.modules['resources.lib.modules.debrid'] = _debrid

# Stub resolveurl HostedMediaFile
_resolveurl = types.ModuleType('resolveurl')
class HostedStub:
    def __init__(self, url, include_disabled=False, include_universal=False):
        self._url = url
    def valid_url(self):
        return self._url.startswith('https://hosted')
    def resolve(self):
        return 'https://hosted-resolved.example/stream.m3u8'
_resolveurl.HostedMediaFile = HostedStub
sys.modules['resolveurl'] = _resolveurl

# Provide light-weight stubs for heavy modules to avoid executing addon runtime code during tests
sys.modules['resources.lib.modules.player'] = types.ModuleType('player')
setattr(sys.modules['resources.lib.modules.player'], 'player', object)

# import Sources
from resources.lib.modules.sources import Sources

class FakeCall:
    def resolve(self, url):
        # Return magnet unchanged to force debrid path
        return url


def test_debrid_resolution_and_logging(capfd):
    log_capture.clear()
    s = Sources()
    # use small sourceDict with our fake provider
    s.sourceDict = [('fake', FakeCall())]

    item = {'provider': 'fake', 'url': 'magnet:?xt=urn:btih:ABCDEF123456', 'debrid': 'Real-Debrid', 'direct': False}

    res = s.sourcesResolve(item)

    assert res == 'https://rd-resolved.example/stream.mp4'

    # Check logs for our new INFO-level resolver messages
    prints = capfd.readouterr().out
    joined = '\n'.join(log_capture) + '\n' + prints
    assert 'Attempting debrid resolver' in joined
    assert 'Resolved via Real-Debrid' in joined


def test_hosted_media_resolution_and_logging(capfd):
    log_capture.clear()
    s = Sources()
    s.sourceDict = [('fake', FakeCall())]

    # No debrid, hosted link which HostedStub.valid_url() accepts
    item = {'provider': 'fake', 'url': 'https://hosted.example/video.m3u8', 'debrid': '', 'direct': False}

    res = s.sourcesResolve(item)

    assert res == 'https://hosted-resolved.example/stream.m3u8'
    prints = capfd.readouterr().out
    joined = '\n'.join(log_capture) + '\n' + prints
    assert 'No debrid assigned' in joined or 'HostedMediaFile resolved' in joined
