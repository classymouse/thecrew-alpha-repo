import json
import requests
from types import SimpleNamespace
from resources.lib.modules import http_client


def make_resp(status=200, text='{}', headers=None):
    r = SimpleNamespace()
    r.status_code = status
    r.text = text
    r.headers = headers or {}
    def raise_for_status():
        if 400 <= r.status_code < 600:
            resp = SimpleNamespace(status_code=r.status_code)
            raise requests.HTTPError(f'Status {r.status_code}', response=resp)
    r.raise_for_status = raise_for_status
    def json():
        return json.loads(r.text)
    r.json = json
    return r


def test_tmdb_get_conditional_retries_on_429_then_200(monkeypatch):
    # First call: 429, then 200
    seq = [make_resp(429, ''), make_resp(200, '{"results": []}', {'ETag': '"v2"'})]

    def fake_get_with_ratelimit(url, api_type='tmdb', **kwargs):
        return seq.pop(0)

    monkeypatch.setattr(http_client.HTTPClient, 'get_with_ratelimit', classmethod(lambda cls, url, api_type='tmdb', **kwargs: fake_get_with_ratelimit(url, api_type, **kwargs)))

    body_headers_status = http_client.tmdb_get_conditional('https://api.themoviedb.org/3/movie/popular', conditional_headers={'If-None-Match': 'v1'})
    assert body_headers_status is not None
    body, headers, status = body_headers_status
    assert status == 200
    assert 'results' in json.loads(body)


def test_tmdb_get_conditional_gives_up_after_attempts_on_429(monkeypatch):
    # Always return 429
    resp429 = make_resp(429, '')
    def fake_always_429(url, api_type='tmdb', **kwargs):
        return resp429

    monkeypatch.setattr(http_client.HTTPClient, 'get_with_ratelimit', classmethod(lambda cls, url, api_type='tmdb', **kwargs: fake_always_429(url, api_type, **kwargs)))

    body_headers_status = http_client.tmdb_get_conditional('https://api.themoviedb.org/3/movie/popular')
    assert body_headers_status is None


def test_tmdb_get_json_retries_on_429_then_succeeds(monkeypatch):
    seq = [make_resp(429, ''), make_resp(200, '{"results": []}')]
    def fake_get_with_ratelimit(url, api_type='tmdb', **kwargs):
        return seq.pop(0)

    monkeypatch.setattr(http_client.HTTPClient, 'get_with_ratelimit', classmethod(lambda cls, url, api_type='tmdb', **kwargs: fake_get_with_ratelimit(url, api_type, **kwargs)))

    result = http_client.tmdb_get_json('https://api.themoviedb.org/3/movie/popular')
    assert isinstance(result, dict)


def test_tmdb_get_json_gives_up_on_repeated_429(monkeypatch):
    resp429 = make_resp(429, '')
    def fake_always_429(url, api_type='tmdb', **kwargs):
        return resp429

    monkeypatch.setattr(http_client.HTTPClient, 'get_with_ratelimit', classmethod(lambda cls, url, api_type='tmdb', **kwargs: fake_always_429(url, api_type, **kwargs)))

    result = http_client.tmdb_get_json('https://api.themoviedb.org/3/movie/popular', attempts=2)
    assert result is None
