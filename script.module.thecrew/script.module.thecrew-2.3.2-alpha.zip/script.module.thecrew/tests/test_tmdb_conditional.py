import json
from types import SimpleNamespace
from resources.lib.modules import http_client


def make_resp(status=200, text='{}', headers=None):
    r = SimpleNamespace()
    r.status_code = status
    r.text = text
    r.headers = headers or {}
    def raise_for_status():
        if 400 <= r.status_code < 600:
            raise Exception(f'Status {r.status_code}')
    r.raise_for_status = raise_for_status
    return r


def test_tmdb_get_conditional_200_and_304(monkeypatch):
    # 200 response
    resp = make_resp(status=200, text='{"results": []}', headers={'ETag': '"v1"'})
    called = {}

    def fake_get_with_ratelimit(url, api_type='tmdb', **kwargs):
        called['url'] = url
        called['headers'] = kwargs.get('headers')
        return resp

    monkeypatch.setattr(http_client.HTTPClient, 'get_with_ratelimit', classmethod(lambda cls, url, api_type='tmdb', **kwargs: fake_get_with_ratelimit(url, api_type, **kwargs)))

    body, headers, status = http_client.tmdb_get_conditional('https://api.themoviedb.org/3/movie/popular', conditional_headers={'If-None-Match': '"v0"'})
    assert status == 200
    assert 'results' in json.loads(body)
    assert headers.get('ETag') == '"v1"'
    assert called['headers'] == {'If-None-Match': '"v0"'}

    # 304 response
    resp304 = make_resp(status=304, text='', headers={'ETag': '"v1"'})
    monkeypatch.setattr(http_client.HTTPClient, 'get_with_ratelimit', classmethod(lambda cls, url, api_type='tmdb', **kwargs: resp304))

    body, headers, status = http_client.tmdb_get_conditional('https://api.themoviedb.org/3/movie/popular', conditional_headers={'If-None-Match': '"v1"'})
    assert status == 304
    assert body == ''
    assert headers.get('ETag') == '"v1"'
