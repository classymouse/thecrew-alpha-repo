import sys
sys.argv = ['script', '0', '?']
from resources.lib.indexers.movies import movies
from resources.lib.modules import cache


def test_movies_uses_get_with_etag_for_network(monkeypatch):
    from resources.lib.modules import control
    monkeypatch.setattr(control, 'setting', lambda key, default=None: '50' if key == 'page.item.limit' else '')

    m = movies()
    url = m.tmdb_networks_link % '337'

    called = {}
    parsed = {'results': [{'title': 'Net', 'release_date': '2021-01-01'}], 'page': 1, 'total_pages': 1}

    def fake_get_with_etag(key, fetcher, ttl_seconds=60, namespace=None):
        called['key'] = key
        called['ttl'] = ttl_seconds
        called['namespace'] = namespace
        return parsed

    monkeypatch.setattr(cache, 'get_with_etag', fake_get_with_etag)

    # Call the high-level getter and ensure get_with_etag was invoked
    res = m.get(url, tid=337, idx=False, create_directory=False)

    # Enable debug logging to surface internal parsing errors during test
    from resources.lib.modules import c as _c
    monkeypatch.setattr(_c, 'log', print)

    # tmdb_list should be able to process the parsed JSON into list entries
    m.tmdb_list(url, tid=337, response=parsed)

    assert called['key'] == url
    assert called['ttl'] == int(0.25 * 3600)
    assert isinstance(m.list, list) and len(m.list) == 1
    assert m.list[0].get('title') == 'Net'
    assert m.list[0].get('year') == '2021'
