import sys
sys.argv = ['script', '0', '?']

from resources.lib.indexers.movies import movies
from resources.lib.modules import cache


def test_tmdb_discover_genre_uses_get_with_etag(monkeypatch):
    from resources.lib.modules import control
    monkeypatch.setattr(control, 'setting', lambda key, default=None: '50' if key == 'page.item.limit' else '')

    m = movies()
    # Build a genre discover URL using the template attribute
    url = m.genre_link % '28'  # genre id placeholder (e.g., 28 = Action)

    called = {}
    parsed = {'results': [{'title': 'GenreMovie', 'release_date': '2019-01-01'}], 'page': 1, 'total_pages': 1}

    def fake_get_with_etag(key, fetcher, ttl_seconds=60, namespace=None):
        called['key'] = key
        called['ttl'] = ttl_seconds
        return parsed

    monkeypatch.setattr(cache, 'get_with_etag', fake_get_with_etag)

    res = m.get(url, idx=False, create_directory=False)

    # tmdb_list should be able to parse the returned JSON when passed directly
    m.tmdb_list(url, response=parsed)

    assert called['key'] == url
    assert called['ttl'] == int(0.25 * 3600)
    assert isinstance(m.list, list) and len(m.list) == 1
    assert m.list[0].get('title') == 'GenreMovie'


def test_tmdb_discover_year_uses_get_with_etag(monkeypatch):
    from resources.lib.modules import control
    monkeypatch.setattr(control, 'setting', lambda key, default=None: '50' if key == 'page.item.limit' else '')

    m = movies()
    # Use tmdb_movie_discover_year_link formatting for discovery by year
    url = m.tmdb_movie_discover_year_link % 'en-US'

    called = {}
    parsed = {'results': [{'title': 'YearMovie', 'release_date': '2018-05-05'}], 'page': 1, 'total_pages': 1}

    def fake_get_with_etag(key, fetcher, ttl_seconds=60, namespace=None):
        called['key'] = key
        called['ttl'] = ttl_seconds
        return parsed

    monkeypatch.setattr(cache, 'get_with_etag', fake_get_with_etag)

    res = m.get(url, idx=False, create_directory=False)

    # tmdb_list should be able to parse the returned JSON when passed directly
    m.tmdb_list(url, response=parsed)

    assert called['key'] == url
    assert called['ttl'] == int(0.25 * 3600)
    assert isinstance(m.list, list) and len(m.list) == 1
    assert m.list[0].get('title') == 'YearMovie'
