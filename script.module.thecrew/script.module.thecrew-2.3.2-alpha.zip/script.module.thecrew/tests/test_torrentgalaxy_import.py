def test_torrentgalaxy_import():
    import sys, types, importlib

    # ensure conftest stubs are registered (if conftest runs before this test, this is no-op)
    import tests.conftest  # executes top-level stub registration

    # Use stubs installed by conftest if present
    xbmc = sys.modules.get('xbmc', None)
    xbmcaddon = sys.modules.get('xbmcaddon', None)
    xbmcgui = sys.modules.get('xbmcgui', None)
    if not xbmc:
        xbmc = types.ModuleType('xbmc')
        xbmc.log = lambda *a, **k: None
        xbmc.getInfoLabel = lambda *a, **k: '19.5.0'
        xbmc.getCondVisibility = lambda s: False
        xbmc.getLocalizedString = lambda idx: ''
        xbmc.translatePath = lambda p: p
        xbmc.getSkinDir = lambda : ''
        sys.modules['xbmc'] = xbmc
    if not xbmcaddon:
        xbmcaddon = types.ModuleType('xbmcaddon')
        class Addon:
            _settings = {}
            def __init__(self, id=None):
                self.id = id
            def getAddonInfo(self, *a, **k):
                return ''
            def getLocalizedString(self, idx):
                return ''
            def getSetting(self, key, *a, **k):
                return Addon._settings.get(key, '')
            def setSetting(self, key, value):
                Addon._settings[key] = value
        xbmcaddon.Addon = Addon
        sys.modules['xbmcaddon'] = xbmcaddon
    if not xbmcgui:
        sys.modules['xbmcgui'] = types.ModuleType('xbmcgui')

    # ensure local libs on sys.path
    import os
    sys.path.insert(0, os.path.abspath('lib'))
    sys.path.insert(0, os.path.abspath(os.path.join('..', 'script.module.gearsscrapers', 'lib')))

    # Import the provider - should not raise
    m = importlib.import_module('gearsscrapers.providers.torrents.torrentgalaxy')
    assert hasattr(m, 'source')

    # ensure cfscrape resolved to our wrapper
    import cfscrape
    # debug: show which module file resolved and its public names
    # accept at least one of these public attributes
    assert any(hasattr(cfscrape, name) for name in ('create_scraper', 'get_cookie_string', 'CloudScraper'))

