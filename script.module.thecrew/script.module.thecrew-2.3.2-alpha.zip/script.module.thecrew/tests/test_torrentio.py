# Smoke test for torrentio parser
import sys, os, importlib.util
lib_parent = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'lib'))
if lib_parent not in sys.path:
    sys.path.insert(0, lib_parent)

import types
# Minimal resources.lib.modules stubs
if 'resources' not in sys.modules:
    resources = types.ModuleType('resources')
    sys.modules['resources'] = resources
if 'resources.lib' not in sys.modules:
    sys.modules['resources.lib'] = types.ModuleType('resources.lib')
if 'resources.lib.modules' not in sys.modules:
    modpkg = types.ModuleType('resources.lib.modules')
    # cleantitle stub
    def _cleantitle_get(x):
        return x.lower().replace(' ', '.')
    cleantitle = types.SimpleNamespace(get=_cleantitle_get, geturl=lambda x: x)
    # debrid stub
    debrid = types.SimpleNamespace(status=lambda: True)
    # source_utils stub
    def _get_release_quality(title, url):
        return ('HD', [])
    def _size(size_str):
        # very simple parse
        return (1024.0, '1.02 GB')
    source_utils = types.SimpleNamespace(get_release_quality=_get_release_quality, _size=_size, release_title_format=lambda x: x)
    # client stub
    client = types.SimpleNamespace(request=lambda *a, **k: '')
    c_stub = types.SimpleNamespace(log=lambda *a, **k: print(*a), scraper_error=lambda *a, **k: print('SCRAPER ERROR', *a))
    modpkg.cleantitle = cleantitle
    modpkg.debrid = debrid
    modpkg.source_utils = source_utils
    modpkg.client = client
    modpkg.crewruntime = types.SimpleNamespace(c=c_stub)
    sys.modules['resources.lib.modules'] = modpkg
    crewruntime_mod = types.ModuleType('resources.lib.modules.crewruntime')
    crewruntime_mod.c = c_stub
    sys.modules['resources.lib.modules.crewruntime'] = crewruntime_mod

# Load torrentio module
spec = importlib.util.spec_from_file_location('torrentio', os.path.join(os.path.dirname(__file__), '..', 'lib', 'resources', 'lib', 'sources', 'en_tor', 'torrentio.py'))
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

# Fake requests.get
class FakeResp:
    def __init__(self, json_data):
        self._json = json_data
    def json(self):
        return self._json

class FakeRequests:
    def __init__(self, resp):
        self.resp = resp
    def get(self, url, headers=None, timeout=None):
        print('[FakeRequests] GET', url, 'headers=', headers)
        return self.resp

# Build a fake stream item
stream_item = {
    'infoHash': 'A'*40,
    'title': 'Test.Movie.2017\n👤 12 seeders | 1.23 GB'
}

fake_json = {'streams': [stream_item]}

# Monkeypatch requests
import requests as real_requests
orig_requests_get = None
try:
    orig_requests_get = real_requests.get
    real_requests.get = FakeRequests(FakeResp(fake_json)).get
except Exception:
    pass

# Instantiate source and run
if __name__ == '__main__':
    s = mod.source()
    res = s.sources({'title':'Test Movie','year':'2017','imdb':'tt0000000'}, hostDict=['example'])
    print('torrentio sources length:', len(res))
    print('torrentio result:', res)

    # Deep-dive: simulate debrid cache processing
    print('\n=== Deep dive: sourcesProcessTorrents simulation ===')
    # Build a minimal copy of the sourcesProcessTorrents logic used by Sources
    import re, traceback

    def simulate_sources_process_torrents(torrent_sources, cached_hashes=None):
        try:
            if len(torrent_sources) == 0:
                return []
            # Check debrid assignment: we simulate that each torrent has 'debrid' set
            for i in torrent_sources:
                if i.get('debrid', '') not in ['Real-Debrid', 'AllDebrid', 'Premiumize.me', 'Torbox']:
                    # if debrid not yet set, do early return (matching production behavior)
                    return torrent_sources

            hashList = []
            for i in torrent_sources:
                try:
                    r = re.findall(r'btih:(\w{40})', str(i['url']))[0]
                    if r:
                        infoHash = r.lower()
                        i['info_hash'] = infoHash
                        hashList.append(infoHash)
                except Exception:
                    torrent_sources.remove(i)
            hashList = list(set(hashList))

            cachedRDHashes = cached_hashes or []

            cachedTorrents = [dict(i.items()) for i in torrent_sources if (any(v in i.get('info_hash') for v in cachedRDHashes) and i.get('debrid', '') == 'Real-Debrid')]
            for i in cachedTorrents:
                i.update({'source': 'cached torrent'})

            uncachedTorrents = [dict(i.items()) for i in torrent_sources if (not any(v in i.get('info_hash') for v in cachedRDHashes) and i.get('debrid', '') == 'Real-Debrid')]
            for i in uncachedTorrents:
                i.update({'source': 'uncached torrent'})

            return cachedTorrents + uncachedTorrents
        except Exception:
            print('Exception in simulation:\n', traceback.format_exc())
            return []

# Test 1: no debrid assigned -> early return (raw list)
if __name__ == '__main__':
    raw = simulate_sources_process_torrents([dict(r) for r in res])
    print('simulate (no debrid assigned) ->', raw)

    # Test 2: set debrid to Real-Debrid and simulate no cached hashes
    test_rs = [dict(r) for r in res]
    for r in test_rs:
        r['debrid'] = 'Real-Debrid'
    uncached = simulate_sources_process_torrents(test_rs, cached_hashes=[])
    print('simulate (RD, no cached hashes) ->', uncached)

    # Test 3: set a cached hash
    test_rs2 = [dict(r) for r in res]
    for r in test_rs2:
        r['debrid'] = 'Real-Debrid'
    cached = simulate_sources_process_torrents(test_rs2, cached_hashes=[res[0]['hash'].lower()])
    print('simulate (RD, cached) ->', cached)

    # Restore
    if orig_requests_get:
        real_requests.get = orig_requests_get
