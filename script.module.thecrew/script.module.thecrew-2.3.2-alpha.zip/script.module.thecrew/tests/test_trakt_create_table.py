import os
import pytest
from resources.lib.modules import control, trakt


def test_create_table_idempotent(tmp_path):
    # Ensure a clean traktsync DB
    try:
        if os.path.exists(control.traktsyncFile):
            os.remove(control.traktsyncFile)
    except Exception:
        pass

    # First call should create the table
    trakt.create_table('trakt_progress')

    # Second call should not raise (idempotent)
    try:
        trakt.create_table('trakt_progress')
    except Exception as e:
        pytest.fail(f'create_table raised on second call: {e}')


def test_create_table_with_query_idempotent(tmp_path):
    # Ensure a clean traktsync DB
    try:
        if os.path.exists(control.traktsyncFile):
            os.remove(control.traktsyncFile)
    except Exception:
        pass

    query = 'CREATE TABLE sample_test_table (id INTEGER PRIMARY KEY, name TEXT)'

    # First invocation should succeed
    trakt.create_table(name='', query=query)

    # Second invocation should not raise
    try:
        trakt.create_table(name='', query=query)
    except Exception as e:
        pytest.fail(f'create_table with query raised on second call: {e}')
