import os
import sqlite3
from resources.lib.modules import control
from resources.lib.modules import db_schema
from resources.lib.modules import crewruntime


def test_upgrade_report_shown_once(monkeypatch):
    # Fresh DB
    if os.path.exists(control.traktsyncFile):
        try:
            os.remove(control.traktsyncFile)
        except Exception:
            pass

    # Set recorded old version
    db_schema._set_service_setting('addon_version', '2.0.0')

    # Register a migration that will run
    ran = {'v': False}
    def _fn():
        ran['v'] = True
    db_schema.register_migration('test_upgrade_report', '2.1.0', _fn)

    # Enable devmode and capture infoDialog calls
    monkeypatch.setattr(crewruntime.c, 'devmode', True)
    calls = []
    monkeypatch.setattr(control, 'infoDialog', lambda msg: calls.append(msg))

    # Set current pluginversion to higher
    monkeypatch.setattr(crewruntime.c, 'pluginversion', '2.2.0')

    # Ensure one-time flag cleared
    db_schema._set_service_setting('upgrade_report_shown_2.2.0', '0')

    db_schema.check_and_migrate_version()

    # sanity: migration ran
    assert ran['v'] is True

    # Expect at least two infoDialog calls: one for Applied migrations and one for upgrade report
    assert len(calls) >= 2

    # Check the one-time flag is set
    assert db_schema._upgrade_report_shown('2.2.0') is True

    # Call again; no new report should be shown
    prev_calls = len(calls)
    db_schema.check_and_migrate_version()
    assert len(calls) == prev_calls

    # cleanup
    db_schema.MIGRATIONS[:] = [m for m in db_schema.MIGRATIONS if m['name'] != 'test_upgrade_report']


def test_upgrade_report_not_shown_when_not_devmode(monkeypatch):
    # Fresh DB
    if os.path.exists(control.traktsyncFile):
        try:
            os.remove(control.traktsyncFile)
        except Exception:
            pass

    db_schema._set_service_setting('addon_version', '2.0.0')

    ran = {'v': False}
    def _fn():
        ran['v'] = True
    db_schema.register_migration('test_upgrade_report_2', '2.1.0', _fn)

    monkeypatch.setattr(crewruntime.c, 'devmode', False)
    calls = []
    monkeypatch.setattr(control, 'infoDialog', lambda msg: calls.append(msg))
    monkeypatch.setattr(crewruntime.c, 'pluginversion', '2.2.0')

    # Ensure one-time flag cleared
    db_schema._set_service_setting('upgrade_report_shown_2.2.0', '0')

    db_schema.check_and_migrate_version()

    assert ran['v'] is True
    # there should be at least one call for 'Applied migrations' but no upgrade report flag
    assert len(calls) >= 1
    assert db_schema._upgrade_report_shown('2.2.0') is False

    db_schema.MIGRATIONS[:] = [m for m in db_schema.MIGRATIONS if m['name'] != 'test_upgrade_report_2']
