import os
import sqlite3
from resources.lib.modules import control
from resources.lib.modules import db_schema
from resources.lib.modules import crewruntime


def test_reset_archives_old_databases(tmp_path, monkeypatch):
    # Setup: create a fake legacy cache.v with a very old version
    addon_data_dir = os.path.dirname(control.dataPath)
    pv_dir = os.path.join(addon_data_dir, 'plugin.video.thecrew')
    os.makedirs(pv_dir, exist_ok=True)
    cache_v = os.path.join(pv_dir, 'cache.v')
    with open(cache_v, 'w', encoding='utf-8') as f:
        f.write('1.0.0')

    # create fake DB files so backups will occur (avoid creating traktsyncFile to allow fresh DB creation)
    for p in (control.cacheFile, control.viewsFile):
        if not p:
            continue
        d = os.path.dirname(p) or os.getcwd()
        os.makedirs(d, exist_ok=True)
        with open(p, 'w', encoding='utf-8') as f:
            f.write('dummy')

    # Ensure any leftover traktsync DB from other tests is removed so we get a fresh DB
    if os.path.exists(control.traktsyncFile):
        try:
            os.remove(control.traktsyncFile)
        except Exception:
            pass

    # Force current code to be newer
    monkeypatch.setattr(crewruntime.c, 'pluginversion', '2.2.0')

    # Capture logs during the run
    logs = []
    monkeypatch.setattr(db_schema.c, 'log', lambda msg, *a, **k: logs.append(msg))

    # Run check
    db_schema.check_and_migrate_version()

    # Legacy file should be removed or at least not interfere; DB backup files may have been created
    cache_dir = os.path.dirname(control.cacheFile) or os.getcwd()
    backups = [p for p in os.listdir(cache_dir) if p.startswith(os.path.basename(control.cacheFile) + '.bak')]

    # The tracked service addon_version should be set to current
    conn = sqlite3.connect(control.traktsyncFile)
    cur = conn.cursor()
    cur.execute("SELECT value FROM service WHERE setting = 'addon_version'")
    assert cur.fetchone() is not None

    # Migration record for reset should exist
    cur.execute("SELECT name FROM schema_migrations WHERE name LIKE 'addon_reset_%' LIMIT 1")
    assert cur.fetchone() is not None

    # There should be a standardized upgrade log entry recorded
    assert any('[UPGRADE] Reset upgrade' in l or 'Performed reset migration' in l for l in logs)

    conn.close()