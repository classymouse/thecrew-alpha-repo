"""Test xxx.xml Python code for syntax errors"""
import re
import ast
import sys

xml_path = r"c:\Users\fvanb\AppData\Roaming\Kodi\addons\script.module.thecrew\xml\xxx.xml"

with open(xml_path, 'r', encoding='utf-8') as f:
    content = f.read()

# Find all Python functions in the XML
python_blocks = re.findall(r'<expres>\s*<!\[CDATA\[#\$pyFunction\s*(def GetLSProData.*?)\]\]></expres>', content, re.DOTALL)

print(f"Found {len(python_blocks)} Python code blocks in xxx.xml\n")

errors = []
for i, code_block in enumerate(python_blocks, 1):
    # Extract the function definition
    try:
        # Try to parse the code
        ast.parse(code_block)
        print(f"✓ Block {i}: Syntax OK")
    except SyntaxError as e:
        errors.append((i, code_block, e))
        print(f"✗ Block {i}: SyntaxError - {e}")
        # Show the problematic line
        lines = code_block.split('\n')
        if e.lineno and e.lineno <= len(lines):
            print(f"  Line {e.lineno}: {lines[e.lineno-1]}")
            print(f"  {' ' * (e.offset-1 if e.offset else 0)}^")

if errors:
    print(f"\n\n=== FOUND {len(errors)} SYNTAX ERRORS ===\n")
    for block_num, code, error in errors:
        print(f"\n--- Block {block_num} ---")
        print(f"Error: {error}")
        print("\nFull code:")
        print(code[:500])  # Show first 500 chars
else:
    print("\n✓ All Python code blocks have valid syntax!")

# Check specifically for PA and XXF
pa_match = re.search(r'<name>Porn Movies.*?</item>', content, re.DOTALL)
xxf_match = re.search(r'<name>New Videos - \[COLOR orchid\] XXF.*?</item>', content, re.DOTALL)

if pa_match:
    print("\n✓ Porn Movies PA entry found in XML")
else:
    print("\n✗ Porn Movies PA entry NOT FOUND")

if xxf_match:
    print("✓ New Videos XXF entry found in XML")
else:
    print("✗ New Videos XXF entry NOT FOUND")

# Check if Cliphunter is commented
if '<!-- DISABLED: Cliphunter' in content:
    print("✓ Cliphunter entries are commented out")
else:
    print("✗ Cliphunter entries are NOT commented!")

# Check webcam icon
if 'webcam.png' in content:
    print("✓ webcam.png icon reference found")
else:
    print("✗ webcam.png icon reference NOT found")
