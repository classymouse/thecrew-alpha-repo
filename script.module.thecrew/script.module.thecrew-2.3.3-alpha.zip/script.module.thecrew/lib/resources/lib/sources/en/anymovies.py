# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file anymovies.py
* @package script.module.thecrew
*
* Original author: Tempest
*
* @copyright (c) 2026, The Crew
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*
'''

import re

from urllib.parse import urlencode, quote_plus, parse_qs, urljoin

from ...modules import source_utils
from ...modules import client
from ...modules.crewruntime import c




class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domain = ['downloads-anymovies.com']
        self.base_link = 'https://www.downloads-anymovies.com'
        self.search_link = '/search.php?zoom_query=%s'
        self.headers = {'User-Agent': client.agent()}

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urlencode(url)
            return url
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if url is None:
                return sources

            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            hdlr = data['year']

            query = '%s %s' % (data['title'], data['year'])
            query = re.sub('(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', ' ', query)

            url = self.search_link % quote_plus(query)
            url = urljoin(self.base_link, url).replace('++', '+')

            try:
                post = client.request(url, headers=self.headers)
            except Exception as e:
                # network error
                c.log(f"[AnyMovies] Network error requesting search page: {e}")
                return sources

            if not post or 'Just a moment' in post or '404 Not Found' in post:
                c.log('[AnyMovies] Blocked or empty search result')
                return sources

            try:
                links = re.compile(r'class="result_title"><a href="(.+?)">(.+?)</a></div>').findall(post) or []
                c.log(f"[AnyMovies] Found {len(links)} search links")
                for _url, data in links:
                    if hdlr not in data:
                        continue
                    try:
                        page = client.request(_url, headers=self.headers)
                    except Exception as e:
                        c.log(f"[AnyMovies] Error fetching result page {_url}: {e}")
                        continue
                    try:
                        found = re.findall(r'<span class="text"><a href="(.+?)" target="_blank">', page) or []
                        c.log(f"[AnyMovies] Found {len(found)} outgoing links on page {_url}")
                        for link in found:
                            valid, host = source_utils.is_host_valid(link, hostDict)
                            c.log(f"[AnyMovies] is_host_valid({link}) -> {valid}, {host}")
                            if valid:
                                c.log(f"[AnyMovies] Adding source {host} {link}")
                                sources.append({'source': host, 'quality': 'HD', 'language': 'en', 'url': link, 'direct': False, 'debridonly': False})
                    except Exception as e:
                        c.log(f"[AnyMovies] Error parsing result page {_url}: {e}")
                        continue
            except Exception as e:
                c.log(f"[AnyMovies] Unexpected error processing search results: {e}")
                return sources

            return sources
        except Exception:
            return sources

    def resolve(self, url):
        return url
