# -*- coding: UTF-8 -*-
#######################################################################
# ----------------------------------------------------------------------------
# "THE BEER-WARE LICENSE" (Revision 42):
# @tantrumdev wrote this file.  As long as you retain this notice you
# can do whatever you want with this stuff. If we meet some day, and you think
# this stuff is worth it, you can buy me a beer in return. - Muad'Dib
# ----------------------------------------------------------------------------
#######################################################################


import re

from urllib.parse import parse_qs, urljoin, urlparse, urlencode, quote_plus
from ...modules.crewruntime import c



from ...modules import cleantitle, client, debrid, source_utils
from ...modules import cfscrape


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['rlsbb.in', 'rlsbb.com', 'rlsbb.ru', 'rlsbb.to', 'rlsbb.cc']
        self.base_link = 'https://rlsbb.in/'
        self.old_base_link = 'http://old3.rlsbb.in/'
        self.search_base_link = 'http://search.rlsbb.in/'
        self.search_cookie = 'serach_mode=rlsbb'
        self.search_link = 'lib/search526049.php?phrase=%s&pindex=1&content=true'


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urlencode(url)
            return url
        except:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urlencode(url)
            return url
        except:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None:
                return

            # Accept either a query-string or a dict; normalize to a simple dict of scalars
            if isinstance(url, dict):
                _data = {k: (v[0] if isinstance(v, (list, tuple)) else v) for k, v in url.items()}
            else:
                _data = parse_qs(url)
                _data = {k: (_data[k][0] if _data[k] else '') for k in _data}

            _data['title'], _data['premiered'], _data['season'], _data['episode'] = title, premiered, season, episode
            url = urlencode(_data)
            return url
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            scraper = cfscrape.create_scraper()
            c.log(f"[CM Debug @ 68 in rlsbb.py] url = {url}")

            if url is None:
                return sources

            if debrid.status() is False:
                return sources

            hostDict = hostprDict + hostDict

            # Accept either a query-string or a dict; normalize to a simple dict of scalars
            if isinstance(url, dict):
                data = {k: (v[0] if isinstance(v, (list, tuple)) else v) for k, v in url.items()}
            else:
                data = parse_qs(url)
                data = {k: (data[k][0] if data[k] else '') for k in data}

            title = data.get('tvshowtitle', data['title'])
            year = data['year']
            _year = re.findall('(\d{4})', data['premiered'])[0] if 'tvshowtitle' in data else year
            title = cleantitle.get_query(title)
            hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else year
            #premDate = ''

            query = '%s S%02dE%02d' % (title, int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else '%s %s' % (title, year)
            query = re.sub(r'(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', '', query or '')
            query = query.replace(" ", "-")

            _base_link = self.base_link if int(year) >= 2021 else self.old_base_link

            url = _base_link + query

            # Use response object to check status and handle non-200/404 gracefully
            resp = scraper.get(url)
            try:
                status = resp.status_code
            except Exception:
                status = None

            if status is not None and status != 200:
                c.log(f"[RLSBB Debug] HTTP status {status} for {url} - returning no sources")
                return sources

            r = resp.content
            c.log(f"[RLSBB Debug @ 83 in rlsbb.py] r: {r}")
            r = c.ensure_text(r, errors='replace')

            # Check for Cloudflare protection, 404 or empty response
            if not r or 'Just a moment' in r or 'Enable JavaScript and cookies' in r or '404 Not Found' in r:
                c.log("[RLSBB Debug] Cloudflare protection, 404 or empty response detected")
                return sources

            if r is None and 'tvshowtitle' in data:
                try:
                    m = re.search(r'S(\d+)E', hdlr)
                    season = m[1] if m else ''
                except re.error as rex:
                    c.log(f"[RLSBB Debug] Regex error extracting season: {rex}")
                    return sources

                query = title
                try:
                    query = re.sub(r'(\\\:;*?"<>|/\\-\')', '', query or '')
                except re.error:
                    # Last resort: escape and strip unsafe chars
                    query = re.sub(r'[\\:;*?"<>|/\\-\']', '', re.escape(query or ''))

                query = f"{query}-S{season}"
                query = query.replace("&", "and")
                query = query.replace("  ", " ")
                query = query.replace(" ", "-")
                url = _base_link + query
                r = scraper.get(url).content
                r = c.ensure_text(r, errors='replace')

            for loopCount in range(2):
                if loopCount == 1 or (r is None and 'tvshowtitle' in data):

                    try:
                        query = re.sub(r'[\\:;*?"<>|/\-\']', '', title or '')
                    except re.error as rex:
                        c.log(f"[RLSBB Debug] Regex error sanitizing title: {rex}")
                        query = re.sub(r'[\\:;*?"<>|/\-\']', '', re.escape(title or ''))
                    query = query.replace(
                        "&", " and ").replace(
                        "  ", " ").replace(
                        " ", "-")  # throw in extra spaces around & just in case
                    #query = query + "-" + premDate

                    url = _base_link + query
                    url = url.replace('The-Late-Show-with-Stephen-Colbert', 'Stephen-Colbert')

                    resp = scraper.get(url)
                    if getattr(resp, 'status_code', None) != 200:
                        c.log(f"[RLSBB Debug] HTTP status {getattr(resp, 'status_code', None)} for {url}")
                        r = ''
                    else:
                        r = resp.content
                        r = c.ensure_text(r, errors='replace')

                posts = client.parseDom(r, "div", attrs={"class": "content"})
                #hostDict = hostprDict + hostDict
                items = []
                for post in posts:
                    try:
                        u = client.parseDom(post, 'a', ret='href')
                        for i in u:
                            try:
                                name = str(i)
                                if hdlr in name.upper():
                                    items.append(name)
                                #elif len(premDate) > 0 and premDate in name.replace(".", "-"):
                                    #items.append(name)
                            except:
                                pass
                    except Exception as e:
                        c.log(f"[CM Debug @ 143 in rlsbb.py] Exception raised. Error = {e}")


                if items:
                    break

            seen_urls = set()

            for item in items:
                try:
                    info = []

                    url = str(item)
                    url = client.replaceHTMLCodes(url)
                    url = c.ensure_str(url, errors='ignore')

                    if url in seen_urls:
                        continue
                    seen_urls.add(url)

                    host = url.replace("\\", "")
                    host2 = host.strip('"')
                    host = re.findall(r'([\w]+[.][\w]+)$', urlparse(host2.strip().lower()).netloc)[0]

                    if host not in hostDict:
                        continue
                    if any(x in host2 for x in ['.rar', '.zip', '.iso', '.part']):
                        continue

                    quality, info = source_utils.get_release_quality(host2)

                    #try:
                    #    size = re.findall('((?:\d+\,\d+\.\d+|\d+\.\d+|\d+\,\d+|\d+)\s*(?:GiB|MiB|GB|MB))', post)[0]
                    #    div = 1 if size.endswith(('GB', 'GiB')) else 1024
                    #    size = float(re.sub('[^0-9|/.|/,]', '', size.replace(',', '.'))) / div
                    #    size = '%.2f GB' % size
                    #    info.append(size)
                    #except:
                    #    pass

                    info = ' | '.join(info)

                    host = client.replaceHTMLCodes(host)
                    host = c.ensure_text(host)
                    sources.append({'source': host, 'quality': quality, 'language': 'en',
                                    'url': host2, 'info': info, 'direct': False, 'debridonly': True})
                except Exception as e:
                    c.log(f"[CM Debug @ 190 in rlsbb.py] Exception raised. Error = {e}")

            if check := [i for i in sources if i['quality'] != 'CAM']:
                sources = check
            return sources
        except Exception as e:
            c.log(f"[CM Debug @ 197 in rlsbb.py] Exception raised. Error = {e}")
            return sources

    def resolve(self, url):
        return url
