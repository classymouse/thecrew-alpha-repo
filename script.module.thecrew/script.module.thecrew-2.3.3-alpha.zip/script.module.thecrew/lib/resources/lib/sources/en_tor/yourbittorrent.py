# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file yourbittorrent.py
* @package script.module.thecrew
*
* @copyright (c) 2025, The Crew
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*
'''


import re

from urllib.parse import urlencode, quote_plus,  parse_qs, urljoin

from resources.lib.modules import cache
from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import debrid
from resources.lib.modules import source_utils
from resources.lib.modules import workers
from resources.lib.modules import utils
from resources.lib.modules.crewruntime import c


class source:
    pack_capable = True

    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['yourbittorrent.com', 'yourbittorrent2.com']
        #self.base_link = 'https://yourbittorrent.com'
        self.base_link = None
        self.search_link = '?q=%s'
        self.aliases = []
        self.sources_list = []


    @property
    def base_link(self):
        if not self._base_link:
            #self._base_link = cache.get(self.__get_base_url, 120, 'https://%s' % self.domains[0])
            self._base_link = cache.get(self.__get_base_url, 0, 'https://%s' % self.domains[0])
        return self._base_link

    @base_link.setter
    def base_link(self, value):
        self._base_link = value

    def sources(self, data, hostDict):

        try:

            # c.log(f"[CM Debug @ 91 in yourbittorrent.py] data = {data}")
            if not data:
                return self.sources_list

            if debrid.status() is False:
                return self.sources_list

            self.title = data.get('tvshowtitle', data.get('title'))
            self.title = self.title.replace('&', 'and').replace('Special Victims Unit', 'SVU')

            self.hdlr = 'S%02dE%02d' % (int(data.get('season')), int(data.get('episode'))) if data.get('tvshowtitle') else data.get('year')
            self.year = data.get('year')

            query = ' '.join((self.title, self.hdlr))
            query = re.sub('[^A-Za-z0-9\s\.-]+', '', query)

            url = self.search_link % quote_plus(query)
            url = urljoin(self.base_link, url).replace('+', '-')
            # c.log(f"[CM Debug @ 113 in yourbittorrent.py]\n\n\n url = {url} \n\n\n")

            try:
                result = client.request(url)
                # c.log(f"[CM Debug @ 116 in yourbittorrent.py] r = {result}")
                links = re.findall('<a href="(/torrent/.+?)"', result, re.DOTALL)

                # c.log(f"[CM Debug @ 118 in yourbittorrent.py] links = {repr(links)}")

                threads = []
                for link in links:
                    threads.append(workers.Thread(self.get_sources, link))

                [i.start() for i in threads]
                [i.join() for i in threads]

                return self.sources_list
            except Exception as e:
                import traceback
                failure = traceback.format_exc()
                c.log(f'[CM Debug @ 133 in yourbittorrent.py]Traceback:: {failure}')
                c.log(f'[CM Debug @ 134 in yourbittorrent.py]Exception raised. Error = {e}')
                return self.sources_list
                #except Exception as e:
                #    c.log(f'YourBT3 - Exception: {e}', 1)
                #    return self.sources_list

        except Exception as e:
            c.log(f'YourBT4 - Exception: {e}', 1)
            return self.sources_list


    def get_sources(self, link):
        try:
            url = urljoin(self.base_link, link)
            # c.log(f"[CM Debug @ 128 in yourbittorrent.py] url = {url}")
            result = client.request(url)

            # Validate response
            if not result or result is None:
                c.log(f'[YourBT5] Empty or None response from {url}', 1)
                return

            # Ensure result is a string
            result = c.ensure_text(result, errors='replace')

            info_hash = re.findall(r'<kbd>(.+?)<', result, re.DOTALL)
            if not info_hash:
                c.log('[YourBT5] No info hash found in response', 1)
                return
            info_hash = info_hash[0]
            url = f'magnet:?xt=urn:btih:{info_hash}'

            name_match = re.findall(r'<h3 class="card-title">(.+?)<', result, re.DOTALL)
            if not name_match:
                c.log('[YourBT5] No name found in response', 1)
                return
            name = name_match[0]
            #url = '%s%s%s' % (url, '&dn=', str(name))
            url = f"{url}&dn={name}"

            size_match = re.findall(r'<div class="col-3">File size:</div><div class="col">(.+?)<', result, re.DOTALL)
            if not size_match:
                c.log('[YourBT5] No size found in response', 1)
                return
            size = size_match[0]

            if url in str(self.sources_list):
                return

            if any(x in url.lower() for x in ['french', 'italian', 'spanish', 'truefrench', 'dublado', 'dubbed']):
                return

            title = name.split(self.hdlr)[0].replace(self.year, '').replace('(', '').replace(')', '').replace('&', 'and').replace('+', ' ')

            if str(cleantitle.get(title)) not in str(cleantitle.get(self.title)):
                return

            if self.hdlr not in name:
                return

            quality, info = source_utils.get_release_quality(name, url)

            try:
                if size_parsed := re.findall(
                    r'((?:\d+\,\d+\.\d+|\d+\.\d+|\d+\,\d+|\d+)\s*(?:GiB|MiB|GB|MB))',
                    size,
                ):
                    size_str = size_parsed[0]
                    div = 1 if size_str.endswith(('GB', 'GiB')) else 1024
                    size_num = float(re.sub(r'[^0-9.|,]', '', size_str.replace(',', '.'))) / div
                    size = f'{size_num:.2f} GB'
                    info.insert(0, size)
            except Exception as e:
                c.log(f"[YourBT5] Exception parsing size: {e}", 1)


            info = ' | '.join(info)

            self.sources_list.append({
                'source': 'torrent', 'quality': quality, 'language': 'en', 'url': url,
                'info': info, 'direct': False, 'debridonly': True
                })

        except Exception as e:
            c.log(f'YourBT5 - Exception: {e}', 1)





    def __get_base_url(self, fallback):
        try:
            for domain in self.domains:
                try:
                    url = 'https://%s' % domain
                    result = client.request(url, timeout=7)
                    result = c.ensure_text(result, errors='ignore')
                    search_n = re.findall('<title>(.+?)</title>', result, re.DOTALL)[0]
                    if result and '1337x' in search_n:
                        return url
                except Exception:
                    pass
        except Exception:
            pass

        return fallback

    def sources_packs(self, data, hostDict, search_series=False, total_seasons=0, bypass_filter=0):
        sources = []
        try:
            if debrid.status() is False:
                return sources

            tvshowtitle = data.get('tvshowtitle')
            year = data.get('year')
            season = int(data.get('season', 0))
            imdb = data.get('imdb')
            aliases = data.get('aliases', [])

            if not tvshowtitle:
                return sources

            title_query = cleantitle.get_query(tvshowtitle)
            queries = []
            if search_series:
                queries.append(f'{title_query} Complete Series')
            else:
                queries.append(f'{title_query} S{season:02d}')

            for query in queries:
                try:
                    url = self.search_link % quote_plus(query)
                    url = urljoin(self.base_link, url)
                    r = client.request(url)
                    r = c.ensure_text(r, errors='replace')

                    posts = client.parseDom(r, 'div', attrs={'class': 'row'})
                    for post in posts:
                        try:
                            name = client.parseDom(post, 'div', attrs={'class': 'title'})[0]
                            name = client.parseDom(name, 'a')[0]

                            if search_series:
                                valid, last_season = source_utils.filter_show_pack(
                                    tvshowtitle, aliases, imdb, year, season,
                                    source_utils.release_title_format(name), total_seasons
                                )
                                if not valid:
                                    continue
                                package_meta = {'package': 'show', 'last_season': last_season}
                            else:
                                valid, episode_start, episode_end = source_utils.filter_season_pack(
                                    tvshowtitle, aliases, year, season,
                                    source_utils.release_title_format(name)
                                )
                                if not valid:
                                    continue
                                package_meta = {'package': 'season', 'episode_start': episode_start, 'episode_end': episode_end}

                            url_link = client.parseDom(post, 'div', attrs={'class': 'title'})[0]
                            url_link = client.parseDom(url_link, 'a', ret='href')[0]
                            url_link = urljoin(self.base_link, url_link)
                            r2 = client.request(url_link)
                            r2 = c.ensure_text(r2, errors='replace')
                            url_magnet = client.parseDom(r2, 'a', ret='href', attrs={'class': 'btn-magnet'})[0]
                            url_magnet = url_magnet.split('&tr=')[0]

                            quality, info = source_utils.get_release_quality(name, name)
                            try:
                                size = re.findall(r'((?:\d+\.\d+|\d+\,\d+|\d+)\s*(?:GB|GiB|MB|MiB))', post)[0]
                                div = 1 if size.endswith(('GB', 'GiB')) else 1024
                                size = float(re.sub('[^0-9|/.|/,]', '', size.replace(',', '.'))) / div
                                size = '%.2f GB' % size
                                info.append(size)
                            except Exception:
                                pass
                            info = ' | '.join(info)

                            source_dict = {'source': 'Torrent', 'quality': quality, 'language': 'en',
                                         'url': url_magnet, 'info': info, 'direct': False, 'debridonly': True}
                            source_dict.update(package_meta)
                            sources.append(source_dict)
                        except Exception:
                            continue
                except Exception:
                    continue
            return sources
        except Exception:
            return sources


    def resolve(self, url):
        return url