# -*- coding: utf-8 -*-

import re, json, base64, requests, time, random, math, xbmcgui
try:
    from urllib import urlencode, quote_plus, urlparse, urljoin
except ImportError:
    from urllib.parse import urlencode, quote_plus, urlparse, urljoin

from resources.lib.modules import control
from resources.lib.modules import client
from resources.lib.modules import site
from resources.lib.modules import workers
from resources.lib.modules import jsunpack
from resources.lib.modules import hunter
from resources.lib.modules.crewruntime import c

UA = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'


class streamer:
    def dodgycodes(self, s):
        return re.sub('&#(\d+);', '', s)

    def resolve(self, url):
        c.log(f'[crewstreamer.resolve] Called with URL: {url}')
        try:
            if 'roxiestreams' in url:
                c.log(f'[crewstreamer.resolve] Matched roxiestreams, calling roxie()')
                u = self.roxie(url)
                c.log(f'[crewstreamer.resolve] roxie() returned: {u}')
                return u
            else:
                c.log(f'[crewstreamer.resolve] No roxiestreams match, URL not handled')
                return None
        except Exception as e:
            c.log(f'[crewstreamer.resolve] EXCEPTION: {e}')
            import traceback
            c.log(f'[crewstreamer.resolve] Traceback: {traceback.format_exc()}')
            return None

    def roxie(self, url):
        try:
            c.log(f'[roxie] Starting with URL: {url}')

            plugin_name = control.infoLabel('Container.PluginName')
            c.log(f'[roxie] Plugin name check: {plugin_name}')
            if plugin_name != 'plugin.video.thecrew':
                c.log(f'[roxie] Plugin name mismatch, returning None')
                return

            c.log(f'[roxie] Requesting page: {url}')
            page_data = client.request(url)
            c.log(f'[roxie] Page data received: {len(page_data) if page_data else 0} bytes')

            if not page_data:
                c.log(f'[roxie] No page data, returning None')
                return

            if 'getRandomStream' in page_data:
                c.log(f'[roxie] Found getRandomStream pattern')
                pattern = r"getRandomStream\(\s*'([^']+)'\s*,\s*'([^']+)'\s*\)"
                stream_calls = set(re.findall(pattern, page_data))
                c.log(f'[roxie] Found {len(stream_calls)} stream calls: {stream_calls}')

                if not stream_calls:
                    c.log(f'[roxie] No stream calls found, returning None')
                    return

                try:
                    c.log(f'[roxie] Fetching domains from roxiestreams.live/domains.txt')
                    domain_text = client.request('https://roxiestreams.live/domains.txt')
                    domains = [d.strip() for d in domain_text.splitlines() if d.strip()]
                    c.log(f'[roxie] Got domains: {domains}')
                except Exception as e:
                    c.log(f'[roxie] Domain fetch failed: {e}, using default')
                    domains = ['shadow-ran.online']

                m3u8_list = []
                for stream_path, subdomain in stream_calls:
                    domain = random.choice(domains)
                    stream_url = f'https://{subdomain}.{domain}/{stream_path}'
                    c.log(f'[roxie] Constructed stream: {stream_url}')
                    m3u8_list.append(stream_url)

                if not m3u8_list:
                    c.log(f'[roxie] No m3u8 URLs constructed, returning None')
                    return
            else:
                c.log(f'[roxie] Looking for m3u8 URLs via regex')
                m3u8_list = re.findall(
                    r'https?://[^\s\'"]+\.m3u8',
                    page_data,
                    re.DOTALL
                )
                c.log(f'[roxie] Found {len(m3u8_list)} m3u8 URLs: {m3u8_list}')

                if not m3u8_list:
                    c.log(f'[roxie] No m3u8 URLs found, returning None')
                    return

            if len(m3u8_list) == 1:
                stream_url = m3u8_list[0]
                c.log(f'[roxie] Single stream selected: {stream_url}')
            else:
                labels = [f'Stream {i+1}' for i in range(len(m3u8_list))]
                choice = xbmcgui.Dialog().select('Select Stream', labels)
                c.log(f'[roxie] User selected stream #{choice}')
                if choice == -1:
                    c.log(f'[roxie] User cancelled, returning None')
                    return
                stream_url = m3u8_list[choice]

            u = urlparse(url)
            origin = f'{u.scheme}://{u.netloc}'
            final_url = (
                stream_url
                + '|User-Agent=' + UA
                + '&Referer=' + url
                + '&Origin=' + origin
            )
            c.log(f'[roxie] Returning final URL: {final_url[:100]}...')
            return final_url

        except Exception as e:
            c.log(f'[roxie] EXCEPTION: {e}')
            import traceback
            c.log(f'[roxie] Traceback: {traceback.format_exc()}')
            return
