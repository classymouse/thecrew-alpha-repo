# -*- coding: utf-8 -*-

'''
 ***********************************************************
 *
 * The Crew Addon
 *
 * @file cleandate.py
 * @package script.module.thecrew
 *
 * @copyright 2025, The Crew
 * @license GNU General Public License, version 3 (GPL-3.0)
 *
 ********************************************************cm*
'''

import time
import datetime


def new_iso_to_utc(iso_ts):
    if not iso_ts:
        return 0
    return int(time.mktime(time.strptime(iso_ts, "%Y-%m-%dT%H:%M:%S.000Z")))

def now_to_iso():
    return datetime.datetime.now().isoformat('T', 'milliseconds') + 'Z'
