# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file debrid.py
* @package script.module.thecrew
*
* @copyright (c) 2026, The Crew
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*
'''

import re
import time

import traceback
import requests

import xbmc
from . import control
from . import log_utils
from . import source_utils
from .crewruntime import c


# Constants for pack resolution
DEBRID_API_TIMEOUT = 10  # seconds
PACK_PROCESS_DELAY = 2   # seconds - wait for torrent processing
STATUS_CHECK_DELAY = 1   # seconds - wait before status check

try:
    import resolveurl
    debrid_resolvers = [resolver() for resolver in resolveurl.relevant_resolvers(order_matters=True) if resolver.isUniversal()]
except:
    debrid_resolvers = []


# Global lock to prevent multiple pack resolutions from running simultaneously
_pack_resolution_active = {}  # Dictionary to track active resolutions by hash

# Global progress dialog for resolution attempts (shared across sources)
_resolution_progress_dialog = {'dialog': None}


def create_shared_resolution_dialog(message='Resolving sources...'):
    """Create the shared resolution progress dialog."""
    if _resolution_progress_dialog['dialog'] is None:
        try:
            c.log('[Debrid] Creating shared resolution progress dialog')
            _resolution_progress_dialog['dialog'] = control.progressDialog if control.setting('progress.dialog') == '0' else control.progressDialogBG
            _resolution_progress_dialog['dialog'].create(control.addonInfo('name'), message)
            _resolution_progress_dialog['dialog'].update(0)
        except Exception as e:
            c.log(f'[Debrid] Error creating shared dialog: {e}', 1)
    return _resolution_progress_dialog['dialog']


def update_shared_resolution_dialog(message, percent=0):
    """Update the shared resolution progress dialog if it exists."""
    if _resolution_progress_dialog['dialog'] is not None:
        try:
            _resolution_progress_dialog['dialog'].update(percent, message)
        except Exception as e:
            c.log(f'[Debrid] Error updating shared dialog: {e}', 1)


def close_shared_resolution_dialog():
    """Close the shared resolution progress dialog if it exists."""
    if _resolution_progress_dialog['dialog'] is not None:
        try:
            c.log('[Debrid] Closing shared resolution progress dialog')
            _resolution_progress_dialog['dialog'].close()
        except Exception as e:
            c.log(f'[Debrid] Error closing shared dialog: {e}', 1)
        finally:
            _resolution_progress_dialog['dialog'] = None


def status(torrent=False):
    debrid_check = debrid_resolvers != []
    if debrid_check is True:
        if torrent:
            enabled = control.setting('torrent.enabled')
            if enabled == '' or enabled.lower() == 'true':
                return True
            else:
                return False
    return debrid_check


def get_debrid_token(service_name, thecrew_setting_name):
    """Get debrid token from resolveurl first, then fall back to The Crew settings."""
    token = None
    source = None

    # Try resolveurl first
    try:
        resolveurl_addon = control.addon('script.module.resolveurl')
        token = resolveurl_addon.getSetting(service_name)
        if token:
            source = 'resolveurl'
            c.log(f'[Debrid Token] Got {service_name} token from resolveurl')
    except Exception as e:
        c.log(f'[Debrid Token] Could not get {service_name} token from resolveurl: {e}')

    # Fall back to The Crew settings
    if not token:
        token = control.setting(thecrew_setting_name)
        if token:
            source = 'thecrew'
            c.log(f'[Debrid Token] Got {service_name} token from The Crew settings')

    return token, source


def resolver(url, debrid, season=None, episode=None):
    # Import at function level to avoid namespace issues


    try:
        c.log('[Debrid] ========== RESOLVER CALLED ==========')
        c.log(f'[Debrid] resolver() called: url={url[:60] if url else None}..., debrid={debrid}, season={season}, episode={episode}')

        # Check if this is a magnet link with season/episode (pack source)
        if url.startswith('magnet:') and season is not None and episode is not None:
            c.log('[Debrid] Pack source detected: magnet link with S{season:02d}E{episode:02d}')
            c.log('[Debrid] Starting pack resolution')

            # Check if there's an active persistent overlay (TV Evening/Up Next)
            try:
                from .sources import get_active_overlay
                active_overlay = get_active_overlay()
                c.log(f'[Debrid] Overlay check: active_overlay={active_overlay}, type={type(active_overlay)}')

                if active_overlay and hasattr(active_overlay, 'transition_to_state'):
                    # Use existing overlay - just update message
                    c.log('[Debrid] Using active overlay for resolution progress')
                    active_overlay.transition_to_state('resolving', 'Generating download link...')
                    progressDialog = active_overlay
                    close_dialog_after = False  # Don't close - it's managed elsewhere
                else:
                    # Check if we already have a global resolution dialog active
                    if _resolution_progress_dialog['dialog'] is not None:
                        c.log('[Debrid] Reusing existing resolution progress dialog')
                        progressDialog = _resolution_progress_dialog['dialog']
                        close_dialog_after = False  # Don't close shared dialog
                        # Update the dialog message for this attempt
                        try:
                            progressDialog.update(0, f'Trying {debrid} for S{season:02d}E{episode:02d}...')
                        except Exception:
                            pass
                    else:
                        # No overlay and no shared dialog - create one
                        if active_overlay:
                            c.log('[Debrid] Overlay exists but missing transition_to_state method')
                        else:
                            c.log('[Debrid] No active overlay detected')
                        c.log('[Debrid] Creating shared progress dialog')
                        progressDialog = control.progressDialog if control.setting('progress.dialog') == '0' else control.progressDialogBG
                        progressDialog.create(control.addonInfo('name'), 'Resolving...')
                        progressDialog.update(0, f'Trying {debrid} for S{season:02d}E{episode:02d}...')
                        _resolution_progress_dialog['dialog'] = progressDialog
                        close_dialog_after = False  # Don't close - let sourcesDirect manage it
            except Exception as e:
                c.log(f'[Debrid] Error checking for active overlay: {e}', 1)
                c.log(f'[Debrid] Traceback: {traceback.format_exc()}')
                # Fallback to creating a dialog
                if _resolution_progress_dialog['dialog'] is not None:
                    progressDialog = _resolution_progress_dialog['dialog']
                    close_dialog_after = False
                else:
                    progressDialog = control.progressDialog if control.setting('progress.dialog') == '0' else control.progressDialogBG
                    progressDialog.create(control.addonInfo('name'), f'Resolving pack for S{season:02d}E{episode:02d}...')
                    progressDialog.update(0)
                    _resolution_progress_dialog['dialog'] = progressDialog
                    close_dialog_after = False

            # Try direct pack resolution for supported debrid services
            # Normalize debrid service name (case-insensitive matching)
            debrid_normalized = debrid.lower().replace(' ', '-')
            if debrid_normalized in ('real-debrid', 'alldebrid', 'premiumize.me'):
                # Map to canonical name for resolve_pack
                canonical_name_map = {
                    'real-debrid': 'Real-Debrid',
                    'alldebrid': 'AllDebrid',
                    'premiumize.me': 'Premiumize.me'
                }
                canonical_name = canonical_name_map.get(debrid_normalized, debrid)
                c.log(f'[Debrid] Normalized "{debrid}" -> "{canonical_name}" for pack resolution')
                pack_url = resolve_pack(url, canonical_name, season, episode, progressDialog)

                # Close dialog only if we created it (not if using overlay)
                if close_dialog_after:
                    try:
                        if progressDialog:
                            progressDialog.close()
                    except Exception:
                        pass

                if pack_url:
                    c.log('[Debrid] Pack resolution successful: Selected correct episode file')
                    c.log('[Debrid] ========== RESOLVER RETURNING (PACK SUCCESS) ==========')
                    return pack_url
                else:
                    c.log('[Debrid] Pack resolution failed, falling back to resolveurl', 1)
                    c.log('[Debrid] About to call resolveurl fallback (may show another progress dialog)')

        c.log(f'[Debrid] Calling resolveurl standard resolver for {debrid}')
        debrid_resolver = [resolver for resolver in debrid_resolvers if resolver.name == debrid][0]

        debrid_resolver.login()
        _host, _media_id = debrid_resolver.get_host_and_id(url)

        # Log season/episode info for debugging pack file selection
        if season is not None and episode is not None:
            c.log(f'[Debrid] Resolving with season={season}, episode={episode} for pack file selection')

        # Try to pass season/episode to get_media_url if it supports it
        try:
            # Some resolvers support season/episode parameters for pack file selection
            stream_url = debrid_resolver.get_media_url(_host, _media_id, season=season, episode=episode)
        except TypeError:
            # Fallback if resolver doesn't support season/episode parameters
            stream_url = debrid_resolver.get_media_url(_host, _media_id)
            if season is not None and episode is not None:
                c.log('[Debrid] Note: Resolver does not support season/episode parameters')

        c.log('[Debrid] ========== RESOLVER RETURNING (RESOLVEURL SUCCESS) ==========')
        return stream_url
    except Exception as e:
        c.log(f'{debrid} Resolve Failure: {e}', 1)
        c.log('[Debrid] ========== RESOLVER RETURNING (EXCEPTION) ==========')
        return None


def resolve_pack(magnet_url, debrid_service, season, episode, progressDialog=None):
    """
    Resolve pack torrent by selecting correct episode file from magnet link.

    Args:
        magnet_url: Magnet link
        debrid_service: Debrid service name ('Real-Debrid', 'AllDebrid', 'Premiumize.me')
        season: Season number
        episode: Episode number
        progressDialog: Optional progress dialog to update during resolution

    Returns:
        str: Direct download URL for correct episode file, or None if failed
    """
    # Extract hash from magnet to use as lock key
    hash_match = re.search(r'btih:([a-fA-F0-9]+)', magnet_url)
    if hash_match:
        torrent_hash = hash_match.group(1).lower()

        # Check if this torrent is already being resolved
        if torrent_hash in _pack_resolution_active:
            c.log('[Pack] Another resolution is already in progress for this torrent, skipping')
            return None

        # Mark this torrent as being resolved
        _pack_resolution_active[torrent_hash] = True

    try:
        c.log(f'[Pack] Resolving with {debrid_service} for S{season:02d}E{episode:02d}')

        result = None
        if debrid_service == 'Real-Debrid':
            c.log('[Pack] Dispatching to resolve_pack_realdebrid()')
            result = resolve_pack_realdebrid(magnet_url, season, episode, progressDialog)
        elif debrid_service == 'AllDebrid':
            c.log('[Pack] Dispatching to resolve_pack_alldebrid()')
            result = resolve_pack_alldebrid(magnet_url, season, episode, progressDialog)
            c.log(f'[Pack] resolve_pack_alldebrid() returned: {result}')
        elif debrid_service == 'Premiumize.me':
            c.log('[Pack] Dispatching to resolve_pack_premiumize()')
            result = resolve_pack_premiumize(magnet_url, season, episode, progressDialog)
        else:
            c.log(f'[Pack] Resolution not implemented for {debrid_service}')

        return result
    except Exception as e:
        c.log(f'[Pack] Resolution error: {e}', 1)
        c.log(f'[Pack] Traceback: {traceback.format_exc()}', 1)
        return None
    finally:
        # Always clear the lock when done
        if hash_match and torrent_hash in _pack_resolution_active:
            del _pack_resolution_active[torrent_hash]
            c.log('[Pack] Released resolution lock')


def resolve_pack_realdebrid(magnet_url, season, episode, progressDialog=None):
    """Resolve pack with Real-Debrid API."""
    c.log(f'[RD Pack] Starting resolution for S{season:02d}E{episode:02d}')
    try:
        # Get RD API token from resolveurl or settings
        if progressDialog:
            try:
                progressDialog.update(10, 'Getting Real-Debrid token...')
            except Exception:
                pass
        rd_token, token_source = get_debrid_token('RealDebridResolver_token', 'realdebridtoken')
        if not rd_token:
            c.log('[RD Pack] No Real-Debrid token found in resolveurl or The Crew settings', 1)
            return None
        c.log(f'[RD Pack] Token found from {token_source}')

        base_url = 'https://api.real-debrid.com/rest/1.0'
        headers = {'Authorization': f'Bearer {rd_token}'}

        # Add magnet to RD
        c.log('[RD Pack] Adding magnet to Real-Debrid')
        add_url = f'{base_url}/torrents/addMagnet'
        add_data = {'magnet': magnet_url}
        add_response = requests.post(add_url, data=add_data, headers=headers, timeout=DEBRID_API_TIMEOUT)

        if add_response.status_code != 201:
            c.log(f'[RD Pack] Failed to add magnet: {add_response.status_code}', 1)
            return None

        torrent_id = add_response.json().get('id')
        if not torrent_id:
            c.log('[RD Pack] No torrent ID returned', 1)
            return None

        # Wait for torrent to be processed
        if progressDialog:
            try:
                progressDialog.update(40, 'Processing torrent...')
            except Exception:
                pass
        time.sleep(PACK_PROCESS_DELAY)

        # Get torrent info
        if progressDialog:
            try:
                progressDialog.update(60, 'Finding episode file...')
            except Exception:
                pass
        info_url = f'{base_url}/torrents/info/{torrent_id}'
        info_response = requests.get(info_url, headers=headers, timeout=DEBRID_API_TIMEOUT)

        if info_response.status_code != 200:
            c.log(f'[RD Pack] Failed to get torrent info: {info_response.status_code}', 1)
            return None

        torrent_info = info_response.json()
        files = torrent_info.get('files', [])

        if not files:
            c.log('[RD Pack] No files in torrent', 1)
            return None

        # Filter video files
        video_extensions = source_utils.supported_video_extensions()
        video_files = [f for f in files if any(f['path'].lower().endswith(ext) for ext in video_extensions)]

        if not video_files:
            c.log('[RD Pack] No video files in torrent', 1)
            return None

        c.log(f'[RD Pack] Found {len(video_files)} video files, searching for S{season:02d}E{episode:02d}')

        # Find ALL matching files using seas_ep_filter
        matched_files = []
        for file in video_files:
            if source_utils.seas_ep_filter(season, episode, file['path']):
                matched_files.append(file)
                c.log(f'[RD Pack] Potential match: {file["path"]} ({file.get("bytes", 0) / 1024 / 1024:.1f} MB)')

        if not matched_files:
            c.log('[RD Pack] No matching episode file found', 1)
            return None

        # Filter out samples and proofs
        non_sample_files = [f for f in matched_files if not any(x in f['path'].lower() for x in ['sample', 'proof', '-trailer'])]
        if non_sample_files:
            matched_files = non_sample_files
        else:
            c.log('[RD Pack] Warning: All matches look like samples!')

        # Choose the largest file (most likely to be the full episode)
        matched_file = max(matched_files, key=lambda f: f.get('bytes', 0))
        c.log(f'[RD Pack] Selected best match: {matched_file["path"]} ({matched_file.get("bytes", 0) / 1024 / 1024:.1f} MB)')
        if progressDialog:
            try:
                progressDialog.update(80, 'Generating download link...')
            except Exception:
                pass

        # Final validation that we have a matched file
        if not matched_file:
            c.log(f'[RD Pack] No file matched S{season:02d}E{episode:02d} pattern', 1)
            return None

        # Select the file
        file_id = str(matched_file['id'])
        select_url = f'{base_url}/torrents/selectFiles/{torrent_id}'
        select_data = {'files': file_id}
        select_response = requests.post(select_url, data=select_data, headers=headers, timeout=DEBRID_API_TIMEOUT)

        if select_response.status_code != 204:
            c.log(f'[RD Pack] Failed to select file: {select_response.status_code}', 1)
            return None

        # Check if torrent is already cached (downloaded) or needs downloading
        c.log('[RD Pack] Checking torrent status...')
        time.sleep(STATUS_CHECK_DELAY)

        info_response = requests.get(info_url, headers=headers, timeout=DEBRID_API_TIMEOUT)
        torrent_info = info_response.json()
        status = torrent_info.get('status')

        # If torrent is not cached, let resolveurl handle it
        if status in ('downloading', 'queued', 'magnet_conversion', 'waiting_files_selection'):
            c.log(f'[RD Pack] Torrent not cached (status: {status}), falling back to resolveurl')
            return None

        if status == 'error':
            c.log('[RD Pack] Real-Debrid reported an error status', 1)
            return None

        # Torrent is cached (downloaded), get links
        c.log(f'[RD Pack] Torrent is cached (status: {status}), getting links...')

        links = torrent_info.get('links', [])
        if not links:
            c.log('[RD Pack] No download links available', 1)
            return None

        # Unrestrict the link
        link = links[0]
        unrestrict_url = f'{base_url}/unrestrict/link'
        unrestrict_data = {'link': link}
        unrestrict_response = requests.post(unrestrict_url, data=unrestrict_data, headers=headers, timeout=DEBRID_API_TIMEOUT)

        if unrestrict_response.status_code != 200:
            c.log(f'[RD Pack] Failed to unrestrict link: {unrestrict_response.status_code}', 1)
            return None

        download_url = unrestrict_response.json().get('download')
        if download_url:
            c.log('[RD Pack] Successfully resolved pack file')
            return download_url

        return None

    except Exception as e:
        c.log(f'[RD Pack] Exception: {e}', 1)
        c.log(f'[RD Pack] Traceback: {traceback.format_exc()}', 1)
        return None


def resolve_pack_alldebrid(magnet_url, season, episode, progressDialog=None):
    """Resolve pack with AllDebrid API."""
    c.log(f'[AD Pack] Function called for S{season:02d}E{episode:02d}')
    try:
        # Get AD API key from resolveurl or settings
        if progressDialog:
            try:
                progressDialog.update(10, 'Getting AllDebrid token...')
            except Exception:
                pass
        ad_token, token_source = get_debrid_token('AllDebridResolver_token', 'alldebridtoken')
        if not ad_token:
            c.log('[AD Pack] No AllDebrid token found in resolveurl or The Crew settings', 1)
            return None

        # Use current API version (v4.6 or latest stable)
        base_url = 'https://api.alldebrid.com/v4'

        # Add magnet to AD
        c.log(f'[AD Pack] Adding magnet to AllDebrid (token from {token_source})')
        if progressDialog:
            try:
                progressDialog.update(20, 'Adding magnet to AllDebrid...')
            except Exception:
                pass
        add_url = f'{base_url}/magnet/upload'
        add_params = {'agent': 'thecrew', 'apikey': ad_token, 'magnets[]': magnet_url}
        add_response = requests.get(add_url, params=add_params, timeout=DEBRID_API_TIMEOUT)

        if add_response.status_code != 200:
            c.log(f'[AD Pack] Failed to add magnet: {add_response.status_code}', 1)
            return None

        add_data = add_response.json()
        if add_data.get('status') != 'success':
            c.log(f'[AD Pack] Upload failed: {add_data}', 1)
            return None

        magnet_id = add_data['data']['magnets'][0]['id']

        # Check if torrent is already cached
        c.log('[AD Pack] Checking magnet status...')
        if progressDialog:
            try:
                progressDialog.update(40, 'Checking if cached...')
            except Exception:
                pass
        time.sleep(STATUS_CHECK_DELAY)

        status_url = f'{base_url}/magnet/status'
        status_params = {'agent': 'thecrew', 'apikey': ad_token, 'id': magnet_id}
        status_response = requests.get(status_url, params=status_params, timeout=DEBRID_API_TIMEOUT)

        if status_response.status_code != 200:
            c.log(f'[AD Pack] Failed to get status: {status_response.status_code}', 1)
            return None

        status_data = status_response.json()
        if status_data.get('status') != 'success':
            c.log(f'[AD Pack] Status check failed: {status_data}', 1)
            return None

        magnets = status_data.get('data', {}).get('magnets', [])
        if not magnets:
            c.log('[AD Pack] No magnets in status', 1)
            return None

        magnet_info = magnets[0]
        magnet_status = magnet_info.get('status')

        # If magnet is not ready (still downloading), let resolveurl handle it
        if magnet_status != 'Ready':
            c.log(f'[AD Pack] Torrent not cached (status: {magnet_status}), falling back to resolveurl')
            return None

        # Magnet is ready (cached), get links
        c.log(f'[AD Pack] Torrent is cached (status: {magnet_status}), getting links...')

        links = magnet_info.get('links', [])
        if not links:
            c.log('[AD Pack] No links available', 1)
            return None

        # Filter video files
        video_extensions = source_utils.supported_video_extensions()
        video_files = [link for link in links if any(link['filename'].lower().endswith(ext) for ext in video_extensions)]

        if not video_files:
            c.log('[AD Pack] No video files found', 1)
            return None

        c.log(f'[AD Pack] Found {len(video_files)} video files, searching for S{season:02d}E{episode:02d}')
        if progressDialog:
            try:
                progressDialog.update(60, 'Finding episode file...')
            except Exception:
                pass

        # Find ALL matching files using seas_ep_filter
        matched_files = []
        for file in video_files:
            if source_utils.seas_ep_filter(season, episode, file['filename']):
                matched_files.append(file)
                c.log(f'[AD Pack] Potential match: {file["filename"]} ({file.get("size", 0) / 1024 / 1024:.1f} MB)')

        if not matched_files:
            c.log('[AD Pack] No matching episode file found', 1)
            return None

        # Filter out samples and proofs
        non_sample_files = [f for f in matched_files if not any(x in f['filename'].lower() for x in ['sample', 'proof', '-trailer'])]
        if non_sample_files:
            matched_files = non_sample_files
        else:
            c.log('[AD Pack] Warning: All matches look like samples!')

        # Choose the largest file (most likely to be the full episode)
        matched_file = max(matched_files, key=lambda f: f.get('size', 0))
        c.log(f'[AD Pack] Selected best match: {matched_file["filename"]} ({matched_file.get("size", 0) / 1024 / 1024:.1f} MB)')
        if progressDialog:
            try:
                progressDialog.update(80, 'Generating download link...')
            except Exception:
                pass

        # Final validation that we have a matched file
        if not matched_file:
            c.log(f'[AD Pack] No file matched S{season:02d}E{episode:02d} pattern', 1)
            return None

        # Unrestrict the link
        unrestrict_url = f'{base_url}/link/unlock'
        unrestrict_params = {'agent': 'thecrew', 'apikey': ad_token, 'link': matched_file['link']}
        unrestrict_response = requests.get(unrestrict_url, params=unrestrict_params, timeout=DEBRID_API_TIMEOUT)

        if unrestrict_response.status_code != 200:
            c.log(f'[AD Pack] Failed to unrestrict: {unrestrict_response.status_code}', 1)
            return None

        unrestrict_data = unrestrict_response.json()
        if unrestrict_data.get('status') != 'success':
            c.log(f'[AD Pack] Unrestrict failed: {unrestrict_data}', 1)
            return None

        download_url = unrestrict_data['data']['link']
        if download_url:
            c.log('[AD Pack] Successfully resolved pack file')
            return download_url

        return None

    except Exception as e:
        c.log(f'[AD Pack] Exception: {e}', 1)
        c.log(f'[AD Pack] Traceback: {traceback.format_exc()}', 1)
        return None


def resolve_pack_premiumize(magnet_url, season, episode, progressDialog=None):
    """Resolve pack with Premiumize API."""
    c.log(f'[PM Pack] Function called for S{season:02d}E{episode:02d}')
    try:
        # Get PM API key from resolveurl or settings
        if progressDialog:
            try:
                progressDialog.update(10, 'Getting Premiumize token...')
            except Exception:
                pass
        pm_token, token_source = get_debrid_token('PremiumizeMeResolver_token', 'premiumizetoken')
        if not pm_token:
            c.log('[PM Pack] No Premiumize token found in resolveurl or The Crew settings', 1)
            return None

        base_url = 'https://www.premiumize.me/api'
        headers = {'Authorization': f'Bearer {pm_token}'}

        # Add magnet to PM
        c.log(f'[PM Pack] Adding magnet to Premiumize (token from {token_source})')
        if progressDialog:
            try:
                progressDialog.update(20, 'Adding magnet to Premiumize...')
            except Exception:
                pass
        add_url = f'{base_url}/transfer/create'
        add_data = {'src': magnet_url}
        add_response = requests.post(add_url, data=add_data, headers=headers, timeout=DEBRID_API_TIMEOUT)

        if add_response.status_code != 200:
            c.log(f'[PM Pack] Failed to add magnet: {add_response.status_code}', 1)
            return None

        add_result = add_response.json()
        if add_result.get('status') != 'success':
            c.log(f'[PM Pack] Create transfer failed: {add_result}', 1)
            return None

        transfer_id = add_result.get('id')

        # Check if transfer is already cached
        c.log('[PM Pack] Checking transfer status...')
        if progressDialog:
            try:
                progressDialog.update(40, 'Checking if cached...')
            except Exception:
                pass
        time.sleep(STATUS_CHECK_DELAY)

        status_url = f'{base_url}/transfer/list'
        status_response = requests.get(status_url, headers=headers, timeout=DEBRID_API_TIMEOUT)

        if status_response.status_code != 200:
            c.log(f'[PM Pack] Failed to get transfer status: {status_response.status_code}', 1)
            return None

        status_data = status_response.json()
        if status_data.get('status') != 'success':
            c.log(f'[PM Pack] Transfer status check failed: {status_data}', 1)
            return None

        # Find our transfer
        transfers = status_data.get('transfers', [])
        our_transfer = None
        for transfer in transfers:
            if transfer.get('id') == transfer_id:
                our_transfer = transfer
                break

        if not our_transfer:
            c.log('[PM Pack] Transfer not found in list', 1)
            return None

        transfer_status = our_transfer.get('status')

        # If transfer is not finished (still downloading), let resolveurl handle it
        if transfer_status != 'finished':
            c.log(f'[PM Pack] Transfer not cached (status: {transfer_status}), falling back to resolveurl')
            return None

        # Transfer is finished (cached), get folder contents
        c.log(f'[PM Pack] Transfer is cached (status: {transfer_status}), getting files...')

        # List folder contents
        folder_id = add_result.get('folder_id')
        if not folder_id:
            c.log('[PM Pack] No folder ID returned', 1)
            return None

        list_url = f'{base_url}/folder/list'
        list_params = {'id': folder_id}
        list_response = requests.get(list_url, params=list_params, headers=headers, timeout=DEBRID_API_TIMEOUT)

        if list_response.status_code != 200:
            c.log(f'[PM Pack] Failed to list folder: {list_response.status_code}', 1)
            return None

        list_data = list_response.json()
        if list_data.get('status') != 'success':
            c.log(f'[PM Pack] List folder failed: {list_data}', 1)
            return None

        content = list_data.get('content', [])

        # Filter video files
        video_extensions = source_utils.supported_video_extensions()
        video_files = [item for item in content if item['type'] == 'file' and any(item['name'].lower().endswith(ext) for ext in video_extensions)]

        if not video_files:
            c.log('[PM Pack] No video files found', 1)
            return None

        c.log(f'[PM Pack] Found {len(video_files)} video files, searching for S{season:02d}E{episode:02d}')
        if progressDialog:
            try:
                progressDialog.update(60, 'Finding episode file...')
            except Exception:
                pass

        # Find ALL matching files using seas_ep_filter
        matched_files = []
        for file in video_files:
            if source_utils.seas_ep_filter(season, episode, file['name']):
                matched_files.append(file)
                c.log(f'[PM Pack] Potential match: {file["name"]} ({file.get("size", 0) / 1024 / 1024:.1f} MB)')

        if not matched_files:
            c.log('[PM Pack] No matching episode file found', 1)
            return None

        # Filter out samples and proofs
        non_sample_files = [f for f in matched_files if not any(x in f['name'].lower() for x in ['sample', 'proof', '-trailer'])]
        if non_sample_files:
            matched_files = non_sample_files
        else:
            c.log('[PM Pack] Warning: All matches look like samples!')

        # Choose the largest file (most likely to be the full episode)
        matched_file = max(matched_files, key=lambda f: f.get('size', 0))
        c.log(f'[PM Pack] Selected best match: {matched_file["name"]} ({matched_file.get("size", 0) / 1024 / 1024:.1f} MB)')
        if progressDialog:
            try:
                progressDialog.update(80, 'Generating download link...')
            except Exception:
                pass

        if not matched_file:
            c.log(f'[PM Pack] No file matched S{season:02d}E{episode:02d} pattern', 1)
            return None

        download_url = matched_file.get('link')
        if download_url:
            c.log('[PM Pack] Successfully resolved pack file')
            return download_url

        return None

    except Exception as e:
        c.log(f'[PM Pack] Exception: {e}', 1)
        c.log(f'[PM Pack] Traceback: {traceback.format_exc()}', 1)
        return None
