# -*- coding: utf-8 -*-

'''
    The Crew Add-on
    Debrid Account Manager

    Displays user account information for Real-Debrid, AllDebrid, and Premiumize
    Shows account status, expiration, points, and cloud storage access
'''

import xbmcgui
from resources.lib.modules import control
from resources.lib.modules.crewruntime import c

try:
    import resolveurl
    RESOLVEURL_AVAILABLE = True
except:
    RESOLVEURL_AVAILABLE = False


class DebridAccountManager:
    def __init__(self):
        self.services = {
            'Real-Debrid': self.get_realdebrid_info,
            'AllDebrid': self.get_alldebrid_info,
            'Premiumize': self.get_premiumize_info
        }

    def show_account_info(self):
        """Main entry point - shows account info for all configured debrid services"""
        if not RESOLVEURL_AVAILABLE:
            xbmcgui.Dialog().ok(
                '[B]Debrid Account Manager[/B]',
                'ResolveURL is not installed or configured.\nPlease install ResolveURL to use debrid services.'
            )
            return

        # Get info for all services
        c.log('[Debrid Manager] Starting account info check...', 1)
        service_info = {}
        for service_name, get_info_func in self.services.items():
            try:
                c.log(f'[Debrid Manager] Checking {service_name}...', 1)
                info = get_info_func()
                if info:
                    c.log(f'[Debrid Manager] Got info for {service_name}', 1)
                    service_info[service_name] = info
                else:
                    c.log(f'[Debrid Manager] No info returned for {service_name}', 1)
            except Exception as e:
                c.log(f'[Debrid Manager] Error getting {service_name} info: {e}', 1)

                c.log(f'[Debrid Manager] Traceback: {traceback.format_exc()}', 1)

        c.log(f'[Debrid Manager] Found {len(service_info)} configured services', 1)
        if not service_info:
            xbmcgui.Dialog().ok(
                '[B]Debrid Account Manager[/B]',
                'No debrid accounts configured.\nConfigure your debrid services in ResolveURL settings.'
            )
            return

        # Show menu with available services
        self.show_service_menu(service_info)

    def show_service_menu(self, service_info):
        """Shows menu to select which debrid service to view details for"""
        service_names = list(service_info.keys())
        service_labels = []

        for name in service_names:
            info = service_info[name]
            status = '[COLOR green]Active[/COLOR]' if info.get('active') else '[COLOR red]Inactive[/COLOR]'
            service_labels.append(f'[COLOR skyblue]{name}[/COLOR]: {status}')

        service_labels.append('[COLOR skyblue]Browse Cloud Storage[/COLOR]')
        service_labels.append('Configure Debrid Services')

        choice = xbmcgui.Dialog().select(
            '[B]Debrid Account Manager[/B]',
            service_labels
        )

        if choice < 0:
            return
        elif choice < len(service_names):
            # Show detailed info for selected service
            self.show_service_details(service_names[choice], service_info[service_names[choice]], service_info)
        elif choice == len(service_names):
            # Browse cloud storage
            self.browse_cloud_menu(service_info)
        else:
            # Open ResolveURL settings
            control.execute('RunPlugin(plugin://plugin.video.thecrew/?action=ResolveUrlSettings)')

    def show_service_details(self, service_name, info, service_info):
        """Shows detailed account information for a specific service"""
        lines = []

        if info.get('username'):
            lines.append(f'Username: {info["username"]}')
        if info.get('email'):
            lines.append(f'Email: {info["email"]}')

        # Format expiration date and calculate days left
        if info.get('expiration') and info['expiration'] != 'N/A':
            expiration_str, days_left = self._format_expiration(info['expiration'])
            lines.append(f'Expires: {expiration_str}')
            if days_left is not None and days_left >= 0:
                if days_left == 0:
                    lines.append('[COLOR red]Days Left: Expires Today![/COLOR]')
                elif days_left <= 7:
                    lines.append(f'[COLOR red]Days Left: {days_left} days[/COLOR]')
                elif days_left <= 30:
                    lines.append(f'[COLOR yellow]Days Left: {days_left} days[/COLOR]')
                else:
                    lines.append(f'[COLOR green]Days Left: {days_left} days[/COLOR]')
            elif days_left is not None and days_left < 0:
                lines.append(f'[COLOR red]Expired {abs(days_left)} days ago[/COLOR]')

        if info.get('type'):
            lines.append(f'Account Type: {info["type"]}')
        if info.get('points'):
            lines.append(f'Points/Credits: {info["points"]}')
        if info.get('storage'):
            lines.append(f'Storage Used: {info["storage"]}')
        if info.get('limits'):
            lines.append(f'Limits: {info["limits"]}')

        if not info.get('active'):
            lines.append('[COLOR red]Account is not active or expired[/COLOR]')

        # Add options at the end
        lines.append('')
        lines.append('[COLOR skyblue]<< Back to Account Manager[/COLOR]')

        choice = xbmcgui.Dialog().select(
            f'[B]{service_name} Account[/B]',
            lines
        )

        # If user selects "Back" option (last item) or backs out, return to main menu
        if choice == len(lines) - 1 or choice < 0:
            # Show the service menu again
            self.show_service_menu(service_info)

    def browse_cloud_menu(self, service_info):
        """Shows menu to select cloud storage to browse"""
        service_names = [name for name in service_info.keys()]
        service_labels = [f'[COLOR skyblue]{name}[/COLOR] Cloud Storage' for name in service_names]
        service_labels.append('[COLOR skyblue]<< Back to Account Manager[/COLOR]')

        choice = xbmcgui.Dialog().select(
            '[B]Browse Cloud Storage[/B]',
            service_labels
        )

        if choice < 0:
            # User cancelled
            return
        elif choice < len(service_names):
            # Selected a service
            service_name = service_names[choice]
            self.browse_cloud_storage(service_name, service_info)
        else:
            # Back button - return to main menu
            self.show_service_menu(service_info)

    def browse_cloud_storage(self, service_name, service_info):
        """Opens cloud storage browser for the selected service"""
        c.log(f'[Debrid Manager] Opening {service_name} cloud browser...', 1)

        # Use control.execute to run the cloud browser action through the router
        if service_name == 'Real-Debrid':
            control.execute('Container.Update(plugin://plugin.video.thecrew/?action=rd_cloud)')
        elif service_name == 'AllDebrid':
            control.execute('Container.Update(plugin://plugin.video.thecrew/?action=ad_cloud)')
        elif service_name == 'Premiumize':
            control.execute('Container.Update(plugin://plugin.video.thecrew/?action=pm_cloud)')
        else:
            xbmcgui.Dialog().ok(
                'Unknown Service',
                f'Cloud browsing not available for {service_name}'
            )
            self.browse_cloud_menu(service_info)

    def get_realdebrid_info(self):
        """Get Real-Debrid account information"""
        try:
            # Find Real-Debrid resolver
            c.log('[Debrid Manager] Getting Real-Debrid resolver...', 1)
            resolver = self._get_resolver('Real-Debrid')
            if not resolver:
                c.log('[Debrid Manager] Real-Debrid resolver not found', 1)
                return None

            c.log(f'[Debrid Manager] Real-Debrid resolver: {resolver}', 1)
            if not self._is_resolver_logged_in(resolver):
                c.log('[Debrid Manager] Real-Debrid not logged in', 1)
                return None

            # Get user info from Real-Debrid API
            import requests
            auth_token = self._get_resolver_auth(resolver)
            if not auth_token:
                c.log('[Debrid Manager] Real-Debrid no auth token', 1)
                return None

            c.log('[Debrid Manager] Making Real-Debrid API call...', 1)
            headers = {'Authorization': f'Bearer {auth_token}'}
            response = requests.get('https://api.real-debrid.com/rest/1.0/user', headers=headers, timeout=10)

            c.log(f'[Debrid Manager] Real-Debrid API response: {response.status_code}', 1)
            if response.status_code == 200:
                data = response.json()
                c.log(f'[Debrid Manager] Real-Debrid data received: {data.get("username", "N/A")}', 1)
                return {
                    'active': True,
                    'username': data.get('username', 'N/A'),
                    'email': data.get('email', 'N/A'),
                    'expiration': data.get('expiration', 'N/A'),
                    'type': data.get('type', 'N/A'),
                    'points': str(data.get('points', 0)),
                    'limits': f"{data.get('limit', 'N/A')}"
                }
        except Exception as e:
            c.log(f'[Debrid Manager] Real-Debrid error: {e}', 1)

            c.log(f'[Debrid Manager] Real-Debrid traceback: {traceback.format_exc()}', 1)
        return None

    def get_alldebrid_info(self):
        """Get AllDebrid account information"""
        try:
            resolver = self._get_resolver('AllDebrid')
            if not resolver or not self._is_resolver_logged_in(resolver):
                return None

            import requests
            api_key = self._get_resolver_auth(resolver)
            if not api_key:
                return None

            response = requests.get(f'https://api.alldebrid.com/v4/user?agent=theCrew&apikey={api_key}', timeout=10)

            if response.status_code == 200:
                data = response.json().get('data', {}).get('user', {})
                return {
                    'active': True,
                    'username': data.get('username', 'N/A'),
                    'email': data.get('email', 'N/A'),
                    'expiration': data.get('premiumUntil', 'N/A'),
                    'type': 'Premium' if data.get('isPremium') else 'Free',
                    'points': str(data.get('fidelityPoints', 0))
                }
        except Exception as e:
            c.log(f'[Debrid Manager] AllDebrid error: {e}', 1)
        return None

    def get_premiumize_info(self):
        """Get Premiumize account information"""
        try:
            resolver = self._get_resolver('Premiumize.me')
            if not resolver or not self._is_resolver_logged_in(resolver):
                return None

            import requests
            api_key = self._get_resolver_auth(resolver)
            if not api_key:
                return None

            headers = {'Authorization': f'Bearer {api_key}'}
            response = requests.get('https://www.premiumize.me/api/account/info', headers=headers, timeout=10)

            if response.status_code == 200:
                data = response.json()
                storage_used = data.get('space_used', 0)
                storage_total = data.get('limit_used', 0)
                storage_str = f'{storage_used / (1024**3):.2f} GB / {storage_total / (1024**3):.2f} GB'

                return {
                    'active': True,
                    'email': data.get('customer_id', 'N/A'),
                    'expiration': data.get('premium_until', 'N/A'),
                    'type': 'Premium' if data.get('premium_until') else 'Free',
                    'storage': storage_str,
                    'points': str(data.get('fairuse_left', 'N/A'))
                }
        except Exception as e:
            c.log(f'[Debrid Manager] Premiumize error: {e}', 1)
        return None

    def _get_resolver(self, service_name):
        """Get resolver instance for a service"""
        try:
            if not RESOLVEURL_AVAILABLE:
                return None

            # Get resolver class and instantiate it
            resolver_classes = [r for r in resolveurl.relevant_resolvers(order_matters=True) if r.name == service_name]
            if resolver_classes:
                return resolver_classes[0]()  # Instantiate the resolver class
            return None
        except Exception as e:
            c.log(f'[Debrid Manager] Error getting {service_name} resolver: {e}', 1)
            return None

    def _is_resolver_logged_in(self, resolver):
        """Check if resolver is logged in"""
        try:
            # Check if resolver has get_setting method and a valid auth token/key
            if not hasattr(resolver, 'get_setting'):
                return False

            # Check for different auth setting names used by different services
            for setting_name in ['token', 'api_key', 'apikey', 'auth']:
                try:
                    value = resolver.get_setting(setting_name)
                    if value:
                        c.log(f'[Debrid Manager] Found {setting_name} for {resolver.name}', 1)
                        return True
                except:
                    continue

            c.log(f'[Debrid Manager] No auth found for {resolver.name}', 1)
            return False
        except Exception as e:
            c.log(f'[Debrid Manager] Login check error for {resolver.name}: {e}', 1)
            return False

    def _get_resolver_auth(self, resolver):
        """Get auth token/key from resolver"""
        try:
            # Try to get stored auth data
            if hasattr(resolver, 'get_setting'):
                # Try different setting names used by different services
                for setting_name in ['token', 'api_key', 'apikey', 'auth', 'client_id']:
                    try:
                        value = resolver.get_setting(setting_name)
                        if value:
                            c.log(f'[Debrid Manager] Retrieved {setting_name} for {resolver.name}', 1)
                            return value
                    except:
                        continue

            c.log(f'[Debrid Manager] No auth token found for {resolver.name}', 1)
        except Exception as e:
            c.log(f'[Debrid Manager] Auth retrieval error for {resolver.name}: {e}', 1)
        return None

    def _format_expiration(self, expiration):
        """Convert Unix timestamp or ISO date to readable format and calculate days left"""
        try:
            from datetime import datetime, timezone

            # Try to parse as Unix timestamp first
            try:
                if isinstance(expiration, (int, float)):
                    exp_timestamp = int(expiration)
                elif isinstance(expiration, str) and expiration.isdigit():
                    exp_timestamp = int(expiration)
                else:
                    # Try parsing as ISO date string
                    exp_dt = datetime.fromisoformat(expiration.replace('Z', '+00:00'))
                    exp_timestamp = int(exp_dt.timestamp())

                exp_dt = datetime.fromtimestamp(exp_timestamp, timezone.utc)
                now = datetime.now(timezone.utc)

                # Calculate days left
                days_left = (exp_dt - now).days

                # Format as readable date
                date_str = exp_dt.strftime('%Y-%m-%d %H:%M UTC')

                return date_str, days_left
            except (ValueError, OSError):
                # If timestamp parsing fails, try as ISO string
                return str(expiration), None
        except Exception as e:
            c.log(f'[Debrid Manager] Expiration format error: {e}', 1)
            return str(expiration), None


def show_debrid_accounts():
    """Entry point for the debrid account manager"""
    manager = DebridAccountManager()
    manager.show_account_info()
