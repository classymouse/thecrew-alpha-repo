# -*- coding: utf-8 -*-

'''
 ***********************************************************
 * The Crew Add-on
 *
 *
 * @file sources.py
 * @package script.module.thecrew
 *
 * @copyright (c) 2023-2026, The Crew
 * @license GNU General Public License, version 3 (GPL-3.0)
 *
 ********************************************************cm*
'''

import requests
import random

from . import utils
from . import cache

from .crewruntime import c

class realdebrid():
    def __init__(self):
        self.name = 'RealDebrid'
        self.url = 'https://realdebrid.com'
        self.api = 'https://api.realdebrid.com'
        self.rest_base_url = 'https://api.real-debrid.com/rest/1.0/'
        self.oauth_url = 'https://api.real-debrid.com/oauth/v2/'
        self.token = c.get_setting('rd.token')
        self.secret = c.get_setting('rd.secret')
        self.client_id = c.get_setting('rd.client_id') or 'X245A4XAIBGVM' # RealDebrid Client ID - limited!
        self.refresh = c.get_setting('rd.refresh')
        self.account_id = c.get_setting('rd.account_id')
        self.enabled = c.get_setting('rd.enabled')
        self.device_code = c.get_setting('rd.device_code')
        self.user_agent = cache.get(self.randomagent, 12)

    def _get(self, url):
        original_url = url
        url = self.rest_base_url + url
        if '?' not in url:
            url += "?auth_token=%s" % self.token
        else:
            url += "&auth_token=%s" % self.token
        response = requests.get(url).text
        try:
            resp = utils.json_loads_as_str(response)
        except Exception as e:
            c.log(f"[CM Debug @ 51 in debridcheck.py] exception: error = {e}")
            resp = utils.byteify(response)
        return resp

    def _post(self, url, data={}):
        result = None
        if self.token == '':
            return None
        url = self.rest_base_url + url + '?agent=%s&apikey=%s' % (self.user_agent, self.token)

        resp = requests.post(url, data=data).json()
        if resp.get('status') == 'success':
            if 'data' in resp:
                resp = resp['data']['magnets']
        return resp

    def _put(self, url, data={}):
        result = None
        if self.token == '':
            return None
        url = self.rest_base_url + url + '?agent=%s&apikey=%s' % (self.user_agent, self.token)
        resp = requests.put(url, data=data).json()
        if resp.get('status') == 'success':
            if 'data' in resp:
                resp = resp['data']['magnets']
        return resp

    def _delete(self, url, data={}):
        result = None
        if self.token == '': return None
        url = self.base_url + url + '?agent=%s&apikey=%s' % (self.user_agent, self.token)
        resp = requests.delete(url, data=data).json()
        if resp.get('status') == 'success':
            if 'data' in resp:
                resp = resp['data']['magnets']
        return resp

    def refreshToken(self):
        data = {'grant_type': 'refresh_token', 'refresh_token': self.refresh}
        response = requests.post(self.oauth_url + 'token', data=data, timeout=30).json()
        self.token = response['access_token']
        self.refresh = response['refresh_token']
        c.set_setting('rd.token', self.token)
        c.set_setting('rd.refresh', self.refresh)

        return True

    def revoke(self):
        c.set_setting('rd.client_id', 'empty_setting')
        c.set_setting('rd.secret', 'empty_setting')
        c.set_setting('rd.refresh', 'empty_setting')
        c.set_setting('rd.token', 'empty_setting')
        c.set_setting('rd.account_id', 'empty_setting')
        c.set_setting('rd.enabled', 'false')
        c.set_setting('rd.device_code', 'empty_setting')

        return True

    def auth(self):
        self.client_id = c.get_setting('rd.client_id')
        self.secret = c.get_setting('rd.secret')
        self.refresh = c.get_setting('rd.refresh')
        self.token = c.get_setting('rd.token')
        self.account_id = c.get_setting('rd.account_id')
        self.enabled = c.get_setting('rd.enabled')
        self.device_code = c.get_setting('rd.device_code')

        return True

    def check(self):
        self.client_id = c.get_setting('rd.client_id')
        self.secret = c.get_setting('rd.secret')
        self.refresh = c.get_setting('rd.refresh')
        self.token = c.get_setting('rd.token')
        self.account_id = c.get_setting('rd.account_id')
        self.enabled = c.get_setting('rd.enabled')
        self.device_code = c.get_setting('rd.device_code')

        return True

    def enabled(self):
        self.client_id = c.get_setting('rd.client_id')
        self.secret = c.get_setting('rd.secret')
        self.refresh = c.get_setting('rd.refresh')
        self.token = c.get_setting('rd.token')
        self.account_id = c.get_setting('rd.account_id')
        self.enabled = c.get_setting('rd.enabled')
        self.device_code = c.get_setting('rd.device_code')

        return True

    def disable(self):
        self.client_id = c.get_setting('rd.client_id')
        self.secret = c.get_setting('rd.secret')
        self.refresh = c.get_setting('rd.refresh')
        self.token = c.get_setting('rd.token')
        self.account_id = c.get_setting('rd.account_id')
        self.enabled = c.get_setting('rd.enabled')
        self.device_code = c.get_setting('rd.device_code')

        return True

    def randomagent():
        BR_VERS = [
            ['%s.0' % i for i in range(18, 50)],
            [
                '37.0.2062.103', '37.0.2062.120', '37.0.2062.124', '38.0.2125.101', '38.0.2125.104', '38.0.2125.111',
                '39.0.2171.71', '39.0.2171.95', '39.0.2171.99', '40.0.2214.93', '40.0.2214.111', '40.0.2214.115',
                '42.0.2311.90', '42.0.2311.135', '42.0.2311.152', '43.0.2357.81', '43.0.2357.124', '44.0.2403.155',
                '44.0.2403.157', '45.0.2454.101', '45.0.2454.85', '46.0.2490.71', '46.0.2490.80', '46.0.2490.86',
                '47.0.2526.73', '47.0.2526.80', '48.0.2564.116', '49.0.2623.112', '50.0.2661.86', '51.0.2704.103',
                '52.0.2743.116', '53.0.2785.143', '54.0.2840.71', '61.0.3163.100'
            ],
            ['11.0'],
            ['8.0', '9.0', '10.0', '10.6']]
        WIN_VERS = ['Windows NT 10.0', 'Windows NT 7.0', 'Windows NT 6.3', 'Windows NT 6.2',
                    'Windows NT 6.1', 'Windows NT 6.0', 'Windows NT 5.1', 'Windows NT 5.0']
        FEATURES = ['; WOW64', '; Win64; IA64', '; Win64; x64', '']
        RAND_UAS = ['Mozilla/5.0 ({win_ver}{feature}; rv:{br_ver}) Gecko/20100101 Firefox/{br_ver}',
                    'Mozilla/5.0 ({win_ver}{feature}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{br_ver} Safari/537.36',
                    'Mozilla/5.0 ({win_ver}{feature}; Trident/7.0; rv:{br_ver}) like Gecko',
                    'Mozilla/5.0 (compatible; MSIE {br_ver}; {win_ver}{feature}; Trident/6.0)']
        index = random.randrange(len(RAND_UAS))
        return RAND_UAS[index].format(
            win_ver=random.choice(WIN_VERS),
            feature=random.choice(FEATURES),
            br_ver=random.choice(BR_VERS[index]))

    # ===== CLOUD BROWSING METHODS =====

    def user_cloud(self):
        """Get list of torrents in Real-Debrid cloud storage"""
        try:
            response = self._get('torrents')
            if isinstance(response, list):
                # Filter to only show downloaded/ready torrents
                return [t for t in response if t.get('status') == 'downloaded']
            return []
        except Exception as e:
            c.log(f'[RD API] Error getting cloud storage: {e}', 1)
            return []

    def torrent_info(self, torrent_id):
        """Get detailed information about a specific torrent"""
        try:
            return self._get(f'torrents/info/{torrent_id}')
        except Exception as e:
            c.log(f'[RD API] Error getting torrent info: {e}', 1)
            return None

    def unrestrict_link(self, link):
        """Unrestrict a hoster link"""
        try:
            data = {'link': link}
            url = 'unrestrict/link'
            if '?' not in url:
                url += f'?auth_token={self.token}'
            else:
                url += f'&auth_token={self.token}'

            response = requests.post(self.rest_base_url + url, data=data, timeout=30).json()
            return response.get('download', '')
        except Exception as e:
            c.log(f'[RD API] Error unrestricting link: {e}', 1)
            return None

    def delete_torrent(self, torrent_id):
        """Delete a torrent from cloud storage"""
        try:
            url = f'torrents/delete/{torrent_id}'
            if '?' not in url:
                url += f'?auth_token={self.token}'
            else:
                url += f'&auth_token={self.token}'

            response = requests.delete(self.rest_base_url + url, timeout=30)
            return response.status_code == 204
        except Exception as e:
            c.log(f'[RD API] Error deleting torrent: {e}', 1)
            return False


class alldebrid():
    def __init__(self):
        self.name = 'AllDebrid'
        self.base_url = 'https://api.alldebrid.com/v4/'
        self.api_key = c.get_setting('ad.api_key')
        self.user_agent = 'TheCrew'

    def _get(self, url, **params):
        """Make GET request to AllDebrid API"""
        try:
            params['agent'] = self.user_agent
            params['apikey'] = self.api_key
            response = requests.get(self.base_url + url, params=params, timeout=30).json()
            if response.get('status') == 'success':
                return response.get('data', {})
            return None
        except Exception as e:
            c.log(f'[AD API] GET error: {e}', 1)
            return None

    def _post(self, url, data=None):
        """Make POST request to AllDebrid API"""
        try:
            params = {'agent': self.user_agent, 'apikey': self.api_key}
            response = requests.post(self.base_url + url, params=params, data=data or {}, timeout=30).json()
            if response.get('status') == 'success':
                return response.get('data', {})
            return None
        except Exception as e:
            c.log(f'[AD API] POST error: {e}', 1)
            return None

    def user_cloud(self):
        """Get list of magnets in AllDebrid cloud storage"""
        try:
            response = self._get('magnet/status')
            if response and 'magnets' in response:
                # Filter to only show ready/downloaded magnets
                return [m for m in response['magnets'] if m.get('statusCode') == 4]
            return []
        except Exception as e:
            c.log(f'[AD API] Error getting cloud storage: {e}', 1)
            return []

    def magnet_status(self, magnet_id):
        """Get status of a specific magnet"""
        try:
            return self._get(f'magnet/status', id=magnet_id)
        except Exception as e:
            c.log(f'[AD API] Error getting magnet status: {e}', 1)
            return None

    def unrestrict_link(self, link):
        """Unrestrict a hoster link"""
        try:
            response = self._get('link/unlock', link=link)
            if response and 'link' in response:
                return response['link']
            return None
        except Exception as e:
            c.log(f'[AD API] Error unrestricting link: {e}', 1)
            return None

    def delete_magnet(self, magnet_id):
        """Delete a magnet from cloud storage"""
        try:
            response = self._get('magnet/delete', id=magnet_id)
            return response is not None
        except Exception as e:
            c.log(f'[AD API] Error deleting magnet: {e}', 1)
            return False


class premiumize():
    def __init__(self):
        self.name = 'Premiumize'
        self.base_url = 'https://www.premiumize.me/api/'
        self.api_key = c.get_setting('pm.api_key')

    def _get(self, endpoint, **params):
        """Make GET request to Premiumize API"""
        try:
            params['apikey'] = self.api_key
            response = requests.get(self.base_url + endpoint, params=params, timeout=30).json()
            if response.get('status') == 'success':
                return response
            return None
        except Exception as e:
            c.log(f'[PM API] GET error: {e}', 1)
            return None

    def _post(self, endpoint, data=None):
        """Make POST request to Premiumize API"""
        try:
            if data is None:
                data = {}
            data['apikey'] = self.api_key
            response = requests.post(self.base_url + endpoint, data=data, timeout=30).json()
            if response.get('status') == 'success':
                return response
            return None
        except Exception as e:
            c.log(f'[PM API] POST error: {e}', 1)
            return None

    def user_cloud(self, folder_id=None):
        """Get list of items in Premiumize cloud storage"""
        try:
            params = {}
            if folder_id:
                params['id'] = folder_id
                response = self._get('folder/list', **params)
            else:
                response = self._get('folder/list')

            if response:
                return {
                    'folders': response.get('content', []),
                    'files': response.get('content', [])
                }
            return {'folders': [], 'files': []}
        except Exception as e:
            c.log(f'[PM API] Error getting cloud storage: {e}', 1)
            return {'folders': [], 'files': []}

    def unrestrict_link(self, link):
        """Unrestrict a hoster link"""
        try:
            response = self._post('transfer/directdl', {'src': link})
            if response and 'content' in response:
                items = response['content']
                if items and len(items) > 0:
                    return items[0].get('link', '')
            return None
        except Exception as e:
            c.log(f'[PM API] Error unrestricting link: {e}', 1)
            return None

    def delete_item(self, item_id):
        """Delete an item from cloud storage"""
        try:
            response = self._post('item/delete', {'id': item_id})
            return response is not None
        except Exception as e:
            c.log(f'[PM API] Error deleting item: {e}', 1)
            return False
