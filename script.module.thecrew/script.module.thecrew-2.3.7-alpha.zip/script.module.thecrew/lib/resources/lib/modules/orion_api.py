# -*- coding: utf-8 -*-

'''
 ***********************************************************
 * The Crew Add-on
 *
 *
 * @file orion_api.py
 * @package script.module.thecrew
 *
 * @copyright (c) 2025, The Crew
 * @license GNU General Public License, version 3 (GPL-3.0)
 *
 ********************************************************cm*
'''

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import json
import os

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import math

from orion import Orion
from .crewruntime import c
from . import keys
from . import control
from . import source_utils


class orionApi:
    def __init__(self):
        self.base_url = 'https://api.orionoid.com'
        self.appkey = keys.orion_key
        self.testkey = 'TESTTESTTESTTESTTESTTESTTESTTEST'
        self.orion_installed = self.is_orion_installed()
        self.session = requests.Session()
        self.retries = Retry(total=3, backoff_factor=0.5)
        self.session.mount(self.base_url, HTTPAdapter(max_retries=self.retries))
        self.orion = Orion(self.appkey)


    def get_orion(self, mode, action, data):
        try:
            headers = {
                'Content-Type': 'application/json',
            }
            addonID = xbmcaddon.Addon().getAddonInfo("id")
            c.log(f"[CM Debug @ 61 in orion_api.py] addonID = {addonID}")

            data = json.dumps(data) if data else None
            #build url

            response = self.session.post(url, json=data, headers=headers)

            c.log(f"[CM Debug @ 76 in orion_api.py] response = {response.text}")
            c.log(f"[CM Debug @ 77 in orion_api.py] response_code = {response.status_code}")

        except Exception as e:

            failure = traceback.format_exc()
            c.log(f'[CM Debug @ 55 in orion_api.py]Traceback:: {failure}')
            c.log(f'[CM Debug @ 55 in orion_api.py]Exception raised. Error = {e}')
            pass





    def is_orion_installed(self):# -> Any:
        return xbmc.getCondVisibility('System.HasAddon(script.module.orion)')

    def get_credentials_info(self) -> bool:
        """Check if user has valid Orion credentials."""
        try:
            orion = Orion(self.appkey)
            # Orion module stores credentials internally, check if enabled and valid
            return orion.userEnabled() and orion.userValid()
        except Exception as e:
            c.log(f"[CM Debug @ 88 in orion_api.py] Error checking Orion credentials: {e}")
            return False

    def get_movie(self, imdb, limit=None) -> dict:
        """Get movie streams from Orion.

        Args:
            imdb: IMDb ID
            limit: Override Orion's configured limit (None = use Orion settings)
        """
        # Use FilterSettings (None) to respect user's Orion settings, or override with limit parameter
        limitCount = limit if limit is not None else Orion.FilterSettings
        results = self.orion.streams(
            type=Orion.TypeMovie,
            idImdb=imdb,
            limitCount=limitCount
        )
        return results

    def get_episode(self, imdb=0, tmdb=0, title='', season=0, episode=0, limit=None) -> dict:
        """Get episode streams from Orion.

        Args:
            imdb: IMDb ID
            tmdb: TMDB ID
            title: Show title (fallback search)
            season: Season number
            episode: Episode number
            limit: Override Orion's configured limit (None = use Orion settings)
        """
        # Use FilterSettings (None) to respect user's Orion settings, or override with limit parameter
        limitCount = limit if limit is not None else Orion.FilterSettings

        if imdb and imdb != 0:
            results = self.orion.streams(
                type=Orion.TypeShow,
                idImdb=imdb,
                numberSeason=season,
                numberEpisode=episode,
                limitCount=limitCount
            )
        elif tmdb and tmdb != 0:
            results = self.orion.streams(
                type=Orion.TypeShow,
                idTmdb=tmdb,
                numberSeason=season,
                numberEpisode=episode,
                limitCount=limitCount
            )
        elif title and title != '':
            results = self.orion.streams(
                type=Orion.TypeShow,
                query=title,
                limitCount=limitCount
            )
        else:
            return None
        return results

    def do_orion_scrape(self, data, _type='movie'):
        """Parse Orion API results into source format.

        Args:
            data: List of stream dictionaries from Orion API
            _type: 'movie' or 'episode'
        """
        try:
            sources = []

            # Validate data
            if data is None:
                c.log("[Orion] No data returned (API key not configured or service unavailable)")
                return []

            if not isinstance(data, list):
                c.log(f"[Orion] Unexpected data type: {type(data)}")
                return []

            if len(data) == 0:
                c.log("[Orion] No streams found for this title")
                return []

            c.log(f"[Orion] Processing {len(data)} streams for {_type}")

            # Log first item structure for debugging (only once)
            if len(data) > 0 and c.devmode:
                c.log(f"[Orion] Sample stream structure (first item): {data[0].keys()}")
                c.log(f"[Orion] Full first item: {data[0]}")

            if _type == 'movie':
                for i, item in enumerate(data):
                    try:
                        # Extract link
                        links = item.get("links", [])
                        url = ''
                        for link in links:
                            if link.startswith("magnet:") and url == '':
                                url = link
                                break

                        if not url:
                            continue

                        # Extract file info
                        fileinfo = item.get("file", {})
                        name = fileinfo.get("name", "")
                        path = fileinfo.get("path", "")  # Full path if available (Orion API improvement)
                        size = fileinfo.get("size", 0)
                        pack = fileinfo.get("pack", None)  # Check if it's a pack

                        # Prefer path over name for better context (e.g., "Show.2160p/S01/E01.mkv" vs "E01.mkv")
                        display_name = path if path else name

                        if not name:
                            continue

                        # Log pack detection for movies (this should NOT be a pack)
                        if pack and c.devmode:
                            c.log(f"[Orion] WARNING: Movie result has pack={pack}, name={display_name}")

                        # Extract video metadata from API if available
                        video = item.get("video", {})
                        audio = item.get("audio", {})
                        stream_info = item.get("stream", {})

                        # Get quality from path (if available) or filename
                        # Path often contains better quality info than filename alone
                        quality, info = source_utils.get_release_quality(display_name)

                        # Enhance info with Orion API metadata (video/audio specs)
                        if video:
                            codec = video.get("codec", "")
                            if codec:
                                codec_map = {"h264": "H.264", "h265": "HEVC", "hevc": "HEVC", "x264": "H.264", "x265": "HEVC"}
                                codec_display = codec_map.get(codec.lower(), codec.upper())
                                if codec_display not in ' '.join(info):
                                    info.append(codec_display)

                        if audio:
                            channels = audio.get("channels", "")
                            codec = audio.get("codec", "")
                            if codec:
                                audio_map = {"dd": "DD", "ddp": "DD+", "dts": "DTS", "atmos": "ATMOS", "truehd": "TrueHD"}
                                audio_display = audio_map.get(codec.lower(), codec.upper())
                                if audio_display not in ' '.join(info):
                                    info.append(audio_display)
                            if channels and str(channels) not in ' '.join(info):
                                info.append(f"{channels}CH")

                        if stream_info:
                            source_type = stream_info.get("source", "")
                            if source_type:
                                source_map = {"webrip": "WEB-DL", "webdl": "WEB-DL", "bluray": "BluRay", "brrip": "BRRip"}
                                source_display = source_map.get(source_type.lower(), source_type)
                                if source_display not in ' '.join(info):
                                    info.append(source_display)

                        try:
                            dsize, isize = source_utils.file_size(size)
                        except:
                            dsize, isize = 0.0, ''

                        if isize:
                            info.insert(0, isize)

                        # Log enhanced info in devmode
                        if c.devmode and i < 3:  # Log first 3 items
                            c.log(f"[Orion] Movie #{i}: quality={quality}, info={info}, pack={pack}")

                        sources.append({
                            'provider': 'Orion',
                            'source': 'Torrent',
                            'quality': quality,
                            'language': 'en',
                            'url': url,
                            'info': ' | '.join(info) if isinstance(info, list) else info,
                            'direct': False,
                            'debridonly': True,
                            'size': dsize,
                            'name': display_name  # Use path if available for better context
                        })
                    except Exception as item_error:
                        c.log(f"[Orion] Error processing movie item {i}: {item_error}")
                        import traceback
                        c.log(f"[Orion] Traceback: {traceback.format_exc()}")
                        continue

                c.log(f"[Orion] Returned {len(sources)} movie sources")
                return sources

            else:  # episode
                for i, item in enumerate(data):
                    try:
                        # Extract link
                        links = item.get("links", [])
                        url = ''
                        for link in links:
                            if link.startswith("magnet:") and url == '':
                                url = link
                                break

                        if not url:
                            continue

                        # Extract file info
                        fileinfo = item.get("file", {})
                        name = fileinfo.get("name", "")
                        path = fileinfo.get("path", "")  # Full path if available (Orion API improvement)
                        size = fileinfo.get("size", 0)
                        pack = fileinfo.get("pack", None)  # Pack info (season/show pack)

                        # Prefer path over name for better context (e.g., "Show.2160p/S01/E01.mkv" vs "E01.mkv")
                        display_name = path if path else name

                        if not name:
                            continue

                        # Extract video/audio metadata from API
                        video = item.get("video", {})
                        audio = item.get("audio", {})
                        stream_info = item.get("stream", {})

                        # Get quality from path (if available) or filename
                        # Path often contains better quality info than filename alone
                        quality, info = source_utils.get_release_quality(display_name)

                        # Enhance info with Orion API metadata (video/audio specs)
                        if video:
                            codec = video.get("codec", "")
                            if codec:
                                codec_map = {"h264": "H.264", "h265": "HEVC", "hevc": "HEVC", "x264": "H.264", "x265": "HEVC"}
                                codec_display = codec_map.get(codec.lower(), codec.upper())
                                if codec_display not in ' '.join(info):
                                    info.append(codec_display)

                        if audio:
                            channels = audio.get("channels", "")
                            codec = audio.get("codec", "")
                            if codec:
                                audio_map = {"dd": "DD", "ddp": "DD+", "dts": "DTS", "atmos": "ATMOS", "truehd": "TrueHD"}
                                audio_display = audio_map.get(codec.lower(), codec.upper())
                                if audio_display not in ' '.join(info):
                                    info.append(audio_display)
                            if channels and str(channels) not in ' '.join(info):
                                info.append(f"{channels}CH")

                        if stream_info:
                            source_type = stream_info.get("source", "")
                            if source_type:
                                source_map = {"webrip": "WEB-DL", "webdl": "WEB-DL", "bluray": "BluRay", "brrip": "BRRip"}
                                source_display = source_map.get(source_type.lower(), source_type)
                                if source_display not in ' '.join(info):
                                    info.append(source_display)

                        try:
                            dsize, isize = source_utils.file_size(size)
                        except:
                            dsize, isize = 0.0, ''

                        if isize:
                            info.insert(0, isize)

                        # Log pack info in devmode
                        if c.devmode and i < 3:  # Log first 3 items
                            c.log(f"[Orion] Episode #{i}: quality={quality}, info={info}, pack={pack}")

                        source_dict = {
                            'provider': 'Orion',
                            'source': 'Torrent',
                            'quality': quality,
                            'language': 'en',
                            'url': url,
                            'info': ' | '.join(info) if isinstance(info, list) else info,
                            'direct': False,
                            'debridonly': True,
                            'size': dsize,
                            'name': display_name  # Use path if available for better context
                        }

                        # Add pack metadata if present
                        if pack:
                            source_dict['package'] = pack  # 'season' or 'show'

                        sources.append(source_dict)
                    except Exception as item_error:
                        c.log(f"[Orion] Error processing episode item {i}: {item_error}")
                        import traceback
                        c.log(f"[Orion] Traceback: {traceback.format_exc()}")
                        continue

                c.log(f"[Orion] Returned {len(sources)} episode sources")
                return sources

        except Exception as e:

            failure = traceback.format_exc()
            c.log(f'[CM Debug @ 252 in orion_api.py] Traceback:: {failure}')
            c.log(f'[CM Debug @ 253 in orion_api.py] Exception raised. Error = {e}')
            return []





    def authorize_orion(self):
        """Show Orion login dialog for user to enter credentials (API key, username/password)."""
        try:
            orion = Orion(self.appkey)
            # userLogin() shows the login dialog where users can enter their API key or credentials
            result = orion.userLogin()
            c.log(f"[CM Debug @ 193 in orion_api.py] Orion login result = {result}")
            return result
        except Exception as e:
            c.log(f"[CM Debug @ 196 in orion_api.py] Error during Orion authorization: {e}")
            return False

    def settings_orion(self):
        """Open Orion's full settings dialog."""
        try:
            orion = Orion(self.appkey)
            orion.settingsLaunch()
            c.log("[CM Debug @ 203 in orion_api.py] Opened Orion settings")
        except Exception as e:
            c.log(f"[CM Debug @ 205 in orion_api.py] Error opening Orion settings: {e}")

    def settings_orion_filters(self):
        """Open Orion's filter settings dialog specifically."""
        try:
            orion = Orion(self.appkey)
            orion.settingsFilters()
            c.log("[CM Debug @ 212 in orion_api.py] Opened Orion filter settings")
        except Exception as e:
            c.log(f"[CM Debug @ 214 in orion_api.py] Error opening Orion filter settings: {e}")

    def user_info_orion(self):
        """Show Orion user account information dialog."""
        try:
            orion = Orion(self.appkey)
            # userDialog() shows account info (username, package, expiration, usage stats)
            orion.userDialog()
            c.log("[CM Debug @ 222 in orion_api.py] Showed Orion user info dialog")
        except Exception as e:
            c.log(f"[CM Debug @ 224 in orion_api.py] Error showing Orion user info: {e}")

    def info_orion(self):
        """Get Orion info for a test movie."""
        results = self.get_movie('tt5519340')
        c.log(f"[CM Debug @ 208 in orion_api.py] results = {results}")

    @classmethod
    def auth_orion(cls):
        """
        Authenticate with Orion - shows login dialog.
        This is a classmethod to match the pattern of other auth methods.
        """
        try:
            orion = Orion(keys.orion_key)

            # Show the Orion login dialog where users can enter their API key or credentials
            result = orion.userLogin()

            if result:
                c.log("[CM Debug @ 221 in orion_api.py] Orion authentication successful")
                control.infoDialog("Orion authentication successful", icon='INFO')
            else:
                c.log("[CM Debug @ 224 in orion_api.py] Orion authentication failed or cancelled")

            return result
        except Exception as e:

            failure = traceback.format_exc()
            c.log(f'[CM Debug @ 230 in orion_api.py] Traceback:: {failure}')
            c.log(f'[CM Debug @ 231 in orion_api.py] Exception raised. Error = {e}')
            control.infoDialog("Orion authentication failed", icon='ERROR')
            return False





oa = orionApi()
####################################################################################################


def window():
    file = 'LogViewer_QR.xml'
    path = c.artwork_path
    skin = c.appearance()
    resolution = '1080i'
    return xbmcgui.WindowXMLDialog(file, path, skin, resolution)

def get_orion_qr():
    try:
        #r = open(CHANGELOG_FILE)
        #text = r.read()
        header = "authenticate orion"
        url = "https%3A%2F%2Ftrakt.tv%2Factivate%2FECFABC3" # test for now
        size = "260"
        text = "for now just some text"
        qr_code = f"https://api.qrserver.com/v1/create-qr-code/?data={url}&size={size}x{size}"
        c.log(f"[CM Debug @ 56 in orion_api.py] qr_code = {qr_code}")
        #view_orion_qr(window(),header, str(text), qr_code)
        # Call the function to show the dialog
        show_custom_dialog()
    except Exception as e:

        failure = traceback.format_exc()
        c.log(f'[CM Debug @ 58 in orion_api.py]Traceback:: {failure}')
        c.log(f'[CM Debug @ 58 in orion_api.py]Exception raised. Error = {e}')
        pass





def view_orion_qr(xml, header, message, qr_code) -> None:
    class orionQRViewer(xbmcgui.WindowXMLDialog):
        def __init__(self, xml, header, message, qr_code):
            if not header or not message or not qr_code:
                c.log(f"[CM Debug @ 66 in orion_api.py] One of the parameters passed to orion_qr_viewer is empty/None. Skipping this.")
                return
            super().__init__()
            self.initialize(self)
            self.header = header
            self.message = message
            self.qr_code = qr_code
            self.xml = xml

        def initialize(self):
            #key id's
            self.KEY_NAV_ENTER = 7
            self.KEY_NAV_ESC = 10
            self.KEY_NAV_BACK = 92

            self.KEY_NAV_MOVEUP = 3
            self.KEY_NAV_MOVEDOWN = 4
            self.KEY_NAV_PAGEUP = 5
            self.KEY_NAV_PAGEDOWN = 6

            #xml id's
            self.HEADERLABEL = 101
            self.TEXT = 502
            self.QR_IMAGE = 501
            self.CLOSEBUTTON = 503

            self.TITLE = '[B]' + c.module_addon + ' v.' + c.moduleversion + '[/B]'


        def onInit(self):
            HEADERTITLE = self.TITLE if header == '' else header
            self.getControl(self.HEADERLABEL).setLabel(HEADERTITLE)
            self.getControl(self.TEXT).setText(message)
            self.getControl(self.QR_IMAGE).setImage(qr_code)

        def onAction(self, action):
            try:
                actionID = action.getId()
            except:
                c.log(f"[CM Debug @ 94 in orion_api.py] Exception raised. Error = {action}")
                return

            if actionID in[self.KEY_NAV_BACK, self.KEY_NAV_ENTER, self.KEY_NAV_ESC]:
                self.close()

            if actionID in [self.KEY_NAV_MOVEUP, self.KEY_NAV_PAGEUP]:
                self.getControl(self.TEXT).scroll(1)

            if actionID in [self.KEY_NAV_MOVEDOWN, self.KEY_NAV_PAGEDOWN]:
                self.getControl(self.TEXT).scroll(-1)

        def onClick(self, controlId):
            try:
                if controlId == self.CLOSEBUTTON:
                    self.close()
            except:
                c.log(f"[CM Debug @ 110 in orion_api.py] Exception raised. Error = {controlId}")
                pass




    try:
        d = orionQRViewer(header, message, qr_code)
        d.doModal()
        del d
    except Exception as e:

        failure = traceback.format_exc()
        c.log(f'[CM Debug @ 138 in orion_api.py]Traceback:: {failure}')
        c.log(f'[CM Debug @ 138 in orion_api.py]Exception raised. Error = {e}')
        pass
















class CustomDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # Initialize necessary variables for the dialog
        self.label = None
        self.title = None
        self.background = None
        self.qr_code = None

    def onInit(self):
        # Called when the dialog is initialized (window is loaded)
        self.background_id = 100
        self.header_id = 101
        self.qr_code_id = 501
        self.qr_code_text_id = 502
        self.button_id = 503

        self.set_title("Default Title")
        self.set_label("Default Label")
        self.set_background("logviewer_bg.png")
        c.log(f"[CM Debug @ 192 in orion_api.py] inside onInit method, Title = {self.title}")

    def onAction(self, action):
        """Handle all keystrokes."""
        if action is None:
            return

        keycode = action.getId()
        c.log(f"[CM Debug @ 210 in orion_api.py] keycode {keycode} of type {type(keycode)} pressed")

        if keycode == xbmcgui.ACTION_NAV_BACK:
            # Example: Close the dialog if the back button is pressed
            self.close()
        elif keycode == xbmcgui.ACTION_SELECT_ITEM:
            # Handle the select button (Enter key) if needed
            c.log("Select key pressed.")
        elif keycode == xbmcgui.ACTION_MOVE_UP:
            # Handle up movement
            c.log("Up key pressed.")
        elif keycode == xbmcgui.ACTION_MOVE_DOWN:
            # Handle down movement
            c.log("Down key pressed.")
        else:
            if keycode != "107":
                c.log(f"Keycode {keycode} pressed.")

    def set_label(self, text):
        """Set the text for the label in the dialog."""
        if self.label:
            self.label.setLabel(text)
        else:
            c.log("Label not found!")

    def set_title(self, title):
        """Set the title for the dialog."""
        if title:
            self.getLabel(self.header_id).setLabel(title)
        else:
            c.log("Title not found!")

    def set_background(self, background_image):
        """Set the background image."""
        if self.background:
            self.getLabel(self.background_id).setImage(background_image)
        else:
            c.log("Background image not found!")

    def load_custom_elements(self):
        """Load the custom elements from the XML (e.g., label, title, background)."""
        # Example: Assuming the label is a control named 'label' in the XML  # Example control ID for the label
        try:
            self.title = self.getControl(101)  # Example control ID for the title
            self.background = self.getControl("100")
            self.qr_code = self.getControl("501")  # Example control ID for the background image
            self.qr_txt = self.getControl("502")  # Example control ID for the background image
            self.button = self.getControl("503")  # Example control ID for the background image
        except Exception as e:

            failure = traceback.format_exc()
            c.log(f'[CM Debug @ 250 in orion_api.py]Traceback:: {failure}')
            c.log(f'[CM Debug @ 250 in orion_api.py]Exception raised. Error = {e}')
            pass

# Function to create and show the dialog
def show_custom_dialog(*args, **kwargs):
    # Path to your custom XML file. Make sure to replace this with your actual file path.
    try:
        xml_path = "LogViewer_QR.xml"  # Replace with your actual path

        # Path to the skin directory (required for non-standard XML files)
        #skin_path = xbmcvfs.translatePath("special://skin/")

        skin_path = c.artwork_path # Using Kodi's special path for skin location
        temp = c.get_artwork_path()
        c.log(f"[CM Debug @ 256 in orion_api.py] temp = {temp}")

        skin_path = temp +  "resources/skins/thecrew/1080i/"

        c.log(f"[CM Debug @ 258 in orion_api.py] path = {skin_path}")

        # Create an instance of the custom dialog class
        #dialog = CustomDialog(xml_path, skin_path, "default", "1080i")
        ARTADDON_PATH = xbmcaddon.Addon('script.thecrew.artwork').getAddonInfo('path')
        dialog = CustomDialog('LogViewer_QR.xml', ARTADDON_PATH, c.appearance(), '1080i')



        # Load custom elements (like label, title, background)
        #dialog.load_custom_elements()

        # Show the dialog
        dialog.doModal()

        # Cleanup after dialog is closed
        del dialog
    except Exception as e:
        c.log(f"Failed to load custom dialog: {str(e)}")

# Call the function to show the dialog
#show_custom_dialog()
