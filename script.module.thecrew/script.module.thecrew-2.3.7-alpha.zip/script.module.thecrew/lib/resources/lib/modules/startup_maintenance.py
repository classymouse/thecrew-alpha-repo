# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file startup_maintenance.py
* @package script.module.thecrew
*
* @copyright (c) 2026, The Crew
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*
Comprehensive Startup Maintenance System
Runs on every Kodi startup to ensure addon health and readiness
'''

import json
import os
import time
import traceback
import sqlite3 as db
import xbmcaddon

from . import control
from .crewruntime import c
from . import http_client
from . import keys


class StartupMaintenance:
    """
    Comprehensive startup maintenance system for The Crew addon.

    Handles:
    - Database integrity checks
    - Version tracking and updates
    - Cache cleanup
    - Stale data removal
    - API configuration updates
    """

    def __init__(self):
        """Initialize maintenance system."""
        self.maintenance_log = []
        self.errors = []

    def log(self, message, level='INFO'):
        """Log maintenance message."""
        full_msg = f"[Startup Maintenance] {message}"
        c.log(full_msg)
        self.maintenance_log.append(f"{level}: {message}")

    def log_error(self, message, exception=None):
        """Log maintenance error."""
        self.log(message, 'ERROR')
        self.errors.append(message)
        if exception:
            c.log(f"[Startup Maintenance] Exception: {exception}")
            c.log(f"[Startup Maintenance] Traceback: {traceback.format_exc()}")

    def run_all(self):
        """Run all maintenance tasks."""
        self.log("========================================")
        self.log("Starting comprehensive maintenance check")
        self.log("========================================")

        start_time = time.time()

        # Run maintenance tasks in order
        tasks = [
            ('Database Schema', self._ensure_database_schemas),
            ('Stale Sessions', self._clear_stale_sessions),
            ('TMDB Configuration', self._update_tmdb_config),
            ('Cache Cleanup', self._cleanup_old_caches),
            ('Version Tracking', self._track_versions),
            ('Database Integrity', self._check_database_integrity),
        ]

        for task_name, task_func in tasks:
            try:
                self.log(f"Running: {task_name}")
                task_func()
                self.log(f"✓ {task_name} completed")
            except Exception as e:
                self.log_error(f"✗ {task_name} failed: {e}", e)

        elapsed = time.time() - start_time
        self.log("========================================")
        self.log(f"Maintenance completed in {elapsed:.2f}s")
        if self.errors:
            self.log(f"Completed with {len(self.errors)} error(s)")
        else:
            self.log("All tasks completed successfully")
        self.log("========================================")

        # IMPORTANT: Show version announcement AFTER maintenance completes
        # This is done last so users see the eye-catching dialog after all startup tasks
        try:
            self._show_version_announcement_if_needed()
        except Exception as e:
            self.log_error(f"Version announcement failed: {e}", e)

        return len(self.errors) == 0

    def _ensure_database_schemas(self):
        """Ensure all database schemas are present."""
        try:
            # Database schemas are created on-demand by each module
            # Just verify key databases exist or can be created
            databases = [
                ('Settings DB', control.dbSettings),
                ('Meta DB', c.get_path('meta')),
            ]

            for db_name, db_path in databases:
                try:
                    # Ensure directory exists
                    db_dir = os.path.dirname(db_path)
                    if not os.path.exists(db_dir):
                        os.makedirs(db_dir)

                    # Touch the database to ensure it exists
                    if not os.path.exists(db_path):
                        dbcon = db.connect(db_path)
                        dbcon.close()
                        self.log(f"{db_name}: Created at {db_path}")
                    else:
                        self.log(f"{db_name}: Exists at {db_path}")

                except Exception as e:
                    self.log(f"{db_name}: Could not verify - {e}")

        except Exception as e:
            self.log_error(f"Database schema check failed: {e}", e)

    def _clear_stale_sessions(self):
        """Clear stale TV Evening sessions from previous Kodi instances."""
        try:
            from . import tvevening_playlist_db
            from . import tvevening_recovery

            # Check for stale TV Evening sessions
            db = tvevening_playlist_db.get_playlist_db()
            playlist_size = db.get_playlist_size()
            monitor_active = control.window.getProperty('thecrew.tvevening.monitor.active')

            # If playlist exists but monitor not running = stale session
            if playlist_size > 0 and monitor_active != 'true':
                self.log(f"Found stale TV Evening session: {playlist_size} episodes")
                tvevening_recovery.clear_stale_session()
                self.log("Stale TV Evening session cleared")
            else:
                self.log("No stale TV Evening sessions detected")

        except Exception as e:
            # TV Evening might not be initialized yet, that's OK
            self.log(f"TV Evening check skipped: {e}")

    def _update_tmdb_config(self):
        """Update TMDB image configuration cache if stale (> 7 days old)."""
        try:
            days = 7
            diff_time = (86400 * days)

            tmdb_user = control.setting('tm.personal_user') or control.setting('tm.user')
            if not tmdb_user:
                tmdb_user = keys.tmdb_key

            settings_table = 'settings'
            control.makeFile(control.dataPath)
            dbcon = db.connect(control.dbSettings)
            dbcur = dbcon.cursor()

            now = int(time.time())

            # Create settings table with proper SQL syntax
            dbcur.execute(
                f"CREATE TABLE IF NOT EXISTS {settings_table} ("
                "id INTEGER, secure_base_url TEXT, backdrop_sizes TEXT, logo_sizes TEXT, "
                "poster_sizes TEXT, profile_sizes TEXT, still_sizes TEXT, added TEXT, "
                "UNIQUE(id))"
            )

            # Check if TMDB config cache is stale (> 7 days old)
            dbcur.execute(f"SELECT * FROM {settings_table} WHERE added < ? AND id = 1", (now - diff_time,))
            row = dbcur.fetchone()

            if row is None:
                self.log("TMDB config cache is stale, fetching fresh data...")

                # Fetch fresh TMDB configuration
                url = f"https://api.themoviedb.org/3/configuration?api_key={tmdb_user}"
                result = http_client.tmdb_get_json(url, timeout=16) or {}

                images = result.get('images', {})
                s_base_url = images.get('secure_base_url', '')
                b_sizes = images.get('backdrop_sizes', [])
                b_sizes = b_sizes[-4:] if len(b_sizes) >= 4 else b_sizes
                l_sizes = images.get('logo_sizes', [])
                l_sizes = l_sizes[-4:] if len(l_sizes) >= 4 else l_sizes
                p_sizes = images.get('poster_sizes', [])
                p_sizes = p_sizes[-4:] if len(p_sizes) >= 4 else p_sizes
                pr_sizes = images.get('profile_sizes', [])
                pr_sizes = pr_sizes[-4:] if len(pr_sizes) >= 4 else pr_sizes
                s_sizes = images.get('still_sizes', [])
                s_sizes = s_sizes[-4:] if len(s_sizes) >= 4 else s_sizes

                # Store TMDB configuration with parameterized query
                dbcur.execute(
                    f"INSERT OR REPLACE INTO {settings_table} "
                    "(id, secure_base_url, backdrop_sizes, logo_sizes, poster_sizes, profile_sizes, still_sizes, added) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    (1, s_base_url, json.dumps(b_sizes), json.dumps(l_sizes), json.dumps(p_sizes),
                     json.dumps(pr_sizes), json.dumps(s_sizes), now)
                )

                # Store user's fanart quality preference
                fanart_quality = control.setting('fanart.quality')
                if fanart_quality and fanart_quality.isdigit():
                    quality_idx = int(fanart_quality)
                    dbcur.execute(
                        f"INSERT OR REPLACE INTO {settings_table} "
                        "(id, secure_base_url, backdrop_sizes, logo_sizes, poster_sizes, profile_sizes, still_sizes, added) "
                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                        (2, fanart_quality,
                         b_sizes[quality_idx] if quality_idx < len(b_sizes) else '',
                         l_sizes[quality_idx] if quality_idx < len(l_sizes) else '',
                         p_sizes[quality_idx] if quality_idx < len(p_sizes) else '',
                         pr_sizes[quality_idx] if quality_idx < len(pr_sizes) else '',
                         s_sizes[quality_idx] if quality_idx < len(s_sizes) else '',
                         now)
                    )

                self.log("TMDB configuration updated successfully")
            else:
                self.log("TMDB config cache is current (< 7 days old)")

            dbcon.commit()
            dbcon.close()

        except Exception as e:
            self.log_error(f"TMDB config update failed: {e}", e)

    def _cleanup_old_caches(self):
        """Clean up old cache files and temporary data."""
        try:
            cache_dir = control.cacheFile
            if not os.path.exists(cache_dir):
                self.log("Cache directory doesn't exist, skipping cleanup")
                return

            # Clean up old subtitle files (older than 1 day)
            try:
                now = time.time()
                one_day = 86400
                removed_count = 0

                for filename in os.listdir(cache_dir):
                    if filename.startswith('TemporarySubs') and filename.endswith('.srt'):
                        filepath = os.path.join(cache_dir, filename)
                        if os.path.isfile(filepath):
                            file_age = now - os.path.getmtime(filepath)
                            if file_age > one_day:
                                os.remove(filepath)
                                removed_count += 1

                if removed_count > 0:
                    self.log(f"Removed {removed_count} old subtitle cache file(s)")
                else:
                    self.log("No old cache files to remove")

            except Exception as e:
                self.log(f"Cache cleanup warning: {e}")

        except Exception as e:
            self.log_error(f"Cache cleanup failed: {e}", e)

    def _track_versions(self):
        """Track current addon versions for monitoring."""
        try:
            module_version = xbmcaddon.Addon('script.module.thecrew').getAddonInfo('version')
            plugin_version = xbmcaddon.Addon('plugin.video.thecrew').getAddonInfo('version')

            # Store in settings for reference
            xbmcaddon.Addon('plugin.video.thecrew').setSetting('module_base', module_version)
            xbmcaddon.Addon('plugin.video.thecrew').setSetting('plugin_base', plugin_version)

            self.log(f"Plugin version: {plugin_version}")
            self.log(f"Module version: {module_version}")

        except Exception as e:
            self.log_error(f"Version tracking failed: {e}", e)

    def _check_database_integrity(self):
        """Run basic database integrity checks."""
        try:
            # Check main databases exist and are accessible
            databases = [
                ('Settings DB', control.dbSettings),
                ('Meta DB', c.get_path('meta')),
                ('Bookmarks DB', control.bookmarksFile),
            ]

            for db_name, db_path in databases:
                if os.path.exists(db_path):
                    # Try to open and query the database
                    try:
                        dbcon = db.connect(db_path)
                        dbcur = dbcon.cursor()
                        dbcur.execute("SELECT name FROM sqlite_master WHERE type='table'")
                        tables = dbcur.fetchall()
                        dbcon.close()
                        self.log(f"{db_name}: OK ({len(tables)} tables)")
                    except Exception as e:
                        self.log(f"{db_name}: Warning - {e}")
                else:
                    self.log(f"{db_name}: Not yet created")

        except Exception as e:
            self.log_error(f"Database integrity check failed: {e}", e)

    def _show_version_announcement_if_needed(self):
        """
        Show eye-catching version announcement dialog if needed.

        Shows for:
        - New versions (once per version)
        - Alpha versions (once per Kodi session)
        """
        try:
            from . import version_announcement

            self.log("Checking if version announcement should be shown...")
            was_shown = version_announcement.check_and_show_version_announcement()

            if was_shown:
                self.log("Version announcement dialog was shown to user")
            else:
                self.log("No version announcement needed")

        except Exception as e:
            # Don't fail maintenance if announcement has issues
            self.log(f"Version announcement check skipped: {e}")


def run_startup_maintenance():
    """
    Main entry point for startup maintenance.
    Call this from service.py on Kodi startup.

    Returns:
        bool: True if all maintenance tasks succeeded, False otherwise
    """
    try:
        maintenance = StartupMaintenance()
        return maintenance.run_all()
    except Exception as e:
        c.log(f"[Startup Maintenance] CRITICAL ERROR: {e}")
        c.log(f"[Startup Maintenance] Traceback: {traceback.format_exc()}")
        return False


# Backwards compatibility - keep existing function name
def startupMaintenance():
    """Legacy function name for backwards compatibility."""
    return run_startup_maintenance()
