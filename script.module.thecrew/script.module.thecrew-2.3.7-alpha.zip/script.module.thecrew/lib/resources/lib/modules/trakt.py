# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file trakt.py
* @package script.module.thecrew
*
* @copyright (c) 2026, The Crew
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*
'''

import re
import os
import time
import json
from datetime import datetime, timedelta
from typing import Dict, Any
import traceback

from urllib.parse import urljoin, quote_plus
import sqlite3 as database
from sqlite3 import OperationalError


import requests

from requests.adapters import HTTPAdapter
# from requests.structures import CaseInsensitiveDict
from urllib3.util.retry import Retry

from . import cache
from . import cleandate
from . import client
from . import control
from . import utils
from . import crew_errors
from . import http_client
from .crewruntime import c

trakt_endpoints = {
    'settings': {

    },
    'shows': {

    },
    'movies': {
    }

}

trakt_response_codes = {
    '200': 'Success',
    '201': 'Success - new resource created (POST)',
    '204': 'Success - no content to return (DELETE)',
    '400': 'Bad Request - request couldn\'t be parsed',
    '401': 'Unauthorized - OAuth must be provided',
    '403': 'Forbidden - invalid API key or unapproved app',
    '404': 'Not Found - method exists but no record found',
    '405': 'Method Not Found - method doesn\'t exist',
    '409': 'Conflict - resource already created',
    '412': 'Precondition Failed - use application/json content type',
    '420': 'Account Limit Exceeded - list count, item count, etc',
    '422': 'Unprocessable Entity - validation errors',
    '423': 'Locked User Account - have the user contact support',
    '426': 'VIP Only - user must upgrade to VIP',
    '429': 'Rate Limit Exceeded',
    '500': 'Server Error - please open a support ticket',
    '502': 'Service Unavailable - server overloaded (try again in 30s)',
    '503': 'Service Unavailable - server overloaded (try again in 30s)',
    '504': 'Service Unavailable - server overloaded (try again in 30s)',
    '520': 'Service Unavailable - Cloudflare error',
    '521': 'Service Unavailable - Cloudflare error',
    '522': 'Service Unavailable - Cloudflare error',
}

BASE_URL = 'https://api.trakt.tv/'
CLIENT_ID = '482f9db52ee2611099ce3aa1abf9b0f7ed893c6d3c6b5face95164eac7b01f71'
CLIENT_SECRET = '80a2729728b53ba1cc38137b22f21f34d590edd35454466c4b8920956513d967'
REDIRECT_URI = 'urn:ietf:wg:oauth:2.0:oob'
TRAKTUSER = c.get_setting('trakt.user').strip()
# Adopt a helpful User-Agent for Trakt API requests (recommended by docs)
try:
    USER_AGENT = f"{control.addonInfo('id')}/{control.addonInfo('version')}"
except Exception:
    USER_AGENT = 'script.module.thecrew/unknown'

# Use shared HTTP client with connection pooling and retry logic
session = http_client.get_trakt_session()

def get_trakt(url, post=None, conditional_headers=None):
    """
    Make a request to the Trakt API with automatic token refresh.
    Accepts optional conditional headers (If-None-Match / If-Modified-Since).
    Returns a tuple (text, headers, status_code) for caller convenience.
    """
    try:
        # Check if token needs refresh before making request
        check_and_refresh_token()
        return _handle_the_request(url, post, conditional_headers)
    except Exception as e:
        c.log(f'get_trakt error: {e}')


def check_and_refresh_token():
    """
    Check if access token is expired or about to expire, and refresh if needed.
    Refreshes proactively when less than 1 hour remains.
    """
    try:
        # Check if another thread is already refreshing - wait for it to finish
        max_wait = 30  # seconds
        wait_count = 0
        while control.window.getProperty('thecrew.trakt_refreshing_token') == 'true':
            if wait_count >= max_wait:
                c.log('[Trakt] Timeout waiting for token refresh by another thread', 1)
                return
            time.sleep(0.25)
            wait_count += 0.25

        # If we waited, another thread refreshed - reload and check again
        if wait_count > 0:
            c.log(f'[Trakt] Waited {wait_count}s for token refresh by another thread')
            # Re-check if still need refresh after wait
            expires_at_str = c.get_setting('trakt.expires_at')
            if expires_at_str:
                expires_at = int(expires_at_str)
                time_remaining = int(time.time()) - expires_at
                if time_remaining >= 3600:
                    c.log(f'[Trakt] Token refreshed by other thread, now valid for {time_remaining/3600:.1f} hours')
                    return

        if not get_trakt_credentials_info():
            return  # No token to refresh

        expires_at_str = c.get_setting('trakt.expires_at')
        if not expires_at_str:
            # No expiration data, token might be from old version
            # Let it fail naturally and refresh on 401
            return

        expires_at = int(expires_at_str)
        current_time = int(time.time())
        time_remaining = expires_at - current_time

        # Refresh if less than 1 hour remains (3600 seconds)
        if time_remaining < 3600:
            c.log(f'[Trakt] Token expires in {time_remaining}s, refreshing proactively')

            # Set property to prevent other threads from refreshing simultaneously
            control.window.setProperty('thecrew.trakt_refreshing_token', 'true')
            try:
                headers = {
                    'Content-Type': 'application/json',
                    'trakt-api-key': CLIENT_ID,
                    'trakt-api-version': '2',
                    'Authorization': f'Bearer {c.get_setting("trakt.token")}'
                }
                token_refresh(headers, None, None)
            finally:
                # Always clear the property, even if refresh fails
                control.window.clearProperty('thecrew.trakt_refreshing_token')
        else:
            c.log(f'[Trakt] Token valid for {time_remaining/3600:.1f} hours')

    except Exception as e:
        c.log(f'[Trakt] Exception in check_and_refresh_token: {e}')
        # Clear property in case of exception
        try:
            control.window.clearProperty('thecrew.trakt_refreshing_token')
        except:
            pass
        # Continue anyway, let reactive 401 handling catch issues


def _handle_the_request(url, post, conditional_headers=None):
    """Perform a Trakt API request and handle retries on token refresh."""
    # Normalize URL - if not absolute, use BASE_URL
    if not url.startswith('http'):
        url = urljoin(BASE_URL, url)

    # Use json= where possible so requests sets content-type and encodes safely
    payload = post if post else None

    headers = {
        'Content-Type': 'application/json',
        'trakt-api-key': CLIENT_ID,
        'trakt-api-version': '2',
        'User-Agent': USER_AGENT,
    }

    # OAuth endpoints don't use Authorization header (they use client_id/secret in body)
    is_oauth_endpoint = '/oauth/' in url
    if not is_oauth_endpoint and get_trakt_credentials_info():
        headers['Authorization'] = f'Bearer {c.get_setting("trakt.token")}'

    # Debug logging for OAuth requests
    if is_oauth_endpoint:
        c.log(f'[Trakt OAuth] Request to {url}')
        c.log(f'[Trakt OAuth] Headers: {list(headers.keys())}')
        if payload:
            # Don't log secrets, just structure
            c.log(f'[Trakt OAuth] Payload keys: {list(payload.keys()) if isinstance(payload, dict) else type(payload)}')

    # Add conditional request headers (If-Modified-Since, If-None-Match)
    if conditional_headers:
        headers.update(conditional_headers)

    # Try the request; if token refresh happens, retry once
    retried = False
    while True:
        try:
            if payload is not None:
                response = session.post(url, json=payload, headers=headers, timeout=30)
            else:
                response = session.get(url, headers=headers, timeout=30)
        except Exception as e:
            c.log(f"[Trakt] Network exception when requesting {url}: {e}")
            raise

        response.encoding = 'utf-8'
        status_code = response.status_code

        # Debug logging for OAuth responses
        if '/oauth/' in url:
            c.log(f'[Trakt OAuth] Response status: {status_code}')
            c.log(f'[Trakt OAuth] Response length: {len(response.text) if response.text else 0} bytes')
            if response.text and len(response.text) < 500:
                c.log(f'[Trakt OAuth] Response body: {response.text}')

        # If not 2xx, let the message handler decide whether a retry is appropriate
        if not status_code or not str(status_code).startswith('2'):
            should_retry = msg_handler(url, response, str(status_code), payload, headers)
            if should_retry and not retried:
                retried = True
                # Update Authorization header if token was rotated in msg_handler/token_refresh
                # But skip for OAuth endpoints
                if not is_oauth_endpoint and get_trakt_credentials_info():
                    headers['Authorization'] = f'Bearer {c.get_setting("trakt.token")}'
                # loop to retry once
                continue
        # Return raw text, headers and status for caller convenience
        return response.text, response.headers, status_code


def msg_handler(url, response, status_code, post, headers) -> bool:
    """Handle non-2xx responses. Return True when caller should retry the request once (e.g., after token refresh)."""
    # Default: do not retry
    if status_code in ['401', '403']:
        # Check if another thread is already refreshing - wait for it
        wait_count = 0
        max_wait = 30
        while control.window.getProperty('thecrew.trakt_refreshing_token') == 'true':
            if wait_count >= max_wait:
                c.log('[Trakt] Timeout waiting for reactive token refresh by another thread', 1)
                return False
            time.sleep(0.25)
            wait_count += 0.25

        # If we waited, another thread may have refreshed - retry with new token
        if wait_count > 0:
            c.log(f'[Trakt] Waited {wait_count}s for reactive token refresh, will retry request')
            headers['Authorization'] = f'Bearer {c.get_setting("trakt.token")}'
            return True

        # Try token refresh once (prevent infinite loop)
        control.window.setProperty('thecrew.trakt_refreshing_token', 'true')
        try:
            if token_refresh(headers, url, post):
                c.log('[Trakt] Token refreshed, original request should be retried by caller')
                return True
            else:
                c.log('[Trakt] Token refresh failed - authentication required', 1)
                if c.devmode:
                    control.infoDialog('Trakt authentication expired. Please re-authorize.', sound=True)
                return False
        finally:
            control.window.clearProperty('thecrew.trakt_refreshing_token')
    elif status_code == '405':
        c.log(f'[Trakt] Method Not Allowed (405) for {url}', 1)
        return False
    elif not response:
        # Only show dialog if authenticated (unexpected error) or in dev mode
        # When not authenticated, background Trakt requests fail silently to avoid spamming
        # Never show for 404 errors (expected when no watch history exists)
        if status_code != '404' and (get_trakt_credentials_info() or c.devmode):
            if c.devmode:
                control.infoDialog(f'Trakt Server didn\'t respond, {trakt_response_codes.get(status_code, "No status")} ', sound=False)
            else:
                control.infoDialog('The Trakt Server didn\'t respond', sound=True)
        return False
    elif status_code == '423':
        control.infoDialog(trakt_response_codes[status_code], sound=True)
        c.log(f"Trakt status = {trakt_response_codes[status_code]}")
        return False
    elif status_code == '429':
        if 'Retry-After' in headers:
            retry_time = headers['Retry-After']
            control.infoDialog(f'Trakt Rate Limit Reached, waiting for {retry_time} seconds', sound=False, time=2000)
            control.sleep((int(retry_time) + 1) * 1000)
            c.log(f"Trakt Rate Limit Reached, waiting for {retry_time} seconds\n{trakt_response_codes[status_code]}")
            # After waiting, caller may retry
            return True
        else:
            control.infoDialog('Trakt Rate Limit Reached (429)', sound=False)
        return False
    elif status_code == '422':
        # Validation errors - log the response body for debugging
        try:
            error_details = response.text if response else 'No response body'
            c.log(f"[Trakt] 422 Validation Error - {trakt_response_codes[status_code]}")
            c.log(f"[Trakt] Error details: {error_details}")
            if c.devmode:
                control.infoDialog(f'Trakt validation error: {error_details[:100]}', sound=False, time=3000)
        except Exception:
            c.log(f"[Trakt] {trakt_response_codes[status_code]}")
        return False
    elif status_code in ['404']:
        # 404 is expected for unwatched episodes/movies - don't show notification
        c.log(f"trakt status = {trakt_response_codes[status_code]}")
        return False
    elif status_code:
        c.log(f"trakt status = {trakt_response_codes[status_code]}")
        return False
    else:
        return False



def token_refresh(headers, url, post) -> bool:
    """
    Refresh the Trakt OAuth access token using the refresh token.

    Returns:
        bool: True if refresh successful, False otherwise
    """
    try:
        oauth = urljoin(BASE_URL, '/oauth/token')

        refresh_token = c.get_setting('trakt.refresh')
        if not refresh_token:
            c.log('[Trakt] No refresh token available', 1)
            return False

        opost = {
            'client_id': CLIENT_ID,
            'client_secret': CLIENT_SECRET,
            'redirect_uri': REDIRECT_URI,
            'grant_type': 'refresh_token',
            'refresh_token': refresh_token
        }

        # Use fresh headers for token refresh (don't include Authorization)
        refresh_headers = {
            'Content-Type': 'application/json',
            'trakt-api-key': CLIENT_ID,
            'trakt-api-version': '2',
            'User-Agent': USER_AGENT,
        }

        # Use json= for safer encoding
        raw_response = session.post(oauth, json=opost, headers=refresh_headers, timeout=30)

        # Check HTTP status first
        if raw_response.status_code == 401:
            c.log('[Trakt] Refresh token expired or invalid - user must re-authenticate', 1)
            # Clear invalid tokens
            c.set_setting('trakt.token', '')
            c.set_setting('trakt.refresh', '')
            return False

        if raw_response.status_code != 200:
            c.log(f'[Trakt] Token refresh failed with status {raw_response.status_code}', 1)
            return False

        response = raw_response.json()
        c.log(f"Token refresh response: {response}")

        # Check for error in response body
        if response and isinstance(response, dict) and 'error' in response:
            error_msg = response.get('error_description', response['error'])
            c.log(f'[Trakt] Token refresh error: {error_msg}', 1)
            return False

        # Validate required fields
        if not all(k in response for k in ['access_token', 'refresh_token', 'expires_in']):
            c.log('[Trakt] Token refresh response missing required fields', 1)
            return False

        # Save new tokens with expiration timestamp
        token = response['access_token']
        refresh = response['refresh_token']
        expires_in = int(response['expires_in'])  # Trakt now uses 86400 (1 day)

        # Calculate expiration timestamp (current time + expires_in)
        expiration_timestamp = int(time.time()) + expires_in

        c.set_setting('trakt.token', token)
        c.set_setting('trakt.refresh', refresh)
        c.set_setting('trakt.expires_at', str(expiration_timestamp))

        # Update Authorization header for retry if provided
        try:
            headers['Authorization'] = f'Bearer {token}'
        except Exception:
            pass

        c.log(f'[Trakt] Token refresh successful, expires in {expires_in}s ({expires_in/3600:.1f} hours)')
        return True

    except Exception as e:
        c.log(f'[Trakt] Exception in token_refresh: {e}', 1)
        return False

def getTraktAsJson(url, post=None):
    """Make a request to the Trakt API and return the response as a JSON object/list."""
    try:
        if isinstance(url, str):
            result = get_trakt(url, post) if post else get_trakt(url)
        else:
            return None

        if result:
            # _sort_list_by_header expects (body, headers) - support (body, headers, status) too
            if isinstance(result, tuple) and len(result) >= 2:
                return _sort_list_by_header(result[:2])
            return _sort_list_by_header(result)
        # Handle the case where get_trakt returns None
        c.log('getTraktAsJson Error: get_trakt returned None')
        return None
    except Exception as e:
        failure = traceback.format_exc()
        c.log(f'Traceback:: {failure}')
        c.log(f'getTraktAsJson exception: {e}')

def deleteTraktPlayback(playback_id):
    """
    Delete a playback progress item from Trakt.

    :param playback_id: The Trakt playback ID (resume_id) to delete
    :return: True if successful, False otherwise
    """
    try:
        if not playback_id:
            c.log('[Trakt] deleteTraktPlayback: No playback_id provided')
            return False

        if not get_trakt_credentials_info():
            c.log('[Trakt] deleteTraktPlayback: Not authenticated')
            return False

        check_and_refresh_token()

        url = urljoin(BASE_URL, f'/sync/playback/{playback_id}')

        headers = {
            'Content-Type': 'application/json',
            'trakt-api-key': CLIENT_ID,
            'trakt-api-version': '2',
            'User-Agent': USER_AGENT,
            'Authorization': f'Bearer {c.get_setting("trakt.token")}'
        }

        c.log(f'[Trakt] DELETE request to: {url}')
        response = session.delete(url, headers=headers, timeout=30)
        status_code = response.status_code

        c.log(f'[Trakt] DELETE playback response: {status_code}')

        # 204 = Success - no content to return (standard for DELETE)
        # 404 = Item not found (already deleted or never existed)
        if status_code in [204, 404]:
            c.log(f'[Trakt] Successfully deleted playback {playback_id}')
            return True
        else:
            c.log(f'[Trakt] Failed to delete playback {playback_id}: {status_code}')
            if response.text:
                c.log(f'[Trakt] Response: {response.text}')
            return False

    except Exception as e:
        c.log(f'[Trakt] Exception in deleteTraktPlayback: {e}')
        c.log(f'[Trakt] Traceback: {traceback.format_exc()}')
        return False


def _sort_list_by_header(result):
    resp, res_headers = result
    # Support empty or invalid responses gracefully
    try:
        # If response is a string, strip whitespace and abort early on empty body
        if isinstance(resp, str):
            s = resp.strip()
            if not s:
                c.log('[Trakt] Empty response body returned by Trakt API; returning None')
                return None
            resp = json.loads(s)
    except json.JSONDecodeError as e:
        c.log(f"[Trakt] Failed to decode JSON from Trakt response: {e}")
        return None
    except Exception as e:
        c.log(f"[Trakt] Unexpected error parsing Trakt response: {e}")
        return None

    if res_headers and isinstance(res_headers, dict) and 'X-Sort-By' in res_headers and 'X-Sort-How' in res_headers:
        resp = sort_list(res_headers['X-Sort-By'], res_headers['X-Sort-How'], resp)
    return resp
    #except Exception as e:
        #c.log('getTraktAsJson Error: ' + str(e))
        #pass







def generate_qr_code_local(data, size=280):
    """Generate QR code locally using segno library"""
    try:
        import os
        import tempfile
        from .segno import make as make_qr

        # Create temp directory if it doesn't exist
        temp_dir = os.path.join(tempfile.gettempdir(), 'thecrew_qr')
        os.makedirs(temp_dir, exist_ok=True)

        # Generate unique filename
        qr_filename = os.path.join(temp_dir, 'trakt_auth_qr.png')

        # Generate QR code
        c.log(f'[Trakt QR] Generating QR code for: {data}')
        qr = make_qr(data, error='H')  # High error correction

        # Calculate scale to get approximately desired size
        # QR codes are typically 21-177 modules depending on version
        # We want final size to be around 'size' pixels
        scale = max(1, size // 50)  # Reasonable scale factor

        # Save as PNG
        qr.save(qr_filename, scale=scale, border=2, dark='#000000', light='#FFFFFF')

        c.log(f'[Trakt QR] QR code saved to: {qr_filename}')
        return qr_filename
    except Exception as e:
        c.log(f'[Trakt QR] Failed to generate local QR code: {e}')
        import traceback
        c.log(f'[Trakt QR] Traceback: {traceback.format_exc()}')
        # Fallback to external API
        from urllib.parse import quote
        return f'https://api.qrserver.com/v1/create-qr-code/?data={quote(data)}&size={size}x{size}'


def show_trakt_qr_dialog(verification_url, user_code, qr_path, device_code, interval, expires_in):
    """Show QR code dialog for Trakt authentication with polling"""
    try:
        import xbmcgui
        import threading
        import time

        c.log(f'[Trakt QR] Starting QR dialog with polling')

        class TraktQRViewer(xbmcgui.WindowXMLDialog):
            def __init__(self, *args, **kwargs):
                c.log('[Trakt QR] TraktQRViewer.__init__ called')
                self.header = kwargs.get('header', 'Trakt Authentication')
                self.message = kwargs.get('message', '')
                self.qr_path = kwargs.get('qr_path', '')
                self.device_code = kwargs.get('device_code', '')
                self.interval = kwargs.get('interval', 1)
                self.expires_in = kwargs.get('expires_in', 600)
                self.authenticated = False
                self.access_token = None
                self.polling = True
                self.poll_thread = None

            def onInit(self):
                try:
                    c.log('[Trakt QR] onInit called')
                    # Control IDs from LogViewer_QR.xml
                    HEADERLABEL = 101
                    TEXT = 502
                    QR_IMAGE = 501
                    CLOSEBUTTON = 503

                    c.log(f'[Trakt QR] Setting header to: {self.header}')
                    self.getControl(HEADERLABEL).setLabel(self.header)

                    c.log(f'[Trakt QR] Setting message text (length: {len(self.message)})')
                    self.getControl(TEXT).setText(self.message)

                    c.log(f'[Trakt QR] Setting QR image: {self.qr_path}')
                    self.getControl(QR_IMAGE).setImage(self.qr_path)

                    # Set focus to close button
                    c.log('[Trakt QR] Setting focus to close button')
                    self.setFocusId(CLOSEBUTTON)

                    c.log('[Trakt QR] Controls set successfully')

                    # Start polling thread
                    self.poll_thread = threading.Thread(target=self._poll_for_token)
                    self.poll_thread.daemon = True
                    self.poll_thread.start()
                    c.log('[Trakt QR] Polling thread started')
                except Exception as e:
                    c.log(f'[Trakt QR] Failed to initialize: {e}')
                    import traceback
                    c.log(f'[Trakt QR] Traceback: {traceback.format_exc()}')

            def _poll_for_token(self):
                """Poll for token in background thread"""
                try:
                    start_time = time.time()
                    while self.polling and (time.time() - start_time) < self.expires_in:
                        time.sleep(self.interval)

                        try:
                            r = getTraktAsJson(
                                '/oauth/device/token',
                                {
                                    'client_id': CLIENT_ID,
                                    'client_secret': CLIENT_SECRET,
                                    'code': self.device_code
                                })

                            if r and isinstance(r, dict) and 'access_token' in r:
                                c.log('[Trakt QR] Authentication successful!')
                                self.authenticated = True
                                self.access_token = r
                                self.close()
                                return
                        except Exception as e:
                            # Expected during polling (400 error = pending)
                            pass

                    if self.polling:
                        c.log('[Trakt QR] Polling expired')
                        self.close()
                except Exception as e:
                    c.log(f'[Trakt QR] Polling error: {e}')

            def onAction(self, action):
                # Close on back/esc
                if action.getId() in [10, 92]:  # ACTION_NAV_BACK, ACTION_PREVIOUS_MENU
                    c.log('[Trakt QR] Dialog closed by user action')
                    self.polling = False
                    self.close()

            def onClick(self, controlId):
                if controlId == 503:  # Close button
                    c.log('[Trakt QR] Close button clicked')
                    self.polling = False
                    self.close()

        # Show dialog
        xml_file = 'LogViewer_QR.xml'
        addon_path = c.get_artwork_path()
        skin = c.appearance() or 'thecrew'

        message = (
            f'Scan QR code with your mobile device\n\n'
            f'OR manually visit:\n{verification_url}\n\n'
            f'And enter code: {user_code}\n\n'
            f'Waiting for authentication...'
        )

        c.log('[Trakt QR] Creating dialog instance')
        dialog = TraktQRViewer(
            xml_file,
            addon_path,
            skin,
            '1080i',
            header='Trakt Authentication',
            message=message,
            qr_path=qr_path,
            device_code=device_code,
            interval=interval,
            expires_in=expires_in
        )
        c.log('[Trakt QR] Showing dialog with doModal()')
        dialog.doModal()
        c.log('[Trakt QR] Dialog closed')

        # Return result
        authenticated = dialog.authenticated
        access_token = dialog.access_token
        dialog.polling = False
        del dialog

        return authenticated, access_token
    except Exception as e:
        c.log(f'[Trakt QR] Failed to show QR dialog: {e}')
        import traceback
        c.log(f'[Trakt QR] Traceback: {traceback.format_exc()}')
        return False, None


def auth_trakt():
    try:
        if get_trakt_credentials_info() is True:
            if control.yesnoDialog(
                f'{control.lang(32511)}[CR]{control.lang(32512)}',
                heading='Trakt',
            ):
                set_trakt_credentials('', '', '')
            return  # Changed from raise Exception()

        result = getTraktAsJson('/oauth/device/code', {'client_id': CLIENT_ID})
        c.log(f'auth_trakt result type: {type(result)}')
        if not result or not isinstance(result, dict) or 'device_code' not in result:
            c.log(f'[Trakt] Failed to get device code: {result}')
            control.infoDialog('Failed to connect to Trakt', sound=True)
            return

        verification_url = result.get('verification_url', 'https://trakt.tv/activate')
        user_code = result.get('user_code', '')
        expires_in = int(result.get('expires_in', 0))
        device_code = result.get('device_code', '')
        interval = result.get('interval', 1)

        # Generate QR code locally using segno
        activation_url = f'{verification_url}/{user_code}'
        c.log(f'[Trakt] Generating QR code for: {activation_url}')
        c.log(f'[Trakt] Verification URL: {verification_url}')
        c.log(f'[Trakt] User code: {user_code}')

        qr_filepath = generate_qr_code_local(activation_url, size=280)
        c.log(f'[Trakt] QR code path: {qr_filepath}')

        # Show QR dialog with polling (replaces progress dialog)
        authenticated, r = show_trakt_qr_dialog(
            verification_url,
            user_code,
            qr_filepath,
            device_code,
            interval,
            expires_in
        )

        if not authenticated or not r or not isinstance(r, dict) or 'access_token' not in r:
            c.log('[Trakt] Failed to get access token')
            control.infoDialog('Trakt authorization failed or timed out', sound=True)
            return

        token = r['access_token']
        refresh = r['refresh_token']
        expires_in = int(r.get('expires_in', 86400))  # Default to 1 day if missing

        # Calculate expiration timestamp
        expiration_timestamp = int(time.time()) + expires_in

        headers = {
                    'Content-Type': 'application/json',
                    'trakt-api-key': CLIENT_ID,
                    'trakt-api-version': 2,
                    'Authorization': f'Bearer {token}'
                }

        # Initialize user to empty string in case /users/me fails
        user = ''
        authed = ''

        # Save tokens FIRST so getTraktAsJson can use them
        set_trakt_credentials('', token, refresh, expiration_timestamp)

        # Now get username with the new token
        try:
            result = getTraktAsJson('/users/me')
            c.log(f'auth_trakt /users/me result type: {type(result)}')
            if result and isinstance(result, dict) and 'username' in result:
                user = result.get('username')
                authed = '' if user == '' else 'yes'
                # Update username
                c.set_setting('trakt.user', user)
        except Exception as e:
            c.log(f'[Trakt] Failed to get username: {e}')
            # Continue anyway with empty username

        control.infoDialog(f'Trakt authorized{": " + user if user else ""}', sound=True)
    except Exception as e:
        c.log(f'[Trakt] Authorization error: {e}')
        c.log(traceback.format_exc())
        control.openSettings('3.1')



def set_trakt_credentials(value, arg1, arg2, expires_at=None):
    c.set_setting('trakt.user', value)
    c.set_setting('trakt.token', arg1)
    c.set_setting('trakt.refresh', arg2)
    if expires_at:
        c.set_setting('trakt.expires_at', str(expires_at))

def get_trakt_credentials_info() -> bool:
    """Checks if Trakt credentials are set in the crew settings."""
    user = c.get_setting('trakt.user').strip()
    token = c.get_setting('trakt.token')
    refresh = c.get_setting('trakt.refresh')
    return user != '' and token != '' and refresh != ''

#cm - indicators
def getTraktIndicatorsInfo() -> bool:
    """
    Checks if Trakt indicators are set in the crew settings, using the alternative
    indicators setting if Trakt credentials are set.
    """
    indicator_setting = c.get_setting('indicators')
    alternative_indicator_setting = c.get_setting('indicators.alt')
    indicators = alternative_indicator_setting if get_trakt_credentials_info() else indicator_setting
    return indicators == '1'

def use_trakt_bookmarks() -> bool:
    if getTraktIndicatorsInfo():
        setting = c.get_setting('indicators.alt')
        return setting != '32314'
    return False

def get_trakt_addon_movie_info():
    """
    Check if Trakt is enabled and authorized in the Trakt addon.
    """
    if not c.addon_exists('script.trakt'):
        return False

    try:
        scrobble = control.addon('script.trakt').getSetting('scrobble_movie') or ''
        exclude_http = control.addon('script.trakt').getSetting('ExcludeHTTP') or ''
        authorization = control.addon('script.trakt').getSetting('authorization') or ''

    except Exception as e:
        c.log(f"Exception in get_trakt_addon_movie_info: {e}")
        return False


    return scrobble == 'true' and exclude_http == 'false' and authorization

def getTraktAddonEpisodeInfo():
    """
    Check if Trakt is enabled and authorized in the Trakt addon for episodes.
    """
    try:
        scrobble = control.addon('script.trakt').getSetting('scrobble_episode') == 'true'
        exclude_http = control.addon('script.trakt').getSetting('ExcludeHTTP') == 'false'
        authorization = control.addon('script.trakt').getSetting('authorization') != ''
    except LookupError:
        return False
    return scrobble and exclude_http and authorization

def manager(name: str, imdb: str, tmdb: str, content: str) -> None:
    """Opens a dialog to select a Trakt action to perform."""
    try:
        post = {"movies": [{"ids": {"imdb": imdb}}]} if content == "movie" else {"shows": [{"ids": {"tmdb": tmdb}}]}

        actions = [
            (control.lang(32516), "/sync/collection"),
            (control.lang(32517), "/sync/collection/remove"),
            (control.lang(32518), "/sync/watchlist"),
            (control.lang(32519), "/sync/watchlist/remove"),
            (control.lang(32520), "/users/me/lists/%s/items"),
        ]

        result = getTraktAsJson("/users/me/lists")
        if not result:
            return
        lists = [(i["name"], i["ids"]["slug"]) for i in result]
        lists = [lists[i // 2] for i in range(len(lists) * 2)]

        for i in range(0, len(lists), 2):
            lists[i] = ((control.lang(32521) % lists[i][0]), f"/users/me/lists/{lists[i][1]}/items")
        for i in range(1, len(lists), 2):
            lists[i] = ((control.lang(32522) % lists[i][0]), f"/users/me/lists/{lists[i][1]}/items/remove")
        actions += lists

        select = control.selectDialog([i[0] for i in actions], control.lang(32515))

        if select == -1:
            return

        if select == 4:
            t = control.lang(32520)
            k = control.keyboard("", t)
            k.doModal()

            new = k.getText() if k.isConfirmed() else None
            if new is None or new == "":
                return

            result = get_trakt("/users/me/lists", post={"name": new, "privacy": "private"})
            if result and isinstance(result, (list, tuple)):
                result = result[0]

            try:
                data = utils.json_loads_as_str(result)
                if isinstance(data, list) and data:
                    slug = data[0].get("ids", {}).get("slug")
                else:
                    slug = data.get("ids", {}).get("slug")
            except Exception:
                control.infoDialog(control.lang(32515), heading=name, sound=True, icon="ERROR")
                return

            result = get_trakt(actions[select][1] % slug, post=post)[0]
        else:
            result = get_trakt(actions[select][1], post=post)[0]

        icon = control.infoLabel("ListItem.Icon") if result is not None else "ERROR"
        control.infoDialog(control.lang(32515), heading=name, sound=True, icon=icon)
    except Exception as e:
        c.log(f"Exception in trakt manager: {e}")








def slug(title):
    """
    Convert a given title to a slug string.
    """
    if not isinstance(title, str):
        return ''
    title = title.strip().lower()
    title = re.sub('[^a-z0-9_]', '-', title)
    title = re.sub('-{2,}', '-', title)
    return title.rstrip('-')

def sort_list(sort_key, sort_direction, list_data) -> list:
    """
    Sort a list of trakt items based on the given key and direction.
    """
    reverse = sort_direction != 'asc'
    if sort_key == 'rank':
        return sorted(list_data, key=lambda x: x['rank'], reverse=reverse)
    elif sort_key == 'added':
        return sorted(list_data, key=lambda x: x['listed_at'], reverse=reverse)
    elif sort_key == 'title':
        return sorted(list_data, key=lambda x: utils.title_key(x[x['type']].get('title')), reverse=reverse)
    elif sort_key == 'released':
        return sorted(list_data, key=lambda x: released_key(x[x['type']]), reverse=reverse)
    elif sort_key == 'runtime':
        return sorted(list_data, key=lambda x: x[x['type']].get('runtime', 0), reverse=reverse)
    elif sort_key == 'popularity':
        return sorted(list_data, key=lambda x: x[x['type']].get('votes', 0), reverse=reverse)
    elif sort_key == 'percentage':
        return sorted(list_data, key=lambda x: x[x['type']].get('rating', 0), reverse=reverse)
    elif sort_key == 'votes':
        return sorted(list_data, key=lambda x: x[x['type']].get('votes', 0), reverse=reverse)
    else:
        return list_data

def released_key(item):
    """ Return the released or first_aired timestamp from a trakt item. """
    if 'released' in item:
        return item['released'] or '0'
    elif 'first_aired' in item:
        return item['first_aired'] or '0'
    else:
        return '0'

def _convert_and_get_latest_iso(values):
    """
    Convert a list of ISO timestamp-like values to integers (UTC) and return the latest value.
    Non-parseable values are treated as 0.
    """
    converted = []
    for v in values:
        try:
            if v is None:
                converted.append(0)
            else:
                converted.append(int(cleandate.new_iso_to_utc(v)))
        except ValueError:
            converted.append(0)
    return sorted(converted)[-1] if converted else 0


def getActivity() -> int:
    try:
        i = getTraktAsJson('/sync/last_activities')

        if i and isinstance(i, dict):
            movies = i.get('movies', {})
            episodes = i.get('episodes', {})
            shows = i.get('shows', {})
            seasons = i.get('seasons', {})
            lists = i.get('lists', {})

            activity_values = [
                movies.get('collected_at', 0),
                movies.get('watchlisted_at', 0),
                shows.get('watchlisted_at', 0),
                episodes.get('collected_at', 0),
                episodes.get('watchlisted_at', 0),
                seasons.get('watchlisted_at', 0),
                lists.get('updated_at', 0),
                lists.get('liked_at', 0),
            ]
            activity = _convert_and_get_latest_iso(activity_values)
        else:
            activity = 0

        c.log(f"trakt activity = {activity}")

        return activity
    except ValueError:
        return 0

# def getWatchedActivity():
#     try:
#         i = getTraktAsJson('/sync/last_activities')
def getWatchedActivity():
    """Return timestamp (ISO) of most recent watched activity from Trakt.

    Uses conditional ETag fetch to minimize server load. Cached for 60s.
    """
    try:
        # fetcher that performs conditional requests via get_trakt and returns (body, headers, status)
        def fetcher(conditional_headers=None):
            res = get_trakt('/sync/last_activities', conditional_headers=conditional_headers)
            if not res:
                return None
            # get_trakt returns (text, headers, status)
            return res

        i = cache.get_with_etag('trakt.last_activities', fetcher, ttl_seconds=60, namespace='trakt')

        c.log(f"getWatchedActivity returned: {i}")

        if not i or not isinstance(i, dict):
            return 0

        activity_values = [
            i.get('movies', {}).get('watched_at'),
            i.get('episodes', {}).get('watched_at'),
        ]
        activity = _convert_and_get_latest_iso(activity_values)

        return activity

    except Exception as e:
        failure = traceback.format_exc()
        c.log(f'Traceback:: {failure}')
        c.log(f'Exception raised in trakt handler: {e}')
        return 0
def get_queued_indicators_movies():
    """
    Get movie indicators from scrobble queue for items marked as watched (>92%).
    Returns list of IMDB IDs that are queued as watched but not yet synced to Trakt.
    """
    try:
        dbcon = get_connection(control.traktsyncFile)
        dbcur = get_connection_cursor(dbcon)

        if not table_exists('scrobble_queue'):
            dbcur.close()
            dbcon.close()
            return []

        # Get movies with progress >= 92% and action='stop' (marked as watched)
        dbcur.execute("SELECT DISTINCT imdb FROM scrobble_queue WHERE media_type='movie' AND progress >= 92 AND action='stop'")
        results = dbcur.fetchall()

        dbcur.close()
        dbcon.close()

        return [row[0] for row in results] if results else []
    except Exception as e:
        c.log(f'[Trakt] Error getting queued movie indicators: {e}')
        return []


def get_queued_indicators_episodes():
    """
    Get episode indicators from scrobble queue for items marked as watched (>92%).
    Returns dict mapping TMDB ID to list of (season, episode) tuples.
    """
    try:
        dbcon = get_connection(control.traktsyncFile)
        dbcur = get_connection_cursor(dbcon)

        if not table_exists('scrobble_queue'):
            dbcur.close()
            dbcon.close()
            return {}

        # Get episodes with progress >= 92% and action='stop' (marked as watched)
        dbcur.execute("SELECT imdb, season, episode FROM scrobble_queue WHERE media_type='episode' AND progress >= 92 AND action='stop'")
        results = dbcur.fetchall()

        dbcur.close()
        dbcon.close()

        # Group by show IMDB
        episodes_by_show = {}
        if results:
            for imdb, season, episode in results:
                if imdb not in episodes_by_show:
                    episodes_by_show[imdb] = []
                try:
                    episodes_by_show[imdb].append((int(season), int(episode)))
                except (ValueError, TypeError):
                    continue

        return episodes_by_show
    except Exception as e:
        c.log(f'[Trakt] Error getting queued episode indicators: {e}')
        return {}


def get_queued_progress(media_type, imdb, season='', episode=''):
    """
    Get progress for a specific item from the scrobble queue.
    Returns progress percentage if found in queue, None otherwise.
    This is used to show real-time resume points before queue is processed.
    """
    try:
        dbcon = get_connection(control.traktsyncFile)
        dbcur = get_connection_cursor(dbcon)

        if not table_exists('scrobble_queue'):
            dbcur.close()
            dbcon.close()
            return None

        if media_type == 'movie':
            dbcur.execute("SELECT progress FROM scrobble_queue WHERE media_type='movie' AND imdb=?", (imdb,))
        else:  # episode
            dbcur.execute("SELECT progress FROM scrobble_queue WHERE media_type='episode' AND imdb=? AND season=? AND episode=?",
                         (imdb, str(season), str(episode)))

        result = dbcur.fetchone()

        dbcur.close()
        dbcon.close()

        return result[0] if result else None
    except Exception as e:
        c.log(f'[Trakt] Error getting queued progress: {e}')
        return None


def cachesyncMovies(timeout=0):
    return cache.get(syncMovies, timeout, TRAKTUSER)

def timeoutsyncMovies():
    timeout = cache.timeout(syncMovies, TRAKTUSER)
    return timeout

def syncMovies(user):
    try:
        if get_trakt_credentials_info() is False:
            c.log('getTraktCredentialsInfo is false')
            return

        # Get watched movies from Trakt
        trakt_watched = []
        if indicators := getTraktAsJson('/users/me/watched/movies'):
            if indicators := [i['movie']['ids'] for i in indicators]:
                trakt_watched = [str(i['imdb']) for i in indicators if 'imdb' in i]

        # Merge with queued indicators (movies marked as watched locally but not yet synced)
        queued_watched = get_queued_indicators_movies()

        # Combine both lists (use set to avoid duplicates)
        if trakt_watched or queued_watched:
            combined = list(set(trakt_watched + queued_watched))
            c.log(f"[Trakt] Movie indicators: {len(trakt_watched)} from Trakt + {len(queued_watched)} queued = {len(combined)} total")
            return combined

        return []
    except Exception as e:
        c.log(f'Exception raised in trakt operation: {e}')


def cachesyncTVShows(timeout=0):
    return syncTVShows(0)


def timeoutsyncTVShows():
    timeout = cache.timeout(syncTVShows, TRAKTUSER) or 0
    return timeout

def syncTVShows(user):
    try:
        if not get_trakt_credentials_info():
            c.log('getTraktCredentialsInfo is false')
            return

        # Get watched shows from Trakt
        watched_shows = getTraktAsJson('/users/me/watched/shows?extended=full')
        indicators = [(show['show']['ids']['tmdb'], show['show']['aired_episodes'], [(s['number'], e['number']) for s in show['seasons'] for e in s['episodes']]) for show in watched_shows]
        indicators = [(str(tmdb_id), aired_episodes, watched_episodes) for tmdb_id, aired_episodes, watched_episodes in indicators]

        # Merge with queued episode indicators
        queued_episodes = get_queued_indicators_episodes()

        if queued_episodes:
            # Convert indicators to dict for easier merging
            indicators_dict = {tmdb_id: (aired_episodes, set(watched_episodes)) for tmdb_id, aired_episodes, watched_episodes in indicators}

            # For queued episodes, we need to look up TMDB ID from IMDB (requires additional data)
            # For now, add queued episodes to existing shows in indicators
            # Note: This is a simplified approach - full implementation would need IMDB->TMDB mapping
            for imdb, episodes in queued_episodes.items():
                # Find matching show in indicators (would need proper IMDB->TMDB lookup)
                # For now, log that we have queued episodes
                c.log(f"[Trakt] Found {len(episodes)} queued episodes for show {imdb}")

            # Convert back to list format
            indicators = [(tmdb_id, aired, list(watched)) for tmdb_id, (aired, watched) in indicators_dict.items()]

        return indicators
    except Exception as e:
        c.log(f"Exception raised: {e}")





def syncSeason(imdb):
    try:
        if get_trakt_credentials_info() is False:
            return
        indicators = getTraktAsJson(f'/shows/{imdb}/progress/watched?specials=false&hidden=false')
        indicators = indicators['seasons']
        indicators = [(i['number'], [x['completed'] for x in i['episodes']]) for i in indicators]
        #indicators = ['%01d' % int(i[0]) for i in indicators if False not in i[1]]
        indicators = [f"{int(i[0]):01d}" for i in indicators if False not in i[1]]
        return indicators
    except:
        pass


def syncTraktStatus(silent=False):
    try:
        cachesyncMovies()
        cachesyncTVShows()
        if not silent:
            control.infoDialog(control.lang(32092))
    except:
        control.infoDialog('Trakt sync failed')

##########################################
# Movies
##########################################
def markMovieAsWatched(key, media_id):
    try:
        if key == 'imdb' and not media_id.startswith('tt'):
            media_id = f'tt{media_id}'
        result = get_trakt('/sync/history', {"movies": [{"ids": {key: media_id}}]})
        if result:
            delete_progress_from_database(key, media_id)

        return result[0] if result else None
    except Exception:
        return None

def markMovieAsNotWatched(key, media_id):
    try:
        if key == 'imdb' and not media_id.startswith('tt'):
            media_id = f'tt{media_id}'
        result = get_trakt('/sync/history/remove', {"movies": [{"ids": {key: media_id}}]})
        return result[0] if result else None
    except Exception:
        return None



###########################################
# TV Shows
###########################################
def markTVShowAsNotWatched(key, media_id):
    try:
        result = get_trakt('/sync/history/remove', {"shows": [{"ids": {key: media_id}}]})
        return result[0] if result else None
    except Exception:
        return None

def markTVShowAsWatched(key, media_id):
    try:
        result = get_trakt('/sync/history/', {"shows": [{"ids": {key: media_id}}]})
        return result[0] if result else None
    except Exception:
        return None


def markTVShowAsWatched(key, media_id):
    try:
        result = get_trakt('/sync/history/', {"shows": [{"ids": {key: media_id}}]})
        return result[0] if result else None
    except Exception:
        return None


#############################################
# Seasons
#############################################
def markSeasonAsWatched(key, media_id, season):
    """
    Mark all episodes in a season as watched using a single batch API call.
    This prevents HTTP 429 (rate limiting) errors from individual episode calls.
    """
    c.log(f"[Trakt] Marking season {season} as watched for {key}={media_id}")
    try:
        # Get TMDB ID if we only have IMDB
        tmdb_id = media_id if key == 'tmdb' else None
        if key == 'imdb':
            # Look up TMDB ID from IMDB
            from ..indexers import episodes
            try:
                # Use TMDB's find endpoint to get TMDB ID from IMDB
                import requests
                from . import keys
                tmdb_user = c.get_setting('tm.personal_user') or c.get_setting('tm.user') or keys.tmdb_key
                url = f'https://api.themoviedb.org/3/find/{media_id}?api_key={tmdb_user}&external_source=imdb_id'
                r = requests.get(url, timeout=10)
                result = r.json()
                tv_results = result.get('tv_results', [])
                if tv_results:
                    tmdb_id = str(tv_results[0]['id'])
                    c.log(f"[Trakt] Converted IMDB {media_id} to TMDB {tmdb_id}")
            except Exception as e:
                c.log(f"[Trakt] Failed to convert IMDB to TMDB: {e}")

        if not tmdb_id:
            c.log(f"[Trakt] No TMDB ID available, falling back to season-only sync")
            result = getTraktAsJson('/sync/history', {"shows": [{"seasons": [{"number": int(season)}], "ids": {key: media_id}}]})
            return result

        # Get all episodes in this season from TMDB
        from . import keys
        tmdb_user = c.get_setting('tm.personal_user') or c.get_setting('tm.user') or keys.tmdb_key
        season_url = f'https://api.themoviedb.org/3/tv/{tmdb_id}/season/{season}?api_key={tmdb_user}'

        import requests
        r = requests.get(season_url, timeout=10)
        season_data = r.json()

        episodes_list = season_data.get('episodes', [])
        if not episodes_list:
            c.log(f"[Trakt] No episodes found for season {season}")
            return None

        # Build episodes array for batch sync (all episodes in one call)
        episode_numbers = [{"number": ep['episode_number']} for ep in episodes_list]

        c.log(f"[Trakt] Marking {len(episode_numbers)} episodes in season {season} as watched")

        # Single API call for entire season
        payload = {
            "shows": [{
                "seasons": [{
                    "number": int(season),
                    "episodes": episode_numbers
                }],
                "ids": {key: media_id}
            }]
        }

        result = getTraktAsJson('/sync/history', payload)
        c.log(f"[Trakt] Season {season} marked as watched successfully")
        return result

    except Exception as e:
        c.log(f"[Trakt] Exception in markSeasonAsWatched: {e}")
        c.log(f"[Trakt] Traceback: {traceback.format_exc()}")
        return None

def markSeasonAsNotWatched(key, media_id, season):
    """
    Mark all episodes in a season as unwatched using a single batch API call.
    This prevents HTTP 429 (rate limiting) errors from individual episode calls.
    """
    c.log(f"[Trakt] Marking season {season} as unwatched for {key}={media_id}")
    try:
        # Get TMDB ID if we only have IMDB
        tmdb_id = media_id if key == 'tmdb' else None
        if key == 'imdb':
            # Look up TMDB ID from IMDB
            try:
                import requests
                from . import keys
                tmdb_user = c.get_setting('tm.personal_user') or c.get_setting('tm.user') or keys.tmdb_key
                url = f'https://api.themoviedb.org/3/find/{media_id}?api_key={tmdb_user}&external_source=imdb_id'
                r = requests.get(url, timeout=10)
                result = r.json()
                tv_results = result.get('tv_results', [])
                if tv_results:
                    tmdb_id = str(tv_results[0]['id'])
                    c.log(f"[Trakt] Converted IMDB {media_id} to TMDB {tmdb_id}")
            except Exception as e:
                c.log(f"[Trakt] Failed to convert IMDB to TMDB: {e}")

        if not tmdb_id:
            c.log(f"[Trakt] No TMDB ID available, falling back to season-only sync")
            result = getTraktAsJson('/sync/history/remove', {"shows": [{"seasons": [{"number": int(season)}], "ids": {key: media_id}}]})
            c.log(f"[Trakt] Season-only unwatched result: {result}")
            return result

        # Get all episodes in this season from TMDB
        from . import keys
        tmdb_user = c.get_setting('tm.personal_user') or c.get_setting('tm.user') or keys.tmdb_key
        season_url = f'https://api.themoviedb.org/3/tv/{tmdb_id}/season/{season}?api_key={tmdb_user}'

        import requests
        r = requests.get(season_url, timeout=10)
        season_data = r.json()

        episodes_list = season_data.get('episodes', [])
        if not episodes_list:
            c.log(f"[Trakt] No episodes found for season {season}")
            return None

        # Build episodes array for batch sync
        episode_numbers = [{"number": ep['episode_number']} for ep in episodes_list]

        c.log(f"[Trakt] Marking {len(episode_numbers)} episodes in season {season} as unwatched")

        # Single API call for entire season
        payload = {
            "shows": [{
                "seasons": [{
                    "number": int(season),
                    "episodes": episode_numbers
                }],
                "ids": {key: media_id}
            }]
        }

        c.log(f"[Trakt] Unwatched payload: {payload}")
        result = getTraktAsJson('/sync/history/remove', payload)
        c.log(f"[Trakt] Season {season} unwatched result: {result}")
        c.log(f"[Trakt] Season {season} marked as unwatched successfully")
        return result

    except Exception as e:
        c.log(f"[Trakt] Exception in markSeasonAsNotWatched: {e}")
        c.log(f"[Trakt] Traceback: {traceback.format_exc()}")
        return None

#############################################
# Episodes
#############################################
def markEpisodeAsWatched(key, media_id, season, episode):
    season, episode = int('%01d' % int(season)), int('%01d' % int(episode))
    #season, episode = int(f'{season:01d}'), int(f'{episode:01d}')
    result = get_trakt('/sync/history', {"shows": [{"seasons": [{"episodes": [{"number": episode}], "number": season}], "ids": {key: media_id}}]})
    try:
        return result[0] if result else None
    except IndexError:
        # Handle the case when get_trakt returns None
        # For example, you can return a default value or raise an exception
        return None

def markEpisodeAsNotWatched(key, media_id, season, episode):
    season, episode = int('%01d' % int(season)), int('%01d' % int(episode))
    season, episode = int(f'{season:01d}'), int(f'{episode:01d}')
    result = get_trakt('/sync/history/remove', {"shows": [{"seasons": [{"episodes": [{"number": episode}], "number": season}], "ids": {key: media_id}}]})
    try:
        return result[0] if result else None
    except IndexError:
        # Handle the case when get_trakt returns None
        # For example, you can return a default value or raise an exception
        return None






##############################################
# Scrobble
##############################################
def queue_scrobble(media_type, imdb, watched_percent, action, season='', episode=''):
    """
    Queue a scrobble event instead of making immediate API call.
    This reduces API spam and allows batching.
    """
    try:
        if not imdb.startswith('tt'):
            imdb = 'tt' + imdb

        timestamp = get_now_in_iso()

        dbcon = get_connection(control.traktsyncFile)
        dbcur = get_connection_cursor(dbcon)

        # Ensure table exists
        if not table_exists('scrobble_queue'):
            dbcur.execute(sql_dict['sql_create_scrobble_queue'])
            dbcon.commit()

        # Queue the scrobble (replaces existing queue item for same content)
        sql = sql_dict['sql_insert_scrobble_queue']
        dbcur.execute(sql, (media_type, imdb, season, episode, watched_percent, action, timestamp))
        dbcon.commit()

        # Note: Do NOT update progress table here - bookmarks.reset() already handles it with correct seconds value
        # If we update here with percentage, it overwrites the correct seconds value from bookmarks.reset()

        dbcur.close()
        dbcon.close()

        c.log(f"[Trakt] Queued scrobble: {media_type} {imdb} s{season}e{episode} - {watched_percent}% ({action})")
        return True
    except Exception as e:
        c.log(f'[Trakt] Failed to queue scrobble: {e}')
        return False


def process_scrobble_queue(force=False):
    """
    Process queued scrobble events and send to Trakt.
    Called periodically (e.g., every 5 minutes) or on demand.
    """
    try:
        dbcon = get_connection(control.traktsyncFile)
        dbcur = get_connection_cursor(dbcon)

        if not table_exists('scrobble_queue'):
            dbcur.close()
            dbcon.close()
            return

        # Get all queued scrobbles
        dbcur.execute(sql_dict['sql_select_scrobble_queue'])
        queue_items = dbcur.fetchall()

        if not queue_items:
            dbcur.close()
            dbcon.close()
            return

        c.log(f"[Trakt] Processing {len(queue_items)} queued scrobble events")

        for item in queue_items:
            item_id, media_type, imdb, season, episode, progress, action = item

            try:
                # Round progress to 2 decimal places to avoid Trakt validation errors
                progress_rounded = round(float(progress), 2)

                # Make the actual API call
                if media_type == 'movie':
                    r = get_trakt(f'/scrobble/{action}', {"movie": {"ids": {"imdb": imdb}}, "progress": progress_rounded})
                    # Note: Do NOT update progress table here - bookmarks.reset() already set correct resume_point in seconds
                else:  # episode
                    r = get_trakt(f'/scrobble/{action}', {
                        "show": {"ids": {"imdb": imdb}},
                        "episode": {"season": int(season), "number": int(episode)},
                        "progress": progress_rounded
                    })

                # Remove from queue on success
                dbcur.execute(sql_dict['sql_delete_scrobble_item'], (item_id,))
                dbcon.commit()

                # Invalidate last activities cache so UI sees recent activity quickly
                try:
                    cache.cache_delete('trakt.last_activities', table='trakt')
                except Exception:
                    pass

                c.log(f"[Trakt] Processed scrobble: {media_type} {imdb} - {progress_rounded}% ({action})")

            except Exception as e:
                c.log(f'[Trakt] Failed to process scrobble {item_id}: {e}')
                # Keep in queue to retry later
                continue

        dbcur.close()
        dbcon.close()

    except Exception as e:
        c.log(f'[Trakt] Error processing scrobble queue: {e}')


def scrobbleMovie(imdb, watched_percent, action, use_queue=True):
    """
    Scrobble a movie to Trakt.
    By default, queues the scrobble for batch processing.
    Set use_queue=False for immediate API call.
    """
    try:
        if not imdb.startswith('tt'):
            imdb = 'tt' + imdb

        c.log(f"inside trakt.scrobbleMovie | imdb = {imdb} | watched_percent = {watched_percent} | action = {action} | use_queue = {use_queue}")

        # Round progress to 2 decimal places to avoid Trakt validation errors
        watched_percent = round(float(watched_percent), 2)

        # Queue by default, immediate only if use_queue=False
        if use_queue:
            return queue_scrobble('movie', imdb, watched_percent, action)
        else:
            r = get_trakt(f'/scrobble/{action}', {"movie": {"ids": {"imdb": imdb}}, "progress": watched_percent})
            # Note: Do NOT update progress table here - bookmarks.reset() already set correct resume_point in seconds
            c.log(f"scrobbleMovie response: {r}")
            return r
    except Exception as e:
        failure = traceback.format_exc()
        c.log(f'Traceback:: {failure}')
        c.log(f'Exception in scrobbleMovie: {e}')
        pass


def scrobbleEpisode(imdb, season, episode, watched_percent, action, use_queue=True):
    """
    Scrobble an episode to Trakt.
    By default, queues the scrobble for batch processing.
    Set use_queue=False for immediate API call.
    """
    try:
        if not imdb.startswith('tt'):
            imdb = f'tt{imdb}'

        # Convert season and episode to int (they might be strings)
        season, episode = int(season), int(episode)
        c.log(f"inside trakt.scrobbleEpisode (imdb={imdb}, season={season}, episode={episode}, progress={watched_percent})")

        # Round progress to 2 decimal places to avoid Trakt validation errors
        watched_percent = round(float(watched_percent), 2)

        # Queue by default, immediate only if use_queue=False
        if use_queue:
            return queue_scrobble('episode', imdb, watched_percent, action, str(season), str(episode))
        else:
            r = get_trakt(f'/scrobble/{action}', {"show": {"ids": {"imdb": imdb}}, "episode": {"season": season, "number": episode}, "progress": watched_percent})
            # Note: Do NOT update progress table here - bookmarks.reset() already set correct resume_point in seconds
            c.log(f"scrobbleEpisode response: {r}")
            return r
    except Exception as e:
        failure = traceback.format_exc()
        c.log(f'Traceback:: {failure}')
        c.log(f'Exception in scrobbleEpisode: {e}')
        pass


# ========== BATCH OPERATIONS (OPTIMIZED) ==========

def get_watched_batch(media_type='shows', last_modified=None, etag=None):
    """
    Get watched status for all shows/movies in a single batch request.
    Uses conditional requests to avoid fetching unchanged data.

    Args:
        media_type: 'shows' or 'movies'
        last_modified: ISO 8601 timestamp from previous fetch (for conditional requests)
        etag: ETag from previous fetch (for conditional requests)

    Returns:
        tuple: (data, last_modified_timestamp, etag)
        Returns (None, last_modified, etag) if data hasn't changed (304 Not Modified)
    """
    try:
        url = f'/sync/watched/{media_type}'

        # Add conditional request headers if we have cached validators
        conditional_headers = {}
        if last_modified:
            conditional_headers['If-Modified-Since'] = last_modified
        if etag:
            conditional_headers['If-None-Match'] = etag

        # Make request with conditional headers
        if not url.startswith('http'):
            url = urljoin(BASE_URL, url)

        headers = {
            'Content-Type': 'application/json',
            'trakt-api-key': CLIENT_ID,
            'trakt-api-version': '2'
        }

        if get_trakt_credentials_info():
            headers['Authorization'] = f'Bearer {c.get_setting("trakt.token")}'

        if conditional_headers:
            headers.update(conditional_headers)

        response = session.get(url, headers=headers, timeout=30)

        # 304 Not Modified - data hasn't changed
        if response.status_code == 304:
            c.log(f'[Trakt Batch] {media_type} not modified (304), using cached data')
            # Return cached validators
            return None, last_modified, etag

        # Success - return data and new cache validators
        if response.status_code == 200:
            new_last_modified = response.headers.get('Last-Modified')
            new_etag = response.headers.get('ETag')
            data = response.json()
            c.log(f'[Trakt Batch] Fetched {len(data)} {media_type}, Last-Modified: {new_last_modified}, ETag: {new_etag}')
            return data, new_last_modified, new_etag

        # Handle other status codes
        c.log(f'[Trakt Batch] Unexpected status {response.status_code} for {media_type}')
        return None, None, None

    except Exception as e:
        c.log(f'[Trakt Batch] Exception in get_watched_batch: {e}')
        return None, None, None


def sync_watched_batch():
    """
    Sync all watched content from Trakt using optimized batch operations.
    Uses conditional requests to minimize API calls and data transfer.

    Returns:
        dict: {'shows': data, 'movies': data} or None on error
    """
    try:
        # Get last sync validators from cache (Last-Modified timestamps and ETags)
        shows_last_modified = cache.get(lambda: c.get_setting('trakt.shows.last_modified'), 0)
        shows_etag = cache.get(lambda: c.get_setting('trakt.shows.etag'), 0)
        movies_last_modified = cache.get(lambda: c.get_setting('trakt.movies.last_modified'), 0)
        movies_etag = cache.get(lambda: c.get_setting('trakt.movies.etag'), 0)

        result = {}

        # Fetch shows with conditional request (using both Last-Modified and ETag)
        shows_data, shows_timestamp, shows_new_etag = get_watched_batch('shows', shows_last_modified, shows_etag)
        if shows_data is not None:
            result['shows'] = shows_data
            # Save new cache validators
            if shows_timestamp:
                c.set_setting('trakt.shows.last_modified', shows_timestamp)
            if shows_new_etag:
                c.set_setting('trakt.shows.etag', shows_new_etag)
        else:
            c.log('[Trakt Batch] Shows data unchanged (304), using cached version')

        # Fetch movies with conditional request (using both Last-Modified and ETag)
        movies_data, movies_timestamp, movies_new_etag = get_watched_batch('movies', movies_last_modified, movies_etag)
        if movies_data is not None:
            result['movies'] = movies_data
            # Save new cache validators
            if movies_timestamp:
                c.set_setting('trakt.movies.last_modified', movies_timestamp)
            if movies_new_etag:
                c.set_setting('trakt.movies.etag', movies_new_etag)
        else:
            c.log('[Trakt Batch] Movies data unchanged (304), using cached version')

        return result if result else None

    except Exception as e:
        c.log(f'[Trakt Batch] Exception in sync_watched_batch: {e}')
        return None


def get_progress_batch(show_ids):
    """
    Get watch progress for multiple shows in optimized batches.

    Args:
        show_ids: List of show IDs (Trakt IDs)

    Returns:
        dict: {show_id: progress_data}
    """
    try:
        if not show_ids:
            return {}

        # Trakt doesn't have a true batch progress endpoint, but we can optimize
        # by requesting only hidden shows to reduce payload
        url = '/users/hidden/progress_watched'
        params = '?type=show&limit=1000'

        response = get_trakt(url + params)

        if not response:
            return {}

        # Process response into dict for quick lookup
        progress_dict = {}
        for item in response:
            show_id = item.get('show', {}).get('ids', {}).get('trakt')
            if show_id:
                progress_dict[show_id] = item

        c.log(f'[Trakt Batch] Fetched progress for {len(progress_dict)} shows')
        return progress_dict

    except Exception as e:
        c.log(f'[Trakt Batch] Exception in get_progress_batch: {e}')
        return {}









def getMovieTranslation(_id, lang, full=False):
    url = f'/movies/{_id}/translations/{lang}'
    try:
        item = getTraktAsJson(url)[0]
        return item if full else item.get('title')
    except:
        pass


def getTVShowTranslation(_id, lang, season=None, episode=None, full=False):
    if season and episode:
        url = f'/shows/{_id}/seasons/{season}/episodes/{episode}/translations/{lang}'
    else:
        url = f'/shows/{_id}/translations/{lang}'

    try:
        item = getTraktAsJson(url)[0]
        return item if full else item.get('title')
    except:
        pass


def getMovieAliases(_id):
    try:
        return getTraktAsJson(f'/movies/{_id}/aliases')
    except:
        return []


def getTVShowAliases(_id):
    try:
        return getTraktAsJson(f'/shows/{_id}/aliases')
    except:
        return []


def getMovieSummary(_id, full=True):
    try:
        url = f'/movies/{_id}'
        if full:
            url += '?extended=full'
        return getTraktAsJson(url)
    except:
        return


def getTVShowSummary(_id, full=True):
    try:
        url = f'/shows/{_id}'
        if full:
            url += '?extended=full'
        return getTraktAsJson(url)
    except:
        return


def getPeople(_id, content_type, full=True):
    try:
        url = f'/{content_type}/{_id}/people'
        if full:
            url += '?extended=full'
        return getTraktAsJson(url)
    except:
        return


def get_boxoffice():
    """Get weekend box office top 10 movies (updates Monday)"""
    try:
        if not get_trakt_credentials_info():
            return []
        return getTraktAsJson('/movies/boxoffice')
    except:
        return []


def get_recommendations_movies(page=1, limit=20):
    """Get personalized movie recommendations based on watch history"""
    try:
        if not get_trakt_credentials_info():
            return []
        return getTraktAsJson(f'/recommendations/movies?page={page}&limit={limit}')
    except:
        return []


def get_recommendations_shows(page=1, limit=20):
    """Get personalized TV show recommendations"""
    try:
        if not get_trakt_credentials_info():
            return []
        return getTraktAsJson(f'/recommendations/shows?page={page}&limit={limit}')
    except:
        return []


def get_movies_popular(page=1, limit=40):
    """Get popular movies"""
    try:
        return getTraktAsJson(f'/movies/popular?page={page}&limit={limit}')
    except:
        return []


def get_movies_anticipated(page=1, limit=40):
    """Get most anticipated upcoming movies"""
    try:
        return getTraktAsJson(f'/movies/anticipated?page={page}&limit={limit}')
    except:
        return []


def get_movies_played(page=1, limit=40):
    """Get most played movies (by watch count)"""
    try:
        return getTraktAsJson(f'/movies/played?page={page}&limit={limit}')
    except:
        return []


def get_movies_watched(page=1, limit=40):
    """Get most watched movies (by unique users)"""
    try:
        return getTraktAsJson(f'/movies/watched?page={page}&limit={limit}')
    except:
        return []


def get_movies_collected(page=1, limit=40):
    """Get most collected movies (in user libraries)"""
    try:
        return getTraktAsJson(f'/movies/collected?page={page}&limit={limit}')
    except:
        return []


def get_shows_popular(page=1, limit=40):
    """Get popular TV shows"""
    try:
        return getTraktAsJson(f'/shows/popular?page={page}&limit={limit}')
    except:
        return []


def get_shows_anticipated(page=1, limit=40):
    """Get most anticipated upcoming TV shows"""
    try:
        return getTraktAsJson(f'/shows/anticipated?page={page}&limit={limit}')
    except:
        return []


def get_shows_played(page=1, limit=40):
    """Get most played TV shows (by watch count)"""
    try:
        return getTraktAsJson(f'/shows/played?page={page}&limit={limit}')
    except:
        return []


def get_shows_watched(page=1, limit=40):
    """Get most watched TV shows (by unique users)"""
    try:
        return getTraktAsJson(f'/shows/watched?page={page}&limit={limit}')
    except:
        return []


def get_shows_collected(page=1, limit=40):
    """Get most collected TV shows (in user libraries)"""
    try:
        return getTraktAsJson(f'/shows/collected?page={page}&limit={limit}')
    except:
        return []


def SearchAll(title, year, full=True):
    try:
        movies = SearchMovie(title, year, full) or []
        shows = SearchTVShow(title, year, full) or []

        # Ensure both are lists before concatenation
        if not isinstance(movies, list):
            movies = [movies]
        if not isinstance(shows, list):
            shows = [shows]

        return movies + shows
    except:
        return []


def SearchMovie(title, year, full=True):
    try:
        title = quote_plus(title)
        url = f'/search/movie?query={title}'

        if year:
            url += f'&year={year}'
        if full:
            url += '&extended=full'
        return getTraktAsJson(url)
    except Exception:
        return


def SearchTVShow(title, year, full=True):
    try:
        title = quote_plus(title)
        url = f'/search/show?query={title}'

        if year:
            url += f'&year={year}'
        if full:
            url += '&extended=full'
        return getTraktAsJson(url)
    except Exception:
        return

def IdLookup(content, _type, type_id):
    try:
        r = getTraktAsJson(f'/search/{_type}/{type_id}?type={content}')
        return r[0].get(content, {}).get('ids', []) if r is not None else {}
    except Exception:
        return {}

def getGenre(content, _type, type_id):
    try:
        r = f'/search/{_type}/{type_id}?type={content}&extended=full'
        c.log(f"trakt operation response: {r}")
        r = getTraktAsJson(r)
        return r[0].get(content, {}).get('genres', []) if r is not None else []
    except Exception:
        return []

def getEpisodeRating(imdb, season, episode):
    """Get the rating and votes for a given episode."""

    try:
        if not imdb.startswith('tt'):
            imdb = f'tt{imdb}'
        url = f'/shows/{imdb}/seasons/{season}/episodes/{episode}/ratings'
        r = getTraktAsJson(url)
        if r is None:
            return '0', '0'

        if isinstance(r, dict):
            r1 = r.get('rating', '0')
            r2 = r.get('votes', '0')
        return str(r1), str(r2)
    except crew_errors.GeneralError as e:
        c.log(f'Trakt getEpisodeRating Error: {e}')
        return '0', '0'








####################################################################################################
# Database - 25-11-2024
#
# cm new from here to add functions for syncing with trakt
#
####################################################################################################
sql_dict = {
    'sql_create_movies_collection' :
        'CREATE TABLE IF NOT EXISTS movies_collection (last_collected_at TEXT, last_updated_at TEXT, Title TEXT, Year INT, trakt INT, slug TEXT, imdb TEXT, tmdb INT, UNIQUE(trakt, imdb, tmdb));',
    'sql_create_shows_collection' :
        'CREATE TABLE IF NOT EXISTS shows_collection (last_collected_at TEXT, last_updated_at TEXT, Title TEXT, Year INT, trakt INT, slug TEXT, tvdb INT, imdb TEXT, tmdb INT, tvrage TEXT, UNIQUE(trakt, tvdb, imdb, tmdb));',
    'sql_create_seasons_collection' :
        'CREATE TABLE IF NOT EXISTS seasons_collection (trakt INT, tvdb INT, imdb TEXT, tmdb INT, season INT, episode INT, collected_at TEXT, UNIQUE (trakt, tvdb, imdb, tmdb, season, episode));',
    'sql_create_trakt_progress' :
        'CREATE TABLE progress (media_type text not null, trakt integer primary key, imdb text, tmdb integer, tvdb integer, showtrakt integer, showimdb text, showtmdb integer, showtvdb integer, season integer, episode integer, resume_point real, curr_time text, last_played text, resume_id integer, tvshowtitle text, title text, year integer)',
    'sql_insert_trakt_progress' :
        'INSERT OR REPLACE INTO progress (media_type, trakt, imdb, tmdb, tvdb, showtrakt, showimdb, showtmdb, showtvdb, season, episode, resume_point, curr_time, last_played, resume_id, tvshowtitle, title, year) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?) ',
    'sql_create_service' :
        'CREATE TABLE IF NOT EXISTS service(setting TEXT, value TEXT, UNIQUE(setting));',
    'sql_update_service' :
        'UPDATE service SET value = ? where setting = ?',

    'sql_create_sync_data' :
        'CREATE TABLE sync_data (media_type TEXT NOT NULL, name TEXT NOT NULL, date TEXT);',
    'sql_insert_sync_data' :
        'INSERT OR REPLACE INTO sync_data (media_type, name, date) VALUES (?,?,?)',
    'sql_select_sync_data' :
        'SELECT date FROM sync_data WHERE media_type = ? AND name = ?',
    'sql_delete_sync_data' :
        'DELETE FROM sync_data WHERE media_type = ? AND name = ?',
    'sql_create_trakt_watched' :
        'CREATE TABLE IF NOT EXISTS watched (media_type text not null, trakt integer, tvdb integer, imdb TEXT, tmdb integer, season integer, episode integer, last_played text, title text, unique(media_type, trakt, season, episode))',
    'sql_insert_trakt_watched' :
        'INSERT OR REPLACE INTO watched (media_type, trakt, tvdb, imdb, tmdb, season, episode, last_played, title) VALUES (?,?,?,?,?,?,?,?,?)',
    'sql_create_scrobble_queue' :
        'CREATE TABLE IF NOT EXISTS scrobble_queue (id INTEGER PRIMARY KEY AUTOINCREMENT, media_type TEXT, imdb TEXT, season TEXT, episode TEXT, progress REAL, action TEXT, timestamp TEXT, UNIQUE(media_type, imdb, season, episode))',
    'sql_insert_scrobble_queue' :
        'INSERT OR REPLACE INTO scrobble_queue (media_type, imdb, season, episode, progress, action, timestamp) VALUES (?,?,?,?,?,?,?)',
    'sql_select_scrobble_queue' :
        'SELECT id, media_type, imdb, season, episode, progress, action FROM scrobble_queue ORDER BY timestamp ASC',
    'sql_delete_scrobble_item' :
        'DELETE FROM scrobble_queue WHERE id = ?',
    'sql_clear_scrobble_queue' :
        'DELETE FROM scrobble_queue',
}

def syncTrakt() -> None:
    """
    Syncs Kodi status with Trakt.tv
    """
    if not control.player.isPlayingVideo() and c.devmode:
        c.infoDialog('Syncing with Trakt', 'Please wait', icon='main_classy.png', sound=False)
    else:
        c.log('(def syncTrakt) Syncing with Trakt', 1)

    try:
        fill_progress_table()
        fill_trakt_watched()

        #endpoint = 'sync/watched/movies'

        _types = ['movies', 'episodes']
        start = '2016-06-01T00:00:00.000Z'
        end = cleandate.now_to_iso()
        for _type in _types:
            endpoint = f'/sync/history/{_type}?start_at={start}&end_at={end}'
            result = getTraktAsJson(endpoint)

            # TODO: add a function to insert into the database, nothing happens with result
            # TODO: add a fill_history function

        sync_last_activities()

        if not control.player.isPlayingVideo():
            return c.infoDialog('Syncing with Trakt Finished', 'Please wait', icon='main_classy.png', sound=False)
        else:
            c.log('Syncing with Trakt Finished', 1)

    except (Exception, OperationalError) as e:

        failure = traceback.format_exc()
        c.log(f'Traceback:: {failure}')
        c.log(f'Exception raised in trakt flow: {e}')



def get_show_extended_info(trakt_id):
    endpoint = f'/shows/{trakt_id}?extended=full'
    return getTraktAsJson(endpoint)

def fill_progress_table() -> None:
    """
    Fetches progress from trakt and inserts/updates it in the database (trakt_progress).
    This includes movies and episodes.
    """
    start, end = get_start_end(diff=365)

    # Fetch BOTH movies and episodes from Trakt playback progress
    for media in ['movies', 'episodes']:
        endpoint = f'sync/playback/{media}?extended=full&start_at={start}&end_at={end}'
        c.log(f"[Trakt] fill_progress_table: Fetching {media} from {endpoint}")

        if result := getTraktAsJson(endpoint):
            if not table_exists('trakt_progress'):
                create_table('trakt_progress')

            c.log(f"[Trakt] fill_progress_table: Processing {len(result)} {media}")

            for item in result:
                media_type = item.get('type')
                progress = item.get('progress')
                ids = item.get(media_type).get('ids')
                trakt_id = ids.get('trakt')
                tvdb_id = ids.get('tvdb')
                tmdb_id = ids.get('tmdb')
                imdb_id = ids.get('imdb')
                year = item.get(media_type).get('year')
                title = item.get(media_type).get('title')
                season = item.get(media_type).get('season') if media_type == 'episode' else 0
                episode = item.get(media_type).get('number') if media_type == 'episode' else 0
                current_time = get_now_in_iso()
                last_played = item.get('paused_at')
                resume_id = item.get('id')

                if 'show' in item:
                    tvshowtitle = item.get('show').get('title')
                    show_trakt_id = item.get('show').get('ids').get('trakt')
                    show_imdb_id = item.get('show').get('ids').get('imdb')
                    show_tmdb_id = item.get('show').get('ids').get('tmdb')
                    show_tvdb_id = item.get('show').get('ids').get('tvdb')
                else:
                    tvshowtitle = ''
                    show_trakt_id = 0
                    show_imdb_id = 0
                    show_tmdb_id = 0
                    show_tvdb_id = 0

                insert_trakt_progress(
                    media_type,
                    trakt_id,
                    imdb_id,
                    tmdb_id,
                    tvdb_id,
                    show_trakt_id,
                    show_imdb_id,
                    show_tmdb_id,
                    show_tvdb_id,
                    season,
                    episode,
                    progress,
                    current_time,
                    last_played,
                    resume_id,
                    tvshowtitle,
                    title,
                    year,
                )

def update_progress_in_database(imdb_id: str = '', trakt_id: int = 0, tmdb_id: int = 0, season: int = 0, episode: int = 0, progress: int = 0, resume_point: float = None) -> None:
    """
    Updates progress in the trakt sync database using UPSERT logic.

    :param imdb_id: IMDB ID for lookup
    :param trakt_id: Trakt ID for lookup
    :param tmdb_id: TMDB ID for lookup
    :param season: Season number for episodes
    :param episode: Episode number for episodes
    :param progress: Progress percentage (0-100)
    :param resume_point: Resume point in SECONDS (not percentage). If None, stored as progress/100
    """
    try:
        # If resume_point not provided, use progress percentage as 0-1 fraction
        # Otherwise use the provided value (should be in seconds from bookmarks.reset)
        if resume_point is None:
            resume_point = progress / 100.0        # Determine media type
        media_type = 'episode' if season and episode else 'movie'

        c.log(f"[Trakt] update_progress_in_database: {media_type} imdb={imdb_id} progress={progress}% resume_point={resume_point}")

        connection = get_connection(control.traktsyncFile, return_as_dict=True)
        if connection:
            cursor = connection.cursor()
        else:
            raise OperationalError("Could not establish database connection.")

        # Use INSERT OR REPLACE with minimal fields
        # For movies: trakt is primary key, so we use a dummy value if not provided
        # For episodes: we need show info which we might not have, so try UPDATE first

        if media_type == 'movie':
            # Try UPDATE first
            conditions = []
            if imdb_id:
                conditions.append(f"imdb = '{imdb_id}'")
            if trakt_id:
                conditions.append(f"trakt = {trakt_id}")
            if tmdb_id:
                conditions.append(f"tmdb = {tmdb_id}")

            if conditions:
                sql = 'UPDATE progress SET resume_point = ? WHERE media_type = ? AND (' + ' OR '.join(conditions) + ')'
                c.log(f"[Trakt] Executing UPDATE: {sql} with resume_point={resume_point}")
                cursor.execute(sql, (resume_point, media_type))
                rows_updated = cursor.rowcount
                c.log(f"[Trakt] UPDATE affected {rows_updated} rows")

                if rows_updated == 0:
                    # Row doesn't exist, insert minimal record using imdb as the key
                    # Use a synthetic trakt ID based on imdb hash to satisfy primary key constraint
                    c.log(f"[Trakt] No existing row, inserting new record with imdb={imdb_id}")
                    synthetic_trakt_id = abs(hash(imdb_id)) % (10 ** 8) if imdb_id else (trakt_id if trakt_id else 0)
                    sql = 'INSERT OR REPLACE INTO progress (media_type, trakt, imdb, tmdb, tvdb, showtrakt, showimdb, showtmdb, showtvdb, season, episode, resume_point, curr_time, last_played, resume_id, tvshowtitle, title, year) VALUES (?, ?, ?, ?, 0, 0, NULL, 0, 0, 0, 0, ?, NULL, NULL, 0, NULL, NULL, 0)'
                    cursor.execute(sql, (media_type, synthetic_trakt_id, imdb_id, tmdb_id, resume_point))
                    c.log(f"[Trakt] INSERT completed with synthetic trakt_id={synthetic_trakt_id}")
        else:
            # Episode - try UPDATE
            conditions = []
            if imdb_id:
                conditions.append(f"imdb = '{imdb_id}'")
            if trakt_id:
                conditions.append(f"trakt = {trakt_id}")

            conditions.append(f"season = {season} AND episode = {episode}")

            if conditions:
                sql = 'UPDATE progress SET resume_point = ? WHERE media_type = ? AND ' + ' AND '.join(conditions)
                c.log(f"[Trakt] Executing UPDATE: {sql}")
                cursor.execute(sql, (resume_point, media_type))
                c.log(f"[Trakt] UPDATE affected {cursor.rowcount} rows")

        connection.commit()
        cursor.close()
        connection.close()
        c.log("[Trakt] update_progress_in_database completed successfully")
    except Exception as e:
        c.log(f"[Trakt] ERROR in update_progress_in_database: {e}")
        c.log(f"[Trakt] Traceback: {traceback.format_exc()}")


def delete_progress_from_database(key, media_id, season: int = 0, episode: int = 0) -> None:
    """
    Deletes progress from the trakt sync database.

    :param imdb_id: IMDB ID for lookup
    :param trakt_id: Trakt ID for lookup
    :param tmdb_id: TMDB ID for lookup
    :param season: Season number for episodes
    :param episode: Episode number for episodes
    """
    try:
        if key == 'imdb' and not media_id.startswith('tt'):
            media_id = f'tt{media_id}'
        connection = get_connection(control.traktsyncFile)
        if connection:
            cursor = connection.cursor()
        else:
            raise OperationalError("Could not establish database connection.")

        conditions = []
        if key == 'imdb' and media_id:
            conditions.append(f"imdb = '{media_id}'")
        if key == 'trakt' and media_id:
            conditions.append(f"trakt = {media_id}")
        if key == 'tmdb' and media_id:
            conditions.append(f"tmdb = {media_id}")
        if season:
            conditions.append(f"season = {season}")
        if episode:
            conditions.append(f"episode = {episode}")

        if conditions:
            sql = 'DELETE FROM progress WHERE ' + ' AND '.join(conditions)
            c.log(f"[Trakt] Executing DELETE: {sql}")
            cursor.execute(sql)
            c.log(f"[Trakt] DELETE affected {cursor.rowcount} rows")

        connection.commit()
        cursor.close()
        connection.close()
        c.log("[Trakt] delete_progress_from_database completed successfully")
    except Exception as e:
        c.log(f"[Trakt] ERROR in delete_progress_from_database: {e}")
        c.log(f"[Trakt] Traceback: {traceback.format_exc()}")


def fill_trakt_watched() -> None:
    """
    Fetches watched from trakt and inserts/updates it in the database (trakt_watched).
    OPTIMIZED: Uses batch sync with conditional requests to minimize API calls.
    """
    try:
        dbcon = get_connection(control.traktsyncFile, return_as_dict=True)
        dbcur = get_connection_cursor(dbcon)

        # Use optimized batch sync with conditional requests
        batch_result = sync_watched_batch()

        if not batch_result:
            c.log('[Trakt] No watched data to sync (unchanged or error)')
            dbcur.close()
            dbcon.close()
            return

        if not table_exists('trakt_watched'):
            create_table('trakt_watched')

        # Process shows from batch result
        if 'shows' in batch_result:
            for item in batch_result['shows']:
                media_type = 'show'
                show = item['show']
                trakt_id = show['ids']['trakt']
                tvdb_id = show['ids'].get('tvdb', 0)
                imdb_id = show['ids'].get('imdb')
                tmdb_id = show['ids'].get('tmdb')
                title = show['title']

                for season in item['seasons']:
                    season_nr = season['number']
                    for episodes in season['episodes']:
                        episode_nr = episodes['number']
                        last_watched_at = episodes['last_watched_at']
                        dbcur.execute(sql_dict['sql_insert_trakt_watched'],
                                    (media_type, trakt_id, tvdb_id, imdb_id, tmdb_id,
                                    season_nr, episode_nr, last_watched_at, title))

        # Process movies from batch result
        if 'movies' in batch_result:
            media_type = 'movie'
            for item in batch_result['movies']:
                movie = item['movie']
                trakt_id = movie['ids']['trakt']
                tvdb_id = movie['ids'].get('tvdb', 0)
                imdb_id = movie['ids'].get('imdb')
                tmdb_id = movie['ids'].get('tmdb')
                title = movie['title']
                last_watched_at = item['last_watched_at']

                dbcur.execute(sql_dict['sql_insert_trakt_watched'],
                            (media_type, trakt_id, tvdb_id, imdb_id, tmdb_id,
                            0, 0, last_watched_at, title))

        # Commit and close
        dbcon.commit()
        dbcur.close()
        dbcon.close()

        c.log('[Trakt] Batch sync completed successfully')

    except Exception as e:
        failure = traceback.format_exc()
        c.log(f'Traceback:: {failure}')
        c.log(f'Exception raised: {e}')



def fill_trakt_watched_orig() -> None:
    """
    Fetches watched from trakt and inserts/updates it in the database (trakt_watched).
    This includes movies and episodes.
    """
    try:

        _types = ['movies', 'shows']
        #_types = ['shows']

        for _type in _types:
            c.log(f"type = {_type} (type={type(_type)})")
            endpoint = f'sync/watched/{_type}'
            if result := getTraktAsJson(endpoint):
                if _type == 'movies':
                    indicators = [i['movie']['ids']['tmdb'] for i in result]
                    c.log(f"indicators = {indicators}")
                if not table_exists('trakt_watched'):
                    create_table('trakt_watched')


                dbcon = get_connection(control.traktsyncFile, return_as_dict=True)
                if dbcon:
                    dbcur = get_connection_cursor(dbcon)

                for item in result:
                    media_type = _type
                    trakt_id = item.get(_type).get('ids').get('trakt')
                    tvdb_id = item.get(_type).get('ids').get('tvdb') or 0
                    imdb_id = item.get(_type).get('ids').get('imdb')
                    tmdb_id = item.get(_type).get('ids').get('tmdb')
                    title = item.get(_type).get('title')


                    if _type == 'movies':
                        seasons = 0
                        episode = 0
                        last_watched_at = item.get('last_watched_at')
                        if dbcur:
                            dbcur.execute(sql_dict['sql_insert_trakt_watched'], (media_type, trakt_id, tvdb_id, imdb_id, tmdb_id, seasons, episode, last_watched_at, title))
                    else:
                        seasons = item.get('seasons')
                        c.log(f"seasons = {seasons}")
                        for season in seasons:
                            season_nr = season.get('number')
                            c.log(f"season = {season_nr}")
                            for episodes in season:
                                episode_nr = episodes.get('number')
                                c.log(f"episode_nr = {episode_nr}")
                                for item in episodes.get('episodes'):
                                    c.log(f"item = {item}")
                                    last_watched_at = item.get('last_watched_at')
                                    c.log(f"last_watched = {last_watched_at}")
                                    if dbcur:
                                        dbcur.execute(sql_dict['sql_insert_trakt_watched'], (media_type, trakt_id, tvdb_id, imdb_id, tmdb_id, season_nr, episode_nr, last_watched_at, title))
                if dbcon:
                    dbcon.commit()
                dbcur.close()
                dbcon.close()

    except Exception as e:
        failure = traceback.format_exc()
        c.log(f'Traceback:: {failure}')
        c.log(f'Exception raised: {e}')







def sync_last_activities():
    #sync last activities
    i = getTraktAsJson('/sync/last_activities')
    _all = i.get('all')
    _crew = cleandate.now_to_iso()#last run

    #c.log(f"[CM Debug @ 851 in trakt.py] all = {_all} and crew = {_crew}")
    update_service(_all, _crew)
    #c.log(f"[CM Debug @ 853 in trakt.py] i = {repr(i)}")
    #activity = []
    #activity = [cleandate.new_iso_to_utc(i) for i in activity]
    #activity = sorted(activity, key=int)[-1]



def update_service(_all, _crew):
    try:
        dbcon = get_connection(control.traktsyncFile, return_as_dict=True)
        dbcur = get_connection_cursor(dbcon)
        d = {'all':_all, 'crew_last_sync': _crew}

        if not table_exists('service'):
            create_table('service')

        for k,v in d.items():
            sql = sql_dict['sql_update_service']
            #sql = sql_dict['sql_update_service']
            #c.log(f"[CM Debug @ 880 in trakt.py] sql = {sql}")
            #dbcur.execute(sql, (_all, _crew))
            dbcur.execute(sql, (v, k))
        dbcon.commit()
        dbcur.close()
        dbcon.close()
    except Exception as e:
        c.log(f"Exception raised: {e}")


def insert_trakt_progress(media_type, trakt, imdb, tmdb, tvdb, showtrakt, showimdb, showtmdb, showtvdb, season, episode, resume_point, curr_time, last_played, resume_id, tvshowtitle, title, year):
    dbcon = get_connection(control.traktsyncFile, return_as_dict=True)
    dbcur = get_connection_cursor(dbcon)
    sql = sql_dict['sql_insert_trakt_progress']
    dbcur.execute(sql, (media_type, trakt, imdb, tmdb, tvdb, showtrakt, showimdb, showtmdb, showtvdb, season, episode, resume_point, curr_time, last_played, resume_id, tvshowtitle, title, year))
    dbcon.commit()
    dbcur.close()
    dbcon.close()


def get_start_end(diff):
    """
    Returns a tuple of two strings representing the ISO 8601
    formatted dates for the current date and the date a given
    number of days in the past.

    :param diff: the number of days ago to calculate the start date
    :return: a tuple of two strings, (start, end)
    """
    start = datetime.now() - timedelta(days=diff)
    start = start.strftime("%Y-%m-%dT%H:%M:%S.000Z")
    end = datetime.now().strftime("%Y-%m-%dT%H:%M:%S.000Z")
    return quote_plus(start), quote_plus(end)

def get_now_in_iso():
    return datetime.now().strftime("%Y-%m-%dT%H:%M:%S.000Z")

def get_connection(file, return_as_dict=False):
    """
    Establishes a connection to a SQLite database file

    :param file: the path to the SQLite database file
    :param return_as_dict: if True, the row factory will be set to return results as dictionaries
    :return: a database connection object
    """
    try:

        if not os.path.isfile(control.dataPath):
            control.makeFile(control.dataPath)

        dbcon = database.connect(file)
        dbcon.execute('PRAGMA page_size = 32768')
        dbcon.execute('PRAGMA cache_size = 10000000')
        dbcon.execute('PRAGMA mmap_size = 30000000000')
        #dbcon.execute('PRAGMA journal_mode = OFF')
        dbcon.execute('PRAGMA journal_mode = MEMORY')
        dbcon.execute('PRAGMA temp_store = MEMORY')
        dbcon.execute('PRAGMA synchronous = OFF')

        if return_as_dict:
            dbcon.row_factory = _dict_factory
        return dbcon
    except Exception as e:
        c.log(f"Error getting database connection: {e}")
        return None

def get_connection_cursor(db_connection):
    """
    Returns a database cursor object from a connection
    :param db_connection: a database connection object
    :return: a database cursor object
    """
    if db_connection is None:
        c.log("Database connection is None")
        return None

    try:
        return db_connection.cursor()
    except Exception as e:
        c.log(f"Error getting database cursor: {e}")
        return None


def open_connection(file = control.traktsyncFile):
    """
    Opens a connection to a SQLite database file

    :param file: the path to the SQLite database file
    :return: a database connection object
    """
    conn = get_connection(file)
    cursor = get_connection_cursor(conn)
    return None if conn is None or cursor is None else (conn, cursor)

def commit(db_connection) -> None:
    _commit(db_connection)

def close_connection(db_connection):
    """
    Closes a database connection

    :param db_connection: a database connection object
    """
    if db_connection is not None:
        db_connection.close()
    else:
        c.log("Database connection is None")


def _commit(db_connection):
    """
    Commits the current transaction to the database.

    :param db_connection: a database connection object
    Logs an error if the connection is None or if an exception occurs during commit.
    """
    if db_connection is None:
        c.log("Database connection is None")
        return
    else:
        c.log("Database connection is not None")
    try:
        if db_connection is not None:
            c.log(f"Database connection is of type(): {type(db_connection)}")
            db_connection.commit()
            c.log("Database connection is initialized")
        else:
            c.log("Database connection is not initialized")
    except AttributeError:
        c.log("Database connection does not have a connection attribute")
    except Exception as e:
        c.log(f"Error committing to the database: {e}")



def _dict_factory(cursor, row):
    """
    A factory function that constructs a dictionary from a SQLite query result.
    :param cursor: a SQLite cursor object
    :param row: a row from the SQLite query result
    :return: a dictionary where the keys are the column names and the values are the corresponding
    :values from the row
    """
    if cursor is None or row is None:
        raise ValueError("cursor and row must not be None")

    row_dict = {}
    for index, column in enumerate(cursor.description):
        try:
            row_dict[column[0]] = row[index]
        except Exception as e:
            c.log(f"Error constructing dictionary from SQLite query result: {e}")
    return row_dict

####
# end of core database functions


def get_db_connection(file=control.traktsyncFile, return_as_dict=True):
    """
    Returns a database connection and cursor for the specified SQLite file.

    Attempts to establish a connection and retrieve a cursor; returns (None, None) if unsuccessful.

    Args:
        file (str): Path to the SQLite database file.
        return_as_dict (bool): If True, rows are returned as dictionaries.

    Returns:
        tuple: (database connection, database cursor) or (None, None) if connection fails.
    """
    try:
        dbcon = get_connection(file, return_as_dict)
        dbcur = get_connection_cursor(dbcon)

        # check if we have a valid connection and cursor
        if dbcur and dbcon:
            return dbcon, dbcur
        c.log("Error: dbcur or dbcon is None, cannot create connection")
        return None, None

    except (database.Error, database.OperationalError) as e:
        c.log(f"Error getting database connection: {e}")
        return None, None

####
# start of trakt functions

def check_sync_tables():
    """
    Checks if the trakt sync tables exist and creates them if not.
    """
    try:
        #fetch activities
        last_activities = getTraktAsJson('/sync/last_activities')
        c.log(f"last_activities type = {type(last_activities)}")

        if last_activities:
            create_trakt_tables(last_activities)
        else:
            c.log("Error: last_activities is None")
    except Exception as e:
        c.log(f"Error checking sync tables: {e}")

def fetch_last_service(fetch_all=False):
    """
    Retrieves the last sync timestamp from the trakt sync database.

    Args:
        fetch_all (bool): If True, fetches all rows from the table, otherwise just the first row.

    Returns:
        The last sync timestamp (or all timestamps if fetch_all is True)
    """
    try:
        dbcon = get_connection(control.traktsyncFile, return_as_dict=True)
        if dbcon:
            dbcur = get_connection_cursor(dbcon)
        else:
            raise OperationalError("Could not establish database connection in fetch_last_service.")
        if dbcur:
            sql = 'SELECT value FROM service where setting = "crew_last_sync"'
            if fetch_all:
                dbcur.execute(sql)
                return dbcur.fetchall()
            else:
                dbcur.execute(sql)
                return dbcur.fetchone()
    except (database.Error, database.OperationalError) as e:
        c.log(f"Error fetching last sync timestamp: {e}")
        return None
    finally:
        if dbcon:
            dbcon.close()

def fetch_last_activity(fetch_all=True, activity_type='all'):
    try:
        dbcon = get_connection(control.traktsyncFile, return_as_dict=True)
        if dbcon:
            dbcur = get_connection_cursor(dbcon)
        else:
            raise OperationalError("Could not establish database connection in fetch_last_activity.")


        if dbcur:
            if fetch_all:
                sql = 'SELECT value FROM service where setting = "all"'
                dbcur.execute(sql)
                return dbcur.fetchall()
            else:
                sql = f'SELECT value FROM service where setting = "{activity_type}"'
                dbcur.execute(sql)
                return dbcur.fetchone()
    except (database.Error, database.OperationalError) as e:
        c.log(f"Error fetching last activity: {e}")
        return None
    finally:
        if dbcon:
            dbcon.close()

def create_trakt_tables(last_activities):
    """
    Creates the tables in the trakt sync database if they don't exist
    """
    try:
        dbcon = get_connection(control.traktsyncFile, return_as_dict=True)
        dbcur = get_connection_cursor(dbcon)

        if dbcur and dbcon: #check if we have a valid connection and cursor
            for key, val in last_activities.items():
                if isinstance(val, str):
                    if not table_exists('service'):
                        sql = "CREATE TABLE IF NOT EXISTS service(setting TEXT, value TEXT, UNIQUE(setting));"
                        dbcur.execute(sql)

                    sql = f"INSERT OR REPLACE INTO service Values ('{key}', '{val}')"
                    dbcur.execute(sql)

                elif isinstance(val, dict):
                    if not table_exists(key):
                        sql = f"CREATE TABLE IF NOT EXISTS {key} (setting TEXT, value TEXT, UNIQUE(setting));"
                        dbcur.execute(sql)

                    for k, v in val.items():
                        sql = f"INSERT OR REPLACE INTO {key} Values ('{k}', '{v}')"
                        dbcur.execute(sql)

                    timestamp = datetime.now().strftime("%Y-%m-%dT%H:%M:%S.000Z")
                    sql = f"INSERT OR REPLACE INTO service Values ('crew_last_sync', '{timestamp}')"
                    dbcur.execute(sql)
        else:
            c.log("Error: dbcur or dbcon is None, cannot create trakt tables")
            return

    except Exception as e:
        c.log(f'Exception in create_trakt_tables(last_activities): Error = {e}')
    finally:
        dbcon.commit()
        dbcon.close()

def create_table(name='', query = ''):

    try:
        if not name and not query:
            c.log(f"Trying to create table in trakt::create_table without name or query. name = {name}, query = {query}, returning")
            return

        dbcon = get_connection(control.traktsyncFile, return_as_dict=True)
        dbcur = get_connection_cursor(dbcon)


        if table_exists(name):
            c.log(f"Table {name} already exists")
        elif f'sql_create_{name}' in sql_dict:
            sql = sql_dict[f'sql_create_{name}']
            # Ensure idempotent CREATE TABLE statements include IF NOT EXISTS to avoid race errors
            if isinstance(sql, str) and sql.lower().startswith('create table') and 'if not exists' not in sql.lower():
                sql = sql.replace('CREATE TABLE', 'CREATE TABLE IF NOT EXISTS', 1)
            if dbcur:
                dbcur.execute(sql)
            c.log(f"sql = {sql}")
        elif query:
            if query.lower().startswith('create table'):
                # Add IF NOT EXISTS to prevent OperationalError when table exists
                safe_query = query
                if 'if not exists' not in query.lower():
                    safe_query = query.replace('CREATE TABLE', 'CREATE TABLE IF NOT EXISTS', 1)
                if dbcur:
                    dbcur.execute(safe_query)
            else:
                c.log(f"Trying to use invalid query in trakt::create_table, query = {query}, returning")
        #no return here, gracefully close the connection

        if dbcon:
            dbcon.commit()
            dbcon.close()

    except OperationalError as e:
        # Some OperationalErrors are benign (e.g., 'table x already exists') when multiple
        # callers attempt to create the same table concurrently. Handle that case quietly.
        msg = str(e).lower()
        if 'already exists' in msg:
            c.log(f"Table {name} already exists, skipping")
        else:
            failure = traceback.format_exc()
            c.log(f'Traceback:: {failure}')
            c.log(f'[CM Debug @ 1464 in trakt.py]Exception raised. Error = {e}')
            c.log(f"[CM Debug @ 1465 in trakt.py] SQL Operational Error: {e}")

    except Exception as e:
        failure = traceback.format_exc()
        c.log(f'[CM Debug @ 987 in trakt.py]Traceback:: {failure}')
        c.log(f'[CM Debug @ 988 in trakt.py]Exception raised. Error = {e}')

def get_trakt_collection(media_type="all") -> None:
    try:
        do_commit = False
        dbcon, dbcur = get_db_connection()

        if dbcon and dbcur: #check if we have a valid connection and cursor
            c.log(f"[CM Debug @ 890 in trakt.py] dbcon and dbcur are valid, proceeding to get collection for media_type = {media_type}")

            if media_type in ['movies', 'all']:
                if not table_exists('movies_collection'):
                    sql = sql_dict['sql_create_movies_collection']
                    #dbcon = get_connection(control.traktsyncFile, return_as_dict=True)
                    #dbcur = get_connection_cursor(dbcon)

                    dbcur.execute(sql)
                    do_commit = True
                movie_collection = getTraktAsJson('/sync/collection/movies')
                insert_collection(movie_collection, 'movies')

            if media_type in ['shows', 'all']:
                if not table_exists('shows_collection'):
                    sql = sql_dict['sql_create_shows_collection']
                    c.log(f"[CM Debug @ 1658 in trakt.py] sql = {sql}")
                    dbcur.execute(sql)
                    do_commit= True

                if not table_exists('seasons_collection'):
                    sql = sql_dict['sql_create_seasons_collection']
                    c.log(f"[CM Debug @ 1663 in trakt.py] sql = {sql}")
                    dbcur.execute(sql)
                    do_commit = True

                show_collection = getTraktAsJson('/sync/collection/shows')
                insert_collection(show_collection, 'shows')

            if do_commit:
                dbcon.commit()
                c.infoDialog('trakt collection updated', icon="main_orangehat.png", time=2000)

    except Exception as e:
        failure = traceback.format_exc()
        c.log(f'[CM Debug @ 839 in trakt.py]Traceback:: {failure}')

        c.log(f'[CM Debug @ 839 in trakt.py]Exception raised. Error = {e}')
    finally:
        if do_commit:
            dbcon.close()

def get_collection(media_type, trakt_id=0, imdb_id='', tmdb_id=0):
    """
    Retrieves collection entries from the trakt sync database for the specified media type and identifiers.

    Args:
        media_type (str): The type of media to retrieve, either 'movies' or 'shows'.
        trakt_id (int, optional): The trakt ID for the media. Defaults to 0.
        imdb_id (str, optional): The IMDb ID for the media. Defaults to an empty string.
        tmdb_id (int, optional): The TMDb ID for the media. Defaults to 0.

    Returns:
        list: A list of rows from the database matching the specified identifiers.
    """
    try:

        if media_type not in ['movies', 'shows']:
            c.log(f"[CM Debug @ 1607 in trakt.py] media_type = {media_type}, not in ['movies', 'shows'], returning")
            return
        if not table_exists(f"{media_type}_collection"):
            c.log(f"[CM Debug @ 1608 in trakt.py] table doesn't exist, creating {media_type}_collection with sql = {sql_dict[f'sql_create_{media_type}_collection']}")
            create_table(f"{media_type}_collection", sql_dict[f"sql_create_{media_type}_collection"])
        query = []
        media_type = media_type.lower()
        c.log(f"[CM Debug @ 1609 in trakt.py] media_type = {media_type}, trakt_id = {trakt_id}, imdb_id = {imdb_id}, tmdb_id = {tmdb_id}")


        if trakt_id == 0 and imdb_id == '' and tmdb_id == 0:
            sql = f"SELECT * FROM {media_type}_collection"
            c.log(f"[CM Debug @ 1614 in trakt.py] sql is of type: {type(sql)} and = {sql}")
        else:
            if trakt_id != 0:
                query.append(f"trakt = {trakt_id}")
            if imdb_id != '':
                query.append(f"imdb = '{imdb_id}'")
            if tmdb_id != 0:
                query.append(f"tmdb = {tmdb_id}")
            sql = f"SELECT * FROM {media_type}_collection WHERE {' AND '.join(query)}"
        c.log(f"[CM Debug @ 1224 in trakt.py] sql is of type: {type(sql)} and = {sql}")
        dbcon = get_connection(control.traktsyncFile, return_as_dict=True)
        dbcur = get_connection_cursor(dbcon)

        dbcon, dbcur = get_db_connection()
        if dbcon and dbcur:
            dbcur.execute(sql)
            rows = dbcur.fetchall()

            dbcon.commit()
            dbcur.close()
            dbcon.close()

        if len(rows) > 0:
            return rows
        else:
            return

    except OperationalError as e:
        c.log(f'Exception raised in get_collection. Error = {e}')
    except Exception as e:
        c.log(f'Exception raised in get_collection. Error = {e}')





def get_collection_orig(media_type, trakt=0, imdb='', tmdb=0):
    """
    Retrieves collection entries from the trakt sync database for the specified media type and identifiers.

    Args:
        mediatype (str): The type of media to retrieve, either 'movies' or 'shows'.
        trakt (int, optional): The trakt ID for the media. Defaults to 0.
        imdb (str, optional): The IMDb ID for the media. Defaults to an empty string.
        tmdb (int, optional): The TMDb ID for the media. Defaults to 0.

    Returns:
        list: A list of rows from the database matching the specified identifiers.
    """
    try:
        sql = ''
        if media_type == 'movies':
            if trakt == 0 and imdb == '' and tmdb == 0:
                sql = "SELECT * FROM movies_collection"
            elif imdb == '' and tmdb == 0:
                sql = f"SELECT * FROM movies_collection WHERE trakt = {trakt}"
            elif trakt == 0 and tmdb == 0:
                sql = f"SELECT * FROM movies_collection WHERE imdb = '{imdb}'"
            elif trakt == 0 and imdb == '':
                sql = f"SELECT * FROM movies_collection WHERE tmdb = {tmdb}"
            elif trakt == 0:
                sql = f"SELECT * FROM movies_collection WHERE imdb = '{imdb}' AND tmdb = {tmdb}"
            elif imdb == '':
                sql = f"SELECT * FROM movies_collection WHERE trakt = {trakt} AND tmdb = {tmdb}"
            else:
                sql = f"SELECT * FROM movies_collection WHERE trakt = {trakt} OR imdb = '{imdb}' OR tmdb = {tmdb}"
        elif media_type == 'shows':
            sql = f"SELECT * FROM shows_collection WHERE trakt = '{trakt}' AND imdb = '{imdb}' AND tmdb = '{tmdb}'"
        c.log(f"[CM Debug @ 934 in trakt.py] sql is of type: {type(sql)} and = {sql}")
        dbcon = get_connection(control.traktsyncFile, return_as_dict=True)
        dbcur = get_connection_cursor(dbcon)
        dbcur.execute(sql)
        return dbcur.fetchall()
    except Exception as e:
        c.log(f'Exception raised in get_collection. Error = {e}')







def table_exists(table_name) -> bool:
    """
    Checks if a table exists in the trakt sync database.

    Args:
        table_name (str): The name of the table to check.

    Returns:
        bool: True if the table exists, False if it does not.
    """
    try:
        dbcon = get_connection(control.traktsyncFile, return_as_dict=True)
        dbcur = get_connection_cursor(dbcon)

        sql = f"SELECT count(*) as aantal FROM sqlite_master WHERE type='table' AND name='{table_name}'"
        dbcur.execute(sql)
        row = dbcur.fetchone()
        if row['aantal'] == 0:
            return False
        else:
            return True

    except Exception as e:
        c.log(f'Exception raised in tables_exists. Error = {e}')
        return False


def insert_collection(collection, mediatype):
    try:
        table_name = ''

        if mediatype == 'movies':
            table_name = 'movies_collection'
        elif mediatype == 'shows':
            table_name = 'shows_collection'


        c.log(f"[CM Debug @ 1831 in trakt.py] mediatype = {mediatype}")
        #check if table exists
        # dbcon = get_connection(control.traktsyncFile, return_as_dict=True)
        # dbcur = get_connection_cursor(dbcon)

        dbcon, dbcur = get_db_connection()
        if dbcon and dbcur and not table_exists(table_name):
            sql = sql_dict[f'sql_create_{table_name}']
            dbcur.execute(sql)
            dbcon.commit()

        for item in collection:

            if mediatype == 'movies':
                last_collected_at = item['collected_at']
                last_updated_at = item['updated_at']
                title = item['movie']['title']
                year = item['movie']['year']
                trakt = item['movie']['ids']['trakt']
                slug = item['movie']['ids']['slug']
                imdb = item['movie']['ids']['imdb']
                tmdb = item['movie']['ids']['tmdb']
                sql = f"INSERT OR REPLACE INTO '{table_name}' Values ('{last_collected_at}', '{last_updated_at}', '{title}', {year}, {trakt}, '{slug}', '{imdb}', {tmdb})"
                dbcur.execute(sql)
                dbcon.commit()

            elif mediatype == 'shows':
                c.log(f"[CM Debug @ 1858 in trakt.py] inside shows with item = {item}")
                try:
                    last_collected_at = item['last_collected_at']
                    last_updated_at = item['last_updated_at']
                    seasons = item['seasons']
                    trakt = item['show']['ids']['trakt']
                    slug = item['show']['ids']['slug']
                    imdb = item['show']['ids']['imdb']
                    tmdb = item['show']['ids']['tmdb']
                    tvdb = item['show']['ids']['tvdb']
                    tvrage = item['show']['ids']['tvrage']
                    title = item['show']['title']
                    year = item['show']['year']
                    sql = f"INSERT OR REPLACE INTO '{table_name}' Values ('{last_collected_at}', '{last_updated_at}', '{title}', {year}, {trakt}, '{slug}', '{tvdb}', '{imdb}', {tmdb}, '{tvrage}')"
                    c.log(f"[CM Debug @ 1861 in trakt.py] sql = {sql}")

                    for season in seasons:
                        for episode in season['episodes']:
                            sql = f"INSERT OR REPLACE INTO seasons_collection Values ({trakt}, {tvdb}, '{imdb}', {tmdb}, {season['number']}, {episode['number']}, '{episode['collected_at']}')"
                            c.log(f"[CM Debug @ 1867 in trakt.py] sql = {sql}")

                        # 'sql_create_shows_collection' :
                        #     'CREATE TABLE IF NOT EXISTS shows_collection (last_collected_at TEXT, last_updated_at TEXT, Title TEXT, Year INT, trakt INT, slug TEXT, tvdb INT, imdb TEXT, tmdb INT, tvrage TEXT, UNIQUE(trakt, tvdb, imdb, tmdb));',
                        # 'sql_create_seasons_collection' :
                        #     'CREATE TABLE IF NOT EXISTS seasons_collection (trakt INT, tvdb INT, imdb TEXT, tmdb INT, season INT, episode INT, collected_at TEXT);',





                    dbcur.execute(sql)
                    dbcon.commit()
                except Exception as e:
                    failure = traceback.format_exc()
                    c.log(f'[CM Debug @ 1870 in trakt.py]Traceback:: {failure}')
                    c.log(f'[CM Debug @ 1870 in trakt.py]Exception raised. Error = {e}')



        # c.log(f"[CM Debug @ 1869 in trakt.py] collection = {collection}")
        c.log(f"[CM Debug @ 1870 in trakt.py] collection = {table_name}")

    except Exception as e:
        failure = traceback.format_exc()
        c.log(f'[CM Debug @ 839 in trakt.py]Traceback:: {failure}')
        c.log(f'[CM Debug @ 839 in trakt.py]Exception raised. Error = {e}')
        pass

# TODO needs to be implemented
def sync_collection(collection):
    try:
        c.log(f"[CM Debug @ 833 in trakt.py] collection = {collection}")

    except Exception as e:
        failure = traceback.format_exc()
        c.log(f'[CM Debug @ 857 in trakt.py]Traceback:: {failure}')
        c.log(f'[CM Debug @ 858 in trakt.py]Exception raised. Error = {e}')
        pass



def get_trakt_progress(media_type: str, trakt_id: int = 0) -> list:
    """
    Retrieves progress entries from the trakt sync database for the specified media type and ID.

    Args:
        media_type (str): The type of media to retrieve, either 'movies' or 'shows'.
        trakt_id (int, optional): The ID of the media to retrieve. Defaults to 0.

    Returns:
        list: A list of rows from the database matching the specified media type and ID.
    """
    try:
        dbcon = get_connection(control.traktsyncFile, return_as_dict=True)
        dbcur = get_connection_cursor(dbcon)
        sql = f"SELECT * FROM progress WHERE media_type = '{media_type}'"
        c.log(f"[CM Debug @ 1431 in trakt.py] sql = {sql}")
        if trakt_id:
            sql += f" AND trakt_id = {trakt_id}"

        c.log(f"[CM Debug @ 1616 in trakt.py] sql is of type: {type(sql)} and = {sql}")

        dbcur.execute(sql)
        c.log(f"[CM Debug @ 1620 in trakt.py] sql is of type: {type(sql)} and = {sql}")
        rows = dbcur.fetchall()
        dbcon.commit()

        return rows

    except Exception as e:
        failure = traceback.format_exc()
        c.log(f'[CM Debug @ 1250 in trakt.py]Traceback:: {failure}')
        c.log(f'[CM Debug @ 1251 in trakt.py]Exception raised. Error = {e}')
        results = []








def get_episode_progress(imdb: str, season: int, episode: int):
    """
    Get the progress percentage for a specific episode from the progress table.

    Args:
        imdb: IMDB ID of the show (NOT the episode)
        season: Season number
        episode: Episode number

    Returns:
        float: Progress percentage (0-100), or None if not found
    """
    try:
        dbcon = get_connection(control.traktsyncFile, return_as_dict=True)
        dbcur = get_connection_cursor(dbcon)
        # Use showimdb column since imdb parameter is the show's IMDB ID
        sql = "SELECT resume_point FROM progress WHERE media_type = 'episode' AND showimdb = ? AND season = ? AND episode = ?"
        dbcur.execute(sql, (imdb, season, episode))
        row = dbcur.fetchone()
        dbcon.close()

        if row and row['resume_point'] is not None:
            progress = float(row['resume_point'])
            #c.log(f"[Trakt] get_episode_progress: {imdb} S{season}E{episode} = {progress}%")
            return progress
        #c.log(f"[Trakt] get_episode_progress: {imdb} S{season}E{episode} = NO DATA")
        return None
    except Exception as e:
        c.log(f"[Trakt] Error getting episode progress for {imdb} S{season}E{episode}: {e}\n{traceback.format_exc()}")
        return None






def update_trakt_sync_table(key, value):
    """
    Updates the value in the trakt sync table
    """
    dbcon = get_connection(control.traktsyncFile, return_as_dict=True)
    dbcur = get_connection_cursor(dbcon)
    sql = "INSERT OR REPLACE INTO service Values (?, ?)"
    dbcur.execute(sql, (key, value))
    _commit(dbcon)

def get_trakt_sync_value(key):
    """
    Returns the value from the trakt sync table for the given key
    """
    dbcon = get_connection(control.traktsyncFile, return_as_dict=True)
    dbcur = get_connection_cursor(dbcon)
    sql = "SELECT value FROM service WHERE setting = ?"
    result = dbcur.execute(sql, (key,))
    value = result.fetchone()
    return value[0] if value else None