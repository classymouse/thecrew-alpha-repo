# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file piratebay.py
* @package script.module.thecrew
*
* @copyright (c) 2025, The Crew
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*
'''

import re
import ast
import json
import traceback
from urllib.parse import urljoin, quote_plus

from ..modules import cache, cleantitle, client, control
from .torrent_base import TorrentBaseScraper
from ..modules.crewruntime import c


class source(TorrentBaseScraper):
    def __init__(self):
        super().__init__(
            name='piratebay',
            base_link='https://apibay.org',
            domains=['apibay.org','tpbproxypirate.com', 'pirateproxy.live', 'thepiratebay.org', 'thepiratebay.fun',
                    'thepiratebay.asia', 'tpb.party', 'thepiratebay3.org', 'thepiratebayz.org',
                    'thehiddenbay.com', 'piratebay.live', 'thepiratebay.zone']
        )
        self.search_link = '/q.php?q=%s&cat=0'
        self._cached_base = None

    @property
    def base_url(self):
        if self._cached_base is None:
            default_url = f"https://{self.domains[0]}"
            c.log(f'[TPB] Getting base_url, default={default_url}')
            self._cached_base = cache.get(self._get_base_url, 120, default_url)
            c.log(f'[TPB] base_url resolved to: {self._cached_base}')
        return self._cached_base

    def _scrape_torrents(self, data, hostDict):
        title = data.get('tvshowtitle', data.get('title'))
        year = str(data.get('year', ''))
        aliases = data.get('aliases', [])
        hdlr = self._build_hdlr(data)
        is_movie = not data.get('tvshowtitle')  # True if movie, False if episode

        query = self._build_query(data)
        query = re.sub(r'(\\\|/| -|:|;|\*|\?|"|<|>|\|)', ' ', query)

        url = self.search_link % quote_plus(query)
        url = urljoin(self.base_url, url)
        c.log(f'[TPB] Query="{query}" Title="{title}" Year="{year}" Handler="{hdlr}" IsMovie={is_movie}')
        c.log(f'[TPB] URL: {url}')

        html = client.request(url, timeout=10)
        c.log(f'[TPB] Response: len={len(html) if html else 0}')

        if not html:
            c.log(f'[TPB] Empty response from API')
            return self._sources_list

        try:
            entries = json.loads(html)
            c.log(f'[TPB] Parsed {len(entries)} entries from API')

            if not isinstance(entries, list):
                c.log(f'[TPB] Response is not a list: {type(entries)}')
                return self._sources_list

            processed = 0
            rejected_title = 0
            rejected_seeders = 0

            for entry in entries:
                if not isinstance(entry, dict):
                    continue

                try:
                    name = entry.get('name', '')
                    if not name:
                        continue

                    # Use sophisticated check_title from base scraper (checks aliases, year ranges, episode codes)
                    if not self.check_title(title, aliases, name, hdlr, year, is_movie):
                        rejected_title += 1
                        if processed < 3:  # Log first few rejections for debugging
                            c.log(f'[TPB] Reject (check_title): "{name}"')
                        continue

                    seeders = int(entry.get('seeders', 0))
                    if not self._check_seeders(seeders, self.min_seeders):
                        rejected_seeders += 1
                        continue

                    info_hash = entry.get('info_hash', '')
                    url = self._build_magnet(info_hash, name)

                    size_bytes = entry.get('size', 0)
                    dsize, isize = self._parse_size_bytes(size_bytes)

                    source_dict = self._build_torrent_source(name, url, seeders, dsize, info_hash)
                    source_dict['info'] = isize + ' | ' + source_dict['info'] if isize else source_dict['info']
                    self._sources_list.append(source_dict)
                    processed += 1

                except Exception as e:
                    c.log(f'[TPB] Error processing entry: {e}')
                    continue

            c.log(f'[TPB] Results: {len(self._sources_list)} added | {rejected_title} title rejected | {rejected_seeders} seeders rejected')

        except Exception as e:
            c.log(f'[TPB] Error parsing results: {e}')
            c.log(f'[TPB] Traceback: {traceback.format_exc()}')

        return self._sources_list

    def sources_packs(self, data, hostDict, search_series=False, total_seasons=0, bypass_filter=0):
        from ..modules import source_utils
        sources = []
        try:
            tvshowtitle = data.get('tvshowtitle')
            year = data.get('year')
            season = int(data.get('season', 0))
            imdb = data.get('imdb')
            aliases = data.get('aliases', [])

            if not tvshowtitle:
                return sources

            title_query = cleantitle.get_query(tvshowtitle)
            queries = []

            if search_series:
                queries.extend([
                    f'{title_query} Complete Series',
                    f'{title_query} All Seasons',
                    f'{title_query} Season 1-{total_seasons}' if total_seasons > 0 else None
                ])
            else:
                queries.extend([
                    f'{title_query} S{season:02d}',
                    f'{title_query} Season {season}',
                    f'{title_query} Season.{season}',
                ])

            queries = [q for q in queries if q]

            for query in queries:
                try:
                    url = self.search_link % quote_plus(query)
                    url = urljoin(self.base_url, url)
                    html = client.request(url)

                    if not html or not html.startswith('['):
                        continue

                    entries = ast.literal_eval(html)
                    if not isinstance(entries, list):
                        continue

                    for entry in entries:
                        if not isinstance(entry, dict):
                            continue

                        try:
                            name = entry.get('name', '')
                            if not name:
                                continue

                            if search_series:
                                valid, last_season = source_utils.filter_show_pack(
                                    tvshowtitle, aliases, imdb, year, season,
                                    source_utils.release_title_format(name), total_seasons
                                )
                                if not valid:
                                    continue
                                package_meta = {'package': 'show', 'last_season': last_season}
                            else:
                                valid, episode_start, episode_end = source_utils.filter_season_pack(
                                    tvshowtitle, aliases, year, season,
                                    source_utils.release_title_format(name)
                                )
                                if not valid:
                                    continue
                                package_meta = {
                                    'package': 'season',
                                    'episode_start': episode_start,
                                    'episode_end': episode_end
                                }

                            seeders = int(entry.get('seeders', 0))
                            if not self._check_seeders(seeders, self.min_seeders):
                                continue

                            info_hash = entry.get('info_hash', '')
                            url = self._build_magnet(info_hash, name)

                            size_bytes = entry.get('size', 0)
                            dsize, isize = self._parse_size_bytes(size_bytes)

                            source_dict = self._build_torrent_source(name, url, seeders, dsize, info_hash)
                            source_dict['info'] = isize + ' | ' + source_dict['info'] if isize else source_dict['info']
                            source_dict.update(package_meta)
                            sources.append(source_dict)

                        except Exception as e:
                            c.log(f'TPB Pack - Error processing entry: {e}')
                            continue

                except Exception as e:
                    c.log(f'TPB Pack - Error searching: {e}')
                    continue

            return sources

        except Exception as e:
            c.log(f'TPB Pack - Exception: {e}')
            return sources

    def _get_base_url(self, fallback):
        for domain in self.domains:
            try:
                url = f'https://{domain}'
                result = client.request(url, limit=1, timeout='10')
                result = re.findall('<input type="submit" title="(.+?)"', result, re.DOTALL)[0]
                if result and 'Pirate Search' in result:
                    return url
            except:
                continue
        return fallback
