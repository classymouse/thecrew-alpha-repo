# -*- coding: utf-8 -*-

'''
 ***********************************************************
 * The Crew Add-on - Modern Scraper Template
 *
 * @file modern_scraper_template.py
 * @package script.module.thecrew
 *
 * @copyright (c) 2026, The Crew
 * @license GNU General Public License, version 3 (GPL-3.0)
 *
 * Template for creating modern, pack-capable scrapers
 ***********************************************************
'''

import re
import json
from urllib.parse import urlencode, quote_plus, parse_qs, urljoin

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import source_utils
from resources.lib.modules import directstream
from resources.lib.modules.crewruntime import c


class source:
    """Modern scraper template with best practices."""

    # Set to True if scraper supports season/show packs
    pack_capable = True

    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['example.com', 'example.net']
        self.base_link = 'https://example.com'

        # Search endpoints
        self.search_link = '/search?q=%s'
        self.movie_link = '/movie/%s'
        self.tv_link = '/tv/%s'

        # Headers for requests
        self.headers = {
            'User-Agent': client.agent(),
            'Referer': self.base_link
        }

    def movie(self, imdb, title, localtitle, aliases, year):
        """
        Return URL data for a movie.

        Args:
            imdb: IMDb ID
            title: Movie title
            localtitle: Localized title
            aliases: List of alternative titles
            year: Release year

        Returns:
            URL-encoded string with movie data
        """
        try:
            url = {
                'imdb': imdb,
                'title': title,
                'year': year,
                'aliases': json.dumps(aliases) if aliases else '[]'
            }
            return urlencode(url)
        except Exception as e:
            c.log(f'[ModernScraper] Movie error: {e}')
            return None

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        """
        Return URL data for a TV show.

        Args:
            imdb: IMDb ID
            tvdb: TVDB ID
            tvshowtitle: Show title
            localtvshowtitle: Localized show title
            aliases: List of alternative titles
            year: First air year

        Returns:
            URL-encoded string with show data
        """
        try:
            url = {
                'imdb': imdb,
                'tvdb': tvdb,
                'tvshowtitle': tvshowtitle,
                'year': year,
                'aliases': json.dumps(aliases) if aliases else '[]'
            }
            return urlencode(url)
        except Exception as e:
            c.log(f'[ModernScraper] TVShow error: {e}')
            return None

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        """
        Add episode information to show URL.

        Args:
            url: Show URL from tvshow()
            imdb: IMDb ID
            tvdb: TVDB ID
            title: Episode title
            premiered: Air date
            season: Season number
            episode: Episode number

        Returns:
            URL-encoded string with episode data
        """
        try:
            if url is None:
                return None

            # Parse existing URL data
            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            # Add episode information
            data.update({
                'title': title,
                'premiered': premiered,
                'season': season,
                'episode': episode
            })

            return urlencode(data)
        except Exception as e:
            c.log(f'[ModernScraper] Episode error: {e}')
            return None

    def sources(self, url, hostDict, hostprDict=None):
        """
        Get streaming sources for a movie or episode.

        Args:
            url: URL-encoded data from movie() or episode()
            hostDict: Dictionary of supported hosters
            hostprDict: Dictionary of preferred hosters

        Returns:
            List of source dictionaries
        """
        sources = []

        try:
            if url is None:
                return sources

            # Parse URL data
            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            # Extract common data
            title = data.get('tvshowtitle') or data.get('title')
            year = data.get('year')
            imdb = data.get('imdb')

            # For episodes
            season = data.get('season')
            episode = data.get('episode')

            # Build search query
            if season and episode:
                # TV show episode
                query = f"{title} S{int(season):02d}E{int(episode):02d}"
            else:
                # Movie
                query = f"{title} {year}"

            # Search the site
            search_url = urljoin(self.base_link, self.search_link % quote_plus(query))

            c.log(f'[ModernScraper] Searching: {search_url}')

            # Make request with error handling
            try:
                r = client.request(search_url, headers=self.headers, timeout=10)

                if not r:
                    c.log('[ModernScraper] Empty response')
                    return sources

                # Check for common blocking patterns
                if any(x in r for x in ['Just a moment', 'Enable JavaScript', '403 Forbidden', '404 Not Found']):
                    c.log('[ModernScraper] Site blocked or content not found')
                    return sources

            except Exception as e:
                c.log(f'[ModernScraper] Request error: {e}')
                return sources

            # Parse response and extract sources
            # This is site-specific - example below
            sources = self._parse_sources(r, title, year, season, episode)

        except Exception as e:
            c.log(f'[ModernScraper] Sources error: {e}')

        return sources

    def _parse_sources(self, html, title, year, season=None, episode=None):
        """
        Parse HTML and extract streaming sources.
        Site-specific implementation.

        Args:
            html: HTML response
            title: Title for validation
            year: Year for validation
            season: Season number (for TV)
            episode: Episode number (for TV)

        Returns:
            List of source dictionaries
        """
        sources = []

        try:
            # Example: Parse links from HTML
            # This is site-specific and needs to be customized

            # Method 1: Find direct video links
            video_links = re.findall(r'<a[^>]*href="([^"]+)"[^>]*>.*?Play', html, re.I|re.S)

            for link in video_links:
                try:
                    # Get quality from link or page
                    quality, info = source_utils.get_release_quality(link, link)

                    # Build source dictionary
                    sources.append({
                        'provider': 'modern_scraper',
                        'source': 'direct',
                        'quality': quality,
                        'language': 'en',
                        'url': link,
                        'info': ' | '.join(info) if info else '',
                        'direct': False,
                        'debridonly': False
                    })

                except Exception as e:
                    c.log(f'[ModernScraper] Link parse error: {e}')
                    continue

            # Method 2: Find embedded players
            embeds = re.findall(r'<iframe[^>]*src="([^"]+)"', html, re.I)

            for embed in embeds:
                try:
                    # Check if it's a supported host
                    valid, host = source_utils.is_host_valid(embed, hostDict)

                    if valid:
                        quality = 'HD'  # Default quality

                        sources.append({
                            'provider': 'modern_scraper',
                            'source': host,
                            'quality': quality,
                            'language': 'en',
                            'url': embed,
                            'info': '',
                            'direct': False,
                            'debridonly': False
                        })

                except Exception as e:
                    c.log(f'[ModernScraper] Embed parse error: {e}')
                    continue

        except Exception as e:
            c.log(f'[ModernScraper] Parse error: {e}')

        return sources

    def sources_packs(self, data, hostDict, search_series=False, total_seasons=0, bypass_filter=0):
        """
        Get pack sources (season packs, show packs).
        Only implement if pack_capable = True.

        Args:
            data: Dictionary with show information
            hostDict: Dictionary of supported hosters
            search_series: True for complete series packs
            total_seasons: Total number of seasons
            bypass_filter: Skip filtering if True

        Returns:
            List of pack source dictionaries
        """
        sources = []

        if not self.pack_capable:
            return sources

        try:
            # Extract show information
            title = data.get('tvshowtitle')
            year = data.get('year')
            season = data.get('season')
            imdb = data.get('imdb')
            aliases = data.get('aliases', [])

            if not title:
                return sources

            # Build search query
            if search_series:
                # Search for complete series
                query = f"{title} Complete Series"
            else:
                # Search for season pack
                query = f"{title} Season {season}"

            search_url = urljoin(self.base_link, self.search_link % quote_plus(query))

            c.log(f'[ModernScraper] Pack search: {search_url}')

            # Make request
            r = client.request(search_url, headers=self.headers, timeout=10)

            if not r:
                return sources

            # Parse pack sources
            # This is site-specific
            pack_links = re.findall(r'<a[^>]*href="([^"]+)"[^>]*>.*?Season', r, re.I|re.S)

            for link in pack_links:
                try:
                    # Validate it's the right pack
                    if search_series:
                        # Validate complete series pack
                        valid, last_season = source_utils.filter_show_pack(
                            title, aliases, imdb, year, season, link, total_seasons
                        )
                        package = 'show'
                    else:
                        # Validate season pack
                        valid = source_utils.filter_season_pack(
                            title, aliases, year, season, link
                        )
                        package = 'season'
                        last_season = 0

                    if not valid:
                        continue

                    # Get quality
                    quality, info = source_utils.get_release_quality(link, link)

                    # Build pack source
                    source_dict = {
                        'provider': 'modern_scraper',
                        'source': 'direct',
                        'quality': quality,
                        'language': 'en',
                        'url': link,
                        'info': ' | '.join(info) if info else '',
                        'direct': False,
                        'debridonly': False,
                        'package': package
                    }

                    # Add pack metadata
                    if search_series:
                        source_dict['last_season'] = last_season

                    sources.append(source_dict)

                except Exception as e:
                    c.log(f'[ModernScraper] Pack parse error: {e}')
                    continue

        except Exception as e:
            c.log(f'[ModernScraper] Pack sources error: {e}')

        return sources

    def resolve(self, url):
        """
        Resolve a source URL to a playable video URL.
        Only needed if the source requires resolution.

        Args:
            url: Source URL to resolve

        Returns:
            Resolved video URL or original URL
        """
        try:
            # If direct link, return as-is
            if url.endswith(('.mp4', '.mkv', '.avi', '.m3u8')):
                return url

            # Otherwise, load the page and extract video URL
            r = client.request(url, headers=self.headers)

            if not r:
                return url

            # Example: Extract video URL from page
            video_url = re.findall(r'sources:\s*\[.*?src:\s*["\']([^"\']+)', r, re.S)

            if video_url:
                return video_url[0]

            return url

        except Exception as e:
            c.log(f'[ModernScraper] Resolve error: {e}')
            return url


# Usage Notes:
# 1. Copy this template for new scrapers
# 2. Update domains and base_link
# 3. Customize _parse_sources() for site-specific HTML
# 4. Implement sources_packs() if site has season viewing
# 5. Add to sources/__init__.py
# 6. Test thoroughly before deployment
