# -*- coding: utf-8 -*-
# Wrapper file - imports from refactored scraper
from ....scrapers.300mbfilms import source
