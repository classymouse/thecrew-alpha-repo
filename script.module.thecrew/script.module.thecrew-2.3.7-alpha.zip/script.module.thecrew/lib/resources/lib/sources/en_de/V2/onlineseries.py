# -*- coding: utf-8 -*-
# Wrapper file - imports from refactored scraper
from ....scrapers.onlineseries import source
