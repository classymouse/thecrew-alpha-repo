# -*- coding: utf-8 -*-
# Wrapper file - imports from refactored scraper
from ....scrapers.scenerls_v2 import source
