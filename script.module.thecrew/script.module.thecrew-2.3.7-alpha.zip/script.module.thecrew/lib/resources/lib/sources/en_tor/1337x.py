# -*- coding: utf-8 -*-
# Wrapper file - imports from refactored scraper

from ...modules.crewruntime import c
c.log('========== WRAPPER: sources/en_tor/1337x.py - About to import from scrapers ==========')

from ...scrapers.x1337 import source

c.log('========== WRAPPER: sources/en_tor/1337x.py - Import complete, source class: %s ==========' % source)
c.log(f'========== WRAPPER: source has sources attr? {hasattr(source, "sources")}')
c.log(f'========== WRAPPER: type of source.sources = {type(getattr(source, "sources", None))}')
