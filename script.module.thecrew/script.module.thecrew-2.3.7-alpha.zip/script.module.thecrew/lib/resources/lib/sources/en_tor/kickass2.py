# -*- coding: utf-8 -*-
# Wrapper file - imports from refactored scraper
from ...scrapers.kickass2 import source
