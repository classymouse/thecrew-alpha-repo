# -*- coding: utf-8 -*-
# Wrapper file - imports from refactored scraper
from ...scrapers.piratebay import source
