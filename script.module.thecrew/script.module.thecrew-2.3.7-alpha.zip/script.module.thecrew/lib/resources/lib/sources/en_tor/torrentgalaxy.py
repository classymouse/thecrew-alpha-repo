# -*- coding: utf-8 -*-
# Wrapper file - imports from refactored scraper
from ...scrapers.torrentgalaxy import source
